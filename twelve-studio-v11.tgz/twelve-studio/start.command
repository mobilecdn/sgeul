#!/bin/bash
# SGEUL · Story AI — double-click to run on macOS (needs Node 20+; no npm install required).
cd "$(dirname "$0")"
export NODE_ENV=production
echo "SGEUL starting on http://localhost:8787 (API + web app)"
node apps/api/dist/server.js
