# Contract addendum: ad creatives, local media, stitched previews

Goal: an Operations Lab user picks an ad creative (e.g. "Kinder Bueno 30s"), assigns it to the planned mid-roll
breaks of a title, exports VMAP with inline VAST for that creative, and renders a stitched preview MP4 with the ads
burned in at the break points, snapped to keyframes inside each break's window. Works fully in mock mode.

## Types (add to packages/core/src/types.ts)

```ts
export interface AdCreative {
  id: string;
  name: string;
  advertiser?: string;
  durationSec: number;
  /** Absolute file path on the API host when the creative was added from disk. */
  localPath?: string;
  /** Public URL when added from the web. */
  sourceUrl?: string;
  /** Always set: where a player can fetch it (`/api/ads/:id/media` for local files, else sourceUrl). */
  mediaUrl: string;
  width?: number;
  height?: number;
  createdAt: string;
}

// AdBreak: add
//   creativeId?: string;          // assigned creative
//   snappedAt?: number;           // keyframe-aligned insertion point chosen by the stitcher (inside window)
// CatalogItem: add
//   localPath?: string;           // absolute path on the API host when ingested from disk
// CatalogItem.playback: add
//   fileUrl?: string;             // `/api/catalog/:id/media` when localPath is set (direct progressive playback)

export interface StitchJob {
  id: string;
  itemId: string;
  creativeId: string;
  status: JobStatus;
  /** Break ids included, in time order, with the exact insertion point used. */
  insertions: Array<{ breakId: string; requestedAt: number; snappedAt: number }>;
  outputUrl?: string;      // `/api/renders/:file`
  outputPath?: string;
  durationSec?: number;
  log?: string;            // tail of ffmpeg stderr on failure
  error?: string;
  createdAt: string;
  finishedAt?: string;
}
```

## API additions (apps/api)

```
GET    /api/ads                              → AdCreative[]
POST   /api/ads                              body {name, advertiser?, sourceUrl? | localPath?} → AdCreative (201)
                                             localPath is ffprobed (duration/width/height) when ffmpeg is available
DELETE /api/ads/:id
GET    /api/ads/:id/media                    streams the file with HTTP Range support (video/mp4)
GET    /api/catalog/:id/media                streams item.localPath with Range support
POST   /api/catalog                          accepts sourceUrl that is an absolute local path (or file:// URL):
                                             sets item.localPath, playback.fileUrl, ffprobes duration/fps/w/h;
                                             posterUrl may also be a local path → served at GET /api/catalog/:id/poster
POST   /api/ads/:id/fingerprint              one Pegasus call (uploads the creative as an asset first when it has none)
                                             → AdCreative with .fingerprint: AdFingerprint {brand, product, tagline?, callToAction?,
                                               synopsis, mood, keywords, tone{humorous,emotional,energetic,premium,family}, iab[],
                                               sensitivities[{category,severity,description,confidence}], familySafe, pacing,
                                               moments[{at,label}], language, model, generatedAt}
GET    /api/catalog/:id/adbreaks/fit         → {itemId, creatives[{id,name,fingerprinted}], breaks[{breakId, at, rank, assigned?,
                                               fits: CreativeFit[] best first}]}; CreativeFit = {creativeId, breakId, score,
                                               mood, keywords, iab, safety, because[]} — deterministic (packages/core/src/creativefit.ts):
                                               0.35·mood + 0.30·keywords + 0.20·iab + 0.15·safety; unfingerprinted creatives score 0
POST   /api/catalog/:id/adbreaks/autoassign  body {minScore?: 0..1, breakIds?} → {plan: AdBreakPlan, assignments[{breakId, creativeId?, fit?}]}
POST   /api/catalog/:id/adbreaks/assign      body {creativeId | null, breakIds?: string[]}  (default: all breaks) → AdBreakPlan
POST   /api/catalog/:id/stitch               body {creativeId?, breakIds?, includeUnapproved?: boolean}
                                             default: all breaks with review.status==='approved'; if none approved
                                             and includeUnapproved → all planned breaks. creativeId defaults to
                                             the breaks' assigned creative. → StitchJob (202), runs in background
GET    /api/stitch/:id                       → StitchJob
GET    /api/stitch?itemId=                   → StitchJob[]
GET    /api/renders/:file                    streams data/renders/<file> with Range support
GET    /api/catalog/:id/export/vmap          when a break has creativeId, emit
                                             <vmap:AdSource><vmap:VASTAdData><VAST version="3.0"><Ad><InLine>
                                             with <MediaFile> = absolute URL of creative.mediaUrl (use req host),
                                             <Duration> HH:MM:SS, <AdTitle>; otherwise keep the AdTagURI form.
SSE /api/events                              add {type:'stitch', job}
```

Stitcher (apps/api/src/stitch.ts), requires `ffmpeg`/`ffprobe` on PATH (report `stitch_unavailable` otherwise):
1. Probe movie (codec, w, h, fps, audio codec/sample rate/channels). Require item.localPath (else error `needs_local_file`).
2. For each selected break, list keyframes in [window.start, window.end] via
   `ffprobe -select_streams v -show_entries packet=pts_time,flags -of csv` restricted with `-read_intervals`,
   pick the keyframe nearest `at`; if none inside the window, take the nearest keyframe overall. That is `snappedAt`.
3. Transcode the creative once to match the movie: h264 (same profile/level as movie where possible), same w×h
   (scale + pad to preserve aspect), same fps, aac same sample rate/channels, `-video_track_timescale` matching.
   Cache under data/renders/cache/<creativeId>-<w>x<h>-<fps>.mp4.
4. Cut the movie into N+1 segments with `-ss/-to -c copy` at the snapped keyframes (stream copy, no re-encode),
   write a concat list alternating segment/ad/segment…, and `ffmpeg -f concat -safe 0 -i list.txt -c copy` to
   data/renders/<itemId>-<ts>.mp4. Total wall time should be dominated by the single ad transcode + disk copy.
5. Update the StitchJob as it progresses (emit SSE), store durationSec of the result.
Keep a `dryRun` option that computes insertions without running ffmpeg (used by tests when ffmpeg is missing).

Mock mode: everything above works the same (it is local ffmpeg work, not a model call).

## Web additions (apps/web)

- `playableSrc(item)`: `playback.hlsUrl` → `playback.fileUrl` → direct sourceUrl. Poster: item.posterUrl may be `/api/...` relative.
- Operations Lab top bar: "Ad creative" select (from GET /api/ads, plus "Manage…" opening an Ad library modal:
  list creatives with duration/dimensions, add by URL or local path, delete). "Assign to breaks" applies to all
  planned breaks (POST assign). Inspector (Marker tab, when a break is selected): "Creative" row showing the
  assigned creative name + duration with a small `<video>` thumb, and a per-break override select.
- "Render preview" button (primary, next to Export): POST stitch (approved breaks, or all with a confirm when none
  approved) → progress pill in the top bar fed by SSE → when ready, the centre player switches to the render
  (`outputUrl`) with a "Stitched preview · N ad breaks · +MM:SS" pill and a "Back to source" toggle; the timeline
  shows the ad pods as violet blocks at the shifted positions (snappedAt + k×adDuration); "Download MP4" link.
  Failures show the ffmpeg log tail in a modal.
- Export menu: VMAP now says "(inline VAST: <creative>)" when creatives are assigned.
- Static demo mode: ads list contains the seeded creative(s) from the bundle (`window.__TWELVE_DEMO__.ads`), assign
  works in memory, stitch returns a toast "Rendering needs the local API (ffmpeg)". Never crash.

## MCP additions (apps/mcp)

Tools: `ads_list`, `ads_add` (name, sourceUrl|localPath), `ads_fingerprint` (creativeId), `adbreaks_fit` (itemId),
`adbreaks_autoassign` (itemId, minScore?, breakIds?), `adbreaks_assign_creative` (itemId, creativeId, breakIds?),
`stitch_preview` (itemId, creativeId?, includeUnapproved?, waitSec?) → job with insertions + outputUrl.
