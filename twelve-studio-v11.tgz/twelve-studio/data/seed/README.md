# Demo seed

`catalog.json` is an `ItemBundle[]` (see `packages/core/src/types.ts`) and `lists.json` a
`SmartList[]`. The API imports both on first boot when `data/store.json` is empty, in mock
**and** live mode, so the product always starts with a populated catalog.

## Titles

| id | title | year | duration | source (CC-BY, Blender Foundation) |
|----|-------|------|----------|-------------------------------------|
| `sintel` | Sintel | 2010 | 14:48 | https://www.youtube.com/watch?v=eRsGyueVLvQ |
| `tears-of-steel` | Tears of Steel | 2012 | 12:14 | https://www.youtube.com/watch?v=R6MlUcmOul8 |
| `cosmos-laundromat` | Cosmos Laundromat | 2015 | 12:10 | https://www.youtube.com/watch?v=Y-rmzh0PI3c |

## How it is generated

`build-seed.ts` is the generator. Every section (fingerprint with 8 synopsis translations,
emotion arc, markers, safety, ad-break candidates, thumbnails, clips) is hand-authored in
the exact payload shapes Pegasus returns through `prompts.ts`, then passed through the same
post-processing the live pipeline uses (`planAdBreaks`, `normaliseThumbnails`,
`normaliseClips`, `summariseSafety`, frame maths) so the output is shape-identical to real
TwelveLabs output.

```
npx tsx data/seed/build-seed.ts
```

Notes:

- `fingerprint.embedding` is deliberately absent and `jobs.embedding` unset: the `embedding`
  job fills it (Marengo 3.5 in live mode; a hashed bag-of-labels vector in mock mode). The
  API runs that job for seed items on boot in mock mode.
- `item.upstream` carries `mock-asset-*` / `mock-video-*` ids derived from the source URL.
  The live pipeline treats those as "not ingested" and re-uploads the asset on first use.
- `adBreaks.candidates` (the raw Pegasus candidates) is stored next to the planned `breaks`
  so `POST /api/catalog/:id/adbreaks/plan` can re-plan under a new policy with no model call.
- Ad-break `model` is `pegasus1.5+planner`; everything else is `pegasus1.5`.

## Replacing with real output

Set `TWELVELABS_API_KEY`, start the API, `POST /api/catalog` the three URLs (or re-run jobs on
the seeded ids), then export the bundles from the store:

```
node -e "const s=require('./data/store.json'); console.log(JSON.stringify(Object.values(s.bundles),null,2))" > data/seed/catalog.json
```

Keep `id`, `title`, `year`, `sourceUrl` stable so `lists.json` and the docs keep pointing at the
same items.
