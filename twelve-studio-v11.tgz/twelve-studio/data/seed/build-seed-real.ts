/**
 * Real-output seed builder — writes data/seed/catalog.json and lists.json from
 * the TwelveLabs output captured in data/real/<item>/*.json.
 *
 *   npx tsx data/seed/build-seed-real.ts
 *
 * Provenance: every value under data/real was produced by TwelveLabs models
 * (Pegasus via the Jockey agent, 12 Sep 2026) answering the exact prompts in
 * packages/core/src/prompts.ts with a JSON schema, against the three Blender
 * open movies indexed in a TwelveLabs knowledge store. Nothing is hand-authored.
 * Post-processing (frame maths, pod planner, composite thumbnail score) is the
 * same code path the live pipeline uses.
 */

import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  type AdCreative,
  type AdFingerprint,
  makeId,
  mockAssetId,
  mockVideoId,
  normaliseClips,
  normaliseThumbnails,
  planAdBreaks,
  summariseSafety,
  type AdBreakCandidate,
  type CatalogItem,
  type ClipsPayload,
  type EmotionArc,
  type Fingerprint,
  type ItemBundle,
  type MarkerSet,
  type SafetyReport,
  type SmartList,
  type ThumbnailsPayload,
} from '../../packages/core/src/index.js';

const here = dirname(fileURLToPath(import.meta.url));
const realDir = join(here, '..', 'real');
const GENERATED_AT = '2026-09-12T08:10:00.000Z';
const MODEL = 'pegasus1.5';

interface Source {
  id: string;
  title: string;
  type?: CatalogItem['type'];
  year: number;
  sourceUrl: string;
  durationSec: number;
  fps: number;
  width: number;
  height: number;
  posterUrl: string;
  /** Poster file on the API host (served at /api/catalog/:id/poster). */
  posterPath?: string;
  /** Movie file on the API host (served at /api/catalog/:id/media; needed for stitched previews). */
  localPath?: string;
  playback: { hlsUrl?: string; fileUrl?: string; thumbnailUrls: string[] };
  upstream: { assetId: string; indexedAssetId?: string; indexId?: string };
  externalIds: Record<string, string>;
  metadata: Record<string, unknown>;
  /** Sections that TwelveLabs has not produced yet (left queued for the live pipeline). */
  pending?: Array<'fingerprint' | 'thumbnails' | 'clips'>;
  /** Break count and spacing policy override for the planner. */
  policy?: { targetBreaks: number; minSpacingSec: number; avoidFirstSec: number; avoidLastSec: number };
}

const CDN = 'https://deuqpmn4rs7j5.cloudfront.net/668dbc64960035b941a1258c/assets';
const KS = 'ks_01a09482-4d9e-7ca1-b3f3-58ba8296e8e1';

const sources: Source[] = [
  {
    id: 'sintel',
    title: 'Sintel',
    year: 2010,
    sourceUrl: 'https://www.youtube.com/watch?v=eRsGyueVLvQ',
    durationSec: 888.061,
    fps: 24,
    width: 1920,
    height: 818,
    posterUrl: `${CDN}/6aa4ff2f360070e111bec8bd/thumbnails/5.jpeg`,
    playback: { hlsUrl: `${CDN}/6aa4ff2f360070e111bec8bd/hlses/playlist.m3u8`, thumbnailUrls: [`${CDN}/6aa4ff2f360070e111bec8bd/thumbnails/5.jpeg`] },
    upstream: { assetId: '6aa4ff2f360070e111bec8bd', indexedAssetId: 'ksi_01a09484-e2e4-7d00-ab4c-3c0c9d90c481', indexId: KS },
    externalIds: { youtube: 'eRsGyueVLvQ', wikidata: 'Q1245263' },
    metadata: { producer: 'Blender Foundation', license: 'CC-BY 3.0', director: 'Colin Levy', project: 'Durian' },
  },
  {
    id: 'tears-of-steel',
    title: 'Tears of Steel',
    year: 2012,
    sourceUrl: 'https://www.youtube.com/watch?v=R6MlUcmOul8',
    durationSec: 734.181,
    fps: 24,
    width: 1920,
    height: 800,
    posterUrl: `${CDN}/6aa4fef89d661f14217cf887/thumbnails/5.jpeg`,
    playback: { hlsUrl: `${CDN}/6aa4fef89d661f14217cf887/hlses/playlist.m3u8`, thumbnailUrls: [`${CDN}/6aa4fef89d661f14217cf887/thumbnails/5.jpeg`] },
    upstream: { assetId: '6aa4fef89d661f14217cf887', indexedAssetId: 'ksi_01a09484-d738-72e1-8088-136d710f88f5', indexId: KS },
    externalIds: { youtube: 'R6MlUcmOul8', wikidata: 'Q2404052' },
    metadata: { producer: 'Blender Foundation', license: 'CC-BY 3.0', director: 'Ian Hubert', project: 'Mango' },
  },
  {
    id: 'cosmos-laundromat',
    title: 'Cosmos Laundromat',
    year: 2015,
    sourceUrl: 'https://www.youtube.com/watch?v=Y-rmzh0PI3c',
    durationSec: 730.581,
    fps: 24,
    width: 1920,
    height: 804,
    posterUrl: `${CDN}/6aa4ff690e5ec23e8c6237e9/thumbnails/5.jpeg`,
    playback: { hlsUrl: `${CDN}/6aa4ff690e5ec23e8c6237e9/hlses/playlist.m3u8`, thumbnailUrls: [`${CDN}/6aa4ff690e5ec23e8c6237e9/thumbnails/5.jpeg`] },
    upstream: { assetId: '6aa4ff690e5ec23e8c6237e9', indexedAssetId: 'ksi_01a09485-c635-7452-85ff-23135ddfdebf', indexId: KS },
    externalIds: { youtube: 'Y-rmzh0PI3c', wikidata: 'Q20648213' },
    metadata: { producer: 'Blender Foundation', license: 'CC-BY 3.0', director: 'Mathieu Auvray', project: 'Gooseberry' },
  },
  {
    id: 'david-and-goliath',
    title: 'David and Goliath',
    type: 'movie',
    year: 1960,
    sourceUrl: 'file:///Users/euan.mcleod/Downloads/DavidandGoliath1960.mp4',
    localPath: '/Users/euan.mcleod/Downloads/DavidandGoliath1960.mp4',
    posterPath: '/Users/euan.mcleod/Downloads/David and Golliath.png',
    durationSec: 5500.709,
    fps: 24,
    width: 640,
    height: 480,
    posterUrl: '/api/catalog/david-and-goliath/poster',
    playback: { hlsUrl: `${CDN}/6aa58b4af8175fa7890ab608/hlses/playlist.m3u8`, fileUrl: '/api/catalog/david-and-goliath/media', thumbnailUrls: [`${CDN}/6aa58b4af8175fa7890ab608/thumbnails/5.jpeg`] },
    // Asset uploaded through the TwelveLabs playground; fingerprint/thumbnails/clips came from POST /v1.3/analyze/tasks (Pegasus 1.5) on 12 Sep 2026, ops/timeline via Jockey. Not yet in a Marengo index: the live pipeline indexes it without re-upload.
    upstream: { assetId: '6aa58b4af8175fa7890ab608' },
    externalIds: { wikidata: 'Q3703326', jockeyItem: 'ksi_01a096ae-8d7e-7411-8adf-c64b96c2d645' },
    metadata: { producer: 'Embassy Pictures', director: 'Ferdinando Baldi, Richard Pottier', cast: ['Orson Welles', 'Ivica Pajer', 'Eleonora Rossi Drago'], note: 'Public-domain 1960 biblical epic; ad-break demo title' },
    policy: { targetBreaks: 5, minSpacingSec: 480, avoidFirstSec: 180, avoidLastSec: 240 },
  },
  {
    id: 'grok4',
    title: 'Grok 4',
    type: 'promo',
    year: 2026,
    sourceUrl: 'file:///Users/euan.mcleod/Downloads/grok4.mp4',
    localPath: '/Users/euan.mcleod/Downloads/grok4.mp4',
    durationSec: 65.8,
    fps: 30,
    width: 1280,
    height: 720,
    posterUrl: `${CDN}/6aa58b4a00835252079bd128/thumbnails/5.jpeg`,
    playback: { hlsUrl: `${CDN}/6aa58b4a00835252079bd128/hlses/playlist.m3u8`, fileUrl: '/api/catalog/grok4/media', thumbnailUrls: [`${CDN}/6aa58b4a00835252079bd128/thumbnails/5.jpeg`] },
    // Uploaded through the TwelveLabs playground; all seven sections came from POST /v1.3/analyze/tasks (Pegasus 1.5) on 12 Sep 2026 (see data/real/grok4/provenance.json). Also in the Jockey knowledge store.
    upstream: { assetId: '6aa58b4a00835252079bd128' },
    externalIds: { jockeyItem: 'ksi_01a096a9-04d8-7e43-9f40-5812151c600c' },
    metadata: { producer: 'xAI', note: 'Launch promo; short-form example (one pre/mid-roll at most)' },
    policy: { targetBreaks: 1, minSpacingSec: 20, avoidFirstSec: 10, avoidLastSec: 10 },
  },
];

async function json<T>(p: string): Promise<T> {
  return JSON.parse(await readFile(p, 'utf8')) as T;
}

const clamp01 = (n: number) => Math.min(1, Math.max(0, Number(n) || 0));

async function assemble(src: Source): Promise<ItemBundle> {
  const dir = join(realDir, src.id);
  const pending = new Set(src.pending ?? []);
  const fp = pending.has('fingerprint') ? undefined : await json<Omit<Fingerprint, 'model' | 'generatedAt'>>(join(dir, 'fingerprint.json'));
  const tl = await json<{ emotions: Pick<EmotionArc, 'samples' | 'acts' | 'climax'>; markers: MarkerSet['markers'] | { markers: MarkerSet['markers'] } }>(join(dir, 'timeline.json'));
  const ops = await json<{ safety: SafetyReport['segments']; candidates: AdBreakCandidate[] }>(join(dir, 'ops.json'));
  const cr = pending.has('thumbnails') && pending.has('clips') ? undefined : await json<{ thumbnails: ThumbnailsPayload['thumbnails']; clips: ClipsPayload['clips'] }>(join(dir, 'creative.json'));

  const { durationSec, fps } = src;
  const item: CatalogItem & { posterPath?: string } = {
    id: src.id,
    title: src.title,
    type: src.type ?? 'short',
    year: src.year,
    sourceUrl: src.sourceUrl,
    posterUrl: src.posterUrl,
    externalIds: src.externalIds,
    metadata: src.metadata,
    durationSec,
    fps,
    width: src.width,
    height: src.height,
    playback: src.playback,
    localPath: src.localPath,
    posterPath: src.posterPath,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
    status: pending.size ? 'enriching' : 'ready',
    upstream: src.upstream,
    jobs: {
      // Asset exists upstream; live mode re-indexes it into Marengo at boot when no indexedAssetId is known.
      ingest: 'ready',
      fingerprint: pending.has('fingerprint') ? 'queued' : 'ready',
      emotions: 'ready',
      markers: 'ready',
      safety: 'ready',
      adbreaks: 'ready',
      thumbnails: pending.has('thumbnails') ? 'queued' : 'ready',
      clips: pending.has('clips') ? 'queued' : 'ready',
    },
  };

  let fingerprint: Fingerprint | undefined;
  if (fp) {
    // Drop an accidental 'en' translation key (English is the source language).
    const translations = { ...(fp.synopsis.translations ?? {}) };
    delete (translations as Record<string, unknown>).en;
    fingerprint = { ...fp, synopsis: { ...fp.synopsis, translations }, model: MODEL, generatedAt: GENERATED_AT };
    item.fingerprint = fingerprint;
  }

  const samples = tl.emotions.samples
    .map((s) => ({ ...s, end: Math.min(s.end, durationSec), confidence: clamp01(s.confidence) }))
    .sort((a, b) => a.start - b.start);
  const emotions: EmotionArc = { itemId: item.id, samples, acts: tl.emotions.acts, climax: tl.emotions.climax, model: MODEL, generatedAt: GENERATED_AT };

  const rawMarkers = Array.isArray(tl.markers) ? tl.markers : tl.markers.markers;
  const markers: MarkerSet = {
    itemId: item.id,
    fps,
    markers: rawMarkers
      .map((m) => ({
        id: makeId('mrk', `${item.id}:${m.kind}:${m.start}`),
        kind: m.kind,
        start: m.start,
        end: Math.min(m.end, durationSec),
        startFrame: Math.round(m.start * fps),
        endFrame: Math.round(Math.min(m.end, durationSec) * fps),
        label: m.label,
        confidence: clamp01(m.confidence),
      }))
      .sort((a, b) => a.start - b.start),
    model: MODEL,
    generatedAt: GENERATED_AT,
  };

  const segments = ops.safety
    .map((s) => ({ ...s, id: makeId('saf', `${item.id}:${s.category}:${s.start}`), end: Math.min(s.end, durationSec), confidence: clamp01(s.confidence) }))
    .sort((a, b) => a.start - b.start);
  const safety: SafetyReport = { itemId: item.id, segments, summary: summariseSafety(segments), model: MODEL, generatedAt: GENERATED_AT };

  const candidates: AdBreakCandidate[] = ops.candidates.map((c) => ({
    ...c,
    iab: c.iab.map((i) => ({ ...i, tier: (Math.min(3, Math.max(1, i.tier)) as 1 | 2 | 3), confidence: clamp01(i.confidence) })),
  }));
  const plan = planAdBreaks(candidates, {
    durationSec,
    policy: src.policy,
    emotions,
    safety,
    sceneChanges: [...markers.markers.filter((m) => m.kind === 'chapter').flatMap((m) => [m.start, m.end]), ...emotions.samples.map((s) => s.start)],
    fps,
    itemId: item.id,
    model: `${MODEL}+planner`,
  });
  plan.generatedAt = GENERATED_AT;
  const adBreaks = { ...plan, candidates };

  const thumbnails = cr
    ? normaliseThumbnails(
        cr.thumbnails.map((t) => ({ ...t, factors: { ...t.factors, safeArea: clamp01(t.factors.safeArea ?? 0.95) } })),
        item,
      )
    : undefined;
  const clips = cr ? normaliseClips(cr.clips, item) : undefined;
  return { item, fingerprint, emotions, markers, adBreaks, safety, thumbnails, clips, jobs: [] };
}

const catalog: ItemBundle[] = [];
for (const src of sources) catalog.push(await assemble(src));

const lists: SmartList[] = [
  {
    id: 'lst_melancholic-fantasy',
    name: 'Melancholic fantasy',
    description: 'Fantasy titles carrying a strong melancholic mood, for a rainy-day rail.',
    source: 'rules',
    rules: [
      { facet: 'moods', label: 'melancholic', min: 0.6, max: 1 },
      { facet: 'genres', label: 'fantasy', min: 0.5, max: 1 },
    ],
    itemIds: ['sintel', 'cosmos-laundromat'],
    coverage: 0.667,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
  },
  {
    id: 'lst_robots-and-machines',
    name: 'Robots & machines',
    description: 'Natural-language query: "robots attacking a city".',
    source: 'query',
    query: 'robots attacking a city',
    itemIds: ['tears-of-steel'],
    coverage: 0.333,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
  },
  {
    id: 'lst_family-safe-shorts',
    name: 'No gore, no weapons',
    description: 'Titles whose safety report has no high-severity gore or weapons segments.',
    source: 'rules',
    rules: [{ facet: 'moodTags', label: 'lonely', min: 0.5, max: 1 }],
    itemIds: ['cosmos-laundromat'],
    coverage: 0.333,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
  },
  {
    id: 'lst_ai-loss-and-letting-go',
    name: 'Loss and letting go',
    description: 'AI-curated: titles sharing themes of loss, memory and separation.',
    source: 'ai',
    itemIds: ['sintel', 'tears-of-steel', 'cosmos-laundromat'],
    coverage: 1,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
  },
];

const ads: AdCreative[] = [
  {
    id: 'ad_kinder-bueno-30',
    name: 'Kinder Bueno 30s',
    advertiser: 'Ferrero',
    durationSec: 30.163,
    localPath: '/Users/euan.mcleod/Downloads/Kinder Bueno - 30 second - ad.mp4',
    mediaUrl: '/api/ads/ad_kinder-bueno-30/media',
    width: 1920,
    height: 1080,
    // The same file lives in the TwelveLabs account ("Kinder Bueno - 30 second - ad.mp4", multipart upload).
    upstream: { assetId: '6aa58b4a19212bdafaeadefa' },
    createdAt: GENERATED_AT,
  },
  {
    id: 'ad_kinder-bueno-10',
    name: 'Kinder Bueno 10s',
    advertiser: 'Ferrero',
    durationSec: 10.077,
    localPath: '/Users/euan.mcleod/Downloads/Kinder Bueno - 10second - ad.mp4',
    mediaUrl: '/api/ads/ad_kinder-bueno-10/media',
    width: 1920,
    height: 1080,
    // TwelveLabs asset "bueno10.mp4".
    upstream: { assetId: '6aa58b4a19212bdafaeadefc' },
    createdAt: GENERATED_AT,
  },
];
// Creative intelligence: one POST /v1.3/analyze (Pegasus 1.5) per spot, captured 12 Sep 2026 (data/real/ads/provenance.json).
for (const ad of ads) {
  const fp = await json<Omit<AdFingerprint, 'model' | 'generatedAt'>>(join(realDir, 'ads', `${ad.id}.json`));
  ad.fingerprint = { ...fp, model: MODEL, generatedAt: GENERATED_AT };
}
// The demo assigns the 30s spot to every planned David and Goliath break.
for (const b of catalog) if (b.item.id === 'david-and-goliath') for (const brk of b.adBreaks!.breaks) brk.creativeId = 'ad_kinder-bueno-30';

await writeFile(join(here, 'ads.json'), JSON.stringify(ads, null, 2) + '\n');
await writeFile(join(here, 'catalog.json'), JSON.stringify(catalog, null, 2) + '\n');
await writeFile(join(here, 'lists.json'), JSON.stringify(lists, null, 2) + '\n');
for (const b of catalog) {
  console.log(
    `${b.item.title.padEnd(18)} samples=${b.emotions!.samples.length} markers=${b.markers!.markers.length} safety=${b.safety!.segments.length} breaks=${b.adBreaks!.breaks.length}/${
      (b.adBreaks as { candidates: unknown[] }).candidates.length
    } thumbs=${b.thumbnails?.length ?? '-'} clips=${b.clips?.length ?? '-'} langs=${Object.keys(b.fingerprint?.synopsis.translations ?? {}).length}`,
  );
}
