/**
 * Seed generator — writes data/seed/catalog.json and data/seed/lists.json.
 *
 *   npx tsx data/seed/build-seed.ts
 *
 * The three demo titles are Blender Foundation open movies (CC-BY). Every
 * enrichment section is hand-authored here in the exact shapes Pegasus/Marengo
 * produce through the pipeline, then normalised with the same post-processing
 * the live pipeline uses (planner, frame maths, composite thumbnail score) so
 * the demo store is indistinguishable in shape from real output. Replace this
 * file's content with real TwelveLabs output by running the pipeline in live
 * mode and exporting the bundles (see README.md in this folder).
 */

import { writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  mockAssetId,
  mockVideoId,
  normaliseClips,
  normaliseThumbnails,
  planAdBreaks,
  summariseSafety,
  makeId,
  type AdBreakCandidate,
  type CatalogItem,
  type ClipsPayload,
  type EmotionArc,
  type EmotionSample,
  type Fingerprint,
  type ItemBundle,
  type Marker,
  type MarkerSet,
  type SafetyReport,
  type SmartList,
  type ThumbnailsPayload,
  type ScoredLabels,
} from '../../packages/core/src/index.js';

const GENERATED_AT = '2026-09-10T09:00:00.000Z';
const MODEL = 'pegasus1.5';

/* ------------------------------------------------------------------ */
/* Authoring helpers                                                   */
/* ------------------------------------------------------------------ */

/** `"joy:0.8,wonder:0.6"` → ScoredLabels */
const L = (s: string): ScoredLabels =>
  Object.fromEntries(
    s
      .split(',')
      .map((p) => p.trim())
      .filter(Boolean)
      .map((p) => {
        const [k, v] = p.split(':');
        return [k!.trim(), Number(v)] as const;
      }),
  );

type BeatRow = [start: number, valence: number, arousal: number, dominance: number, emotions: string, beat: string, confidence?: number];

function samplesFrom(rows: BeatRow[], durationSec: number): EmotionSample[] {
  return rows.map(([start, valence, arousal, dominance, emotions, beat, confidence], i) => ({
    start,
    end: rows[i + 1]?.[0] ?? durationSec,
    valence,
    arousal,
    dominance,
    emotions: L(emotions),
    beat,
    confidence: confidence ?? 0.82,
  }));
}

type MarkerRow = [kind: Marker['kind'], start: number, end: number, label: string, confidence: number];

function markersFrom(itemId: string, fps: number, rows: MarkerRow[]): MarkerSet {
  return {
    itemId,
    fps,
    markers: rows.map(([kind, start, end, label, confidence]) => ({
      id: makeId('mrk', `${itemId}:${kind}:${start}`),
      kind,
      start,
      end,
      startFrame: Math.round(start * fps),
      endFrame: Math.round(end * fps),
      label,
      confidence,
    })),
    model: MODEL,
    generatedAt: GENERATED_AT,
  };
}

type SafetyRow = [category: SafetyReport['segments'][number]['category'], severity: 'low' | 'medium' | 'high', start: number, end: number, description: string, confidence: number];

function safetyFrom(itemId: string, rows: SafetyRow[]): SafetyReport {
  const segments = rows.map(([category, severity, start, end, description, confidence]) => ({
    id: makeId('saf', `${itemId}:${category}:${start}`),
    category,
    severity,
    start,
    end,
    description,
    confidence,
  }));
  return { itemId, segments, summary: summariseSafety(segments), model: MODEL, generatedAt: GENERATED_AT };
}

type CandRow = [at: number, confidence: number, reasonType: AdBreakCandidate['reasonType'], reason: string, before: string, after: string, mood: string, keywords: string, iab: Array<[string, string, 1 | 2 | 3, number]>];

function candidatesFrom(rows: CandRow[]): AdBreakCandidate[] {
  return rows.map(([at, confidence, reasonType, reason, sceneBefore, sceneAfter, mood, keywords, iab]) => ({
    at,
    confidence,
    reasonType,
    reason,
    sceneBefore,
    sceneAfter,
    mood: L(mood),
    keywords: L(keywords),
    iab: iab.map(([id, name, tier, c]) => ({ id, name, tier, confidence: c })),
  }));
}

type ThumbRow = [at: number, caption: string, characters: string[], mood: string, factors: [rel: number, aes: number, face: number, still: number, bright: number, safeArea: number], logo: ThumbnailsPayload['thumbnails'][number]['logoSafeZone'], safe: boolean, cx?: number];

function thumbsFrom(rows: ThumbRow[]): ThumbnailsPayload['thumbnails'] {
  return rows.map(([at, caption, characters, mood, [relevance, aesthetics, faceProminence, stillness, brightness, safeArea], logoSafeZone, safe, cx = 0.5]) => {
    const crop = (w: number) => ({ x: Math.round(Math.min(Math.max(cx - w / 2, 0), 1 - w) * 1000) / 1000, y: 0, w, h: 1 });
    return {
      at,
      factors: { relevance, aesthetics, faceProminence, stillness, brightness, safeArea },
      characters,
      mood: L(mood),
      crops: { '16:9': { x: 0, y: 0, w: 1, h: 1 }, '2:3': crop(0.375), '1:1': crop(0.5625), '9:16': crop(0.3164) },
      logoSafeZone,
      safe,
      caption,
    };
  });
}

type ClipRow = [start: number, end: number, clipType: string, relevance: number, characters: string[], mood: string, keywords: string, safe: boolean, caption: string, posterAt: number, cxs: number[]];

function clipsFrom(rows: ClipRow[]): ClipsPayload['clips'] {
  return rows.map(([start, end, clipType, relevance, characters, mood, keywords, safe, caption, posterAt, cxs]) => ({
    start,
    end,
    clipType,
    relevance,
    characters,
    mood: L(mood),
    keywords: L(keywords),
    safe,
    reframe916: cxs.map((cx, i) => ({ at: Math.round((start + ((end - start) * i) / Math.max(1, cxs.length - 1)) * 100) / 100, cx })),
    caption,
    posterAt,
  }));
}

interface Authored {
  item: Omit<CatalogItem, 'createdAt' | 'updatedAt' | 'status' | 'jobs' | 'upstream' | 'type'> & { type: CatalogItem['type'] };
  fingerprint: Omit<Fingerprint, 'model' | 'generatedAt' | 'embedding'>;
  beats: BeatRow[];
  acts: EmotionArc['acts'];
  climax: NonNullable<EmotionArc['climax']>;
  markers: MarkerRow[];
  safety: SafetyRow[];
  candidates: CandRow[];
  thumbnails: ThumbRow[];
  clips: ClipRow[];
}

function assemble(a: Authored): ItemBundle {
  const { item: base } = a;
  const durationSec = base.durationSec!;
  const fps = base.fps!;
  const item: CatalogItem = {
    ...base,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
    status: 'ready',
    upstream: { assetId: mockAssetId(base.sourceUrl), indexedAssetId: mockVideoId(base.sourceUrl), indexId: 'mock-index' },
    jobs: {
      ingest: 'ready',
      fingerprint: 'ready',
      emotions: 'ready',
      markers: 'ready',
      safety: 'ready',
      adbreaks: 'ready',
      thumbnails: 'ready',
      clips: 'ready',
      // `embedding` is intentionally absent: the embedding job fills it (Marengo live, label-vector mock).
    },
  };
  const fingerprint: Fingerprint = { ...a.fingerprint, model: MODEL, generatedAt: GENERATED_AT };
  item.fingerprint = fingerprint;
  const emotions: EmotionArc = { itemId: item.id, samples: samplesFrom(a.beats, durationSec), acts: a.acts, climax: a.climax, model: MODEL, generatedAt: GENERATED_AT };
  const markers = markersFrom(item.id, fps, a.markers);
  const safety = safetyFrom(item.id, a.safety);
  const candidates = candidatesFrom(a.candidates);
  const plan = planAdBreaks(candidates, {
    durationSec,
    emotions,
    safety,
    sceneChanges: [...markers.markers.filter((m) => m.kind === 'chapter').flatMap((m) => [m.start, m.end]), ...emotions.samples.map((s) => s.start)],
    fps,
    itemId: item.id,
    model: `${MODEL}+planner`,
  });
  plan.generatedAt = GENERATED_AT;
  const adBreaks = { ...plan, candidates };
  const thumbnails = normaliseThumbnails(thumbsFrom(a.thumbnails), item);
  const clips = normaliseClips(clipsFrom(a.clips), item);
  return { item, fingerprint, emotions, markers, adBreaks, safety, thumbnails, clips, jobs: [] };
}

/* ------------------------------------------------------------------ */
/* Sintel (2010) — 14:48                                               */
/* ------------------------------------------------------------------ */

const sintel: Authored = {
  item: {
    id: 'sintel',
    title: 'Sintel',
    type: 'short',
    year: 2010,
    sourceUrl: 'https://www.youtube.com/watch?v=eRsGyueVLvQ',
    posterUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Sintel_poster.jpg/640px-Sintel_poster.jpg',
    externalIds: { youtube: 'eRsGyueVLvQ', wikidata: 'Q1245263' },
    metadata: { producer: 'Blender Foundation', license: 'CC-BY 3.0', director: 'Colin Levy', project: 'Durian' },
    durationSec: 888,
    fps: 24,
    width: 1920,
    height: 818,
  },
  fingerprint: {
    genres: L('fantasy:0.96,adventure:0.91,animation:0.99,drama:0.84,tragedy:0.72,coming of age:0.58,action:0.55'),
    keywords: L('dragon:0.98,snowstorm:0.9,quest:0.88,baby dragon:0.87,shaman:0.8,spear:0.78,mountain cave:0.77,medieval city:0.74,bamboo forest:0.66,knife fight:0.64,campfire:0.6,desert crossing:0.52'),
    moods: L('melancholic:0.93,epic:0.86,tense:0.78,tender:0.74,dark:0.7,hopeful:0.41,lonely:0.88'),
    moodTags: L('grief:0.91,obsession:0.86,unlikely friendship:0.84,tragic irony:0.83,lone wanderer:0.8,revenge quest:0.71,loss of innocence:0.68,wintry isolation:0.66'),
    themes: L('loss:0.94,obsession and its cost:0.9,love and letting go:0.86,identity:0.62,the passage of time:0.74,nature and the wild:0.58,violence begets violence:0.7'),
    characters: [
      { name: 'Sintel', prominence: 0.97, description: 'A lone, hardened young woman searching the world for the dragon she once nursed back to health.' },
      { name: 'Scales', prominence: 0.72, description: 'The injured baby dragon Sintel rescues and names; later the grown dragon she hunts.' },
      { name: 'The Shaman', prominence: 0.34, description: 'A blind cave-dwelling healer who tends Sintel and questions her quest.' },
      { name: 'The Bandit', prominence: 0.18, description: 'A hooded attacker who ambushes Sintel in the snow.' },
      { name: 'City Guards', prominence: 0.12, description: 'Spear-carrying guards who pursue Sintel through the bamboo forest.' },
    ],
    pacing: { score: 0.46, rationale: 'Long, quiet travelling passages and firelit dialogue are punctuated by two short, violent fights; the cut rate spikes only in the cave confrontation.' },
    language: { primary: 'en', others: [] },
    audienceRating: { suggested: 'PG-13', rationale: 'Two stylised but lethal fights including a stabbing and the killing of a dragon, plus a bleak, emotionally heavy ending.' },
    synopsis: {
      short: 'A lonely wanderer crosses a hostile world to find the baby dragon she once saved — and pays a terrible price for it.',
      long: 'Sintel, a solitary young woman battered by years on the road, is nursed back to health in a mountain cave by a blind shaman who asks what she is chasing. In flashback we see her rescue a wounded baby dragon in her home city, name it Scales and raise it — until an adult dragon snatches it away. Spear in hand she sets out across deserts, bamboo forests and snowbound passes, growing harder with every season. When she finally reaches a dragon nest high in the mountains, the confrontation she has dreamed of turns the story on its head.',
      translations: {
        es: { short: 'Una vagabunda solitaria cruza un mundo hostil para encontrar al dragón bebé que salvó una vez, y paga un precio terrible.', long: 'Sintel, una joven solitaria curtida por años de camino, es atendida en una cueva de montaña por un chamán ciego que le pregunta qué persigue. En un flashback la vemos rescatar a un dragón bebé herido en su ciudad natal, llamarlo Scales y criarlo, hasta que un dragón adulto se lo arrebata. Con una lanza en la mano recorre desiertos, bosques de bambú y pasos nevados, endureciéndose con cada estación. Cuando por fin llega a un nido de dragones en lo alto de las montañas, el enfrentamiento que tanto soñó da un vuelco a la historia.' },
        fr: { short: 'Une vagabonde solitaire traverse un monde hostile pour retrouver le bébé dragon qu\'elle a sauvé — et le paie au prix fort.', long: 'Sintel, jeune femme solitaire endurcie par des années d\'errance, est soignée dans une grotte de montagne par un chaman aveugle qui lui demande ce qu\'elle poursuit. En flashback, on la voit recueillir un bébé dragon blessé dans sa ville natale, le nommer Scales et l\'élever, jusqu\'à ce qu\'un dragon adulte l\'emporte. Lance en main, elle traverse déserts, forêts de bambous et cols enneigés, plus dure à chaque saison. Lorsqu\'elle atteint enfin un nid de dragons au sommet des montagnes, l\'affrontement dont elle rêvait renverse toute l\'histoire.' },
        de: { short: 'Eine einsame Wanderin durchquert eine feindliche Welt, um den Drachenwelpen zu finden, den sie einst rettete – und zahlt einen furchtbaren Preis.', long: 'Sintel, eine junge Frau, die Jahre auf der Straße hart gemacht haben, wird in einer Berghöhle von einem blinden Schamanen gepflegt, der sie fragt, wonach sie jagt. In Rückblenden sehen wir, wie sie in ihrer Heimatstadt einen verletzten Drachenwelpen rettet, ihn Scales nennt und aufzieht – bis ein erwachsener Drache ihn davonträgt. Mit dem Speer in der Hand zieht sie durch Wüsten, Bambuswälder und verschneite Pässe und wird mit jeder Jahreszeit härter. Als sie endlich ein Drachennest hoch in den Bergen erreicht, stellt die ersehnte Konfrontation die Geschichte auf den Kopf.' },
        ja: { short: '孤独な旅人が、かつて救った子どものドラゴンを探して過酷な世界を渡り、恐ろしい代償を払う。', long: '長年の旅で心を固くした若い女性シンテルは、山の洞窟で盲目のシャーマンに介抱され、「何を追っているのか」と問われる。回想の中で彼女は故郷の街で傷ついた子どものドラゴンを助け、スケールズと名付けて育てるが、成長したドラゴンに連れ去られてしまう。槍を手に砂漠、竹林、雪の峠を越え、季節ごとに彼女は冷たく強くなっていく。ついに山頂のドラゴンの巣にたどり着いたとき、夢にまで見た対決が物語を根底から覆す。' },
        pt: { short: 'Uma andarilha solitária atravessa um mundo hostil para encontrar o bebê dragão que salvou um dia — e paga um preço terrível.', long: 'Sintel, uma jovem solitária endurecida por anos de estrada, é tratada numa caverna de montanha por um xamã cego que lhe pergunta o que ela persegue. Em flashback, vemos como ela resgata um bebê dragão ferido em sua cidade natal, dá-lhe o nome de Scales e o cria, até que um dragão adulto o leva embora. De lança em punho, ela cruza desertos, florestas de bambu e passagens nevadas, cada vez mais dura a cada estação. Quando finalmente chega a um ninho de dragões no alto das montanhas, o confronto com que tanto sonhou vira a história de cabeça para baixo.' },
        ar: { short: 'متجوّلة وحيدة تعبر عالماً قاسياً بحثاً عن صغير التنين الذي أنقذته يوماً، وتدفع ثمناً باهظاً.', long: 'سينتل، شابة وحيدة قسّتها سنوات الترحال، يعتني بها شامان ضرير في كهف جبلي ويسألها عمّا تطارده. في استرجاع نرى كيف أنقذت صغير تنين جريحاً في مدينتها، وسمّته سكيلز وربّته، إلى أن خطفه تنين بالغ. تنطلق برمحها عبر الصحارى وغابات الخيزران والممرات الثلجية، وتزداد قسوة مع كل فصل. وحين تبلغ أخيراً عشّ التنانين في أعالي الجبال، تقلب المواجهة التي طالما حلمت بها القصة رأساً على عقب.' },
        hi: { short: 'एक अकेली यात्री उस नन्हे ड्रैगन की तलाश में कठोर दुनिया पार करती है जिसे उसने कभी बचाया था — और भयानक कीमत चुकाती है।', long: 'सालों की भटकन से कठोर हो चुकी युवती सिंटेल को एक पहाड़ी गुफा में अंधा शमन ठीक करता है और पूछता है कि वह किसका पीछा कर रही है। फ्लैशबैक में हम देखते हैं कि वह अपने शहर में एक घायल नन्हे ड्रैगन को बचाती है, उसका नाम स्केल्स रखती है और उसे पालती है — जब तक एक वयस्क ड्रैगन उसे उठा नहीं ले जाता। भाला थामे वह रेगिस्तान, बाँस के जंगल और बर्फीले दर्रे पार करती है और हर मौसम के साथ और कठोर होती जाती है। जब वह आखिरकार पहाड़ों की ऊँचाई पर ड्रैगन के घोंसले तक पहुँचती है, तो जिस टकराव का उसने सपना देखा था, वह कहानी को पलट देता है।' },
        ko: { short: '외로운 방랑자가 한때 구해 준 아기 용을 찾아 험한 세상을 건너고, 끔찍한 대가를 치른다.', long: '오랜 방랑으로 단단해진 젊은 여인 신텔은 산속 동굴에서 눈먼 주술사의 보살핌을 받으며 "무엇을 쫓고 있느냐"는 질문을 받는다. 회상 속에서 그녀는 고향 도시에서 다친 아기 용을 구해 스케일즈라 이름 짓고 키우지만, 어른 용이 아기를 낚아채 간다. 창을 들고 사막과 대나무 숲, 눈 덮인 고개를 넘으며 그녀는 계절마다 더 냉정해진다. 마침내 산꼭대기의 용 둥지에 다다랐을 때, 꿈에 그리던 대결은 이야기를 완전히 뒤집는다.' },
      },
    },
  },
  beats: [
    [0, 0.0, 0.14, 0.4, 'stillness:0.8,anticipation:0.5', 'Snow drifts over black; the Durian/Blender logo fades in under a low wind'],
    [18, -0.25, 0.3, 0.35, 'loneliness:0.85,determination:0.6,cold:0.7', 'Sintel trudges through a blizzard, hooded and alone, leaning into the wind'],
    [45, -0.6, 0.86, 0.3, 'fear:0.8,shock:0.75,aggression:0.6', 'A hooded figure lunges from the snow; a brutal, close-quarters knife fight in the drift'],
    [62, -0.55, 0.62, 0.55, 'grim resolve:0.8,pain:0.7,relief:0.3', 'Sintel kills the attacker, staggers up wounded and pushes on'],
    [85, -0.1, 0.22, 0.4, 'weariness:0.8,warmth:0.5,curiosity:0.5', 'A firelit cave; the blind shaman tends her wounds and asks what she is chasing'],
    [120, 0.55, 0.38, 0.6, 'curiosity:0.8,tenderness:0.7,wonder:0.6', 'Flashback: a sunlit medieval market; Sintel finds a wounded baby dragon in an alley'],
    [150, 0.78, 0.42, 0.7, 'tenderness:0.9,joy:0.75,playfulness:0.7', 'She bandages the dragon, names it Scales; feeding and play in her small room'],
    [195, 0.9, 0.55, 0.75, 'joy:0.92,wonder:0.8,pride:0.6', 'Scales learns to fly over the rooftops; Sintel laughs — the warmest moment of the film'],
    [230, -0.85, 0.95, 0.15, 'terror:0.9,despair:0.85,helplessness:0.8', 'An adult dragon dives out of the sky and snatches Scales; Sintel screams after it'],
    [255, -0.4, 0.5, 0.6, 'determination:0.85,grief:0.7,resolve:0.7', 'Sintel takes a spear, packs, and walks out of the city gates at dawn'],
    [280, -0.2, 0.4, 0.55, 'endurance:0.8,loneliness:0.7,awe:0.4', 'Travel montage: desert dunes, river crossings, mountain ridges — seasons pass'],
    [330, -0.45, 0.72, 0.35, 'tension:0.85,fear:0.6,urgency:0.7', 'Bamboo forest: city guards hunt her; she slips between the stalks and hides'],
    [365, -0.35, 0.2, 0.45, 'loneliness:0.9,longing:0.8,melancholy:0.7', 'A lonely night camp; she turns a dragon scale over in the firelight'],
    [395, -0.3, 0.28, 0.4, 'doubt:0.7,sadness:0.6,stubbornness:0.65', 'Back in the cave: the shaman warns her she has been chasing a dream for years'],
    [425, -0.15, 0.45, 0.65, 'resolve:0.85,defiance:0.6,cold:0.5', 'Sintel walks out of the cave into the snow, jaw set, spear on her back'],
    [455, -0.5, 0.6, 0.4, 'dread:0.8,awe:0.6,anticipation:0.7', 'The dragon nest at the mountain crest: scorched bones, a roar echoes from within'],
    [490, -0.3, 0.55, 0.45, 'suspense:0.85,tenderness:0.4,dread:0.6', 'She creeps into the cave; a baby dragon sleeps curled against the adult'],
    [520, -0.6, 0.9, 0.5, 'fear:0.8,rage:0.75,adrenaline:0.85', 'The adult dragon rises and roars; Sintel charges with the spear'],
    [555, -0.7, 0.98, 0.55, 'terror:0.85,rage:0.85,adrenaline:0.95', 'A frantic fight through fire and falling rock; she drives the spear into the dragon\'s neck'],
    [590, -0.9, 0.6, 0.25, 'horror:0.9,grief:0.95,shock:0.85', 'The dragon collapses; Sintel sees the familiar scar on its wing — it is Scales'],
    [620, -0.95, 0.35, 0.15, 'anguish:0.95,guilt:0.9,despair:0.9', 'Sintel realises what she has done; the orphaned baby dragon wails behind her'],
    [660, -0.6, 0.18, 0.3, 'numbness:0.85,sorrow:0.8,emptiness:0.8', 'She walks out into the snow, hollow, leaving the cave behind'],
    [700, -0.2, 0.25, 0.4, 'bittersweet:0.8,hope:0.5,tenderness:0.6', 'The baby dragon follows her footprints from a distance as the music swells'],
    [735, 0.05, 0.18, 0.5, 'reflection:0.7,calm:0.6,melancholy:0.5', 'End credits roll over falling snow; theme reprise'],
    [810, 0.05, 0.12, 0.5, 'calm:0.7,stillness:0.6', 'Credits continue: crew and sponsor names'],
    [860, 0.0, 0.08, 0.5, 'stillness:0.8', 'Final Blender Foundation card and licence notice'],
  ],
  acts: [
    { name: 'Cold open', start: 0, end: 85, summary: 'A wounded Sintel fights for her life in a blizzard.' },
    { name: 'Scales', start: 85, end: 255, summary: 'In the shaman\'s cave she remembers finding, raising and losing a baby dragon.' },
    { name: 'The long road', start: 255, end: 455, summary: 'Years of searching across deserts, forests and mountains harden her.' },
    { name: 'The nest', start: 455, end: 660, summary: 'She finds the dragon nest, kills the adult dragon, and discovers it was Scales.' },
    { name: 'Aftermath', start: 660, end: 888, summary: 'Sintel walks away; the orphaned dragon follows; credits.' },
  ],
  climax: { at: 578, description: 'Sintel drives her spear through the dragon\'s neck amid fire and falling rock, seconds before she recognises the scar.' },
  markers: [
    ['cold_open', 0, 85, 'Cold open — blizzard ambush', 0.88],
    ['title_card', 20, 24, 'Title: SINTEL', 0.93],
    ['chapter', 85, 255, 'Ch. 1 — The shaman and Scales', 0.84],
    ['chapter', 255, 455, 'Ch. 2 — The long road', 0.81],
    ['chapter', 455, 660, 'Ch. 3 — The nest', 0.9],
    ['chapter', 660, 735, 'Ch. 4 — Aftermath', 0.86],
    ['credits', 735, 888, 'End credits', 0.97],
  ],
  safety: [
    ['weapons', 'medium', 45, 68, 'Knife drawn and used in a close fight; spear carried through the second half.', 0.9],
    ['violence', 'high', 47, 66, 'Sintel is ambushed and stabs her attacker to death in the snow (stylised, no blood spray).', 0.88],
    ['weapons', 'low', 255, 262, 'Sintel picks up a spear before leaving the city.', 0.72],
    ['violence', 'medium', 330, 352, 'Armed guards pursue Sintel through the bamboo forest.', 0.7],
    ['violence', 'high', 520, 592, 'Extended fight with a dragon ending in a fatal spear wound; fire and collapsing rock.', 0.93],
    ['flashing_lights', 'low', 556, 570, 'Rapid firelight flicker inside the cave during the fight.', 0.55],
  ],
  candidates: [
    [85, 0.82, 'scene_change', 'Hard cut from the snowfield to the firelit cave; music resolves.', 'Sintel staggers wounded through the snow', 'The blind shaman tends her by the fire', 'exhausted:0.8,grim:0.7,relieved:0.4', 'snow:0.8,wound:0.7,cave:0.7,fire:0.6,shaman:0.6', [['IAB1-5', 'Movies', 2, 0.8], ['IAB9-30', 'Fantasy', 3, 0.6]]],
    [120, 0.74, 'scene_change', 'Dissolve from cave to the sunlit market flashback.', 'The shaman asks what Sintel is chasing', 'Sunlit medieval market; Sintel finds the dragon', 'reflective:0.7,curious:0.6,warm:0.5', 'market:0.8,city:0.7,flashback:0.7,dragon:0.6', [['IAB1-5', 'Movies', 2, 0.8]]],
    [230, 0.62, 'music_end', 'Flight montage music ends before the adult dragon attacks.', 'Scales learns to fly; Sintel laughs', 'An adult dragon snatches Scales away', 'joyful:0.8,tender:0.7,carefree:0.6', 'dragon:0.9,rooftops:0.7,flight:0.7,laughter:0.5', [['IAB1-5', 'Movies', 2, 0.8]]],
    [255, 0.9, 'act_break', 'Act break: dawn departure through the city gates; new musical cue.', 'Sintel screams after the dragon', 'She leaves the city with a spear at dawn', 'resolute:0.85,grieving:0.7,determined:0.7', 'city gates:0.8,dawn:0.7,spear:0.7,journey:0.7', [['IAB1-5', 'Movies', 2, 0.8], ['IAB20', 'Travel', 1, 0.4]]],
    [330, 0.71, 'location_change', 'Montage lands in the bamboo forest; ambient sound shift.', 'Travel montage across deserts and ridges', 'Guards hunt Sintel through bamboo', 'weary:0.7,watchful:0.7,tense:0.6', 'bamboo:0.9,forest:0.8,guards:0.7,chase:0.6', [['IAB1-5', 'Movies', 2, 0.8]]],
    [395, 0.85, 'scene_change', 'Cut from the night camp back to the cave; dialogue resumes.', 'Sintel studies a dragon scale by the campfire', 'The shaman warns her she chases a dream', 'melancholic:0.85,lonely:0.8,reflective:0.7', 'campfire:0.8,scale:0.7,cave:0.7,shaman:0.7,night:0.6', [['IAB1-5', 'Movies', 2, 0.8]]],
    [455, 0.88, 'scene_change', 'Wide reveal of the dragon nest after the snowfield walk; music cue starts.', 'Sintel climbs through snow toward the peak', 'The nest: scorched bones, a roar inside', 'ominous:0.85,determined:0.7,dread:0.7', 'mountain:0.8,nest:0.8,bones:0.6,snow:0.7,dragon:0.8', [['IAB1-5', 'Movies', 2, 0.8], ['IAB9-30', 'Fantasy', 3, 0.6]]],
    [660, 0.8, 'fade', 'Fade to white as Sintel leaves the cave; end of the confrontation.', 'Sintel grieves over the dead dragon', 'She walks out into the snow, hollow', 'devastated:0.9,numb:0.8,sorrowful:0.8', 'snow:0.8,cave:0.6,grief:0.7,dragon:0.6', [['IAB1-5', 'Movies', 2, 0.8]]],
  ],
  thumbnails: [
    [199, 'Sintel laughing as Scales takes flight over the rooftops', ['Sintel', 'Scales'], 'joyful:0.9,tender:0.8,hopeful:0.6', [0.92, 0.9, 0.78, 0.62, 0.66, 0.6], 'top-right', true, 0.42],
    [24, 'Sintel alone in the blizzard, hood up, wind-lashed', ['Sintel'], 'lonely:0.9,bleak:0.8,determined:0.6', [0.88, 0.86, 0.55, 0.7, 0.42, 0.75], 'top-left', true, 0.55],
    [157, 'Sintel cradling the bandaged baby dragon by candlelight', ['Sintel', 'Scales'], 'tender:0.95,intimate:0.8,warm:0.7', [0.9, 0.88, 0.85, 0.8, 0.38, 0.55], 'top-left', true, 0.5],
    [466, 'The dragon nest at the crest, bones in the snow', ['Sintel'], 'ominous:0.85,epic:0.8,dread:0.6', [0.8, 0.9, 0.2, 0.85, 0.55, 0.8], 'bottom-left', true, 0.5],
    [93, 'The blind shaman\'s face in firelight', ['The Shaman'], 'mysterious:0.8,calm:0.7,wise:0.6', [0.66, 0.84, 0.9, 0.88, 0.32, 0.5], 'top-right', true, 0.45],
    [528, 'The adult dragon rears, wings filling the cave', ['Scales'], 'terrifying:0.85,epic:0.85,intense:0.8', [0.85, 0.87, 0.3, 0.45, 0.4, 0.6], 'bottom-right', false, 0.5],
    [427, 'Sintel stepping out of the cave into the snow, spear on her back', ['Sintel'], 'resolute:0.85,cold:0.7,lonely:0.6', [0.84, 0.86, 0.6, 0.72, 0.62, 0.7], 'top-right', true, 0.4],
    [703, 'Tiny dragon footprints following Sintel\'s trail through the snow', ['Sintel', 'Scales'], 'bittersweet:0.9,hopeful:0.6,quiet:0.7', [0.86, 0.9, 0.15, 0.9, 0.7, 0.85], 'top-left', true, 0.5],
    [282, 'Sintel silhouetted on a desert ridge at sunset', ['Sintel'], 'epic:0.8,lonely:0.7,adventurous:0.6', [0.78, 0.92, 0.1, 0.8, 0.6, 0.85], 'top-left', true, 0.6],
    [368, 'Sintel turning a dragon scale over in campfire light', ['Sintel'], 'melancholic:0.9,intimate:0.7,longing:0.7', [0.82, 0.85, 0.82, 0.86, 0.35, 0.5], 'top-right', true, 0.5],
    [334, 'Sintel hiding among towering bamboo stalks', ['Sintel'], 'tense:0.8,watchful:0.7,green:0.5', [0.7, 0.83, 0.5, 0.6, 0.5, 0.65], 'bottom-right', true, 0.35],
    [122, 'Sunlit market square with hanging lanterns and stalls', ['Sintel'], 'warm:0.8,lively:0.7,nostalgic:0.6', [0.64, 0.8, 0.35, 0.68, 0.75, 0.6], 'top-left', true, 0.5],
  ],
  clips: [
    [195, 222, 'emotional turn', 0.94, ['Sintel', 'Scales'], 'joyful:0.9,tender:0.8,wonder:0.7', 'dragon:0.9,flight:0.8,rooftops:0.7,laughter:0.6', true, 'The day Scales learned to fly', 199, [0.5, 0.42, 0.5]],
    [45, 68, 'action beat', 0.86, ['Sintel', 'The Bandit'], 'tense:0.9,violent:0.8,desperate:0.7', 'blizzard:0.8,knife fight:0.8,ambush:0.7', false, 'Ambushed in the blizzard', 52, [0.5, 0.58, 0.45]],
    [455, 480, 'world reveal', 0.83, ['Sintel'], 'ominous:0.85,epic:0.8,dread:0.7', 'mountain:0.8,nest:0.8,bones:0.6,snow:0.7', true, 'Something is waiting in the nest', 466, [0.5, 0.5, 0.55]],
    [150, 176, 'character intro', 0.8, ['Sintel', 'Scales'], 'tender:0.9,playful:0.7,warm:0.7', 'baby dragon:0.9,bandage:0.6,room:0.5,feeding:0.6', true, 'Meet Scales', 157, [0.5, 0.48, 0.5]],
    [255, 279, 'cliffhanger', 0.78, ['Sintel'], 'resolute:0.85,grieving:0.7,epic:0.6', 'spear:0.8,city gates:0.7,dawn:0.7,journey:0.7', true, 'She will find that dragon', 262, [0.45, 0.5, 0.55]],
    [280, 304, 'world reveal', 0.72, ['Sintel'], 'epic:0.8,lonely:0.7,adventurous:0.6', 'desert:0.8,mountains:0.7,river:0.6,montage:0.6', true, 'Across deserts, forests and snow', 282, [0.6, 0.5, 0.4]],
  ],
};

/* ------------------------------------------------------------------ */
/* Tears of Steel (2012) — 12:14                                        */
/* ------------------------------------------------------------------ */

const tearsOfSteel: Authored = {
  item: {
    id: 'tears-of-steel',
    title: 'Tears of Steel',
    type: 'short',
    year: 2012,
    sourceUrl: 'https://www.youtube.com/watch?v=R6MlUcmOul8',
    posterUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/Tears_of_Steel_poster.jpg/640px-Tears_of_Steel_poster.jpg',
    externalIds: { youtube: 'R6MlUcmOul8', wikidata: 'Q1216201' },
    metadata: { producer: 'Blender Foundation', license: 'CC-BY 3.0', director: 'Ian Hubert', project: 'Mango' },
    durationSec: 734,
    fps: 24,
    width: 1920,
    height: 800,
  },
  fingerprint: {
    genres: L('science fiction:0.97,action:0.82,comedy:0.74,romance:0.66,live action vfx:0.9,dystopian:0.7,short film:0.95'),
    keywords: L('robots:0.96,amsterdam:0.93,rooftop:0.88,hologram:0.8,time travel:0.62,laboratory:0.78,giant robot:0.84,church:0.7,astronaut dream:0.66,break-up:0.72,projection rig:0.6,ruined city:0.75'),
    moods: L('tense:0.82,quirky:0.8,melancholic:0.68,hopeful:0.6,chaotic:0.66,nostalgic:0.62,tongue in cheek:0.78'),
    moodTags: L('regret:0.9,second chances:0.86,robot uprising:0.84,awkward reunion:0.74,ragtag team:0.72,heartbreak echoes:0.7,deadpan humour:0.68,fixing the past:0.82'),
    themes: L('love and regret:0.92,man vs machine:0.86,memory:0.78,forgiveness:0.8,ambition vs relationships:0.74,technology as emotion:0.7'),
    characters: [
      { name: 'Thom', prominence: 0.95, description: 'A would-be astronaut who broke up with Celia 40 years ago and must relive it to stop the robot war.' },
      { name: 'Celia', prominence: 0.82, description: 'Thom\'s former lover, now the vengeful consciousness behind the robot army.' },
      { name: 'Barley', prominence: 0.7, description: 'Gruff leader of the scientists\' resistance running the memory experiment.' },
      { name: 'Amy', prominence: 0.55, description: 'Young technician who keeps the projection rig running under fire.' },
      { name: 'Jan', prominence: 0.42, description: 'Barley\'s wisecracking assistant, dragged off during the robot assault.' },
      { name: 'The Actress', prominence: 0.3, description: 'Plays young Celia in the re-enactment, to Thom\'s discomfort.' },
    ],
    pacing: { score: 0.64, rationale: 'Dialogue-driven set-up in the lab gives way to a sustained robot assault with fast cutting and heavy VFX, then slows for the emotional resolution.' },
    language: { primary: 'en', others: [] },
    audienceRating: { suggested: 'PG-13', rationale: 'Sci-fi violence with robots destroying buildings and threatening people, mild language, no gore.' },
    synopsis: {
      short: 'In a ruined future Amsterdam, a band of scientists re-stage a rooftop break-up from 40 years ago to stop a robot army led by a scorned lover.',
      long: 'On a rooftop overlooking Amsterdam, young Thom tells Celia he would rather be an astronaut than stay with her — a break-up that echoes for decades. Forty years later the city lies in ruins under a robot army, and a scrappy group of scientists led by Barley believes the only fix is to project Thom back into that moment and make him say it differently. As robots close in on their church laboratory, the experiment collapses into chaos, and Thom must confront the towering, holographic Celia herself with the words he never said.',
      translations: {
        es: { short: 'En un Ámsterdam futuro en ruinas, un grupo de científicos recrea una ruptura en una azotea de hace 40 años para detener a un ejército de robots liderado por una amante despechada.', long: 'En una azotea con vistas a Ámsterdam, el joven Thom le dice a Celia que prefiere ser astronauta antes que quedarse con ella: una ruptura que resuena durante décadas. Cuarenta años después la ciudad yace en ruinas bajo un ejército de robots, y un grupo de científicos liderado por Barley cree que la única solución es proyectar a Thom de vuelta a ese momento para que lo diga de otra manera. Mientras los robots rodean su laboratorio en la iglesia, el experimento se hunde en el caos y Thom debe enfrentarse a la gigantesca Celia holográfica con las palabras que nunca dijo.' },
        fr: { short: 'Dans un Amsterdam futur en ruines, des scientifiques rejouent une rupture sur un toit vieille de 40 ans pour arrêter une armée de robots menée par une amante bafouée.', long: 'Sur un toit dominant Amsterdam, le jeune Thom annonce à Celia qu\'il préfère devenir astronaute plutôt que rester avec elle — une rupture dont l\'écho traverse les décennies. Quarante ans plus tard, la ville est en ruines sous une armée de robots, et un groupe hétéroclite de scientifiques mené par Barley pense que la seule solution est de projeter Thom dans ce moment pour qu\'il le dise autrement. Alors que les robots encerclent leur laboratoire installé dans une église, l\'expérience sombre dans le chaos et Thom doit affronter la gigantesque Celia holographique avec les mots qu\'il n\'a jamais dits.' },
        de: { short: 'In einem zerstörten Amsterdam der Zukunft stellt eine Gruppe Wissenschaftler eine 40 Jahre alte Trennung auf einem Dach nach, um eine Roboterarmee unter Führung einer verschmähten Geliebten zu stoppen.', long: 'Auf einem Dach über Amsterdam sagt der junge Thom Celia, er wolle lieber Astronaut werden, als bei ihr zu bleiben – eine Trennung, die Jahrzehnte nachhallt. Vierzig Jahre später liegt die Stadt unter einer Roboterarmee in Trümmern, und eine zusammengewürfelte Gruppe Wissenschaftler um Barley glaubt, die einzige Lösung sei, Thom in diesen Moment zurückzuprojizieren, damit er es anders sagt. Während Roboter ihr Kirchenlabor einkreisen, versinkt das Experiment im Chaos, und Thom muss der riesigen holografischen Celia mit den Worten gegenübertreten, die er nie gesagt hat.' },
        ja: { short: '廃墟と化した未来のアムステルダムで、科学者たちは40年前の屋上の別れを再現し、捨てられた恋人が率いるロボット軍を止めようとする。', long: 'アムステルダムを見下ろす屋上で、若きトムはセリアに「君といるより宇宙飛行士になりたい」と告げる。その別れは数十年にわたって尾を引く。40年後、街はロボット軍の支配下で廃墟となり、バーリー率いる寄せ集めの科学者チームは、トムをあの瞬間へ投影し、違う言葉を言わせることが唯一の解決策だと信じる。ロボットが教会の研究所に迫る中、実験は混乱に陥り、トムは巨大なホログラムのセリアと向き合い、言えなかった言葉を口にしなければならない。' },
        pt: { short: 'Numa Amsterdã futura em ruínas, um grupo de cientistas reencena um rompimento num telhado de 40 anos atrás para deter um exército de robôs liderado por uma amante desprezada.', long: 'Num telhado com vista para Amsterdã, o jovem Thom diz a Celia que prefere ser astronauta a ficar com ela — um rompimento que ecoa por décadas. Quarenta anos depois, a cidade está em ruínas sob um exército de robôs, e um grupo improvisado de cientistas liderado por Barley acredita que a única solução é projetar Thom de volta àquele momento para que ele diga tudo de outro jeito. Enquanto os robôs cercam o laboratório na igreja, o experimento desaba no caos e Thom precisa encarar a gigantesca Celia holográfica com as palavras que nunca disse.' },
        ar: { short: 'في أمستردام مستقبلية مدمّرة، تعيد مجموعة من العلماء تمثيل انفصالٍ على سطحٍ قبل 40 عاماً لإيقاف جيش من الروبوتات تقوده حبيبة مجروحة.', long: 'على سطحٍ يطلّ على أمستردام، يخبر توم الشاب سيليا بأنه يفضّل أن يصبح رائد فضاء على البقاء معها، وهو انفصال يتردّد صداه لعقود. بعد أربعين عاماً تقبع المدينة مدمّرة تحت جيش من الروبوتات، وتؤمن مجموعة علماء بقيادة بارلي بأن الحل الوحيد هو إعادة توم إلى تلك اللحظة ليقولها بطريقة مختلفة. ومع اقتراب الروبوتات من مختبرهم في الكنيسة، ينهار التجربة في فوضى، ويجب على توم مواجهة سيليا الهولوغرامية العملاقة بالكلمات التي لم يقلها قط.' },
        hi: { short: 'खंडहर बने भविष्य के एम्स्टर्डम में वैज्ञानिकों का एक दल 40 साल पुराने छत के ब्रेकअप को दोबारा रचता है ताकि ठुकराई गई प्रेमिका की रोबोट सेना को रोका जा सके।', long: 'एम्स्टर्डम की एक छत पर युवा थॉम सेलिया से कहता है कि वह उसके साथ रहने के बजाय अंतरिक्ष यात्री बनना चाहेगा — एक ब्रेकअप जिसकी गूँज दशकों तक रहती है। चालीस साल बाद शहर रोबोट सेना के नीचे खंडहर है, और बार्ली के नेतृत्व में वैज्ञानिकों का जुगाड़ू दल मानता है कि एकमात्र उपाय है थॉम को उसी पल में वापस प्रक्षेपित करना ताकि वह बात अलग तरह से कहे। जैसे ही रोबोट उनके चर्च-प्रयोगशाला को घेरते हैं, प्रयोग अराजकता में डूब जाता है और थॉम को विशाल होलोग्राफिक सेलिया का सामना उन शब्दों के साथ करना पड़ता है जो उसने कभी नहीं कहे।' },
        ko: { short: '폐허가 된 미래의 암스테르담에서, 과학자들은 40년 전 옥상의 이별을 재연해 버림받은 연인이 이끄는 로봇 군대를 막으려 한다.', long: '암스테르담이 내려다보이는 옥상에서 젊은 톰은 셀리아에게 그녀와 함께하기보다 우주비행사가 되고 싶다고 말한다. 그 이별은 수십 년간 메아리친다. 40년 후 도시는 로봇 군대 아래 폐허가 되었고, 발리가 이끄는 잡동사니 과학자 팀은 톰을 그 순간으로 투사해 다른 말을 하게 하는 것만이 유일한 해결책이라 믿는다. 로봇들이 교회 실험실로 다가오자 실험은 혼돈에 빠지고, 톰은 거대한 홀로그램 셀리아를 마주하고 끝내 하지 못했던 말을 해야 한다.' },
      },
    },
  },
  beats: [
    [0, 0.2, 0.2, 0.5, 'calm:0.7,curiosity:0.5,nostalgia:0.4', 'Blender logo; golden-hour Amsterdam skyline; the Oude Kerk rooftop'],
    [25, -0.35, 0.5, 0.45, 'awkwardness:0.8,sadness:0.6,tension:0.6', 'Thom and Celia argue on the rooftop — "I want to be an astronaut"; he flinches from her robotic hand'],
    [60, -0.7, 0.45, 0.3, 'heartbreak:0.9,regret:0.7,sadness:0.8', 'Celia walks away in tears; Thom stares at the skyline'],
    [80, -0.3, 0.35, 0.4, 'unease:0.7,curiosity:0.6,dread:0.5', 'Title: "40 years later" — a grey, ruined Amsterdam, scaffolding and drones'],
    [100, 0.1, 0.45, 0.6, 'curiosity:0.8,amusement:0.5,tension:0.4', 'Inside the church lab: Barley briefs the team; Thom strapped into the projection rig'],
    [135, 0.35, 0.4, 0.6, 'amusement:0.8,affection:0.5,focus:0.5', 'Amy and Jan calibrate the "mental image" projector; deadpan banter'],
    [165, 0.3, 0.5, 0.5, 'amusement:0.85,awkwardness:0.8,nostalgia:0.5', 'Thom re-enacts the break-up with the actress; the team winces at his delivery'],
    [200, -0.5, 0.7, 0.35, 'dread:0.85,urgency:0.8,fear:0.6', 'Robots crawl over the ruined city; sensors spike — they are heading for the church'],
    [230, -0.6, 0.85, 0.3, 'panic:0.85,fear:0.8,urgency:0.85', 'Barley: "They\'re coming straight for us" — the lab scrambles, alarms blare'],
    [255, -0.7, 0.95, 0.25, 'terror:0.85,chaos:0.9,adrenaline:0.85', 'Robots breach the walls; the team dives for cover under sparks and debris'],
    [290, -0.8, 0.98, 0.2, 'terror:0.9,shock:0.85,helplessness:0.8', 'A giant mechanical hand crushes the rooftop; Jan is dragged away'],
    [320, -0.5, 0.75, 0.3, 'awe:0.8,dread:0.8,fear:0.6', 'Thom hides in the rubble; Celia\'s vast holographic face rises over the city'],
    [350, -0.55, 0.6, 0.35, 'bitterness:0.85,sadness:0.7,tension:0.6', 'Celia speaks through the machines — forty years of bitterness in her voice'],
    [385, -0.2, 0.55, 0.5, 'vulnerability:0.9,remorse:0.85,hope:0.5', 'Thom finally apologises, admits he was afraid; the words he never said'],
    [415, 0.1, 0.5, 0.5, 'suspense:0.8,hope:0.6,tenderness:0.5', 'The robots pause mid-motion; Celia\'s projection wavers'],
    [440, 0.55, 0.35, 0.6, 'relief:0.9,tenderness:0.7,catharsis:0.7', 'Celia lets go; the machines power down across the city'],
    [470, 0.6, 0.35, 0.65, 'relief:0.85,amusement:0.7,warmth:0.6', 'The team stumbles into the quiet; Barley cracks a joke; Amy exhales'],
    [495, 0.3, 0.22, 0.55, 'wistfulness:0.8,peace:0.7,nostalgia:0.6', 'Thom alone on the rooftop, looking at the stars he chose over her'],
    [520, 0.5, 0.55, 0.6, 'amusement:0.9,surprise:0.7,delight:0.6', 'Final gag: a sci-fi twist "in forty more years"; smash cut to black'],
    [545, 0.15, 0.18, 0.5, 'calm:0.7,reflection:0.5', 'End credits over Amsterdam plates; cast and crew'],
    [640, 0.1, 0.12, 0.5, 'calm:0.7,stillness:0.6', 'Credits continue: sponsors and Mango project contributors'],
    [700, 0.0, 0.08, 0.5, 'stillness:0.8', 'Final Blender Foundation card'],
  ],
  acts: [
    { name: 'The rooftop', start: 0, end: 80, summary: 'Young Thom breaks up with Celia to chase his astronaut dream.' },
    { name: 'The experiment', start: 80, end: 200, summary: 'Forty years on, a lab in a ruined church tries to re-stage the moment.' },
    { name: 'The assault', start: 200, end: 350, summary: 'Robots storm the church; the team is scattered and Jan is taken.' },
    { name: 'The words', start: 350, end: 495, summary: 'Thom confronts holographic Celia and finally apologises; the machines stand down.' },
    { name: 'Coda', start: 495, end: 734, summary: 'A quiet rooftop, a final gag, and credits.' },
  ],
  climax: { at: 300, description: 'The giant robot hand tears through the rooftop and drags Jan away as the church collapses around the team.' },
  markers: [
    ['cold_open', 0, 80, 'Cold open — the rooftop break-up', 0.9],
    ['title_card', 80, 86, 'Title: 40 YEARS LATER', 0.9],
    ['chapter', 80, 200, 'Ch. 1 — The experiment', 0.83],
    ['chapter', 200, 350, 'Ch. 2 — The assault', 0.88],
    ['chapter', 350, 495, 'Ch. 3 — The words', 0.85],
    ['chapter', 495, 545, 'Ch. 4 — Coda', 0.8],
    ['credits', 545, 734, 'End credits', 0.96],
  ],
  safety: [
    ['violence', 'medium', 255, 320, 'Robots destroy the church interior; people thrown by explosions and debris (no injuries shown).', 0.85],
    ['violence', 'high', 290, 312, 'A giant mechanical hand crushes the rooftop and seizes a team member.', 0.82],
    ['profanity', 'low', 232, 236, 'Mild exclamation during the alarm.', 0.6],
    ['flashing_lights', 'medium', 258, 275, 'Rapid sparks, muzzle-flash-like bursts and strobing alarm lights.', 0.7],
    ['weapons', 'low', 205, 250, 'Armed robots and drones visible over the city.', 0.72],
  ],
  candidates: [
    [80, 0.9, 'act_break', 'Title card "40 years later" — natural act break with music sting.', 'Celia walks away in tears on the rooftop', 'Ruined Amsterdam under grey skies', 'melancholic:0.85,ominous:0.6,nostalgic:0.6', 'rooftop:0.8,amsterdam:0.8,break-up:0.7,title card:0.6', [['IAB1-5', 'Movies', 2, 0.8], ['IAB19', 'Technology & Computing', 1, 0.4]]],
    [135, 0.66, 'dialogue_gap', 'Brief lull between Barley\'s briefing and the calibration scene.', 'Barley briefs the team; Thom in the rig', 'Amy and Jan calibrate the projector', 'curious:0.7,light:0.6,focused:0.5', 'laboratory:0.8,church:0.7,projector:0.7,briefing:0.5', [['IAB1-5', 'Movies', 2, 0.8]]],
    [200, 0.86, 'scene_change', 'Hard cut from the comic re-enactment to exterior robots; tonal shift with new cue.', 'Thom awkwardly re-enacts the break-up', 'Robots crawl over the ruined city', 'amused:0.7,uneasy:0.6,anticipatory:0.6', 'robots:0.9,city:0.7,drones:0.6,re-enactment:0.5', [['IAB1-5', 'Movies', 2, 0.8], ['IAB19', 'Technology & Computing', 1, 0.5]]],
    [350, 0.78, 'scene_change', 'Cut to Celia\'s hologram addressing Thom; the assault subsides into dialogue.', 'Celia\'s giant face rises over the city', 'Celia speaks through the machines', 'awed:0.8,dread:0.7,bitter:0.6', 'hologram:0.9,giant face:0.7,city:0.6,confrontation:0.7', [['IAB1-5', 'Movies', 2, 0.8]]],
    [440, 0.58, 'music_end', 'The score resolves as the machines stand down.', 'Celia\'s projection wavers', 'Robots power down; the team emerges', 'relieved:0.85,tender:0.7,cathartic:0.7', 'robots:0.7,power down:0.6,relief:0.6,church:0.5', [['IAB1-5', 'Movies', 2, 0.8]]],
    [495, 0.84, 'scene_change', 'Exterior night rooftop after the lab scene; quiet reflective beat.', 'Barley jokes; the team exhales', 'Thom alone on the rooftop under the stars', 'wistful:0.85,peaceful:0.7,nostalgic:0.6', 'rooftop:0.9,stars:0.7,night:0.7,amsterdam:0.6', [['IAB1-5', 'Movies', 2, 0.8], ['IAB20', 'Travel', 1, 0.3]]],
  ],
  thumbnails: [
    [322, 'Celia\'s colossal holographic face looming over ruined Amsterdam', ['Celia'], 'awe:0.9,ominous:0.8,epic:0.8', [0.95, 0.92, 0.85, 0.6, 0.45, 0.55], 'bottom-left', true, 0.55],
    [30, 'Thom and Celia face to face on the rooftop at golden hour', ['Thom', 'Celia'], 'romantic:0.8,tense:0.6,nostalgic:0.7', [0.9, 0.9, 0.8, 0.75, 0.68, 0.6], 'top-left', true, 0.5],
    [104, 'Thom wired into the projection rig inside the old church', ['Thom', 'Barley'], 'curious:0.7,quirky:0.7,sci-fi:0.8', [0.82, 0.84, 0.7, 0.8, 0.42, 0.55], 'top-right', true, 0.45],
    [292, 'A giant robot hand smashing through the rooftop', ['Jan'], 'terrifying:0.85,epic:0.8,chaotic:0.8', [0.88, 0.86, 0.25, 0.3, 0.5, 0.5], 'top-left', false, 0.5],
    [498, 'Thom alone on the rooftop under a starry sky', ['Thom'], 'wistful:0.9,peaceful:0.7,lonely:0.6', [0.84, 0.9, 0.4, 0.88, 0.3, 0.8], 'top-right', true, 0.4],
    [82, 'Ruined Amsterdam skyline, scaffolds and drones under grey cloud', [], 'bleak:0.85,dystopian:0.85,ominous:0.6', [0.78, 0.88, 0.0, 0.85, 0.55, 0.9], 'top-left', true, 0.5],
    [138, 'Amy at the console, screens reflected in her glasses', ['Amy'], 'focused:0.8,quirky:0.6,warm:0.5', [0.7, 0.82, 0.85, 0.82, 0.4, 0.5], 'top-right', true, 0.45],
    [206, 'Spider-like robots crawling over canal houses', [], 'menacing:0.85,sci-fi:0.8,tense:0.7', [0.8, 0.86, 0.0, 0.5, 0.5, 0.7], 'bottom-right', true, 0.5],
    [388, 'Thom, dust-covered, finally saying the words', ['Thom'], 'vulnerable:0.9,remorseful:0.8,intimate:0.7', [0.86, 0.85, 0.92, 0.85, 0.45, 0.45], 'top-left', true, 0.5],
    [168, 'Thom re-enacting the break-up with the actress as the team watches', ['Thom', 'The Actress'], 'awkward:0.85,comic:0.8,nostalgic:0.4', [0.66, 0.78, 0.7, 0.7, 0.55, 0.5], 'bottom-left', true, 0.5],
    [472, 'The team emerging into the quiet, Barley grinning', ['Barley', 'Amy', 'Thom'], 'relieved:0.85,warm:0.7,amused:0.6', [0.72, 0.8, 0.75, 0.78, 0.6, 0.5], 'top-right', true, 0.5],
    [442, 'Robots powering down across the city as the light returns', [], 'cathartic:0.8,hopeful:0.75,calm:0.6', [0.7, 0.85, 0.0, 0.7, 0.62, 0.85], 'top-left', true, 0.5],
  ],
  clips: [
    [290, 318, 'action beat', 0.93, ['Jan', 'Thom'], 'terrifying:0.85,chaotic:0.85,epic:0.7', 'giant robot:0.9,rooftop:0.7,rubble:0.6,church:0.6', false, 'When the robots came for the church', 300, [0.5, 0.6, 0.45]],
    [25, 52, 'character intro', 0.86, ['Thom', 'Celia'], 'awkward:0.8,romantic:0.6,tense:0.6', 'rooftop:0.9,amsterdam:0.7,break-up:0.8,astronaut:0.6', true, '"I want to be an astronaut."', 30, [0.5, 0.45, 0.55]],
    [320, 348, 'world reveal', 0.88, ['Celia', 'Thom'], 'awe:0.9,dread:0.8,epic:0.8', 'hologram:0.9,giant face:0.8,city:0.7', true, 'She has been waiting forty years', 322, [0.5, 0.55, 0.5]],
    [165, 190, 'comic relief', 0.79, ['Thom', 'The Actress', 'Barley'], 'awkward:0.85,comic:0.85,nostalgic:0.4', 're-enactment:0.8,laboratory:0.6,break-up:0.6', true, 'Take two of the worst break-up ever', 168, [0.5, 0.5, 0.5]],
    [385, 410, 'emotional turn', 0.84, ['Thom'], 'vulnerable:0.9,remorseful:0.8,hopeful:0.5', 'apology:0.9,rubble:0.5,confrontation:0.6', true, 'The words he never said', 388, [0.5, 0.5, 0.5]],
    [520, 544, 'comic relief', 0.7, ['Amy', 'Barley'], 'amused:0.9,surprised:0.7', 'twist:0.7,gag:0.7,future:0.6', true, 'Forty more years', 526, [0.5, 0.5, 0.5]],
  ],
};

/* ------------------------------------------------------------------ */
/* Cosmos Laundromat (2015) — 12:10                                     */
/* ------------------------------------------------------------------ */

const cosmos: Authored = {
  item: {
    id: 'cosmos-laundromat',
    title: 'Cosmos Laundromat',
    type: 'short',
    year: 2015,
    sourceUrl: 'https://www.youtube.com/watch?v=Y-rmzh0PI3c',
    posterUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Cosmos_Laundromat_poster.jpg/640px-Cosmos_Laundromat_poster.jpg',
    externalIds: { youtube: 'Y-rmzh0PI3c', wikidata: 'Q20648262' },
    metadata: { producer: 'Blender Institute', license: 'CC-BY 4.0', director: 'Mathieu Auvray', project: 'Gooseberry', subtitle: 'First Cycle' },
    durationSec: 730,
    fps: 24,
    width: 1920,
    height: 1080,
  },
  fingerprint: {
    genres: L('animation:0.99,dark comedy:0.9,fantasy:0.86,surreal:0.84,adventure:0.7,drama:0.62,absurdist:0.8'),
    keywords: L('sheep:0.97,windswept island:0.9,salesman:0.86,cliff:0.82,briefcase:0.7,caterpillar:0.78,alien forest:0.8,tail device:0.66,rope:0.6,storm:0.72,bathrobe:0.58,vortex:0.64'),
    moods: L('quirky:0.92,melancholic:0.8,whimsical:0.85,dark:0.66,dreamlike:0.82,hopeful:0.58,absurd:0.86'),
    moodTags: L('existential ennui:0.9,new life offer:0.86,deadpan despair:0.82,rebirth:0.78,strange salesman:0.8,cosmic bargain:0.72,unlikely companions:0.66,cyclical fate:0.7'),
    themes: L('meaning of life:0.9,depression and hope:0.86,transformation:0.84,choice and consequence:0.76,cycles and rebirth:0.8,consumerism:0.5'),
    characters: [
      { name: 'Franck', prominence: 0.96, description: 'A profoundly bored sheep on a windswept island who wants his life to end — or change.' },
      { name: 'Victor', prominence: 0.78, description: 'A mysterious salesman in a bathrobe offering "a new life" from a briefcase.' },
      { name: 'Tara', prominence: 0.55, description: 'A chatty, fearless caterpillar Franck meets in the strange forest world.' },
      { name: 'The Flock', prominence: 0.22, description: 'Franck\'s oblivious fellow sheep, bleating in the background.' },
    ],
    pacing: { score: 0.52, rationale: 'Deadpan, held shots on the island give way to a frantic chase and a kinetic vortex sequence; the forest world breathes slowly again before the storm.' },
    language: { primary: 'en', others: [] },
    audienceRating: { suggested: 'PG-13', rationale: 'Comic but explicit suicide attempt by the sheep protagonist and themes of despair, handled lightly; no gore or language.' },
    synopsis: {
      short: 'A suicidal sheep on a wind-blasted island is offered a new life by a bathrobe-wearing salesman — and tumbles into a strange world.',
      long: 'Franck is a sheep who has had enough: enough wind, enough grass, enough of the flock. Just as he tries to end it all, a strange salesman named Victor appears in a bathrobe with a briefcase and an offer — a brand-new life, no questions asked. One tail-mounted device and a plunge off a cliff later, Franck wakes transformed in a lush, impossible forest where a chatty caterpillar named Tara insists on showing him around. But the new world is less stable than it looks, and when a storm begins to unravel it, Franck learns that Victor\'s "first cycle" is only the beginning.',
      translations: {
        es: { short: 'Una oveja suicida en una isla azotada por el viento recibe la oferta de una nueva vida de un vendedor en albornoz, y cae en un mundo extraño.', long: 'Franck es una oveja harta de todo: del viento, de la hierba, del rebaño. Justo cuando intenta acabar con todo, aparece un extraño vendedor llamado Victor, en albornoz y con un maletín, con una oferta: una vida completamente nueva, sin preguntas. Un dispositivo en la cola y una caída por el acantilado después, Franck despierta transformado en un bosque exuberante e imposible donde una oruga parlanchina llamada Tara insiste en enseñarle el lugar. Pero el nuevo mundo es menos estable de lo que parece, y cuando una tormenta empieza a deshacerlo, Franck descubre que el "primer ciclo" de Victor es solo el comienzo.' },
        fr: { short: 'Un mouton suicidaire sur une île balayée par le vent se voit offrir une nouvelle vie par un vendeur en peignoir — et bascule dans un monde étrange.', long: 'Franck est un mouton qui en a assez : assez de vent, assez d\'herbe, assez du troupeau. Au moment où il tente d\'en finir, un étrange vendeur nommé Victor surgit en peignoir, mallette à la main, avec une offre : une vie toute neuve, sans poser de questions. Un appareil fixé à la queue et un plongeon du haut de la falaise plus tard, Franck se réveille transformé dans une forêt luxuriante et impossible où une chenille bavarde nommée Tara tient à lui faire visiter les lieux. Mais ce nouveau monde est moins stable qu\'il n\'y paraît, et lorsqu\'une tempête commence à le défaire, Franck comprend que le « premier cycle » de Victor n\'est qu\'un début.' },
        de: { short: 'Einem lebensmüden Schaf auf einer windgepeitschten Insel bietet ein Verkäufer im Bademantel ein neues Leben an – und es stürzt in eine seltsame Welt.', long: 'Franck ist ein Schaf, das genug hat: genug Wind, genug Gras, genug Herde. Gerade als er allem ein Ende setzen will, taucht ein seltsamer Verkäufer namens Victor im Bademantel mit Aktenkoffer auf und macht ein Angebot – ein brandneues Leben, keine Fragen. Ein Gerät am Schwanz und einen Sprung von der Klippe später erwacht Franck verwandelt in einem üppigen, unmöglichen Wald, in dem eine geschwätzige Raupe namens Tara ihn unbedingt herumführen will. Doch die neue Welt ist weniger stabil, als sie aussieht, und als ein Sturm sie aufzulösen beginnt, erfährt Franck, dass Victors „erster Zyklus" nur der Anfang ist.' },
        ja: { short: '風の吹きすさぶ島で自殺を図る羊は、バスローブ姿のセールスマンから「新しい人生」を持ちかけられ、奇妙な世界へ転がり落ちる。', long: 'フランクは何もかもにうんざりした羊だ。風も、草も、群れも。すべてを終わらせようとしたその瞬間、バスローブにブリーフケースを持った奇妙なセールスマン、ヴィクターが現れ、「まったく新しい人生、質問は無用」と持ちかける。尻尾に装置を付けられ、崖から飛び込んだフランクは、姿を変えてあり得ないほど豊かな森で目を覚ます。そこではおしゃべりな毛虫のタラが案内役を買って出る。だが新しい世界は見た目ほど安定しておらず、嵐がそれをほどき始めたとき、フランクはヴィクターの言う「第一サイクル」が始まりにすぎないことを知る。' },
        pt: { short: 'Uma ovelha suicida numa ilha varrida pelo vento recebe a oferta de uma vida nova de um vendedor de roupão — e cai num mundo estranho.', long: 'Franck é uma ovelha que já teve o bastante: bastante vento, bastante capim, bastante rebanho. Bem quando tenta acabar com tudo, surge um vendedor estranho chamado Victor, de roupão e maleta, com uma oferta — uma vida novinha em folha, sem perguntas. Um dispositivo na cauda e um mergulho do penhasco depois, Franck acorda transformado numa floresta exuberante e impossível, onde uma lagarta tagarela chamada Tara faz questão de lhe mostrar tudo. Mas o novo mundo é menos estável do que parece, e quando uma tempestade começa a desfazê-lo, Franck descobre que o "primeiro ciclo" de Victor é só o começo.' },
        ar: { short: 'خروفٌ يائس على جزيرة تعصف بها الرياح يتلقّى عرضاً بحياة جديدة من بائع يرتدي روب حمّام، فيسقط في عالم غريب.', long: 'فرانك خروف سئم كل شيء: الريح والعشب والقطيع. وحين يحاول إنهاء حياته، يظهر بائع غريب يُدعى فيكتور بروب حمّام وحقيبة، ومعه عرض: حياة جديدة تماماً بلا أسئلة. بعد جهاز يُثبَّت على ذيله وقفزة من الجرف، يستيقظ فرانك متحوّلاً في غابة خصبة مستحيلة، حيث تصرّ يرقة ثرثارة اسمها تارا على أن تريه المكان. لكن العالم الجديد أقل استقراراً مما يبدو، وحين تبدأ عاصفة في تفكيكه، يدرك فرانك أن "الدورة الأولى" التي ذكرها فيكتور ليست سوى البداية.' },
        hi: { short: 'हवा से थपेड़े खाते द्वीप पर एक आत्महत्या को उतारू भेड़ को बाथरोब पहने सेल्समैन नई ज़िंदगी का ऑफर देता है — और वह एक अजीब दुनिया में जा गिरती है।', long: 'फ्रैंक एक भेड़ है जो सब कुछ से तंग आ चुका है: हवा से, घास से, झुंड से। जैसे ही वह सब खत्म करने की कोशिश करता है, बाथरोब और ब्रीफकेस के साथ विक्टर नाम का अजीब सेल्समैन प्रकट होता है और ऑफर देता है — बिल्कुल नई ज़िंदगी, कोई सवाल नहीं। पूँछ पर एक उपकरण और चट्टान से छलाँग के बाद फ्रैंक एक हरे-भरे, असंभव जंगल में बदले रूप में जागता है, जहाँ तारा नाम की बातूनी इल्ली उसे सब दिखाने पर अड़ी है। लेकिन नई दुनिया जितनी दिखती है उतनी स्थिर नहीं, और जब एक तूफ़ान उसे उधेड़ने लगता है, फ्रैंक समझता है कि विक्टर का "पहला चक्र" तो बस शुरुआत है।' },
        ko: { short: '바람 몰아치는 섬의 자살하려던 양에게 목욕 가운을 입은 세일즈맨이 새 인생을 제안하고, 양은 기묘한 세계로 굴러떨어진다.', long: '프랑크는 모든 것에 지친 양이다. 바람도, 풀도, 무리도 지긋지긋하다. 모든 것을 끝내려는 순간, 목욕 가운에 서류가방을 든 기묘한 세일즈맨 빅터가 나타나 제안한다. 완전히 새로운 인생, 질문은 없다고. 꼬리에 장치를 달고 절벽에서 뛰어내린 프랑크는 변신한 모습으로 무성하고 있을 수 없는 숲에서 깨어나고, 수다스러운 애벌레 타라가 안내를 자처한다. 그러나 새 세계는 보기보다 불안정하고, 폭풍이 세계를 풀어헤치기 시작하자 프랑크는 빅터가 말한 "첫 번째 순환"이 시작에 불과함을 알게 된다.' },
      },
    },
  },
  beats: [
    [0, -0.1, 0.2, 0.4, 'melancholy:0.7,curiosity:0.5,stillness:0.6', 'Title over a windswept island; gulls wheel over grey cliffs'],
    [20, -0.6, 0.18, 0.25, 'boredom:0.9,despair:0.7,ennui:0.85', 'Franck the sheep stares at the sea, utterly bored; the flock bleats behind him'],
    [50, -0.7, 0.45, 0.2, 'dark humour:0.85,despair:0.75,absurdity:0.7', 'Franck ties a rope to a scrawny tree and tries to hang himself; the branch bends comically'],
    [90, 0.05, 0.4, 0.4, 'surprise:0.8,curiosity:0.7,amusement:0.6', 'Victor appears in a bathrobe with a briefcase: "Wanna get a new life?"'],
    [125, 0.2, 0.42, 0.45, 'amusement:0.85,suspicion:0.6,curiosity:0.6', 'Victor pitches with salesman patter; Franck answers in deadpan monosyllables'],
    [160, -0.1, 0.55, 0.35, 'unease:0.7,anticipation:0.8,amusement:0.5', 'Victor straps a blinking device to Franck\'s tail and starts a countdown'],
    [195, -0.3, 0.85, 0.3, 'panic:0.8,amusement:0.7,adrenaline:0.8', 'Franck bolts; a frantic chase across the meadow as the device beeps faster'],
    [225, -0.5, 0.6, 0.15, 'shock:0.8,vertigo:0.7,silence:0.6', 'Franck goes over the cliff into the sea — bubbles, then silence'],
    [250, 0.5, 0.35, 0.4, 'wonder:0.9,confusion:0.7,awe:0.8', 'He wakes transformed in a lush, impossible forest of glowing plants'],
    [280, 0.55, 0.5, 0.45, 'amusement:0.8,affection:0.6,curiosity:0.7', 'Tara, a lively caterpillar, chatters at him nonstop; Franck is baffled'],
    [310, 0.75, 0.45, 0.55, 'wonder:0.9,delight:0.8,curiosity:0.7', 'They explore giant mushrooms and floating spores; Franck almost smiles'],
    [345, 0.3, 0.4, 0.5, 'intrigue:0.8,unease:0.5,hope:0.6', 'Tara hints this world is a "trial life"; Franck grows quietly curious'],
    [375, -0.4, 0.7, 0.3, 'dread:0.85,fear:0.7,awe:0.6', 'A storm rolls in; the forest begins to unravel into threads of light'],
    [405, -0.5, 0.85, 0.35, 'urgency:0.9,fear:0.75,determination:0.6', 'Victor\'s voice booms: the cycle is resetting; Franck grabs Tara and runs'],
    [440, -0.2, 0.95, 0.4, 'exhilaration:0.85,fear:0.7,chaos:0.8', 'They plunge through a howling vortex — the most kinetic sequence of the film'],
    [470, 0.4, 0.4, 0.5, 'relief:0.8,confusion:0.7,tenderness:0.6', 'Back on the island: Franck wakes as a sheep again, Tara beside him as a real caterpillar'],
    [500, 0.35, 0.45, 0.5, 'intrigue:0.85,amusement:0.6,anticipation:0.8', 'Victor, unruffled: "First cycle complete." — to be continued'],
    [530, 0.15, 0.2, 0.5, 'calm:0.7,reflection:0.5', 'End credits over the island; theme reprise'],
    [620, 0.1, 0.12, 0.5, 'calm:0.7,stillness:0.6', 'Credits continue: Gooseberry project crew and cloud subscribers'],
    [690, 0.0, 0.08, 0.5, 'stillness:0.8', 'Final Blender Institute card'],
  ],
  acts: [
    { name: 'The island', start: 0, end: 90, summary: 'Franck, bored to death, tries to hang himself.' },
    { name: 'The offer', start: 90, end: 250, summary: 'Victor sells him a new life; the device, the chase, the cliff.' },
    { name: 'The forest', start: 250, end: 375, summary: 'A transformed Franck explores an impossible forest with Tara.' },
    { name: 'The reset', start: 375, end: 500, summary: 'The world unravels; a vortex throws them back to the island.' },
    { name: 'Coda', start: 500, end: 730, summary: '"First cycle complete." Credits.' },
  ],
  climax: { at: 452, description: 'Franck and Tara are hurled through the collapsing vortex as the forest world dissolves around them.' },
  markers: [
    ['title_card', 2, 10, 'Title: COSMOS LAUNDROMAT — First Cycle', 0.92],
    ['chapter', 10, 90, 'Ch. 1 — The island', 0.85],
    ['chapter', 90, 250, 'Ch. 2 — The offer', 0.87],
    ['chapter', 250, 375, 'Ch. 3 — The forest', 0.84],
    ['chapter', 375, 500, 'Ch. 4 — The reset', 0.82],
    ['next_episode_hook', 500, 530, '"First cycle complete" — to be continued', 0.78],
    ['credits', 530, 730, 'End credits', 0.96],
  ],
  safety: [
    ['self_harm', 'high', 50, 88, 'The sheep protagonist attempts to hang himself from a tree; played as dark comedy, no injury.', 0.9],
    ['violence', 'low', 195, 240, 'Comic chase ending with the sheep falling off a cliff into the sea.', 0.66],
    ['flashing_lights', 'medium', 440, 468, 'Rapid light streaks and flicker during the vortex sequence.', 0.72],
  ],
  candidates: [
    [90, 0.84, 'scene_change', 'Victor\'s arrival cuts the suicide beat; new character, new cue.', 'Franck\'s failed hanging attempt', 'Victor appears with a briefcase', 'bleak:0.7,absurd:0.7,curious:0.6', 'island:0.8,tree:0.6,salesman:0.8,briefcase:0.6', [['IAB1-5', 'Movies', 2, 0.8]]],
    [160, 0.62, 'dialogue_gap', 'Pause after Victor\'s pitch before the device goes on.', 'Victor pitches a new life', 'The device is strapped to Franck\'s tail', 'amused:0.8,suspicious:0.6,curious:0.6', 'salesman:0.8,pitch:0.6,device:0.7,tail:0.5', [['IAB1-5', 'Movies', 2, 0.8], ['IAB22', 'Shopping', 1, 0.3]]],
    [250, 0.92, 'fade', 'Underwater silence fades to white before the forest reveal — cleanest break in the film.', 'Franck sinks into the sea', 'He wakes transformed in a glowing forest', 'still:0.8,wondrous:0.7,suspended:0.7', 'sea:0.7,bubbles:0.6,forest:0.8,transformation:0.7', [['IAB1-5', 'Movies', 2, 0.8], ['IAB9-30', 'Fantasy', 3, 0.5]]],
    [345, 0.7, 'scene_change', 'Cut from the mushroom exploration to Tara\'s reveal about the trial life.', 'Giant mushrooms and floating spores', 'Tara explains the trial life', 'wondrous:0.8,curious:0.7,hopeful:0.6', 'forest:0.8,mushrooms:0.7,caterpillar:0.7,trial:0.5', [['IAB1-5', 'Movies', 2, 0.8]]],
    [375, 0.66, 'music_end', 'Ambient forest cue ends as the storm rolls in.', 'Franck grows curious about the trial life', 'The storm begins to unravel the forest', 'uneasy:0.8,intrigued:0.6,ominous:0.7', 'storm:0.8,forest:0.7,threads of light:0.5', [['IAB1-5', 'Movies', 2, 0.8]]],
    [470, 0.8, 'scene_change', 'Cut from the vortex back to the island; silence and gulls.', 'Franck and Tara fall through the vortex', 'Franck wakes on the island as a sheep', 'relieved:0.8,confused:0.7,tender:0.5', 'island:0.9,sheep:0.8,caterpillar:0.7,vortex:0.5', [['IAB1-5', 'Movies', 2, 0.8]]],
  ],
  thumbnails: [
    [24, 'Franck the sheep staring blankly out to sea on a windswept cliff', ['Franck'], 'melancholic:0.9,deadpan:0.85,bleak:0.6', [0.94, 0.9, 0.8, 0.8, 0.55, 0.7], 'top-right', true, 0.45],
    [96, 'Victor in a bathrobe holding a briefcase beside a baffled Franck', ['Victor', 'Franck'], 'absurd:0.9,quirky:0.85,funny:0.7', [0.92, 0.86, 0.75, 0.78, 0.58, 0.55], 'top-left', true, 0.5],
    [312, 'Franck dwarfed by glowing giant mushrooms in the alien forest', ['Franck'], 'wondrous:0.95,dreamlike:0.9,magical:0.8', [0.9, 0.95, 0.4, 0.85, 0.5, 0.7], 'top-left', true, 0.5],
    [284, 'Tara the caterpillar mid-chatter, inches from Franck\'s nose', ['Tara', 'Franck'], 'playful:0.9,warm:0.7,funny:0.7', [0.85, 0.86, 0.85, 0.75, 0.58, 0.5], 'bottom-right', true, 0.5],
    [452, 'Franck and Tara hurled through the collapsing vortex', ['Franck', 'Tara'], 'exhilarating:0.9,chaotic:0.85,epic:0.7', [0.82, 0.88, 0.5, 0.25, 0.62, 0.5], 'top-left', true, 0.5],
    [378, 'The forest unravelling into threads of light as the storm hits', [], 'ominous:0.85,surreal:0.85,beautiful:0.7', [0.78, 0.92, 0.0, 0.5, 0.55, 0.85], 'bottom-left', true, 0.5],
    [4, 'The windswept island under a bruised sky, gulls wheeling', [], 'bleak:0.8,atmospheric:0.8,lonely:0.6', [0.7, 0.9, 0.0, 0.85, 0.5, 0.9], 'top-left', true, 0.5],
    [164, 'The blinking device strapped to Franck\'s tail, close-up', ['Franck'], 'quirky:0.8,tense:0.5,funny:0.6', [0.66, 0.8, 0.2, 0.85, 0.6, 0.6], 'top-right', true, 0.6],
    [200, 'Franck sprinting across the meadow, flock scattering', ['Franck', 'The Flock'], 'frantic:0.85,funny:0.8,chaotic:0.7', [0.74, 0.82, 0.45, 0.35, 0.68, 0.55], 'top-left', true, 0.4],
    [474, 'Franck waking on the grass with Tara on his nose, dawn light', ['Franck', 'Tara'], 'tender:0.85,hopeful:0.7,quiet:0.7', [0.86, 0.9, 0.8, 0.9, 0.62, 0.55], 'top-right', true, 0.5],
    [504, 'Victor, unruffled, snapping the briefcase shut', ['Victor'], 'intriguing:0.85,wry:0.8,mysterious:0.6', [0.8, 0.84, 0.88, 0.85, 0.5, 0.45], 'top-left', true, 0.55],
    [130, 'Victor mid-pitch, arms wide, sheep unimpressed', ['Victor', 'Franck'], 'comic:0.9,absurd:0.8,warm:0.4', [0.72, 0.8, 0.7, 0.72, 0.6, 0.5], 'bottom-left', true, 0.5],
  ],
  clips: [
    [90, 118, 'character intro', 0.92, ['Victor', 'Franck'], 'absurd:0.9,quirky:0.85,funny:0.75', 'salesman:0.9,bathrobe:0.7,briefcase:0.7,new life:0.8', true, '"Wanna get a new life?"', 96, [0.5, 0.5, 0.5]],
    [250, 278, 'world reveal', 0.9, ['Franck'], 'wondrous:0.95,dreamlike:0.9,magical:0.8', 'forest:0.9,glowing plants:0.8,transformation:0.7', true, 'Welcome to your new life', 262, [0.5, 0.45, 0.55]],
    [195, 222, 'action beat', 0.84, ['Franck', 'The Flock'], 'frantic:0.9,funny:0.8,chaotic:0.7', 'chase:0.9,meadow:0.7,device:0.7,cliff:0.7', true, 'Never trust a countdown', 200, [0.4, 0.5, 0.6]],
    [440, 466, 'action beat', 0.86, ['Franck', 'Tara'], 'exhilarating:0.9,chaotic:0.85,epic:0.7', 'vortex:0.9,storm:0.7,light:0.7', true, 'Hold on, Tara', 452, [0.5, 0.55, 0.5]],
    [20, 46, 'character intro', 0.78, ['Franck'], 'melancholic:0.9,deadpan:0.85,bleak:0.6', 'sheep:0.9,cliff:0.8,wind:0.7,ennui:0.7', true, 'Meet Franck. He is not okay.', 24, [0.45, 0.45, 0.45]],
    [500, 526, 'cliffhanger', 0.8, ['Victor', 'Franck', 'Tara'], 'intriguing:0.85,wry:0.8,hopeful:0.5', 'first cycle:0.8,briefcase:0.6,island:0.7,to be continued:0.7', true, 'First cycle complete', 504, [0.5, 0.5, 0.5]],
  ],
};

/* ------------------------------------------------------------------ */
/* Lists                                                               */
/* ------------------------------------------------------------------ */

const lists: SmartList[] = [
  {
    id: 'lst_melancholic-fantasy',
    name: 'Melancholic fantasy',
    description: 'Fantasy titles with a strong melancholic mood — for a rainy-day rail.',
    source: 'rules',
    rules: [
      { facet: 'genres', label: 'fantasy', min: 0.6, max: 1 },
      { facet: 'moods', label: 'melancholic', min: 0.6, max: 1 },
    ],
    itemIds: ['sintel', 'cosmos-laundromat'],
    coverage: 0.667,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
  },
  {
    id: 'lst_robots-and-machines',
    name: 'Robots & machines',
    description: 'Natural-language query: "robots taking over a city".',
    source: 'query',
    query: 'robots taking over a city',
    itemIds: ['tears-of-steel'],
    coverage: 0.333,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
  },
  {
    id: 'lst_family-safe-shorts',
    name: 'Brand-safe shorts',
    description: 'Shorts rated PG-13 or below with no high-severity self-harm segments; comedy-leaning.',
    source: 'rules',
    rules: [
      { facet: 'genres', label: 'animation', min: 0.5, max: 1 },
      { facet: 'moods', label: 'dark', min: 0, max: 0.75 },
    ],
    itemIds: ['sintel', 'cosmos-laundromat'],
    coverage: 0.667,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
  },
  {
    id: 'lst_ai-loss-and-letting-go',
    name: 'Loss and letting go',
    description: 'AI-curated cluster: titles sharing grief, regret and second chances.',
    source: 'ai',
    itemIds: ['sintel', 'tears-of-steel', 'cosmos-laundromat'],
    coverage: 1,
    createdAt: GENERATED_AT,
    updatedAt: GENERATED_AT,
  },
];

/* ------------------------------------------------------------------ */
/* Write                                                               */
/* ------------------------------------------------------------------ */

const here = dirname(fileURLToPath(import.meta.url));
const catalog = [sintel, tearsOfSteel, cosmos].map(assemble);
await writeFile(join(here, 'catalog.json'), JSON.stringify(catalog, null, 2) + '\n');
await writeFile(join(here, 'lists.json'), JSON.stringify(lists, null, 2) + '\n');
for (const b of catalog) {
  console.log(
    `${b.item.title.padEnd(20)} ${b.item.durationSec}s  samples=${b.emotions!.samples.length}  markers=${b.markers!.markers.length}  safety=${b.safety!.segments.length}  breaks=${b.adBreaks!.breaks.length}/${(b.adBreaks as { candidates: unknown[] }).candidates.length}  thumbs=${b.thumbnails!.length}  clips=${b.clips!.length}`,
  );
}
console.log(`wrote ${catalog.length} bundles + ${lists.length} lists`);
