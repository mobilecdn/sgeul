# @twelve-studio/api

Express 5 REST API + job runner + JSON store for Twelve Studio. One store serves the web
app, this API and the MCP server.

```
npm run dev -w @twelve-studio/api     # builds core, then tsx watch (port 8787)
npm run start -w @twelve-studio/api   # compiled: npm run build first
npm run seed -w @twelve-studio/api    # print seed + store stats
npm test -w @twelve-studio/api        # end-to-end tests in mock mode (temp store)
```

## Modes

| `TWELVELABS_API_KEY` | mode | what happens |
|---|---|---|
| unset | `mock` | `MockTwelveLabsClient` answers from `data/seed`; unknown URLs get deterministic `(mock)` data. Seed items get their (label-vector) embedding on boot. |
| set | `live` | `TwelveLabsClient` calls `https://api.twelvelabs.io/v1.3`. `TWELVELABS_INDEX_ID` reuses an index, otherwise one named `twelve-studio` is found/created and cached in the store. |

Other env (read from the repo-root `.env`): `PORT` (8787), `SYNOPSIS_LANGS`
(`es,fr,de,ja,pt,ar,hi,ko`), `JOB_CONCURRENCY` (2), `STORE_PATH` (`data/store.json`),
`SEED_DIR` (`data/seed`), `CORS_ORIGIN` (any), `MOCK_LATENCY_MS` (`120,480`).

## Layout

| file | role |
|---|---|
| `src/server.ts` | boot: config → store (+seed import on first run) → client → runner → routes |
| `src/config.ts` | `.env` + env → `ApiConfig`; mode = live iff a key is present |
| `src/store.ts` | in-memory Maps, debounced atomic write to `data/store.json`; implements core `PipelineStore` |
| `src/jobs.ts` | FIFO queue (concurrency 2) running `enrichItem` / recipe runs; SSE fan-out |
| `src/routes.ts` | every route in CONTRACT.md; errors are `{error:{code,message}}` |
| `src/exports.ts` | VMAP 1.0 (inline VAST 3.0 when a creative is assigned), SCTE-35-style splice JSON, player markers JSON |
| `src/media.ts` | local-path parsing (`/abs` or `file://`), HTTP Range streaming (`206`/`416`/`HEAD`) |
| `src/stitch.ts` | ffprobe/ffmpeg stitcher: keyframe snapping, cached ad transcode, stream-copied segments, concat (+ re-encode fallback), `StitchQueue` |
| `src/lists.ts` | rule filters, NL query (Marengo text embedding cosine + keyword fallback), k-means curation |
| `src/views.ts` | response shaping — embeddings never leave the API |
| `src/seed.ts` | `npm run seed` stats script |

## Routes

See `CONTRACT.md`. Notes beyond the contract:

- `POST /api/catalog` is idempotent on `sourceUrl`; the response items already show `jobs.*: 'queued'`.
- `POST /api/catalog/:id/jobs/:kind` → `202` + the queued `Job`. Any job runs `ingest` first when the
  item has no asset; `embedding` runs `fingerprint` first when none exists.
- `GET /api/catalog/:id/export/vmap?preroll=1&postroll=1&all=1` — approved breaks only by default;
  `all=1` includes every non-declined ranked break; `preroll`/`postroll` add `start`/`end` breaks.
- `GET /api/catalog/:id/export/scte35?duration=30` — `pts_time` is 90 kHz; same flags as VMAP.
- `GET /api/catalog/:id/export/markers` — `skipIntro`, `skipRecap`, `coldOpen`, `creditsStart/End`,
  `nextEpisodeAt`, `chapters[]`, plus the raw non-declined track. Declined markers are excluded;
  approved ones win over unreviewed ones of the same kind.
- `POST /api/catalog/:id/adbreaks/plan` re-plans from the stored Pegasus candidates (`adBreaks.candidates`)
  — pure function, no model call — and keeps ids + review state for breaks within ±2s.
- `PATCH …/markers/:mid` and `PATCH …/adbreaks/:bid` accept `Partial<ReviewState>`; new comments
  (no `id`) are appended, `status` changes stamp `reviewedAt`/`reviewedBy`.
- `POST /api/lists/curate` replaces all `source:'ai'` lists.
- `GET /api/runs` (all runs) exists next to `GET /api/runs/:id`.
- `GET /api/events` SSE: `{type:'job'|'item'|'run'|'stitch'|'log', …}` with a 25 s heartbeat.

### Local files, ad creatives, stitched previews (CONTRACT-ads.md)

- `POST /api/catalog` also accepts `sourceUrl` as an absolute path or `file://` URL: the item gets
  `localPath`, `playback.fileUrl = /api/catalog/:id/media` and ffprobed `durationSec/fps/width/height`
  (stored `sourceUrl` is the canonical `file://` form). A local `posterUrl` is served at `…/poster`.
  Live mode uploads local files with `POST /assets` `method=direct` (≤ 200 MB, else `file_too_large`).
- `GET/HEAD /api/catalog/:id/media`, `/api/ads/:id/media`, `/api/renders/:file` support `Range: bytes=`.
- `GET|POST /api/ads`, `GET|DELETE /api/ads/:id` — `{name, advertiser?, sourceUrl?|localPath?, durationSec?}`;
  local creatives are ffprobed. Deleting a creative unassigns it from every break.
- `POST /api/catalog/:id/adbreaks/assign` `{creativeId|null, breakIds?}` → `AdBreakPlan`.
- `POST /api/catalog/:id/stitch` `{creativeId?, breakIds?, includeUnapproved?, dryRun?}` → `202` + `StitchJob`;
  `GET /api/stitch/:id`, `GET /api/stitch?itemId=`. Renders are serialised (one ffmpeg pipeline at a time),
  written to `data/renders/<itemId>-<ts>.mp4` (`RENDERS_DIR`), the ad transcode cached under `data/renders/cache/`.
  Fail-fast codes: `needs_local_file` (409), `stitch_unavailable` (503, no ffmpeg), `no_breaks`, `no_creative`.
  `job.log` records which concat path ran (stream copy vs. full re-encode fallback) and the ffmpeg stderr tail on failure.

## TwelveLabs calls behind each endpoint

| endpoint | TwelveLabs |
|---|---|
| `POST /api/catalog` (pipeline) | `POST /assets` → `GET /assets/:id` → `POST/GET /indexes/:id/indexed-assets` (marengo3.0); `POST /analyze` ×7 (pegasus1.5, `response_format: json_schema`); `POST /embed-v2` (marengo3.5). `/analyze/tasks` + `/embed-v2/tasks` for assets over 1 h. |
| `POST /api/search` | `POST /search` (multipart, `group_by=clip`) / `GET /search/:page_token` |
| `POST /api/lists` (query) | `POST /embed-v2` (text) then cosine vs stored video embeddings |
| `POST /api/lists/curate`, `GET …/similar`, `…/adbreaks/plan`, exports | none — pure functions over the store |
| `POST /api/recipes/:id/run` | `POST /analyze` with the brief injected into the thumbnails/clips prompt |
