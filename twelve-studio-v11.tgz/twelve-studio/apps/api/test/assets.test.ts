/**
 * TwelveLabs account sync: GET /api/twelvelabs/assets and POST /api/catalog/import,
 * in mock mode against the real `GET /v1.3/assets` capture in data/seed.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import type { Server } from 'node:http';
import { createApp, type App } from '../src/server.js';
import { loadConfig } from '../src/config.js';

let app: App;
let server: Server;
let base: string;
let dir: string;

const json = async (path: string, init: RequestInit = {}) => {
  const res = await fetch(`${base}${path}`, { ...init, headers: { 'content-type': 'application/json', ...(init.headers ?? {}) } });
  const text = await res.text();
  return { status: res.status, body: text ? (JSON.parse(text) as any) : undefined };
};

const GROK = '6aa58b4a00835252079bd128'; // grok4.mp4 — ready, linked to the seeded "Grok 4" promo
const PROCESSING = '6aa4fc2d360070e111bec7e2'; // DavidandGoliath1960.mp4 — still processing
const SINTEL_ASSET = '6aa4ff2f360070e111bec8bd'; // linked to the seeded "Sintel" title
const BUENO_30 = '6aa58b4a19212bdafaeadefa'; // linked to the seeded 30s creative

before(async () => {
  dir = await mkdtemp(join(tmpdir(), 'twelve-assets-'));
  const config = loadConfig({ ...process.env, TWELVELABS_API_KEY: '', STORE_PATH: join(dir, 'store.json'), MOCK_LATENCY_MS: '0', PORT: '0' });
  app = await createApp(config);
  server = app.app.listen(0);
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
  await app.runner.idle();
});

after(async () => {
  server.close();
  await app.close();
  await rm(dir, { recursive: true, force: true });
});

test('GET /twelvelabs/assets lists the 8 account assets with linkage for 5 titles + 2 ads', async () => {
  const { status, body } = await json('/twelvelabs/assets');
  assert.equal(status, 200);
  assert.equal(body.assets.length, 8);
  assert.deepEqual(body.pageInfo, { page: 1, limitPerPage: 50, totalPage: 1, totalResults: 8 });

  const byId = new Map<string, any>(body.assets.map((a: any) => [a._id, a]));
  const linked = body.assets.filter((a: any) => a.linked);
  assert.equal(linked.filter((a: any) => a.linked.kind === 'title').length, 5);
  assert.equal(linked.filter((a: any) => a.linked.kind === 'ad').length, 2);
  assert.deepEqual(byId.get(SINTEL_ASSET).linked, { kind: 'title', id: 'sintel', title: 'Sintel' });
  assert.deepEqual(byId.get(BUENO_30).linked, { kind: 'ad', id: 'ad_kinder-bueno-30', title: 'Kinder Bueno 30s' });
  assert.deepEqual(byId.get(GROK).linked, { kind: 'title', id: 'grok4', title: 'Grok 4' });
  assert.equal(byId.get(PROCESSING).linked, undefined);
  assert.equal(byId.get(PROCESSING).status, 'processing');
  assert.equal(byId.get(PROCESSING).duration, null);
  // Wire fields pass through untouched.
  assert.equal(byId.get(GROK).filename, 'grok4.mp4');
  assert.match(byId.get(GROK).hls.manifest_url, /\/hlses\/playlist\.m3u8$/);
  assert.equal(byId.get(GROK).size, 12623666);

  // Paging is honoured.
  const page2 = await json('/twelvelabs/assets?page=2&pageLimit=3');
  assert.equal(page2.body.assets.length, 3);
  assert.equal(page2.body.pageInfo.totalPage, 3);
  assert.equal(page2.body.pageInfo.page, 2);
});

test('POST /catalog/import validates the batch shape', async () => {
  for (const body of [{}, { items: [] }, { items: [{ as: 'title' }] }, { items: [{ assetId: GROK, as: 'nope' }] }, { items: [{ assetId: GROK, as: 'title', type: 'trailer' }] }]) {
    const r = await json('/catalog/import', { method: 'POST', body: JSON.stringify(body) });
    assert.equal(r.status, 400, JSON.stringify(body));
    assert.equal(r.body.error.code, 'bad_request');
  }
});

test('import: grok4 as a title creates an item with HLS playback + queued jobs; linked and processing assets are reported per item', async () => {
  // Free the asset for this test by removing its seeded title (the seed is only re-imported at boot).
  assert.equal((await fetch(`${base}/catalog/grok4`, { method: 'DELETE' })).status, 204);
  const before = (await json('/catalog')).body.length;
  const { status, body } = await json('/catalog/import', {
    method: 'POST',
    body: JSON.stringify({
      items: [
        { assetId: GROK, as: 'title', type: 'promo' },
        { assetId: SINTEL_ASSET, as: 'title' },
        { assetId: BUENO_30, as: 'ad' },
        { assetId: PROCESSING, as: 'title' },
        { assetId: 'ffffffffffffffffffffffff', as: 'title' },
      ],
    }),
  });
  assert.equal(status, 201);

  // The one importable asset became a title.
  assert.equal(body.items.length, 1);
  assert.equal(body.ads.length, 0);
  const item = body.items[0];
  assert.equal(item.title, 'grok4');
  assert.equal(item.type, 'promo');
  assert.deepEqual(item.upstream, { assetId: GROK });
  assert.match(item.playback.hlsUrl, new RegExp(`/assets/${GROK}/hlses/playlist\\.m3u8$`));
  assert.equal(item.sourceUrl, item.playback.hlsUrl);
  assert.match(item.posterUrl, /thumbnails\/5\.jpeg$/);
  assert.equal(item.durationSec, 65.8);
  assert.equal(item.fps, 30);
  assert.equal(item.width, 1280);
  assert.equal(item.height, 720);
  assert.equal(item.status, 'ingesting');
  const queued = Object.values(item.jobs as Record<string, string>);
  assert.ok(queued.length >= 9 && queued.every((s) => s === 'queued' || s === 'running'), JSON.stringify(item.jobs));

  // Already-linked assets are skipped, with what they are linked to.
  assert.deepEqual(
    body.skipped.map((s: any) => [s.assetId, s.linked.kind, s.linked.id]),
    [
      [SINTEL_ASSET, 'title', 'sintel'],
      [BUENO_30, 'ad', 'ad_kinder-bueno-30'],
    ],
  );

  // Not-ready and unknown assets are per-item errors, not a 4xx for the batch.
  assert.equal(body.errors.length, 2);
  const notReady = body.errors.find((e: any) => e.assetId === PROCESSING);
  assert.equal(notReady.error.code, 'asset_not_ready');
  assert.match(notReady.error.message, /processing/);
  assert.equal(body.errors.find((e: any) => e.assetId === 'ffffffffffffffffffffffff').error.code, 'asset_not_found');

  // The catalog grew by exactly one and the asset now shows as linked.
  assert.equal((await json('/catalog')).body.length, before + 1);
  const listing = (await json('/twelvelabs/assets')).body.assets.find((a: any) => a._id === GROK);
  assert.deepEqual(listing.linked, { kind: 'title', id: item.id, title: 'grok4' });

  // Mock mode runs the full enrichment; the ingest job reused the asset id (no mock- upload id).
  await app.runner.idle();
  const bundle = (await json(`/catalog/${item.id}`)).body;
  assert.equal(bundle.item.status, 'ready');
  assert.equal(bundle.item.upstream.assetId, GROK);
  assert.equal(bundle.item.playback.hlsUrl, item.playback.hlsUrl);
  assert.ok(bundle.fingerprint);
  assert.ok(bundle.emotions.samples.length > 0);
  const ingest = bundle.jobs.find((j: any) => j.kind === 'ingest');
  assert.equal(ingest.status, 'ready');
  assert.equal(ingest.upstream.assetId, GROK);

  // Re-importing the same asset is now a skip.
  const again = await json('/catalog/import', { method: 'POST', body: JSON.stringify({ items: [{ assetId: GROK, as: 'ad' }] }) });
  assert.equal(again.status, 201);
  assert.equal(again.body.items.length + again.body.ads.length, 0);
  assert.equal(again.body.skipped[0].linked.id, item.id);
});

test('import as an ad creative uses the HLS manifest as media and links the asset', async () => {
  const TEARS_ASSET = '6aa4fef89d661f14217cf887'; // linked to a title → skipped
  const COSMOS_ASSET = '6aa4ff690e5ec23e8c6237e9';
  // Free a ready asset for this test by removing its seeded title.
  const del = await fetch(`${base}/catalog/cosmos-laundromat`, { method: 'DELETE' });
  assert.equal(del.status, 204);

  const { status, body } = await json('/catalog/import', {
    method: 'POST',
    body: JSON.stringify({ items: [{ assetId: COSMOS_ASSET, as: 'ad', title: 'Cosmos spot', advertiser: 'Blender' }, { assetId: TEARS_ASSET, as: 'ad' }] }),
  });
  assert.equal(status, 201);
  assert.equal(body.items.length, 0);
  assert.equal(body.ads.length, 1);
  const ad = body.ads[0];
  assert.match(ad.id, /^ad_/);
  assert.equal(ad.name, 'Cosmos spot');
  assert.equal(ad.advertiser, 'Blender');
  assert.equal(ad.durationSec, 730.581);
  assert.equal(ad.width, 2048);
  assert.equal(ad.height, 858);
  assert.match(ad.mediaUrl, new RegExp(`/assets/${COSMOS_ASSET}/hlses/playlist\\.m3u8$`));
  assert.equal(ad.sourceUrl, ad.mediaUrl);
  assert.deepEqual(ad.upstream, { assetId: COSMOS_ASSET });
  assert.equal(body.skipped[0].assetId, TEARS_ASSET);
  assert.equal(body.skipped[0].linked.kind, 'title');

  assert.ok((await json('/ads')).body.some((a: any) => a.id === ad.id));
  const listing = (await json('/twelvelabs/assets')).body.assets.find((a: any) => a._id === COSMOS_ASSET);
  assert.deepEqual(listing.linked, { kind: 'ad', id: ad.id, title: 'Cosmos spot' });
});
