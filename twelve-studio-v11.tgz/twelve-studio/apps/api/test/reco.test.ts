/**
 * Recommendation API in mock mode: events in, ranked titles and rows out.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import type { Server } from 'node:http';
import { createApp, type App } from '../src/server.js';
import { loadConfig } from '../src/config.js';

let app: App;
let server: Server;
let base: string;
let dir: string;
let ids: string[] = [];

const json = async (path: string, init: RequestInit = {}) => {
  const res = await fetch(`${base}${path}`, { ...init, headers: { 'content-type': 'application/json', ...(init.headers ?? {}) } });
  const text = await res.text();
  return { status: res.status, body: text ? (JSON.parse(text) as any) : undefined };
};

before(async () => {
  dir = await mkdtemp(join(tmpdir(), 'twelve-reco-'));
  const config = loadConfig({ ...process.env, TWELVELABS_API_KEY: '', STORE_PATH: join(dir, 'store.json'), MOCK_LATENCY_MS: '0', PORT: '0' });
  app = await createApp(config);
  server = app.app.listen(0);
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
  await app.runner.idle();
  ids = ((await json('/catalog')).body as Array<{ id: string }>).map((i) => i.id);
  assert.ok(ids.length >= 2, 'the seeded catalog has titles to recommend');
});

after(async () => {
  server.close();
  await app.close();
  await rm(dir, { recursive: true, force: true });
});

test('weights are readable, patchable and resettable', async () => {
  const initial = await json('/reco/weights');
  assert.equal(initial.status, 200);
  assert.equal(initial.body.custom, false);
  assert.equal(initial.body.weights.combo, initial.body.defaults.combo);

  const put = await json('/reco/weights', { method: 'PUT', body: JSON.stringify({ combo: 2.4, facets: { genres: 1.5 }, diversity: 0.6 }) });
  assert.equal(put.body.weights.combo, 2.4);
  assert.equal(put.body.weights.facets.genres, 1.5);
  assert.equal(put.body.weights.facets.keywords, initial.body.defaults.facets.keywords, 'unspecified facets keep their default');

  const clamped = await json('/reco/weights', { method: 'PUT', body: JSON.stringify({ combo: 99 }) });
  assert.equal(clamped.body.weights.combo, 3, 'out-of-range values are clamped, not rejected');

  const reset = await json('/reco/weights/reset', { method: 'POST' });
  assert.equal(reset.body.custom, false);
  assert.equal((await json('/reco/weights')).body.weights.combo, initial.body.defaults.combo);
});

test('watch events build a profile and drive recommendations', async () => {
  const [first, second] = ids;
  const posted = await json('/reco/events?profileId=tester', {
    method: 'POST',
    body: JSON.stringify([{ itemId: first, action: 'watch', completion: 0.92 }]),
  });
  assert.equal(posted.status, 200);
  assert.equal(posted.body[0].profileId, 'tester');
  assert.ok(posted.body[0].id.startsWith('wev_'));

  const profile = await json('/reco/profile/tester');
  assert.equal(profile.status, 200);
  assert.equal(profile.body.events, 1);
  assert.ok(profile.body.top.length > 0, 'the profile picked up labels from the fingerprint');
  assert.equal(profile.body.vector, undefined, 'vectors are not sent to clients');

  const profiles = await json('/reco/profiles');
  assert.ok(profiles.body.some((p: { profileId: string }) => p.profileId === 'tester'));

  const home = await json('/reco/home?profileId=tester');
  assert.equal(home.status, 200);
  assert.ok(home.body.rails.length > 0, 'the viewer gets rows');
  for (const rail of home.body.rails) {
    assert.ok(rail.items.length > 0, `row ${rail.id} is not empty`);
    assert.ok(typeof rail.reason === 'string' && rail.reason.length > 0);
    assert.ok(!rail.items.some((i: { itemId: string }) => i.itemId === first) || rail.kind === 'continue', 'a watched title is not recommended back');
  }

  const next = await json(`/catalog/${second}/recommendations?profileId=tester&limit=3`);
  assert.equal(next.status, 200);
  assert.equal(next.body.seedId, second);
  assert.ok(next.body.items.length > 0);
  assert.ok(!next.body.items.some((i: { itemId: string }) => i.itemId === second), 'the title playing is excluded');
  assert.ok(next.body.items.every((i: { because: string[] }) => Array.isArray(i.because)), 'every pick is explained');
});

test('unknown titles and bad events are rejected', async () => {
  assert.equal((await json('/reco/events', { method: 'POST', body: JSON.stringify({ itemId: 'nope' }) })).status, 404);
  assert.equal((await json('/reco/events', { method: 'POST', body: JSON.stringify({ action: 'watch' }) })).status, 400);
  assert.equal((await json('/reco/events', { method: 'POST', body: JSON.stringify({ itemId: ids[0], action: 'teleport' }) })).status, 400);
  assert.equal((await json(`/catalog/nope/recommendations`)).status, 404);
});

test('simulate scores a hypothetical history without persisting it', async () => {
  const before = (await json('/reco/events?profileId=ghost')).body.length;
  const sim = await json('/reco/simulate', {
    method: 'POST',
    body: JSON.stringify({
      profileId: 'ghost',
      events: [{ itemId: ids[0], action: 'watch', completion: 1 }],
      weights: { combo: 3, diversity: 0 },
      seedId: ids[0],
      limit: 5,
    }),
  });
  assert.equal(sim.status, 200);
  assert.equal(sim.body.weights.combo, 3);
  assert.ok(sim.body.rails.length > 0);
  assert.ok(sim.body.next.length > 0, 'up-next is returned when a seed is given');
  assert.equal((await json('/reco/events?profileId=ghost')).body.length, before, 'nothing was written');
  assert.equal((await json('/reco/weights')).body.custom, false, 'the app weighting is untouched');
});

test('a viewer can be forgotten', async () => {
  await json('/reco/events?profileId=temp', { method: 'POST', body: JSON.stringify({ itemId: ids[0], action: 'like' }) });
  assert.equal((await json('/reco/events?profileId=temp')).body.length, 1);
  const del = await fetch(`${base}/reco/events?profileId=temp`, { method: 'DELETE' });
  assert.equal(del.status, 200);
  assert.equal((await json('/reco/events?profileId=temp')).body.length, 0);
});
