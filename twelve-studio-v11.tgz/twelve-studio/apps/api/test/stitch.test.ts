/**
 * Stitcher tests against real synthetic media (ffmpeg on PATH). Keyframe
 * snapping, insertion ordering, cached ad transcode, stream-copy concat and
 * the re-encode fallback; plus the ffmpeg-free dry run.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { readdir, rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import type { AdBreak, AdCreative, CatalogItem, StitchJob } from '@twelve-studio/core';
import { listKeyframes, nearestKeyframe, planInsertions, probeMedia, runStitch } from '../src/stitch.js';
import { ffmpegAvailable, makeSyntheticMedia, probeDuration, type SyntheticMedia } from './synthetic.js';

const HAS_FFMPEG = await ffmpegAvailable();
const SKIP = HAS_FFMPEG ? false : 'ffmpeg not installed';
let media: SyntheticMedia | undefined;

before(async () => {
  media = await makeSyntheticMedia('twelve-stitch-');
});

after(async () => {
  if (media) await rm(media.dir, { recursive: true, force: true });
});

const brk = (id: string, at: number, window: [number, number], extra: Partial<AdBreak> = {}): AdBreak => ({
  id,
  at,
  window: { start: window[0], end: window[1] },
  rank: 1,
  confidence: 0.9,
  reason: 'test',
  sceneBefore: '',
  sceneAfter: '',
  mood: {},
  keywords: {},
  iab: [],
  brandSafety: { suitable: true, flags: {} },
  ...extra,
});

const itemFor = (path: string | undefined): CatalogItem => ({
  id: 'synthetic-movie',
  title: 'Synthetic movie',
  type: 'movie',
  sourceUrl: path ? `file://${path}` : 'https://example.com/movie.mp4',
  localPath: path,
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z',
  status: 'ready',
  jobs: {},
});

const creativeFor = (path: string | undefined): AdCreative => ({
  id: 'ad-test',
  name: 'Test spot 3s',
  durationSec: 3,
  localPath: path,
  mediaUrl: '/api/ads/ad-test/media',
  createdAt: '2026-01-01T00:00:00.000Z',
});

const newJob = (id = 'stitch-test'): StitchJob => ({ id, itemId: 'synthetic-movie', creativeId: 'ad-test', status: 'queued', insertions: [], createdAt: '2026-01-01T00:00:00.000Z' });

test('nearestKeyframe picks the closest (earlier on ties)', () => {
  assert.equal(nearestKeyframe([18, 19, 20, 21, 22], 20.3), 20);
  assert.equal(nearestKeyframe([18, 19, 20, 21, 22], 20.5), 20);
  assert.equal(nearestKeyframe([18, 19, 20, 21, 22], 20.51), 21);
  assert.equal(nearestKeyframe([], 5), undefined);
});

test('planInsertions snaps inside the window, falls back to the nearest overall, and orders by time', async () => {
  // Fake keyframe index: every 2 s from 0..60.
  const all = Array.from({ length: 31 }, (_, i) => i * 2);
  const calls: Array<[number, number]> = [];
  const keyframesIn = async (s: number, e: number) => {
    calls.push([s, e]);
    return all.filter((k) => k >= s && k <= e);
  };
  const breaks = [
    brk('b-late', 41, [40, 43]), // → 42 (nearest of 40/42 to 41 is a tie → 40)
    brk('b-early', 20.9, [20.2, 21.8]), // no keyframe in [20.2, 21.8] → widen → 20 (0.9 away) vs 22 (1.1 away) → 20
    brk('b-edge', 0.2, [0, 0.5]), // → keyframe 0 → at the edge → skipped
  ];
  const ins = await planInsertions(breaks, keyframesIn, 60);
  assert.deepEqual(
    ins.map((i) => [i.breakId, i.snappedAt]),
    [
      ['b-early', 20],
      ['b-late', 40],
    ],
  );
  assert.ok(ins.every((i, k) => k === 0 || i.snappedAt >= ins[k - 1]!.snappedAt), 'time-ordered');
  // Window lookup first, then the widened lookup for the break without a keyframe in its window.
  assert.deepEqual(calls[0], [0, 0.5]);
  assert.ok(calls.some(([s, e]) => s === 20.2 && e === 21.8));
  assert.ok(calls.some(([s, e]) => s < 20.2 && e > 21.8));
});

test('dry run computes insertions without ffmpeg', async () => {
  const job = await runStitch(newJob('stitch-dry'), {
    item: itemFor(undefined),
    creative: creativeFor(undefined),
    breaks: [brk('b2', 40.7, [38, 44]), brk('b1', 20.3, [18, 23]), brk('b0', 10, [12, 14])],
    rendersDir: '/nonexistent/renders',
    dryRun: true,
  });
  assert.equal(job.status, 'ready');
  assert.deepEqual(
    job.insertions.map((i) => [i.breakId, i.snappedAt]),
    [
      ['b0', 12], // clamped into its window
      ['b1', 20.3],
      ['b2', 40.7],
    ],
  );
  assert.equal(job.outputUrl, undefined);
});

test('listKeyframes uses -read_intervals and returns keyframes inside the window only', { skip: SKIP }, async () => {
  const info = await probeMedia(media!.movie);
  assert.ok(Math.abs(info.durationSec - 60) < 0.2);
  assert.equal(info.video?.width, 320);
  assert.equal(info.video?.fps, 24);
  assert.equal(info.audio?.sampleRate, 48000);
  const kf = await listKeyframes(media!.movie, 18, 23, info.startTime);
  assert.deepEqual(kf, [18, 19, 20, 21, 22, 23]);
});

test('stitch: two insertions snapped to keyframes inside their windows; output ≈ 60 + 2×3 s', { skip: SKIP }, async () => {
  const rendersDir = join(media!.dir, 'renders');
  const events: string[] = [];
  const job = await runStitch(newJob('stitch-copy'), {
    item: itemFor(media!.movie),
    creative: creativeFor(media!.ad),
    breaks: [brk('b2', 40.7, [38, 44]), brk('b1', 20.3, [18, 23])],
    rendersDir,
    onProgress: (j, note) => events.push(`${j.status}${note ? ` ${note}` : ''}`),
  });
  assert.equal(job.status, 'ready', job.error ?? job.log);
  assert.equal(job.insertions.length, 2);
  assert.deepEqual(
    job.insertions.map((i) => i.breakId),
    ['b1', 'b2'],
    'time order',
  );
  const [i1, i2] = job.insertions as [StitchJob['insertions'][number], StitchJob['insertions'][number]];
  assert.equal(i1.requestedAt, 20.3);
  assert.equal(i1.snappedAt, 20, 'nearest 1 s keyframe to 20.3');
  assert.equal(i2.requestedAt, 40.7);
  assert.equal(i2.snappedAt, 41, 'nearest 1 s keyframe to 40.7');
  assert.ok(i1.snappedAt >= 18 && i1.snappedAt <= 23);
  assert.ok(i2.snappedAt >= 38 && i2.snappedAt <= 44);

  assert.ok(job.outputPath && job.outputUrl?.startsWith('/api/renders/'));
  const duration = await probeDuration(job.outputPath!);
  assert.ok(Math.abs(duration - 66) < 0.5, `duration ${duration}`);
  assert.ok(Math.abs((job.durationSec ?? 0) - 66) < 0.5);
  assert.match(job.log ?? '', /stream copy \(-f concat -c copy\)/, 'copy path logged');

  // The output has the movie's format; the ad was scaled+padded and fps-converted.
  const out = await probeMedia(job.outputPath!);
  assert.equal(out.video?.width, 320);
  assert.equal(out.video?.height, 240);
  assert.equal(out.audio?.sampleRate, 48000);
  assert.equal(out.audio?.channels, 2);

  // Cached ad transcode exists and matches the movie format.
  const cache = await readdir(join(rendersDir, 'cache'));
  assert.deepEqual(cache, ['ad-test-320x240-24.mp4']);
  const ad = await probeMedia(join(rendersDir, 'cache', cache[0]!));
  assert.equal(ad.video?.width, 320);
  assert.equal(ad.video?.fps, 24);
  assert.equal(ad.audio?.channels, 2);
  assert.ok(Math.abs(ad.durationSec - 3) < 0.15);

  // Progress went queued → running → ready and the temp dir was cleaned.
  assert.equal(events[0]?.split(' ')[0], 'running');
  assert.equal(events.at(-1)?.split(' ')[0], 'ready');
  await assert.rejects(stat(join(rendersDir, 'tmp', 'stitch-copy')));

  // Second run hits the cache.
  const again = await runStitch(newJob('stitch-cache'), { item: itemFor(media!.movie), creative: creativeFor(media!.ad), breaks: [brk('b1', 20.3, [18, 23])], rendersDir });
  assert.equal(again.status, 'ready', again.error);
  assert.match(again.log ?? '', /cache hit/);
  assert.ok(Math.abs((again.durationSec ?? 0) - 63) < 0.5);
});

test('stitch: re-encode fallback produces the same length', { skip: SKIP }, async () => {
  const rendersDir = join(media!.dir, 'renders-reencode');
  const job = await runStitch(newJob('stitch-reencode'), {
    item: itemFor(media!.movie),
    creative: creativeFor(media!.ad),
    breaks: [brk('b1', 30.4, [28, 33])],
    rendersDir,
    concat: 'reencode',
  });
  assert.equal(job.status, 'ready', job.error ?? job.log);
  assert.match(job.log ?? '', /full re-encode/);
  assert.equal(job.insertions[0]?.snappedAt, 30);
  assert.ok(Math.abs((job.durationSec ?? 0) - 63) < 0.5, `duration ${job.durationSec}`);
});

test('stitch: clear errors without a local file or with a missing creative', { skip: SKIP }, async () => {
  const noFile = await runStitch(newJob('stitch-nofile'), { item: itemFor(undefined), creative: creativeFor(media!.ad), breaks: [brk('b1', 20, [18, 23])], rendersDir: join(media!.dir, 'r2') });
  assert.equal(noFile.status, 'failed');
  assert.match(noFile.error ?? '', /^needs_local_file/);
  const badAd = await runStitch(newJob('stitch-badad'), { item: itemFor(media!.movie), creative: creativeFor(join(media!.dir, 'missing.mp4')), breaks: [brk('b1', 20, [18, 23])], rendersDir: join(media!.dir, 'r2') });
  assert.equal(badAd.status, 'failed');
  assert.match(badAd.error ?? '', /probe_failed|transcode_failed/);
  assert.ok(badAd.log && badAd.log.length > 0, 'ffmpeg log kept');
});
