/**
 * Ad creatives, local ingest, Range streaming, assignment, inline-VAST VMAP
 * and stitched previews through the REST API (mock mode, synthetic media).
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import type { Server } from 'node:http';
import type { AdBreak } from '@twelve-studio/core';
import { createApp, type App } from '../src/server.js';
import { loadConfig } from '../src/config.js';
import { ffmpegAvailable, makeSyntheticMedia, type SyntheticMedia } from './synthetic.js';

const HAS_FFMPEG = await ffmpegAvailable();
const SKIP = HAS_FFMPEG ? false : 'ffmpeg not installed';

let app: App;
let server: Server;
let base: string;
let origin: string;
let dir: string;
let media: SyntheticMedia | undefined;

const json = async (path: string, init: RequestInit = {}) => {
  const res = await fetch(`${base}${path}`, { ...init, headers: { 'content-type': 'application/json', ...(init.headers ?? {}) } });
  const text = await res.text();
  return { status: res.status, body: text ? (JSON.parse(text) as any) : undefined, text, headers: res.headers };
};

const brk = (id: string, at: number, window: [number, number], extra: Partial<AdBreak> = {}): AdBreak => ({
  id,
  at,
  window: { start: window[0], end: window[1] },
  rank: 1,
  confidence: 0.9,
  reason: 'test',
  sceneBefore: 'before',
  sceneAfter: 'after',
  mood: { calm: 0.8 },
  keywords: {},
  iab: [],
  brandSafety: { suitable: true, flags: {} },
  ...extra,
});

before(async () => {
  dir = await mkdtemp(join(tmpdir(), 'twelve-ads-'));
  media = await makeSyntheticMedia('twelve-ads-media-');
  const config = loadConfig({ ...process.env, TWELVELABS_API_KEY: '', STORE_PATH: join(dir, 'store.json'), RENDERS_DIR: join(dir, 'renders'), MOCK_LATENCY_MS: '0', PORT: '0' });
  app = await createApp(config);
  server = app.app.listen(0);
  origin = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  base = `${origin}/api`;
  await app.runner.idle();
});

after(async () => {
  server.close();
  await app.close();
  await rm(dir, { recursive: true, force: true });
  if (media) await rm(media.dir, { recursive: true, force: true });
});

test('ads CRUD: URL creative, validation, delete', async () => {
  // The seed ships two Kinder Bueno creatives, each linked to its TwelveLabs asset.
  const seeded = await json('/ads');
  assert.equal(seeded.status, 200);
  assert.deepEqual(
    seeded.body.map((a: any) => [a.id, a.upstream?.assetId]),
    [
      ['ad_kinder-bueno-30', '6aa58b4a19212bdafaeadefa'],
      ['ad_kinder-bueno-10', '6aa58b4a19212bdafaeadefc'],
    ],
  );
  const seededCount = seeded.body.length;

  const bad = await json('/ads', { method: 'POST', body: JSON.stringify({ name: 'x' }) });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.error.code, 'bad_request');

  const created = await json('/ads', { method: 'POST', body: JSON.stringify({ name: 'Web spot', advertiser: 'ACME', sourceUrl: 'https://cdn.example.com/spots/acme-15.mp4', durationSec: 15 }) });
  assert.equal(created.status, 201);
  assert.match(created.body.id, /^ad_/);
  assert.equal(created.body.mediaUrl, 'https://cdn.example.com/spots/acme-15.mp4');
  assert.equal(created.body.sourceUrl, 'https://cdn.example.com/spots/acme-15.mp4');
  assert.equal(created.body.durationSec, 15);
  assert.equal(created.body.localPath, undefined);

  const list = await json('/ads');
  assert.equal(list.body.length, seededCount + 1);
  const one = await json(`/ads/${created.body.id}`);
  assert.equal(one.body.name, 'Web spot');

  // Media of a URL creative redirects to the source.
  const media = await fetch(`${base}/ads/${created.body.id}/media`, { redirect: 'manual' });
  assert.equal(media.status, 302);
  assert.equal(media.headers.get('location'), 'https://cdn.example.com/spots/acme-15.mp4');

  const del = await fetch(`${base}/ads/${created.body.id}`, { method: 'DELETE' });
  assert.equal(del.status, 204);
  assert.equal((await json('/ads')).body.length, seededCount);
  assert.equal((await json(`/ads/${created.body.id}`)).status, 404);

  const missing = await json('/ads', { method: 'POST', body: JSON.stringify({ name: 'nope', localPath: join(dir, 'does-not-exist.mp4') }) });
  assert.equal(missing.status, 400);
  assert.equal(missing.body.error.code, 'file_not_found');
});

let adId = '';
let itemId = '';

test('ads: local creative is probed (duration, dimensions) and streamed with Range', { skip: SKIP }, async () => {
  const created = await json('/ads', { method: 'POST', body: JSON.stringify({ name: 'Kinder Bueno 3s', advertiser: 'Ferrero', localPath: media!.ad }) });
  assert.equal(created.status, 201, created.text);
  adId = created.body.id;
  assert.equal(created.body.localPath, media!.ad);
  assert.equal(created.body.mediaUrl, `/api/ads/${adId}/media`);
  assert.ok(Math.abs(created.body.durationSec - 3) < 0.15, `duration ${created.body.durationSec}`);
  assert.equal(created.body.width, 640);
  assert.equal(created.body.height, 360);

  // file:// in sourceUrl is treated as a local path too.
  const viaUrl = await json('/ads', { method: 'POST', body: JSON.stringify({ name: 'file url', sourceUrl: `file://${media!.ad}` }) });
  assert.equal(viaUrl.status, 201);
  assert.equal(viaUrl.body.localPath, media!.ad);
  await fetch(`${base}/ads/${viaUrl.body.id}`, { method: 'DELETE' });

  const full = await fetch(`${base}/ads/${adId}/media`);
  assert.equal(full.status, 200);
  assert.equal(full.headers.get('content-type'), 'video/mp4');
  assert.equal(full.headers.get('accept-ranges'), 'bytes');
  const size = Number(full.headers.get('content-length'));
  assert.ok(size > 1000);
  await full.arrayBuffer();

  const part = await fetch(`${base}/ads/${adId}/media`, { headers: { range: 'bytes=0-99' } });
  assert.equal(part.status, 206);
  assert.equal(part.headers.get('content-range'), `bytes 0-99/${size}`);
  assert.equal(part.headers.get('content-length'), '100');
  assert.equal((await part.arrayBuffer()).byteLength, 100);
});

test('catalog: ingest from a local path probes the file, sets localPath/fileUrl/poster and runs the mock pipeline', { skip: SKIP }, async () => {
  const created = await json('/catalog', { method: 'POST', body: JSON.stringify({ title: 'Synthetic feature', type: 'movie', sourceUrl: media!.movie, posterUrl: media!.poster }) });
  assert.equal(created.status, 200, created.text);
  const item = created.body[0];
  itemId = item.id;
  assert.equal(item.localPath, media!.movie);
  assert.equal(item.sourceUrl, `file://${media!.movie}`);
  assert.equal(item.playback.fileUrl, `/api/catalog/${itemId}/media`);
  assert.equal(item.posterUrl, `/api/catalog/${itemId}/poster`);
  assert.ok(Math.abs(item.durationSec - 60) < 0.2, `probed duration ${item.durationSec}`);
  assert.equal(item.fps, 24);
  assert.equal(item.width, 320);
  assert.equal(item.height, 240);

  // Re-posting the same file (as a file:// URL this time) is idempotent.
  const again = await json('/catalog', { method: 'POST', body: JSON.stringify({ sourceUrl: `file://${media!.movie}` }) });
  assert.equal(again.body[0].id, itemId);

  await app.runner.idle();
  const bundle = (await json(`/catalog/${itemId}`)).body;
  assert.equal(bundle.item.status, 'ready');
  assert.ok(Math.abs(bundle.item.durationSec - 60) < 0.2, 'ingest keeps the probed duration');
  assert.equal(bundle.item.playback.fileUrl, `/api/catalog/${itemId}/media`, 'ingest keeps fileUrl');
  assert.equal(bundle.item.localPath, media!.movie);
  assert.ok(bundle.adBreaks, 'adbreaks job ran');
  const ingest = bundle.jobs.find((j: any) => j.kind === 'ingest');
  assert.equal(ingest.status, 'ready');

  // Poster and media stream with Range support.
  const poster = await fetch(`${base}/catalog/${itemId}/poster`);
  assert.equal(poster.status, 200);
  assert.equal(poster.headers.get('content-type'), 'image/png');
  await poster.arrayBuffer();

  const head = await fetch(`${base}/catalog/${itemId}/media`, { method: 'HEAD' });
  assert.equal(head.status, 200);
  const size = Number(head.headers.get('content-length'));
  assert.ok(size > 100_000);

  const part = await fetch(`${base}/catalog/${itemId}/media`, { headers: { range: `bytes=${size - 10}-` } });
  assert.equal(part.status, 206);
  assert.equal(part.headers.get('content-range'), `bytes ${size - 10}-${size - 1}/${size}`);
  assert.equal((await part.arrayBuffer()).byteLength, 10);

  const bad = await fetch(`${base}/catalog/${itemId}/media`, { headers: { range: `bytes=${size + 5}-` } });
  assert.equal(bad.status, 416);
  assert.equal(bad.headers.get('content-range'), `bytes */${size}`);

  const notLocal = await fetch(`${base}/catalog/sintel/media`);
  assert.equal(notLocal.status, 404);
});

test('assign creative to breaks (all, some, clear) and VMAP emits inline VAST', { skip: SKIP }, async () => {
  // Deterministic breaks on the synthetic movie (the mock planner fences a 60 s title out).
  app.store.updateBundle(itemId, (b) => {
    b.adBreaks = {
      itemId,
      breaks: [brk('brk-a', 20.3, [18, 23], { rank: 1, review: { status: 'approved', comments: [] } }), brk('brk-b', 40.7, [38, 44], { rank: 2 })],
      policy: { targetBreaks: 2, minSpacingSec: 10, avoidFirstSec: 5, avoidLastSec: 5 },
      model: 'test',
      generatedAt: new Date().toISOString(),
    };
  });

  const unknown = await json(`/catalog/${itemId}/adbreaks/assign`, { method: 'POST', body: JSON.stringify({ creativeId: 'ad-nope' }) });
  assert.equal(unknown.status, 404);

  const all = await json(`/catalog/${itemId}/adbreaks/assign`, { method: 'POST', body: JSON.stringify({ creativeId: adId }) });
  assert.equal(all.status, 200, all.text);
  assert.ok(all.body.breaks.every((b: AdBreak) => b.creativeId === adId));

  const clearOne = await json(`/catalog/${itemId}/adbreaks/assign`, { method: 'POST', body: JSON.stringify({ creativeId: null, breakIds: ['brk-b'] }) });
  assert.equal(clearOne.body.breaks.find((b: AdBreak) => b.id === 'brk-a').creativeId, adId);
  assert.equal(clearOne.body.breaks.find((b: AdBreak) => b.id === 'brk-b').creativeId, undefined);

  // VMAP (approved only): brk-a is approved and carries the creative → inline VAST with an absolute MediaFile URL.
  const vmap = await fetch(`${base}/catalog/${itemId}/export/vmap`);
  assert.equal(vmap.status, 200);
  const xml = await vmap.text();
  assert.match(xml, /<vmap:AdBreak timeOffset="00:00:20.300" breakType="linear" breakId="brk-a">/);
  assert.match(xml, /<vmap:VASTAdData>\s*<VAST version="3.0">\s*<Ad id="ad_[^"]+" sequence="1">\s*<InLine>/);
  assert.match(xml, /<AdTitle>Kinder Bueno 3s<\/AdTitle>/);
  assert.match(xml, /<Advertiser>Ferrero<\/Advertiser>/);
  assert.match(xml, /<Duration>00:00:03<\/Duration>/);
  assert.ok(xml.includes(`<MediaFile id="${adId}" delivery="progressive" type="video/mp4" width="640" height="360"><![CDATA[${origin}/api/ads/${adId}/media]]></MediaFile>`), xml);
  assert.doesNotMatch(xml, /brk-b/, 'unapproved break not exported by default');

  // With all=1 the unassigned break keeps the AdTagURI form.
  const allXml = await (await fetch(`${base}/catalog/${itemId}/export/vmap?all=1`)).text();
  assert.match(allXml, /breakId="brk-b">\s*<vmap:AdSource id="brk-b-src"[^>]*>\s*<vmap:AdTagURI templateType="vast3">/);
  assert.equal((allXml.match(/<VAST version="3.0">/g) ?? []).length, 1);

  // Re-assign everything for the stitch test.
  await json(`/catalog/${itemId}/adbreaks/assign`, { method: 'POST', body: JSON.stringify({ creativeId: adId }) });
});

test('stitch: 202 → background render → ready with insertions, SSE event, Range-served output', { skip: SKIP }, async () => {
  // Collect SSE stitch events.
  const seen: string[] = [];
  const sse = await fetch(`${base}/events`);
  const reader = sse.body!.getReader();
  const decoder = new TextDecoder();
  const pump = (async () => {
    let buf = '';
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      for (const chunk of buf.split('\n\n').slice(0, -1)) {
        const data = chunk.split('\n').find((l) => l.startsWith('data: '));
        if (!data) continue;
        const ev = JSON.parse(data.slice(6));
        if (ev.type === 'stitch') seen.push(ev.job.status);
      }
      buf = buf.slice(buf.lastIndexOf('\n\n') + 2);
    }
  })().catch(() => undefined);

  const noBreaks = await json(`/catalog/sintel/stitch`, { method: 'POST', body: JSON.stringify({ creativeId: adId, breakIds: ['nope'] }) });
  assert.equal(noBreaks.status, 404);

  // Only brk-a is approved → one insertion by default.
  const started = await json(`/catalog/${itemId}/stitch`, { method: 'POST', body: JSON.stringify({}) });
  assert.equal(started.status, 202, started.text);
  assert.equal(started.body.status, 'queued');
  assert.equal(started.body.creativeId, adId);
  const jobId = started.body.id;

  // includeUnapproved with no approved breaks → all; here brk-a is approved so it stays one. Force both with breakIds.
  const both = await json(`/catalog/${itemId}/stitch`, { method: 'POST', body: JSON.stringify({ breakIds: ['brk-a', 'brk-b'] }) });
  assert.equal(both.status, 202);

  // Poll like a client would.
  let job = started.body;
  for (let i = 0; i < 600 && (job.status === 'queued' || job.status === 'running'); i++) {
    await new Promise((r) => setTimeout(r, 100));
    job = (await json(`/stitch/${jobId}`)).body;
  }
  assert.equal(job.status, 'ready', job.error ?? job.log);
  assert.equal(job.insertions.length, 1);
  assert.deepEqual(job.insertions[0], { breakId: 'brk-a', requestedAt: 20.3, snappedAt: 20 });
  assert.ok(Math.abs(job.durationSec - 63) < 0.5, `duration ${job.durationSec}`);
  assert.match(job.outputUrl, new RegExp(`^/api/renders/${itemId}-\\d+\\.mp4$`));

  await app.stitches.idle();
  const second = (await json(`/stitch/${both.body.id}`)).body;
  assert.equal(second.status, 'ready', second.error ?? second.log);
  assert.deepEqual(
    second.insertions.map((i: any) => [i.breakId, i.snappedAt]),
    [
      ['brk-a', 20],
      ['brk-b', 41],
    ],
  );
  assert.ok(Math.abs(second.durationSec - 66) < 0.5);
  assert.match(second.log, /cache hit/, 'ad transcode reused across jobs');

  // The breaks now carry snappedAt.
  const plan = (await json(`/catalog/${itemId}/adbreaks`)).body;
  assert.equal(plan.breaks.find((b: AdBreak) => b.id === 'brk-a').snappedAt, 20);
  assert.equal(plan.breaks.find((b: AdBreak) => b.id === 'brk-b').snappedAt, 41);
  const vmap = await (await fetch(`${base}/catalog/${itemId}/export/vmap`)).text();
  assert.match(vmap, /<snappedAt>00:00:20.000<\/snappedAt>/);

  // Listing + render streaming with Range.
  const list = (await json(`/stitch?itemId=${itemId}`)).body;
  assert.equal(list.length, 2);
  assert.equal(list[0].id, both.body.id, 'newest first');

  const render = await fetch(`${origin}${job.outputUrl}`, { headers: { range: 'bytes=0-1023' } });
  assert.equal(render.status, 206);
  assert.equal(render.headers.get('content-type'), 'video/mp4');
  assert.match(render.headers.get('content-range') ?? '', /^bytes 0-1023\/\d+$/);
  assert.equal((await render.arrayBuffer()).byteLength, 1024);
  const traversal = await fetch(`${base}/renders/..%2Fstore.json`);
  assert.ok(traversal.status === 400 || traversal.status === 404);

  // SSE saw the job move through the states.
  await new Promise((r) => setTimeout(r, 50));
  await reader.cancel();
  await pump;
  assert.ok(seen.includes('queued') && seen.includes('running') && seen.includes('ready'), `events: ${seen.join(',')}`);

  // Dry run works even for items without a local file.
  const dry = await json(`/catalog/sintel/stitch`, { method: 'POST', body: JSON.stringify({ creativeId: adId, includeUnapproved: true, dryRun: true }) });
  assert.equal(dry.status, 202, dry.text);
  await app.stitches.idle();
  const dryJob = (await json(`/stitch/${dry.body.id}`)).body;
  assert.equal(dryJob.status, 'ready');
  assert.ok(dryJob.insertions.length >= 1);
  assert.equal(dryJob.outputUrl, undefined);

  // Without dryRun, a URL-only item is refused up front.
  const refused = await json(`/catalog/sintel/stitch`, { method: 'POST', body: JSON.stringify({ creativeId: adId, includeUnapproved: true }) });
  assert.equal(refused.status, 409);
  assert.equal(refused.body.error.code, 'needs_local_file');

  // Deleting the creative unassigns it everywhere.
  await fetch(`${base}/ads/${adId}`, { method: 'DELETE' });
  const after = (await json(`/catalog/${itemId}/adbreaks`)).body;
  assert.ok(after.breaks.every((b: AdBreak) => b.creativeId === undefined));
});

test('store persists creatives and stitch jobs', { skip: SKIP }, async () => {
  const created = await json('/ads', { method: 'POST', body: JSON.stringify({ name: 'Persisted', sourceUrl: 'https://cdn.example.com/p.mp4', durationSec: 10 }) });
  await app.store.flush();
  const { readFile } = await import('node:fs/promises');
  const raw = JSON.parse(await readFile(join(dir, 'store.json'), 'utf8'));
  assert.ok(raw.ads.some((a: any) => a.id === created.body.id));
  assert.ok(raw.stitches.length >= 3);
  assert.ok(raw.stitches.every((s: any) => s.status === 'ready' || s.status === 'failed'));
});

test('creative intelligence: seeded creatives carry real fingerprints; fingerprint endpoint fills in a new creative (mock)', async () => {
  const ads = (await json('/ads')).body as any[];
  const bueno = ads.find((a) => a.id === 'ad_kinder-bueno-30');
  assert.equal(bueno.fingerprint.brand, 'Ferrero');
  assert.ok(bueno.fingerprint.mood.playful > 0.5);
  assert.equal(bueno.fingerprint.model, 'pegasus1.5');

  const created = await json('/ads', { method: 'POST', body: JSON.stringify({ name: 'Acme Cola', sourceUrl: 'https://example.com/acme-cola.mp4', durationSec: 15 }) });
  assert.equal(created.status, 201);
  assert.equal(created.body.fingerprint, undefined);
  const fp = await json(`/ads/${created.body.id}/fingerprint`, { method: 'POST' });
  assert.equal(fp.status, 200, fp.text);
  assert.equal(fp.body.id, created.body.id);
  assert.ok(fp.body.fingerprint.mood, 'fingerprint attached');
  assert.match(fp.body.fingerprint.model, /pegasus/);
  assert.ok(fp.body.upstream.assetId, 'creative was uploaded as an asset');
  assert.ok((await json(`/ads/${created.body.id}`)).body.fingerprint, 'persisted');
  await fetch(`${base}/ads/${created.body.id}`, { method: 'DELETE' });
});

test('adbreaks/fit ranks creatives per break with explanations; autoassign picks the best and respects minScore', async () => {
  const fit = await json('/catalog/david-and-goliath/adbreaks/fit');
  assert.equal(fit.status, 200);
  assert.equal(fit.body.breaks.length, 5);
  for (const b of fit.body.breaks) {
    assert.equal(b.fits.length, fit.body.creatives.length);
    assert.ok(b.fits[0].score >= b.fits[b.fits.length - 1].score, 'sorted best first');
    assert.ok(b.fits[0].because.length > 0);
    for (const f of b.fits) assert.ok(f.score >= 0 && f.score <= 1);
  }
  assert.ok(fit.body.creatives.filter((c: any) => c.id.startsWith('ad_kinder')).every((c: any) => c.fingerprinted));
  // Creatives added earlier in this file have no fingerprint: they rank last with a reason, never above a fingerprinted one.
  for (const b of fit.body.breaks) assert.ok(b.fits.filter((f: any) => f.score === 0).every((f: any) => /no fingerprint/.test(f.because[0])));

  // Nothing clears the seeded assignment when every break is below minScore.
  const strict = await json('/catalog/david-and-goliath/adbreaks/autoassign', { method: 'POST', body: JSON.stringify({ minScore: 0.99 }) });
  assert.equal(strict.status, 200);
  assert.ok(strict.body.assignments.every((a: any) => a.creativeId === undefined));
  assert.ok(strict.body.plan.breaks.every((b: any) => b.creativeId === 'ad_kinder-bueno-30'), 'seed assignment untouched');

  const auto = await json('/catalog/david-and-goliath/adbreaks/autoassign', { method: 'POST', body: JSON.stringify({}) });
  assert.equal(auto.status, 200);
  assert.equal(auto.body.assignments.length, 5);
  for (const a of auto.body.assignments) {
    assert.ok(a.creativeId, 'every break got a creative');
    assert.equal(a.fit.creativeId, a.creativeId);
    const brk = auto.body.plan.breaks.find((b: any) => b.id === a.breakId);
    assert.equal(brk.creativeId, a.creativeId);
  }
  // Put the demo back the way the seed had it.
  await json('/catalog/david-and-goliath/adbreaks/assign', { method: 'POST', body: JSON.stringify({ creativeId: 'ad_kinder-bueno-30' }) });

  const missing = await json('/catalog/does-not-exist/adbreaks/fit');
  assert.equal(missing.status, 404);
});
