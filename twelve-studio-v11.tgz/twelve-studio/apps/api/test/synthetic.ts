/**
 * Synthetic media for tests: a 60 s 320x240@24 movie with a keyframe every
 * second (`-g 24`) and a 3 s 640x360@30 mono ad, rendered by ffmpeg into a
 * temp dir. Returns `undefined` when ffmpeg is not installed.
 */
import { execFile } from 'node:child_process';
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';

const exec = promisify(execFile);

export interface SyntheticMedia {
  dir: string;
  movie: string;
  ad: string;
  poster: string;
}

export async function ffmpegAvailable(): Promise<boolean> {
  try {
    await exec('ffmpeg', ['-version']);
    await exec('ffprobe', ['-version']);
    return true;
  } catch {
    return false;
  }
}

export async function makeSyntheticMedia(prefix = 'twelve-media-'): Promise<SyntheticMedia | undefined> {
  if (!(await ffmpegAvailable())) return undefined;
  const dir = await mkdtemp(join(tmpdir(), prefix));
  const movie = join(dir, 'movie.mp4');
  const ad = join(dir, 'ad.mp4');
  const poster = join(dir, 'poster.png');
  await exec('ffmpeg', [
    '-v', 'error', '-y',
    '-f', 'lavfi', '-i', 'testsrc=duration=60:size=320x240:rate=24',
    '-f', 'lavfi', '-i', 'sine=frequency=440:duration=60',
    '-g', '24', '-keyint_min', '24', '-sc_threshold', '0',
    '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-ar', '48000', '-ac', '2', '-shortest', movie,
  ]);
  await exec('ffmpeg', [
    '-v', 'error', '-y',
    '-f', 'lavfi', '-i', 'testsrc=duration=3:size=640x360:rate=30',
    '-f', 'lavfi', '-i', 'sine=frequency=880:duration=3',
    '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-ar', '44100', '-ac', '1', '-shortest', ad,
  ]);
  await exec('ffmpeg', ['-v', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:size=64x96:duration=1', '-frames:v', '1', poster]);
  return { dir, movie, ad, poster };
}

export async function probeDuration(path: string): Promise<number> {
  const { stdout } = await exec('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', path]);
  return Number(stdout.trim());
}
