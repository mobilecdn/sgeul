/**
 * Recommendation routes — watch events in, ranked titles out.
 *
 * The engine itself lives in `@twelve-studio/core` (recommend.ts); this file is
 * the thin REST surface plus the per-viewer event log the store persists:
 *
 *   POST   /api/reco/events                 record a play / like / skip
 *   GET    /api/reco/events?profileId=      raw event log
 *   DELETE /api/reco/events?profileId=      forget a viewer
 *   GET    /api/reco/profiles               viewers seen, with event counts
 *   GET    /api/reco/profile/:profileId     the derived taste profile
 *   GET    /api/reco/weights                the weighting the app applies
 *   PUT    /api/reco/weights                change it (partial, clamped)
 *   POST   /api/reco/weights/reset          back to defaults
 *   GET    /api/reco/home?profileId=        the rows a player would render
 *   GET    /api/catalog/:id/recommendations what to play after this title
 *   POST   /api/reco/simulate               score a hypothetical watch history
 */

import type { Router, Request } from 'express';
import {
  DEFAULT_RECO_WEIGHTS,
  buildTasteProfile,
  makeId,
  normaliseWeights,
  nowIso,
  popularityIndex,
  recommend,
  recommendRails,
  type CatalogItem,
  type RecoWeights,
  type WatchAction,
  type WatchEvent,
} from '@twelve-studio/core';
import type { Store } from './store.js';
import { HttpError } from './routes.js';

const ACTIONS = new Set<WatchAction>(['watch', 'like', 'dislike', 'skip', 'impression']);

const DEFAULT_PROFILE = 'viewer-1';

function profileIdOf(req: Request): string {
  const raw = (req.query.profileId ?? req.query.profile ?? (req.body as { profileId?: string } | undefined)?.profileId) as unknown;
  const id = typeof raw === 'string' && raw.trim() ? raw.trim() : DEFAULT_PROFILE;
  return id.slice(0, 64);
}

function limitOf(req: Request, fallback: number, max = 50): number {
  return Math.min(max, Math.max(1, Number(req.query.limit ?? fallback) || fallback));
}

/** Parse one posted event; throws 400 on anything the engine could not use. */
export function parseEvent(body: unknown, defaults: { profileId: string }): WatchEvent {
  const b = (body ?? {}) as Partial<WatchEvent> & { itemId?: string };
  if (typeof b.itemId !== 'string' || !b.itemId.trim()) throw new HttpError(400, 'bad_request', 'itemId is required');
  const action = (b.action ?? 'watch') as WatchAction;
  if (!ACTIONS.has(action)) throw new HttpError(400, 'bad_request', `action must be one of ${[...ACTIONS].join(', ')}`);
  const completion = b.completion === undefined ? undefined : Math.min(1, Math.max(0, Number(b.completion) || 0));
  const seconds = b.seconds === undefined ? undefined : Math.max(0, Number(b.seconds) || 0);
  return {
    id: makeId('wev'),
    profileId: (typeof b.profileId === 'string' && b.profileId.trim() ? b.profileId.trim() : defaults.profileId).slice(0, 64),
    itemId: b.itemId.trim(),
    action,
    ...(completion === undefined ? {} : { completion }),
    ...(seconds === undefined ? {} : { seconds }),
    at: typeof b.at === 'string' && !Number.isNaN(Date.parse(b.at)) ? b.at : nowIso(),
  };
}

export interface RecoDeps {
  store: Store;
  requireItem(id: string): CatalogItem;
}

export function registerRecoRoutes(router: Router, { store, requireItem }: RecoDeps): void {
  const wrapAsync =
    (fn: (req: Request) => unknown) =>
    (req: Request, res: import('express').Response, next: import('express').NextFunction) => {
      Promise.resolve()
        .then(() => fn(req))
        .then((v) => {
          if (res.headersSent) return;
          if (v === undefined) res.status(204).end();
          else res.json(v);
        })
        .catch(next);
    };

  const weights = (override?: Partial<RecoWeights>): RecoWeights =>
    normaliseWeights({ ...(store.recoWeights() ?? {}), ...(override ?? {}) });

  const context = (profileId: string, override?: Partial<RecoWeights>) => {
    const w = weights(override);
    const items = store.allItems();
    const events = store.watchEvents();
    return {
      weights: w,
      pool: items,
      popularity: popularityIndex(events, w),
      profile: buildTasteProfile(profileId, events, items, w),
    };
  };

  /* ---- events ----------------------------------------------------- */

  router.post(
    '/reco/events',
    wrapAsync((req) => {
      const body = req.body as unknown;
      const list = Array.isArray(body) ? body : [body];
      const profileId = profileIdOf(req);
      const saved = list.map((raw) => {
        const ev = parseEvent(raw, { profileId });
        requireItem(ev.itemId);
        return store.addWatchEvent(ev);
      });
      return saved;
    }),
  );

  router.get(
    '/reco/events',
    wrapAsync((req) => {
      const profileId = typeof req.query.profileId === 'string' ? req.query.profileId : undefined;
      return store.watchEvents(profileId).slice().reverse();
    }),
  );

  router.delete(
    '/reco/events',
    wrapAsync((req) => {
      const profileId = typeof req.query.profileId === 'string' ? req.query.profileId : undefined;
      return { deleted: store.clearWatchEvents(profileId) };
    }),
  );

  router.get(
    '/reco/profiles',
    wrapAsync(() => {
      type ProfileRow = { profileId: string; events: number; lastAt?: string };
      const acc = new Map<string, ProfileRow>();
      for (const ev of store.watchEvents()) {
        const cur: ProfileRow = acc.get(ev.profileId) ?? { profileId: ev.profileId, events: 0 };
        cur.events += 1;
        if (!cur.lastAt || ev.at > cur.lastAt) cur.lastAt = ev.at;
        acc.set(ev.profileId, cur);
      }
      if (acc.size === 0) acc.set(DEFAULT_PROFILE, { profileId: DEFAULT_PROFILE, events: 0 });
      return [...acc.values()].sort((a, b) => (b.lastAt ?? '').localeCompare(a.lastAt ?? ''));
    }),
  );

  router.get(
    '/reco/profile/:profileId',
    wrapAsync((req) => {
      const profileId = String(req.params.profileId ?? DEFAULT_PROFILE);
      const { profile } = context(profileId);
      // The vectors are large and of no use to a client.
      const { vector: _v, labelVec: _l, ...rest } = profile;
      return rest;
    }),
  );

  /* ---- weights ---------------------------------------------------- */

  router.get(
    '/reco/weights',
    wrapAsync(() => ({ weights: weights(), defaults: DEFAULT_RECO_WEIGHTS, custom: store.recoWeights() !== undefined })),
  );

  router.put(
    '/reco/weights',
    wrapAsync((req) => {
      const next = normaliseWeights({ ...(store.recoWeights() ?? {}), ...((req.body ?? {}) as Partial<RecoWeights>) });
      store.setRecoWeights(next);
      return { weights: next, defaults: DEFAULT_RECO_WEIGHTS, custom: true };
    }),
  );

  router.post(
    '/reco/weights/reset',
    wrapAsync(() => {
      store.setRecoWeights(undefined);
      return { weights: DEFAULT_RECO_WEIGHTS, defaults: DEFAULT_RECO_WEIGHTS, custom: false };
    }),
  );

  /* ---- recommendations -------------------------------------------- */

  /** What to play after this title: seed similarity blended with the viewer's taste. */
  router.get(
    '/catalog/:id/recommendations',
    wrapAsync((req) => {
      const seed = requireItem(String(req.params.id));
      const profileId = profileIdOf(req);
      const ctx = context(profileId);
      const items = recommend({ ...ctx, seed, limit: limitOf(req, 12) });
      return { seedId: seed.id, profileId, weights: ctx.weights, items };
    }),
  );

  /** The rows a player would render for this viewer. */
  router.get(
    '/reco/home',
    wrapAsync((req) => {
      const profileId = profileIdOf(req);
      const ctx = context(profileId);
      const seedId = typeof req.query.seedId === 'string' ? req.query.seedId : undefined;
      const seed = seedId ? requireItem(seedId) : undefined;
      const rails = recommendRails({ ...ctx, seed, limit: limitOf(req, 10), maxRails: limitOf(req, 6, 12) });
      return {
        profileId,
        weights: ctx.weights,
        profile: { top: ctx.profile.top, topCombos: ctx.profile.topCombos, events: ctx.profile.events, pacing: ctx.profile.pacing, rating: ctx.profile.rating },
        rails,
      };
    }),
  );

  /**
   * Score a hypothetical history with hypothetical weights and persist nothing —
   * this is what the weight sliders in the Recommendations lab call on every change.
   */
  router.post(
    '/reco/simulate',
    wrapAsync((req) => {
      const body = (req.body ?? {}) as {
        profileId?: string;
        events?: Array<Partial<WatchEvent>>;
        weights?: Partial<RecoWeights>;
        seedId?: string;
        limit?: number;
        maxRails?: number;
      };
      const profileId = (body.profileId ?? 'simulated').slice(0, 64);
      const w = normaliseWeights({ ...(store.recoWeights() ?? {}), ...(body.weights ?? {}) });
      const items = store.allItems();
      const events = (body.events ?? []).map((raw) => {
        const ev = parseEvent(raw, { profileId });
        requireItem(ev.itemId);
        return { ...ev, profileId };
      });
      const profile = buildTasteProfile(profileId, events, items, w);
      const popularity = popularityIndex([...store.watchEvents(), ...events], w);
      const seed = body.seedId ? requireItem(body.seedId) : undefined;
      const limit = Math.min(50, Math.max(1, Number(body.limit ?? 10) || 10));
      const rails = recommendRails({ profile, pool: items, weights: w, popularity, seed, limit, maxRails: Math.min(12, Math.max(1, Number(body.maxRails ?? 6) || 6)) });
      const next = seed ? recommend({ profile, pool: items, weights: w, popularity, seed, limit }) : [];
      const { vector: _v, labelVec: _l, ...profileOut } = profile;
      return { profileId, weights: w, profile: profileOut, rails, next };
    }),
  );
}
