/**
 * Response shaping: embeddings never leave the API (they are large and only
 * useful server-side), list views stay light.
 */

import type { CatalogItem, Fingerprint, ItemBundle } from '@twelve-studio/core';

export type PublicFingerprint = Omit<Fingerprint, 'embedding'> & { hasEmbedding: boolean; embeddingDims?: number };

export function publicFingerprint(fp: Fingerprint): PublicFingerprint {
  const { embedding, ...rest } = fp;
  return { ...rest, hasEmbedding: !!embedding?.length, embeddingDims: embedding?.length };
}

export function publicItem(item: CatalogItem): CatalogItem {
  if (!item.fingerprint) return item;
  return { ...item, fingerprint: publicFingerprint(item.fingerprint) as unknown as Fingerprint };
}

export function publicBundle(bundle: ItemBundle): ItemBundle {
  return {
    ...bundle,
    item: publicItem(bundle.item),
    fingerprint: bundle.fingerprint ? (publicFingerprint(bundle.fingerprint) as unknown as Fingerprint) : undefined,
  };
}
