/**
 * REST routes — see CONTRACT.md "REST API". Every handler is thin: validation,
 * a store call, and (where TwelveLabs is involved) one clearly marked client call.
 */

import { basename, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { Router, type NextFunction, type Request, type Response } from 'express';
import {
  autoAssign,
  ensureIndex,
  fingerprintCreative,
  hash32,
  isHttpUrl,
  listAllAssets,
  makeId,
  mockVideoId,
  nowIso,
  rankCreatives,
  replanAdBreaks,
  similarTitles,
  MODELS,
  TwelveLabsError,
  type ItemType,
  type TwelveLabsAsset,
  type AdBreak,
  type AdBreakPlan,
  type AdCreative,
  type CatalogItem,
  type CatalogItemInput,
  type CatalogStats,
  type Comment,
  type ItemBundle,
  type Job,
  type JobKind,
  type Marker,
  type PipelineDeps,
  type Recipe,
  type ReviewState,
  type SearchHit,
  type SearchModality,
  type SearchResponse,
  type SmartList,
  type StitchJob,
  type AdBreakCandidate,
} from '@twelve-studio/core';
import type { ApiConfig } from './config.js';
import type { Store } from './store.js';
import type { JobRunner } from './jobs.js';
import { toPlayerMarkers, toScte35, toVmap, type ExportOptions } from './exports.js';
import { curateCatalog, matchesRules, queryItems, selectQueryMatches, validateRules } from './lists.js';
import { localPathFrom, mimeFor, requireFile, resolveMediaPath, streamFile } from './media.js';
import { hasFfmpeg, probeMedia, StitchQueue } from './stitch.js';
import { isApproved, isDeclined } from './exports.js';
import { publicBundle, publicItem } from './views.js';
import { registerRecoRoutes } from './reco.js';

export class HttpError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
  }
}

/** What a TwelveLabs asset is attached to in this workspace. */
export interface AssetLink {
  kind: 'title' | 'ad';
  id: string;
  title: string;
}
export type LinkedAsset = TwelveLabsAsset & { linked?: AssetLink };

interface ImportInput {
  assetId: string;
  as: 'title' | 'ad';
  title?: string;
  type?: ItemType;
  advertiser?: string;
}

const JOB_KINDS: JobKind[] = ['ingest', 'fingerprint', 'embedding', 'emotions', 'markers', 'safety', 'adbreaks', 'thumbnails', 'clips'];
const ITEM_TYPES = new Set(['movie', 'episode', 'short', 'clip', 'promo', 'other']);

type Handler = (req: Request, res: Response) => Promise<unknown> | unknown;
/**
 * Handlers return their JSON body (or end the response themselves). Errors
 * thrown or rejected reach the error middleware.
 */
const wrap = (fn: Handler) => (req: Request, res: Response, next: NextFunction) => {
  Promise.resolve()
    .then(() => fn(req, res))
    .then((value) => {
      if (res.headersSent) return;
      if (value === undefined) res.status(204).end();
      else res.json(value);
    })
    .catch(next);
};

function slugify(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 40);
}

function param(req: Request, name: string): string {
  const v = req.params[name];
  if (typeof v !== 'string' || !v) throw new HttpError(400, 'bad_request', `Missing route parameter ${name}`);
  return v;
}

export interface RouteDeps {
  store: Store;
  runner: JobRunner;
  pipeline: PipelineDeps;
  config: ApiConfig;
  startedAt: number;
  /** Serialises stitched-preview renders (one ffmpeg pipeline at a time). */
  stitches: StitchQueue;
}

/** Origin of the current request (`http://host:port`) for absolute media URLs in exports. */
function requestOrigin(req: Request): string {
  return `${req.protocol}://${req.get('host') ?? 'localhost'}`;
}

/** `{code:'file_not_found'}` errors from media helpers → 400. */
function asHttp(err: unknown): never {
  const e = err as { code?: string; status?: number; message?: string };
  if (e && typeof e === 'object' && e.code === 'file_not_found') throw new HttpError(400, 'file_not_found', e.message ?? 'File not found');
  if (e && typeof e === 'object' && e.code === 'probe_failed') throw new HttpError(400, 'probe_failed', e.message ?? 'ffprobe failed');
  throw err;
}

export function buildRouter({ store, runner, pipeline, config, startedAt, stitches }: RouteDeps): Router {
  const router = Router();
  const { client } = pipeline;

  const requireBundle = (id: string): ItemBundle => {
    const b = store.getBundle(id);
    if (!b) throw new HttpError(404, 'not_found', `Item ${id} not found`);
    return b;
  };

  const requireAd = (id: string): AdCreative => {
    const ad = store.getAd(id);
    if (!ad) throw new HttpError(404, 'not_found', `Ad creative ${id} not found`);
    return ad;
  };

  /* ---- health + stats -------------------------------------------- */

  router.get(
    '/health',
    wrap(async () => ({
      ok: true,
      mode: config.mode,
      ffmpeg: await hasFfmpeg(),
      rendersDir: config.rendersDir,
      index: config.indexId ?? store.getMeta('twelvelabs.indexId') ?? null,
      indexName: config.indexName,
      models: { index: MODELS.index, embed: MODELS.embed, analyze: MODELS.analyze },
      synopsisLanguages: config.synopsisLanguages,
      items: store.size,
      jobs: runner.stats,
      uptimeSec: Math.round((Date.now() - startedAt) / 1000),
      pricing: { indexPerHourUsd: 2.5, analyzePerHourUsd: 1.75, analyzePerMTokUsd: 7.5, searchPer1kUsd: 4, embedVideoPerMTokUsd: 0.26 },
    })),
  );

  router.get(
    '/stats',
    wrap((): CatalogStats => {
      const bundles = store.allBundles();
      const items = bundles.length;
      const ready = bundles.filter((b) => b.item.status === 'ready').length;
      const totalDurationSec = bundles.reduce((acc, b) => acc + (b.item.durationSec ?? 0), 0);
      const coverage = items === 0 ? 0 : bundles.reduce((acc, b) => acc + JOB_KINDS.filter((k) => b.item.jobs[k] === 'ready').length / JOB_KINDS.length, 0) / items;
      const pendingReviews = bundles.reduce((acc, b) => {
        const open = (x: { review?: ReviewState }) => !x.review || x.review.status === 'open';
        return acc + (b.adBreaks?.breaks.filter(open).length ?? 0) + (b.markers?.markers.filter(open).length ?? 0);
      }, 0);
      return { items, ready, totalDurationSec: Math.round(totalDurationSec), lists: store.allLists().length, coverage: Math.round(coverage * 1000) / 1000, pendingReviews };
    }),
  );

  /* ---- catalog ---------------------------------------------------- */

  router.get(
    '/catalog',
    wrap(() => store.allItems().map(publicItem)),
  );

  router.post(
    '/catalog',
    wrap(async (req) => {
      const body = req.body as CatalogItemInput | CatalogItemInput[];
      const inputs = Array.isArray(body) ? body : [body];
      if (inputs.length === 0) throw new HttpError(400, 'bad_request', 'Provide a CatalogItemInput or an array of them');
      const created: CatalogItem[] = [];
      const ffmpeg = await hasFfmpeg();
      for (const [i, input] of inputs.entries()) {
        if (!input || typeof input !== 'object') throw new HttpError(400, 'bad_request', `items[${i}] must be an object`);
        // A local file: absolute path or file:// URL. Stored as a file:// URL so dedupe and the mock client see one canonical form.
        const localPath = localPathFrom(input.sourceUrl);
        if (!localPath && (typeof input.sourceUrl !== 'string' || !isHttpUrl(input.sourceUrl))) {
          throw new HttpError(400, 'bad_request', `items[${i}].sourceUrl must be an http(s) URL, an absolute local path or a file:// URL`);
        }
        const sourceUrl = localPath ? pathToFileURL(localPath).href : input.sourceUrl;
        const title = typeof input.title === 'string' && input.title.trim() ? input.title.trim() : localPath ? titleFromFile(localPath) : titleFromUrl(sourceUrl);
        if (input.type !== undefined && !ITEM_TYPES.has(input.type)) throw new HttpError(400, 'bad_request', `items[${i}].type is invalid`);
        const existing = store.findBySourceUrl(sourceUrl);
        if (existing) {
          // Idempotent: re-posting a URL re-queues whatever is still missing.
          runner.enqueueEnrichment(existing);
          created.push(publicItem(store.getBundle(existing.id)?.item ?? existing));
          continue;
        }
        const id = `${slugify(title) || 'item'}-${hash32(sourceUrl).toString(36).slice(0, 5)}`;
        const now = nowIso();
        const item: CatalogItem = {
          ...input,
          sourceUrl,
          title,
          id,
          type: input.type ?? 'other',
          createdAt: now,
          updatedAt: now,
          status: 'ingesting',
          jobs: {},
        };
        if (localPath) {
          await requireFile(localPath).catch(asHttp);
          item.localPath = localPath;
          item.playback = { ...(item.playback ?? {}), fileUrl: `/api/catalog/${id}/media` };
          if (ffmpeg) {
            const info = await probeMedia(localPath).catch(asHttp);
            if (info.durationSec > 0) item.durationSec = Math.round(info.durationSec * 1000) / 1000;
            if (info.video) {
              item.fps = info.video.fps || item.fps;
              item.width = info.video.width || item.width;
              item.height = info.video.height || item.height;
            }
          }
        }
        const posterPath = localPathFrom(input.posterUrl);
        if (posterPath) {
          await requireFile(posterPath).catch(asHttp);
          item.posterPath = posterPath;
          item.posterUrl = `/api/catalog/${id}/poster`;
        }
        store.saveItem(item);
        runner.enqueueEnrichment(item);
        created.push(publicItem(store.getBundle(id)?.item ?? item));
      }
      return created;
    }),
  );

  /* ---- TwelveLabs account assets ------------------------------------ */

  /** Which catalog title / ad creative an upstream asset is already attached to. */
  const linkFor = (assetId: string): AssetLink | undefined => {
    const item = store.allItems().find((i) => i.upstream?.assetId === assetId);
    if (item) return { kind: 'title', id: item.id, title: item.title };
    const ad = store.allAds().find((a) => a.upstream?.assetId === assetId);
    if (ad) return { kind: 'ad', id: ad.id, title: ad.name };
    return undefined;
  };

  /** → GET /v1.3/assets — the account's assets, annotated with what they are linked to here. */
  router.get(
    '/twelvelabs/assets',
    wrap(async (req) => {
      const page = Math.max(1, Number(req.query.page ?? 1) || 1);
      const pageLimit = Math.min(100, Math.max(1, Number(req.query.pageLimit ?? req.query.page_limit ?? 50) || 50));
      const res = await client.listAssets({ page, pageLimit });
      const assets: LinkedAsset[] = res.data.map((a) => {
        const linked = linkFor(a._id);
        return linked ? { ...a, linked } : a;
      });
      return { assets, pageInfo: res.pageInfo };
    }),
  );

  /**
   * Import existing TwelveLabs assets as catalog titles (enrichment starts; the
   * ingest job indexes the asset without re-uploading) or as ad creatives.
   * Per-asset problems are reported in `skipped` / `errors`, never as a 4xx.
   */
  router.post(
    '/catalog/import',
    wrap(async (req, res) => {
      const body = (req.body ?? {}) as { items?: unknown };
      if (!Array.isArray(body.items) || body.items.length === 0) throw new HttpError(400, 'bad_request', 'Provide items: [{ assetId, as: "title" | "ad", title?, type?, advertiser? }]');
      const inputs: ImportInput[] = body.items.map((raw, i) => {
        const x = (raw ?? {}) as Partial<ImportInput>;
        if (typeof x.assetId !== 'string' || !x.assetId.trim()) throw new HttpError(400, 'bad_request', `items[${i}].assetId is required`);
        if (x.as !== 'title' && x.as !== 'ad') throw new HttpError(400, 'bad_request', `items[${i}].as must be "title" or "ad"`);
        if (x.type !== undefined && !ITEM_TYPES.has(x.type)) throw new HttpError(400, 'bad_request', `items[${i}].type is invalid`);
        return { assetId: x.assetId.trim(), as: x.as, title: typeof x.title === 'string' ? x.title.trim() : undefined, type: x.type, advertiser: typeof x.advertiser === 'string' ? x.advertiser.trim() : undefined };
      });

      // → GET /v1.3/assets (every page) — one listing serves the whole batch.
      const byId = new Map((await listAllAssets(client)).map((a) => [a._id, a]));
      const items: CatalogItem[] = [];
      const ads: AdCreative[] = [];
      const skipped: Array<{ assetId: string; linked: AssetLink }> = [];
      const errors: Array<{ assetId: string; error: { code: string; message: string } }> = [];
      const seen = new Set<string>();

      for (const input of inputs) {
        if (seen.has(input.assetId)) continue; // duplicate row in the same request
        seen.add(input.assetId);
        const asset = byId.get(input.assetId);
        if (!asset) {
          errors.push({ assetId: input.assetId, error: { code: 'asset_not_found', message: `Asset ${input.assetId} is not in this TwelveLabs account` } });
          continue;
        }
        const linked = linkFor(asset._id);
        if (linked) {
          skipped.push({ assetId: asset._id, linked });
          continue;
        }
        if (asset.status !== 'ready') {
          errors.push({ assetId: asset._id, error: { code: 'asset_not_ready', message: `${asset.filename} is still ${asset.status} on TwelveLabs — import it once it is ready` } });
          continue;
        }
        const manifest = asset.hls?.manifest_url;
        const name = input.title || titleFromFile(asset.filename || asset._id);
        if (input.as === 'ad') {
          const id = makeId('ad');
          const ad: AdCreative = {
            id,
            name,
            advertiser: input.advertiser || undefined,
            durationSec: asset.duration ?? 30,
            sourceUrl: manifest ?? `twelvelabs://asset/${asset._id}`,
            mediaUrl: manifest ?? `twelvelabs://asset/${asset._id}`,
            width: asset.width ?? undefined,
            height: asset.height ?? undefined,
            upstream: { assetId: asset._id },
            createdAt: nowIso(),
          };
          store.saveAd(ad);
          ads.push(ad);
          continue;
        }
        const sourceUrl = manifest ?? `twelvelabs://asset/${asset._id}`;
        const id = `${slugify(name) || 'item'}-${hash32(asset._id).toString(36).slice(0, 5)}`;
        const now = nowIso();
        const item: CatalogItem = {
          id,
          title: name,
          type: input.type ?? 'other',
          sourceUrl,
          posterUrl: asset.thumbnail?.representative_url,
          durationSec: asset.duration ?? undefined,
          fps: asset.fps ?? undefined,
          width: asset.width ?? undefined,
          height: asset.height ?? undefined,
          playback: manifest ? { hlsUrl: manifest, thumbnailUrls: asset.thumbnail ? [asset.thumbnail.representative_url] : undefined } : undefined,
          upstream: { assetId: asset._id },
          externalIds: { twelvelabsAsset: asset._id },
          metadata: { filename: asset.filename, uploadedAt: asset.created_at, uploadMethod: asset.method, sizeBytes: asset.size },
          createdAt: now,
          updatedAt: now,
          status: 'ingesting',
          jobs: {},
        };
        store.saveItem(item);
        // Live: the ingest job sees `upstream.assetId`, skips the upload and only creates the indexed asset.
        runner.enqueueEnrichment(item);
        items.push(publicItem(store.getBundle(id)?.item ?? item));
      }
      res.status(201);
      return { items, ads, skipped, errors };
    }),
  );

  /** Progressive playback of a locally ingested file (Range-capable). */
  router.get(
    '/catalog/:id/media',
    wrap(async (req, res) => {
      const item = requireBundle(param(req, 'id')).item;
      if (!item.localPath) throw new HttpError(404, 'no_local_file', 'This item was not ingested from a local file');
      await streamFile(req, res, resolveMediaPath(item.localPath), mimeFor(item.localPath, 'video/mp4'));
    }),
  );
  router.head('/catalog/:id/media', (req, res, next) => {
    const item = store.getBundle(String(req.params.id))?.item;
    if (!item?.localPath) return next(new HttpError(404, 'no_local_file', 'This item was not ingested from a local file'));
    void streamFile(req, res, resolveMediaPath(item.localPath), mimeFor(item.localPath, 'video/mp4')).catch(next);
  });

  router.get(
    '/catalog/:id/poster',
    wrap(async (req, res) => {
      const item = requireBundle(param(req, 'id')).item;
      if (!item.posterPath) throw new HttpError(404, 'no_local_file', 'This item has no local poster');
      await streamFile(req, res, resolveMediaPath(item.posterPath), mimeFor(item.posterPath, 'image/jpeg'));
    }),
  );

  router.get(
    '/catalog/:id',
    wrap((req) => {
      const id = param(req, 'id');
      return publicBundle({ ...requireBundle(id), jobs: store.allJobs().filter((j) => j.itemId === id) });
    }),
  );

  router.delete(
    '/catalog/:id',
    wrap((req, res) => {
      if (!store.deleteItem(param(req, 'id'))) throw new HttpError(404, 'not_found', 'Item not found');
      res.status(204).end();
    }),
  );

  router.post(
    '/catalog/:id/jobs/:kind',
    wrap((req, res) => {
      const bundle = requireBundle(param(req, 'id'));
      const kind = param(req, 'kind') as JobKind;
      if (!JOB_KINDS.includes(kind)) throw new HttpError(400, 'bad_request', `Unknown job kind "${kind}"`);
      const jobs = runner.enqueueEnrichment(bundle.item, { only: [kind], force: true });
      const job: Job | undefined = jobs.find((j) => j.kind === kind) ?? jobs[0];
      res.status(202);
      return job;
    }),
  );

  const sections: Record<string, keyof ItemBundle> = {
    emotions: 'emotions',
    markers: 'markers',
    adbreaks: 'adBreaks',
    safety: 'safety',
    thumbnails: 'thumbnails',
    clips: 'clips',
    fingerprint: 'fingerprint',
  };
  for (const [route, key] of Object.entries(sections)) {
    router.get(
      `/catalog/:id/${route}`,
      wrap((req) => {
        const bundle = publicBundle(requireBundle(param(req, 'id')));
        const value = bundle[key];
        if (value === undefined) throw new HttpError(404, 'not_ready', `${route} has not been generated for this item yet (job status: ${bundle.item.jobs[route as JobKind] ?? 'not started'})`);
        return value;
      }),
    );
  }

  /* ---- review ----------------------------------------------------- */

  const applyReview = (existing: ReviewState | undefined, patch: Partial<ReviewState>): ReviewState => {
    const base: ReviewState = existing ?? { status: 'open', comments: [] };
    const next: ReviewState = { ...base, comments: [...base.comments] };
    if (patch.status !== undefined) {
      if (!['open', 'approved', 'declined'].includes(patch.status)) throw new HttpError(400, 'bad_request', 'status must be open | approved | declined');
      next.status = patch.status;
      next.reviewedAt = nowIso();
      next.reviewedBy = patch.reviewedBy ?? base.reviewedBy ?? 'reviewer';
    }
    if (patch.rating !== undefined) {
      if (typeof patch.rating !== 'number' || patch.rating < 0 || patch.rating > 5 || !Number.isInteger(patch.rating)) throw new HttpError(400, 'bad_request', 'rating must be an integer 0..5');
      next.rating = patch.rating as ReviewState['rating'];
    }
    if (patch.reviewedBy !== undefined) next.reviewedBy = patch.reviewedBy;
    if (patch.comments !== undefined) {
      if (!Array.isArray(patch.comments)) throw new HttpError(400, 'bad_request', 'comments must be an array');
      // New comments (no id) are appended; existing ones are matched by id and kept.
      for (const c of patch.comments as Partial<Comment>[]) {
        if (!c || typeof c.text !== 'string' || !c.text.trim()) continue;
        if (c.id && next.comments.some((x) => x.id === c.id)) continue;
        next.comments.push({ id: c.id ?? makeId('cmt'), author: c.author ?? next.reviewedBy ?? 'reviewer', text: c.text.trim(), at: c.at ?? nowIso() });
      }
    }
    return next;
  };

  router.patch(
    '/catalog/:id/markers/:mid',
    wrap((req) => {
      const id = param(req, 'id');
      const mid = param(req, 'mid');
      let updated: Marker | undefined;
      store.updateBundle(id, (b) => {
        const m = b.markers?.markers.find((x) => x.id === mid);
        if (!m) return;
        m.review = applyReview(m.review, req.body as Partial<ReviewState>);
        updated = m;
      });
      if (!store.getBundle(id)) throw new HttpError(404, 'not_found', 'Item not found');
      if (!updated) throw new HttpError(404, 'not_found', 'Marker not found');
      return updated;
    }),
  );

  router.patch(
    '/catalog/:id/adbreaks/:bid',
    wrap((req) => {
      const id = param(req, 'id');
      const bid = param(req, 'bid');
      let updated: AdBreak | undefined;
      store.updateBundle(id, (b) => {
        const brk = b.adBreaks?.breaks.find((x) => x.id === bid);
        if (!brk) return;
        brk.review = applyReview(brk.review, req.body as Partial<ReviewState>);
        updated = brk;
      });
      if (!store.getBundle(id)) throw new HttpError(404, 'not_found', 'Item not found');
      if (!updated) throw new HttpError(404, 'not_found', 'Ad break not found');
      return updated;
    }),
  );

  /** Re-plan deterministically under a new policy — no model call. */
  router.post(
    '/catalog/:id/adbreaks/plan',
    wrap((req) => {
      const id = param(req, 'id');
      const bundle = requireBundle(id);
      const plan = bundle.adBreaks as (AdBreakPlan & { candidates?: AdBreakCandidate[] }) | undefined;
      if (!plan) throw new HttpError(409, 'not_ready', 'Run the adbreaks job first');
      const candidates = plan.candidates ?? [];
      if (candidates.length === 0) throw new HttpError(409, 'no_candidates', 'This plan has no stored candidates to re-plan from; re-run the adbreaks job');
      const body = (req.body ?? {}) as Partial<AdBreakPlan['policy']>;
      const policy: Partial<AdBreakPlan['policy']> = {};
      for (const key of ['targetBreaks', 'minSpacingSec', 'avoidFirstSec', 'avoidLastSec'] as const) {
        const v = body[key];
        if (v === undefined) continue;
        if (typeof v !== 'number' || !Number.isFinite(v) || v < 0) throw new HttpError(400, 'bad_request', `${key} must be a non-negative number`);
        policy[key] = v;
      }
      const next = replanAdBreaks(bundle, candidates, policy, plan.model);
      const withCandidates = { ...next, candidates };
      store.updateBundle(id, (b) => {
        b.adBreaks = withCandidates;
      });
      return withCandidates;
    }),
  );

  /** Assign (or clear, with `creativeId: null`) a creative on some or all planned breaks. */
  router.post(
    '/catalog/:id/adbreaks/assign',
    wrap((req) => {
      const id = param(req, 'id');
      const bundle = requireBundle(id);
      if (!bundle.adBreaks) throw new HttpError(409, 'not_ready', 'Run the adbreaks job first');
      const body = (req.body ?? {}) as { creativeId?: string | null; breakIds?: unknown };
      const creativeId = body.creativeId === null || body.creativeId === undefined ? null : String(body.creativeId);
      if (creativeId) requireAd(creativeId);
      const breakIds = Array.isArray(body.breakIds) ? body.breakIds.map(String) : undefined;
      if (breakIds) {
        const known = new Set(bundle.adBreaks.breaks.map((b) => b.id));
        const missing = breakIds.filter((b) => !known.has(b));
        if (missing.length) throw new HttpError(404, 'not_found', `Unknown break id(s): ${missing.join(', ')}`);
      }
      const updated = store.updateBundle(id, (b) => {
        for (const brk of b.adBreaks?.breaks ?? []) {
          if (breakIds && !breakIds.includes(brk.id)) continue;
          if (creativeId) brk.creativeId = creativeId;
          else {
            delete brk.creativeId;
            delete brk.snappedAt;
          }
        }
      });
      return updated!.adBreaks;
    }),
  );

  /** Creative-to-break fit for every planned break (deterministic, no model call). */
  router.get(
    '/catalog/:id/adbreaks/fit',
    wrap((req) => {
      const bundle = requireBundle(param(req, 'id'));
      if (!bundle.adBreaks) throw new HttpError(409, 'not_ready', 'Run the adbreaks job first');
      const creatives = store.allAds();
      return {
        itemId: bundle.item.id,
        creatives: creatives.map((c) => ({ id: c.id, name: c.name, fingerprinted: !!c.fingerprint })),
        breaks: bundle.adBreaks.breaks.map((brk) => ({ breakId: brk.id, at: brk.at, rank: brk.rank, assigned: brk.creativeId, fits: rankCreatives(brk, creatives) })),
      };
    }),
  );

  /** Assign the best-fitting fingerprinted creative to each planned break (optionally only breaks above `minScore`). */
  router.post(
    '/catalog/:id/adbreaks/autoassign',
    wrap((req) => {
      const id = param(req, 'id');
      const bundle = requireBundle(id);
      if (!bundle.adBreaks) throw new HttpError(409, 'not_ready', 'Run the adbreaks job first');
      const body = (req.body ?? {}) as { minScore?: unknown; breakIds?: unknown };
      const minScore = typeof body.minScore === 'number' ? Math.max(0, Math.min(1, body.minScore)) : 0;
      const breakIds = Array.isArray(body.breakIds) ? new Set(body.breakIds.map(String)) : undefined;
      const creatives = store.allAds();
      if (!creatives.some((c) => c.fingerprint)) throw new HttpError(409, 'no_fingerprints', 'No creative has a fingerprint yet; POST /api/ads/:id/fingerprint first');
      const picks = autoAssign(bundle.adBreaks.breaks.filter((b) => !breakIds || breakIds.has(b.id)), creatives, minScore);
      const updated = store.updateBundle(id, (b) => {
        for (const pick of picks) {
          const brk = b.adBreaks?.breaks.find((x) => x.id === pick.breakId);
          if (!brk || !pick.creativeId) continue;
          if (brk.creativeId !== pick.creativeId) delete brk.snappedAt;
          brk.creativeId = pick.creativeId;
        }
      });
      return { plan: updated!.adBreaks, assignments: picks };
    }),
  );

  /* ---- stitched previews ------------------------------------------ */

  router.post(
    '/catalog/:id/stitch',
    wrap(async (req, res) => {
      const id = param(req, 'id');
      const bundle = requireBundle(id);
      const plan = bundle.adBreaks;
      if (!plan) throw new HttpError(409, 'not_ready', 'Run the adbreaks job first');
      const body = (req.body ?? {}) as { creativeId?: string; breakIds?: unknown; includeUnapproved?: boolean; dryRun?: boolean };

      // Which breaks: explicit ids → approved → (opt-in) every planned, non-declined break.
      let selected: AdBreak[];
      if (Array.isArray(body.breakIds) && body.breakIds.length > 0) {
        const ids = body.breakIds.map(String);
        selected = plan.breaks.filter((b) => ids.includes(b.id));
        const missing = ids.filter((x) => !selected.some((b) => b.id === x));
        if (missing.length) throw new HttpError(404, 'not_found', `Unknown break id(s): ${missing.join(', ')}`);
      } else {
        selected = plan.breaks.filter(isApproved);
        if (selected.length === 0 && body.includeUnapproved) selected = plan.breaks.filter((b) => !isDeclined(b));
      }
      if (selected.length === 0) {
        throw new HttpError(409, 'no_breaks', plan.breaks.length === 0 ? 'This title has no planned ad breaks' : 'No approved ad breaks; approve some or pass includeUnapproved:true');
      }
      selected.sort((a, b) => a.at - b.at);

      // Which creative: explicit, else the one assigned to the selected breaks.
      const assigned = [...new Set(selected.map((b) => b.creativeId).filter((x): x is string => !!x))];
      const creativeId = body.creativeId ? String(body.creativeId) : assigned[0];
      if (!creativeId) throw new HttpError(400, 'no_creative', 'No creative assigned to the selected breaks; pass creativeId or POST /adbreaks/assign first');
      const creative = requireAd(creativeId);
      const dryRun = body.dryRun === true;

      // Fail fast on the two things a queued job could never recover from.
      if (!dryRun && !bundle.item.localPath) throw new HttpError(409, 'needs_local_file', 'Stitching needs the movie on disk: ingest it with sourceUrl set to an absolute local path (or pass dryRun:true)');
      if (!dryRun && !(await hasFfmpeg())) throw new HttpError(503, 'stitch_unavailable', 'ffmpeg/ffprobe are not installed on the API host (or pass dryRun:true)');

      const job: StitchJob = { id: makeId('stitch'), itemId: id, creativeId, status: 'queued', insertions: [], createdAt: nowIso() };
      store.saveStitch(job);
      runner.emitEvent({ type: 'stitch', job });
      stitches.enqueue(job, {
        item: bundle.item,
        creative,
        breaks: selected,
        rendersDir: config.rendersDir,
        dryRun,
        onProgress: (next) => {
          store.saveStitch(next);
          runner.emitEvent({ type: 'stitch', job: next });
          // Reflect the keyframe-aligned points on the breaks themselves.
          if (next.insertions.length > 0) {
            store.updateBundle(id, (b) => {
              for (const ins of next.insertions) {
                const brk = b.adBreaks?.breaks.find((x) => x.id === ins.breakId);
                if (brk) brk.snappedAt = ins.snappedAt;
              }
            });
          }
          if (next.status === 'ready' || next.status === 'failed') {
            runner.emitEvent({ type: 'log', at: nowIso(), message: `[stitch ${next.id}] ${next.status}${next.error ? `: ${next.error}` : next.outputUrl ? ` → ${next.outputUrl}` : ''}` });
          }
        },
      });
      res.status(202);
      return job;
    }),
  );

  router.get(
    '/stitch',
    wrap((req) => {
      const itemId = typeof req.query.itemId === 'string' ? req.query.itemId : undefined;
      return store
        .allStitches()
        .filter((s) => !itemId || s.itemId === itemId)
        .slice()
        .reverse();
    }),
  );

  router.get(
    '/stitch/:id',
    wrap((req) => {
      const job = store.getStitch(param(req, 'id'));
      if (!job) throw new HttpError(404, 'not_found', 'Stitch job not found');
      return job;
    }),
  );

  const renderPath = (file: string): string => {
    if (!/^[A-Za-z0-9._-]+$/.test(file) || file.includes('..')) throw new HttpError(400, 'bad_request', 'Invalid render file name');
    return join(config.rendersDir, file);
  };
  router.get(
    '/renders/:file',
    wrap((req, res) => streamFile(req, res, renderPath(param(req, 'file')), 'video/mp4')),
  );
  router.head('/renders/:file', (req, res, next) => {
    try {
      void streamFile(req, res, renderPath(String(req.params.file)), 'video/mp4').catch(next);
    } catch (err) {
      next(err);
    }
  });

  /* ---- ad creatives ------------------------------------------------ */

  router.get(
    '/ads',
    wrap(() => store.allAds()),
  );

  router.post(
    '/ads',
    wrap(async (req, res) => {
      const body = (req.body ?? {}) as { name?: string; advertiser?: string; sourceUrl?: string; localPath?: string; durationSec?: number; width?: number; height?: number };
      const localPath = localPathFrom(body.localPath) ?? localPathFrom(body.sourceUrl);
      const sourceUrl = typeof body.sourceUrl === 'string' && isHttpUrl(body.sourceUrl) ? body.sourceUrl.trim() : undefined;
      if (!localPath && !sourceUrl) throw new HttpError(400, 'bad_request', 'Provide sourceUrl (http(s) URL) or localPath (absolute path / file:// URL)');
      const name = typeof body.name === 'string' && body.name.trim() ? body.name.trim() : localPath ? titleFromFile(localPath) : titleFromUrl(sourceUrl!);
      const id = makeId('ad');
      const ad: AdCreative = {
        id,
        name,
        advertiser: typeof body.advertiser === 'string' && body.advertiser.trim() ? body.advertiser.trim() : undefined,
        durationSec: typeof body.durationSec === 'number' && body.durationSec > 0 ? body.durationSec : 0,
        width: typeof body.width === 'number' ? body.width : undefined,
        height: typeof body.height === 'number' ? body.height : undefined,
        mediaUrl: localPath ? `/api/ads/${id}/media` : sourceUrl!,
        createdAt: nowIso(),
      };
      if (localPath) {
        await requireFile(localPath).catch(asHttp);
        ad.localPath = localPath;
      }
      if (sourceUrl) ad.sourceUrl = sourceUrl;
      // Probe local files always; probe URLs only when the caller did not state a duration (it is a network fetch).
      if ((localPath || !ad.durationSec) && (await hasFfmpeg())) {
        const info = await probeMedia(localPath ?? sourceUrl!).catch((err) => (localPath ? asHttp(err) : undefined));
        if (info) {
          if (info.durationSec > 0) ad.durationSec = Math.round(info.durationSec * 1000) / 1000;
          if (info.video) {
            ad.width = info.video.width || ad.width;
            ad.height = info.video.height || ad.height;
          }
        }
      }
      if (!ad.durationSec) ad.durationSec = 30;
      store.saveAd(ad);
      res.status(201);
      return ad;
    }),
  );

  router.get(
    '/ads/:id',
    wrap((req) => requireAd(param(req, 'id'))),
  );

  router.delete(
    '/ads/:id',
    wrap((req, res) => {
      if (!store.deleteAd(param(req, 'id'))) throw new HttpError(404, 'not_found', 'Ad creative not found');
      res.status(204).end();
    }),
  );

  router.get(
    '/ads/:id/media',
    wrap(async (req, res) => {
      const ad = requireAd(param(req, 'id'));
      if (!ad.localPath) {
        if (ad.sourceUrl) return void res.redirect(302, ad.sourceUrl);
        throw new HttpError(404, 'no_local_file', 'This creative has no local file');
      }
      await streamFile(req, res, resolveMediaPath(ad.localPath), mimeFor(ad.localPath, 'video/mp4'));
    }),
  );
  router.head('/ads/:id/media', (req, res, next) => {
    const ad = store.getAd(String(req.params.id));
    if (!ad?.localPath) return next(new HttpError(404, 'no_local_file', 'This creative has no local file'));
    void streamFile(req, res, resolveMediaPath(ad.localPath), mimeFor(ad.localPath, 'video/mp4')).catch(next);
  });

  /** Creative intelligence: one Pegasus call (uploading the file as an asset first when needed). */
  router.post(
    '/ads/:id/fingerprint',
    wrap(async (req) => {
      const ad = requireAd(param(req, 'id'));
      const started = Date.now();
      // → POST /v1.3/assets (if needed) then POST /v1.3/analyze (pegasus1.5, json_schema: adFingerprint)
      const { creative, upstream } = await fingerprintCreative(ad, client, (note) => console.log(`[ads] ${ad.id} ${note}`));
      const saved = store.saveAd(creative);
      runner.emitEvent({ type: 'ad', ad: saved });
      return { ...saved, _meta: { model: upstream.model, assetId: upstream.assetId, ms: Date.now() - started } };
    }),
  );

  /** Impression beacon referenced from inline VAST — accepted and dropped. */
  router.get('/ads/:id/impression', (_req, res) => res.status(204).end());

  /* ---- exports ---------------------------------------------------- */

  const exportOpts = (req: Request): ExportOptions => {
    const q = req.query as Record<string, string | undefined>;
    const flag = (v: string | undefined) => v === '1' || v === 'true';
    return { all: flag(q.all), preRoll: flag(q.preroll ?? q.preRoll), postRoll: flag(q.postroll ?? q.postRoll), durationSec: q.duration ? Number(q.duration) : undefined };
  };

  router.get(
    '/catalog/:id/export/vmap',
    wrap((req, res) => {
      const bundle = requireBundle(param(req, 'id'));
      res.type('application/xml').send(toVmap(bundle, { ...exportOpts(req), creative: (cid) => store.getAd(cid), baseUrl: requestOrigin(req) }));
    }),
  );

  router.get(
    '/catalog/:id/export/scte35',
    wrap((req) => toScte35(requireBundle(param(req, 'id')), exportOpts(req))),
  );

  router.get(
    '/catalog/:id/export/markers',
    wrap((req) => toPlayerMarkers(requireBundle(param(req, 'id')))),
  );

  /* ---- similar ---------------------------------------------------- */

  router.get(
    '/catalog/:id/similar',
    wrap((req) => {
      const bundle = requireBundle(param(req, 'id'));
      const limit = Math.min(50, Math.max(1, Number(req.query.limit ?? 8) || 8));
      return similarTitles(bundle.item, store.allItems(), limit);
    }),
  );

  /* ---- recommendations -------------------------------------------- */

  registerRecoRoutes(router, { store, requireItem: (id) => requireBundle(id).item });

  /* ---- search ----------------------------------------------------- */

  router.post(
    '/search',
    wrap(async (req): Promise<SearchResponse> => {
      const body = (req.body ?? {}) as { query?: string; modalities?: SearchModality[]; limit?: number; pageToken?: string };
      const query = typeof body.query === 'string' ? body.query.trim() : '';
      if (!query && !body.pageToken) throw new HttpError(400, 'bad_request', 'query is required');
      const modalities = (body.modalities ?? ['visual', 'audio']).filter((m): m is SearchModality => ['visual', 'audio', 'transcription'].includes(m));
      const limit = Math.min(50, Math.max(1, Number(body.limit ?? 20) || 20));

      // Map TwelveLabs video ids back to catalog items (mock ids derive from the source URL).
      const byVideoId = new Map<string, CatalogItem>();
      for (const item of store.allItems()) {
        if (item.upstream?.indexedAssetId) byVideoId.set(item.upstream.indexedAssetId, item);
        if (client.mode === 'mock') byVideoId.set(mockVideoId(item.sourceUrl), item);
      }

      // → POST /v1.3/search (marengo3.0, multipart, group_by clip) or GET /v1.3/search/:page_token
      const page = body.pageToken
        ? await client.searchPage(body.pageToken)
        : await client.search({ indexId: await ensureIndex(pipeline), queryText: query, searchOptions: modalities, groupBy: 'clip', pageLimit: limit });

      const hits: SearchHit[] = page.data.flatMap((h, i) => {
        const item = byVideoId.get(h.video_id);
        if (!item) return [];
        const hit: SearchHit = { itemId: item.id, title: item.title, start: h.start, end: h.end, rank: h.rank ?? i + 1 };
        if (typeof h.score === 'number') hit.score = h.score;
        if (h.thumbnail_url) hit.thumbnailUrl = h.thumbnail_url;
        if (h.transcription) hit.transcript = h.transcription;
        if (h.modality === 'visual' || h.modality === 'audio' || h.modality === 'transcription') hit.modality = h.modality;
        return [hit];
      });
      const items = store.allItems();
      return {
        query,
        hits,
        nextPageToken: page.page_info?.next_page_token,
        pool: {
          items: page.search_pool?.total_count ?? items.length,
          totalDurationSec: Math.round(page.search_pool?.total_duration ?? items.reduce((a, i) => a + (i.durationSec ?? 0), 0)),
        },
      };
    }),
  );

  /* ---- lists ------------------------------------------------------ */

  router.get(
    '/lists',
    wrap(() => store.allLists()),
  );

  router.post(
    '/lists',
    wrap(async (req, res) => {
      const body = (req.body ?? {}) as { name?: string; description?: string; source?: SmartList['source']; rules?: unknown; query?: string };
      if (typeof body.name !== 'string' || !body.name.trim()) throw new HttpError(400, 'bad_request', 'name is required');
      const source = body.source ?? (body.query ? 'query' : 'rules');
      const items = store.allItems();
      const now = nowIso();
      let list: SmartList;
      if (source === 'rules') {
        const rules = validateRules(body.rules ?? []);
        const itemIds = items.filter((i) => matchesRules(i, rules)).map((i) => i.id);
        list = { id: makeId('lst'), name: body.name.trim(), description: body.description, source, rules, itemIds, coverage: items.length ? itemIds.length / items.length : 0, createdAt: now, updatedAt: now };
      } else if (source === 'query') {
        if (typeof body.query !== 'string' || !body.query.trim()) throw new HttpError(400, 'bad_request', 'query is required for a query list');
        // → POST /v1.3/embed-v2 (text) then cosine vs item embeddings
        const matches = selectQueryMatches(await queryItems(client, items, body.query.trim()));
        const itemIds = matches.map((m) => m.itemId);
        list = { id: makeId('lst'), name: body.name.trim(), description: body.description ?? `Query: "${body.query.trim()}"`, source, query: body.query.trim(), itemIds, coverage: items.length ? itemIds.length / items.length : 0, createdAt: now, updatedAt: now };
      } else {
        throw new HttpError(400, 'bad_request', 'source must be rules or query (use POST /api/lists/curate for ai)');
      }
      list.coverage = Math.round((list.coverage ?? 0) * 1000) / 1000;
      store.saveList(list);
      res.status(201);
      return list;
    }),
  );

  /** AI curation: k-means over embeddings, replaces previous AI lists. */
  router.post(
    '/lists/curate',
    wrap(() => {
      const lists = curateCatalog(store.allItems());
      store.replaceAiLists(lists);
      return lists;
    }),
  );

  router.delete(
    '/lists/:id',
    wrap((req, res) => {
      if (!store.deleteList(param(req, 'id'))) throw new HttpError(404, 'not_found', 'List not found');
      res.status(204).end();
    }),
  );

  /* ---- recipes + runs --------------------------------------------- */

  router.get(
    '/recipes',
    wrap(() => store.allRecipes()),
  );

  router.post(
    '/recipes',
    wrap((req, res) => {
      const body = (req.body ?? {}) as Partial<Recipe>;
      if (typeof body.name !== 'string' || !body.name.trim()) throw new HttpError(400, 'bad_request', 'name is required');
      if (body.target !== 'thumbnails' && body.target !== 'clips') throw new HttpError(400, 'bad_request', 'target must be thumbnails or clips');
      if (typeof body.brief !== 'string') throw new HttpError(400, 'bad_request', 'brief is required (free text)');
      const count = Math.min(24, Math.max(1, Number(body.count ?? (body.target === 'thumbnails' ? 12 : 6)) || 6));
      const formats = (body.formats ?? ['16:9']).filter((f): f is Recipe['formats'][number] => ['16:9', '2:3', '1:1', '9:16'].includes(f));
      const recipe: Recipe = {
        id: makeId('rcp'),
        name: body.name.trim(),
        target: body.target,
        brief: body.brief.trim(),
        count,
        clipLengthSec: Array.isArray(body.clipLengthSec) && body.clipLengthSec.length === 2 ? [Number(body.clipLengthSec[0]), Number(body.clipLengthSec[1])] : undefined,
        formats: formats.length ? formats : ['16:9'],
        requireCharacters: Array.isArray(body.requireCharacters) ? body.requireCharacters.map(String) : undefined,
        excludeSafetyCategories: Array.isArray(body.excludeSafetyCategories) ? body.excludeSafetyCategories : undefined,
        createdAt: nowIso(),
      };
      store.saveRecipe(recipe);
      res.status(201);
      return recipe;
    }),
  );

  router.delete(
    '/recipes/:id',
    wrap((req, res) => {
      if (!store.deleteRecipe(param(req, 'id'))) throw new HttpError(404, 'not_found', 'Recipe not found');
      res.status(204).end();
    }),
  );

  router.post(
    '/recipes/:id/run',
    wrap((req, res) => {
      const recipe = store.getRecipe(param(req, 'id'));
      if (!recipe) throw new HttpError(404, 'not_found', 'Recipe not found');
      const body = (req.body ?? {}) as { itemIds?: string[] };
      const itemIds = Array.isArray(body.itemIds) ? body.itemIds.map(String) : [];
      if (itemIds.length === 0) throw new HttpError(400, 'bad_request', 'itemIds is required');
      const runs = itemIds.map((id) => runner.enqueueRecipeRun(recipe, requireBundle(id).item));
      res.status(202);
      return runs;
    }),
  );

  router.get(
    '/runs',
    wrap(() => store.allRuns()),
  );

  router.get(
    '/runs/:id',
    wrap((req) => {
      const run = store.getRun(param(req, 'id'));
      if (!run) throw new HttpError(404, 'not_found', 'Run not found');
      return run;
    }),
  );

  /* ---- jobs + events ---------------------------------------------- */

  router.get(
    '/jobs',
    wrap((req) => {
      const status = typeof req.query.status === 'string' ? req.query.status : undefined;
      const itemId = typeof req.query.itemId === 'string' ? req.query.itemId : undefined;
      return store
        .allJobs()
        .filter((j) => (!status || j.status === status) && (!itemId || j.itemId === itemId))
        .slice()
        .reverse();
    }),
  );

  router.get('/events', (_req, res) => runner.subscribe(res));

  return router;
}

function titleFromFile(path: string): string {
  return basename(path).replace(/\.[a-z0-9]{2,4}$/i, '').replace(/[-_]+/g, ' ').trim() || 'Untitled';
}

function titleFromUrl(url: string): string {
  try {
    const u = new URL(url);
    const yt = u.searchParams.get('v');
    if (yt) return `YouTube ${yt}`;
    const last = u.pathname.split('/').filter(Boolean).at(-1) ?? u.hostname;
    return decodeURIComponent(last).replace(/\.[a-z0-9]{2,4}$/i, '').replace(/[-_]+/g, ' ') || u.hostname;
  } catch {
    return 'Untitled';
  }
}

export function errorHandler() {
  return (err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof HttpError) {
      res.status(err.status).json({ error: { code: err.code, message: err.message } });
      return;
    }
    if (err instanceof TwelveLabsError) {
      res.status(err.status >= 400 && err.status < 600 ? err.status : 502).json({ error: { code: err.code, message: err.message, details: err.details } });
      return;
    }
    if (err && typeof err === 'object' && 'type' in err && (err as { type: string }).type === 'entity.parse.failed') {
      res.status(400).json({ error: { code: 'bad_json', message: 'Request body is not valid JSON' } });
      return;
    }
    const message = err instanceof Error ? err.message : String(err);
    console.error('[api] unhandled error:', err);
    res.status(500).json({ error: { code: 'internal', message } });
  };
}
