/**
 * Seed stats — `npm run seed` (root) / `npm run seed -w @twelve-studio/api`.
 * Prints what data/seed contains and what the runtime store currently holds.
 */

import { loadSeed } from '@twelve-studio/core';
import { loadConfig } from './config.js';
import { Store } from './store.js';

const config = loadConfig();
const seed = await loadSeed(config.seedDir);

console.log(`Seed directory: ${config.seedDir}`);
console.log(`  items: ${seed.catalog.length}   lists: ${seed.lists.length}`);
for (const b of seed.catalog) {
  const fp = b.fingerprint;
  const langs = Object.keys(fp?.synopsis.translations ?? {});
  console.log(
    `  - ${b.item.id.padEnd(20)} ${b.item.title.padEnd(20)} ${String(b.item.durationSec ?? 0).padStart(5)}s ` +
      `fp=${fp ? 'yes' : 'no '} langs=${langs.length} emo=${b.emotions?.samples.length ?? 0} mk=${b.markers?.markers.length ?? 0} ` +
      `saf=${b.safety?.segments.length ?? 0} brk=${b.adBreaks?.breaks.length ?? 0} thm=${b.thumbnails?.length ?? 0} clp=${b.clips?.length ?? 0}`,
  );
}
for (const l of seed.lists) console.log(`  · list ${l.id.padEnd(30)} ${l.source.padEnd(6)} ${l.itemIds.length} items  "${l.name}"`);

const store = new Store(config.storePath);
const loaded = await store.load();
console.log(`\nRuntime store: ${config.storePath} ${loaded ? '' : '(not created yet)'}`);
if (loaded) {
  const items = store.allItems();
  console.log(`  items: ${items.length}   lists: ${store.allLists().length}   recipes: ${store.allRecipes().length}   jobs: ${store.allJobs().length}`);
  for (const i of items) {
    const ready = Object.values(i.jobs).filter((s) => s === 'ready').length;
    console.log(`  - ${i.id.padEnd(28)} ${i.status.padEnd(9)} jobs ready ${ready}/9 ${i.fingerprint?.embedding ? 'embedding ✓' : ''}`);
  }
}
console.log(`\nMode: ${config.mode}${config.mode === 'mock' ? ' (set TWELVELABS_API_KEY in .env for live TwelveLabs calls)' : ''}`);
