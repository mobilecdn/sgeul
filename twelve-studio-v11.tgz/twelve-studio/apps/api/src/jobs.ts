/**
 * Job runner: a small FIFO queue (concurrency 2 by default) that runs
 * `enrichItem` / creative recipes and fans out progress as SSE events.
 */

import { EventEmitter } from 'node:events';
import type { Response } from 'express';
import {
  enrichItem,
  runJob,
  makeId,
  nowIso,
  type CatalogItem,
  type CreativeRun,
  type EnrichOptions,
  type Job,
  type JobKind,
  type JobProgress,
  type PipelineDeps,
  type Recipe,
  type ThumbnailCandidate,
  type PreviewClip,
  type StitchJob,
  type AdCreative,
} from '@twelve-studio/core';
import type { Store } from './store.js';
import { publicItem } from './views.js';

export type StudioEvent =
  | { type: 'job'; job: Job }
  | { type: 'item'; item: CatalogItem }
  | { type: 'run'; run: CreativeRun }
  | { type: 'stitch'; job: StitchJob }
  | { type: 'ad'; ad: AdCreative }
  | { type: 'log'; at: string; message: string };

interface Task {
  id: string;
  label: string;
  run: () => Promise<void>;
}

export class JobRunner extends EventEmitter {
  private readonly queue: Task[] = [];
  private running = 0;
  private readonly clients = new Set<Response>();
  private readonly heartbeat: NodeJS.Timeout;

  constructor(
    private readonly store: Store,
    private readonly deps: PipelineDeps,
    private readonly concurrency = 2,
  ) {
    super();
    this.heartbeat = setInterval(() => {
      for (const res of this.clients) res.write(': ping\n\n');
    }, 25_000);
    this.heartbeat.unref();
  }

  /* ---- SSE --------------------------------------------------------- */

  subscribe(res: Response): void {
    res.setHeader('content-type', 'text/event-stream');
    res.setHeader('cache-control', 'no-cache, no-transform');
    res.setHeader('connection', 'keep-alive');
    res.setHeader('x-accel-buffering', 'no');
    res.flushHeaders();
    res.write(`event: hello\ndata: ${JSON.stringify({ at: nowIso(), queued: this.queue.length, running: this.running })}\n\n`);
    this.clients.add(res);
    res.on('close', () => this.clients.delete(res));
  }

  emitEvent(event: StudioEvent): void {
    this.emit('event', event);
    const payload = `data: ${JSON.stringify(event)}\n\n`;
    for (const res of this.clients) res.write(payload);
  }

  get stats(): { queued: number; running: number; clients: number } {
    return { queued: this.queue.length, running: this.running, clients: this.clients.size };
  }

  /* ---- enrichment -------------------------------------------------- */

  /**
   * Queue a full (or partial) enrichment for an item. Creates `queued` Job
   * rows immediately so the UI can show the pipeline before it starts.
   */
  enqueueEnrichment(item: CatalogItem, options: EnrichOptions = {}): Job[] {
    const kinds: JobKind[] = options.only ?? ['ingest', 'fingerprint', 'embedding', 'emotions', 'markers', 'safety', 'adbreaks', 'thumbnails', 'clips'];
    const jobs: Job[] = [];
    for (const kind of kinds) {
      const open = this.store.openJob(item.id, kind);
      if (open) {
        jobs.push(open);
        continue;
      }
      const alreadyReady = !options.force && item.jobs[kind] === 'ready';
      if (alreadyReady && !options.only) continue; // enrichItem will skip it anyway
      const job: Job = { id: makeId('job'), itemId: item.id, kind, status: 'queued' };
      this.store.upsertJob(job);
      this.emitEvent({ type: 'job', job });
      jobs.push(job);
    }
    // Reflect the queue on the item itself so list views show the pipeline before it starts.
    const queuedKinds = jobs.filter((j) => j.status === 'queued').map((j) => j.kind);
    if (queuedKinds.length > 0) {
      const current = this.store.getBundle(item.id)?.item ?? item;
      const next = this.store.saveItem({ ...current, jobs: { ...current.jobs, ...Object.fromEntries(queuedKinds.map((k) => [k, 'queued'])) } });
      this.emitEvent({ type: 'item', item: publicItem(next) });
    }
    this.push({
      id: makeId('task'),
      label: `enrich ${item.id}${options.only ? ` (${options.only.join(',')})` : ''}`,
      run: async () => {
        const current = this.store.getBundle(item.id)?.item;
        if (!current) return; // deleted while queued
        const updated = await enrichItem(current, this.deps, (p) => this.onProgress(p), options);
        this.emitEvent({ type: 'item', item: publicItem(updated) });
      },
    });
    return jobs;
  }

  private onProgress(p: JobProgress): void {
    let job = this.store.openJob(p.itemId, p.kind);
    if (!job) {
      if (p.status === 'skipped' && p.note === 'already ready') return; // nothing to record
      job = { id: makeId('job'), itemId: p.itemId, kind: p.kind, status: 'queued' };
    }
    const next: Job = { ...job, status: p.status };
    if (p.startedAt && !next.startedAt) next.startedAt = p.startedAt;
    if (p.finishedAt) next.finishedAt = p.finishedAt;
    if (p.error) next.error = p.error;
    if (p.upstream) next.upstream = { ...(next.upstream ?? {}), ...p.upstream };
    if (p.status === 'skipped' && !next.finishedAt) next.finishedAt = nowIso();
    this.store.upsertJob(next);
    this.emitEvent({ type: 'job', job: next });
    if (p.note) this.emitEvent({ type: 'log', at: nowIso(), message: `[${p.itemId}/${p.kind}] ${p.note}` });
    const item = this.store.getBundle(p.itemId)?.item;
    if (item && (p.status === 'ready' || p.status === 'failed')) this.emitEvent({ type: 'item', item: publicItem(item) });
  }

  /* ---- creative recipes --------------------------------------------- */

  /** Queue a recipe run for one item; returns the `queued` CreativeRun immediately. */
  enqueueRecipeRun(recipe: Recipe, item: CatalogItem): CreativeRun {
    const run: CreativeRun = { id: makeId('run'), recipeId: recipe.id, itemId: item.id, status: 'queued', createdAt: nowIso() };
    this.store.saveRun(run);
    this.emitEvent({ type: 'run', run });
    this.push({
      id: run.id,
      label: `recipe ${recipe.name} → ${item.id}`,
      run: async () => {
        const current = this.store.getBundle(item.id)?.item;
        if (!current) {
          this.store.saveRun({ ...run, status: 'failed' });
          return;
        }
        this.store.saveRun({ ...run, status: 'running' });
        this.emitEvent({ type: 'run', run: { ...run, status: 'running' } });
        try {
          const brief = {
            brief: recipe.brief,
            count: recipe.count,
            requireCharacters: recipe.requireCharacters,
            excludeSafetyCategories: recipe.excludeSafetyCategories,
          };
          const result =
            recipe.target === 'thumbnails'
              ? await runJob('thumbnails', current, this.deps, { creative: { thumbnails: { ...brief, formats: recipe.formats } } })
              : await runJob('clips', current, this.deps, { creative: { clips: { ...brief, clipLengthSec: recipe.clipLengthSec } } });
          const done: CreativeRun = {
            ...run,
            status: 'ready',
            ...(recipe.target === 'thumbnails'
              ? { thumbnails: result.output as ThumbnailCandidate[] }
              : { clips: result.output as PreviewClip[] }),
          };
          this.store.saveRun(done);
          this.emitEvent({ type: 'run', run: done });
        } catch (err) {
          const failed: CreativeRun = { ...run, status: 'failed' };
          this.store.saveRun(failed);
          this.emitEvent({ type: 'run', run: failed });
          this.emitEvent({ type: 'log', at: nowIso(), message: `[run ${run.id}] failed: ${(err as Error).message}` });
        }
      },
    });
    return run;
  }

  /* ---- queue mechanics ---------------------------------------------- */

  private push(task: Task): void {
    this.queue.push(task);
    this.pump();
  }

  private pump(): void {
    while (this.running < this.concurrency && this.queue.length > 0) {
      const task = this.queue.shift()!;
      this.running += 1;
      task
        .run()
        .catch((err: unknown) => {
          this.emitEvent({ type: 'log', at: nowIso(), message: `[${task.label}] ${(err as Error).message}` });
        })
        .finally(() => {
          this.running -= 1;
          this.pump();
        });
    }
  }

  /** Resolves when the queue drains (used by tests and the seed script). */
  idle(): Promise<void> {
    if (this.running === 0 && this.queue.length === 0) return Promise.resolve();
    return new Promise((resolve) => {
      const check = () => {
        if (this.running === 0 && this.queue.length === 0) {
          this.off('event', check);
          resolve();
        }
      };
      this.on('event', check);
      // Also poll in case the last task emits nothing.
      const t = setInterval(() => {
        if (this.running === 0 && this.queue.length === 0) {
          clearInterval(t);
          this.off('event', check);
          resolve();
        }
      }, 100);
      t.unref();
    });
  }

  close(): void {
    clearInterval(this.heartbeat);
    for (const res of this.clients) res.end();
    this.clients.clear();
  }
}
