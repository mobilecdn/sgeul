/**
 * Smart lists: rule filters over fingerprints, natural-language queries via
 * Marengo text embeddings (cosine against item embeddings, keyword fallback),
 * and AI curation via k-means over embeddings labelled by shared labels.
 */

import {
  cosine,
  curationK,
  kmeans,
  labelCluster,
  labelVector,
  makeId,
  nowIso,
  type CatalogItem,
  type SmartList,
  type SmartListRule,
  type TwelveLabsClientLike,
} from '@twelve-studio/core';

/* ------------------------------------------------------------------ */
/* Rules                                                               */
/* ------------------------------------------------------------------ */

export function matchesRules(item: CatalogItem, rules: SmartListRule[]): boolean {
  const fp = item.fingerprint;
  if (!fp) return false;
  return rules.every((rule) => {
    const labels = fp[rule.facet] ?? {};
    const score = ruleScore(labels, rule.label);
    return score >= rule.min && score <= rule.max;
  });
}

/**
 * Score of a rule label against an open-vocabulary facet. Vocabularies are free
 * text ("fantasy adventure", "creature fantasy"), so a rule for "fantasy" matches
 * the exact label first, otherwise any label containing it as a whole word, taking
 * the highest confidence among matches. No match → 0 (so `min: 0` rules still pass).
 */
export function ruleScore(labels: Record<string, number>, label: string): number {
  const want = label.trim().toLowerCase();
  if (!want) return 0;
  const exact = Object.keys(labels).find((k) => k.toLowerCase() === want);
  if (exact !== undefined) return labels[exact] ?? 0;
  const word = new RegExp(`(^|[^a-z0-9])${want.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z0-9]|$)`);
  let best = 0;
  for (const [k, v] of Object.entries(labels)) if (word.test(k.toLowerCase())) best = Math.max(best, v);
  return best;
}

export function validateRules(input: unknown): SmartListRule[] {
  if (!Array.isArray(input)) throw new Error('rules must be an array');
  const facets = new Set(['genres', 'keywords', 'moods', 'moodTags', 'themes']);
  return input.map((r, i) => {
    const rule = r as Partial<SmartListRule>;
    if (!rule || typeof rule !== 'object') throw new Error(`rules[${i}] must be an object`);
    if (!facets.has(String(rule.facet))) throw new Error(`rules[${i}].facet must be one of ${[...facets].join(', ')}`);
    if (typeof rule.label !== 'string' || !rule.label.trim()) throw new Error(`rules[${i}].label is required`);
    const min = rule.min ?? 0;
    const max = rule.max ?? 1;
    if (typeof min !== 'number' || typeof max !== 'number' || min < 0 || max > 1 || min > max) throw new Error(`rules[${i}] min/max must satisfy 0 ≤ min ≤ max ≤ 1`);
    return { facet: rule.facet as SmartListRule['facet'], label: rule.label.trim(), min, max };
  });
}

/* ------------------------------------------------------------------ */
/* Vectors                                                             */
/* ------------------------------------------------------------------ */

/** Embedding for an item: Marengo when present, hashed label vector otherwise. */
export function itemVector(item: CatalogItem): number[] | undefined {
  const fp = item.fingerprint;
  if (!fp) return undefined;
  return fp.embedding?.length ? fp.embedding : labelVector(fp);
}

function keywordScore(item: CatalogItem, query: string): number {
  const fp = item.fingerprint;
  if (!fp) return 0;
  const tokens = query
    .toLowerCase()
    .split(/[^a-z0-9À-ɏ]+/)
    .filter((t) => t.length > 2);
  if (tokens.length === 0) return 0;
  const bag = [
    ...Object.keys(fp.keywords),
    ...Object.keys(fp.genres),
    ...Object.keys(fp.moods),
    ...Object.keys(fp.moodTags),
    ...Object.keys(fp.themes),
    fp.synopsis.short,
    fp.synopsis.long,
    item.title,
  ]
    .join(' ')
    .toLowerCase();
  return tokens.filter((t) => bag.includes(t)).length / tokens.length;
}

/* ------------------------------------------------------------------ */
/* NL query                                                            */
/* ------------------------------------------------------------------ */

export interface QueryMatch {
  itemId: string;
  score: number;
  cosine: number;
  keyword: number;
}

/**
 * Rank items for a natural-language query.
 * → POST /v1.3/embed-v2 (input_type text, marengo3.5) then cosine vs item embeddings.
 * Items without a Marengo embedding (or in mock mode) are compared in the
 * hashed label space; a keyword score is blended in as a safety net.
 */
export async function queryItems(client: TwelveLabsClientLike, items: CatalogItem[], query: string): Promise<QueryMatch[]> {
  let textEmbedding: number[] | undefined;
  try {
    textEmbedding = await client.embedText({ text: query });
  } catch {
    textEmbedding = undefined; // fall back to keywords only
  }
  const raw = items
    .filter((i) => i.fingerprint)
    .map((item) => {
      const vec = itemVector(item);
      const sameSpace = !!textEmbedding && !!vec && vec.length === textEmbedding.length;
      const cos = sameSpace ? Math.max(0, cosine(textEmbedding!, vec!)) : 0;
      return { itemId: item.id, cosine: cos, keyword: keywordScore(item, query) };
    });
  const topCos = Math.max(0.0001, ...raw.map((r) => r.cosine));
  return raw
    .map((r) => ({ ...r, score: Math.round((0.6 * (r.cosine / topCos) * (r.cosine > 0 ? 1 : 0) + 0.4 * r.keyword) * 1000) / 1000 }))
    .sort((a, b) => b.score - a.score);
}

/** Threshold used to materialise a query list from ranked matches. */
export function selectQueryMatches(matches: QueryMatch[]): QueryMatch[] {
  return matches.filter((m) => m.score >= 0.3 || m.keyword >= 0.5);
}

/* ------------------------------------------------------------------ */
/* AI curation                                                         */
/* ------------------------------------------------------------------ */

/** k-means over item vectors; k = clamp(items/6, 3, 12); one SmartList per non-empty cluster. */
export function curateCatalog(items: CatalogItem[]): SmartList[] {
  const withVec = items.map((item) => ({ item, vec: itemVector(item) })).filter((x): x is { item: CatalogItem; vec: number[] } => !!x.vec);
  if (withVec.length === 0) return [];
  // Mixed spaces (Marengo + label vectors) cannot be clustered together; fall back to label vectors for all.
  const dims = new Set(withVec.map((x) => x.vec.length));
  const vectors = dims.size === 1 ? withVec.map((x) => x.vec) : withVec.map((x) => labelVector(x.item.fingerprint!));
  const k = curationK(withVec.length);
  const { assignments } = kmeans(vectors, k, { seed: 12 });
  const now = nowIso();
  const lists: SmartList[] = [];
  for (let c = 0; c < k; c++) {
    const members = withVec.filter((_, i) => assignments[i] === c).map((x) => x.item);
    if (members.length === 0) continue;
    const label = labelCluster(members);
    lists.push({
      id: makeId('lst', `ai:${c}:${members.map((m) => m.id).sort().join(',')}`),
      name: label.name,
      description: `AI-curated · ${label.description}`,
      source: 'ai',
      itemIds: members.map((m) => m.id),
      coverage: Math.round((members.length / items.length) * 1000) / 1000,
      createdAt: now,
      updatedAt: now,
    });
  }
  return lists.sort((a, b) => b.itemIds.length - a.itemIds.length);
}
