/**
 * Twelve Studio API — boot.
 *
 *   npm run dev -w @twelve-studio/api      (tsx watch, mock mode unless TWELVELABS_API_KEY is set)
 *   npm run start -w @twelve-studio/api    (compiled)
 */

import { timingSafeEqual } from 'node:crypto';
import express from 'express';
import { existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import cors from 'cors';
import { MockTwelveLabsClient, TwelveLabsClient, loadSeed, needsIngest, type PipelineDeps, type TwelveLabsClientLike } from '@twelve-studio/core';
import { loadConfig, REPO_ROOT, type ApiConfig } from './config.js';
import { Store } from './store.js';
import { JobRunner } from './jobs.js';
import { buildRouter, errorHandler } from './routes.js';
import { StitchQueue } from './stitch.js';

export interface App {
  app: express.Express;
  store: Store;
  runner: JobRunner;
  stitches: StitchQueue;
  config: ApiConfig;
  client: TwelveLabsClientLike;
  close(): Promise<void>;
}

/** Build the app (used by the server and by tests). */
export async function createApp(config: ApiConfig = loadConfig()): Promise<App> {
  const store = new Store(config.storePath);
  const loaded = await store.load();

  // Seed the store — in mock AND live mode — so the product never starts empty. importSeed is a
  // no-op for ids already in the store, so titles added to the seed later (new real captures)
  // appear on the next boot without touching review state or stitch jobs on existing titles.
  const seed = await loadSeed(config.seedDir);
  const imported = store.importSeed(seed);
  if (!loaded) console.log(`[api] new store at ${config.storePath}`);

  const client: TwelveLabsClientLike =
    config.mode === 'live'
      ? new TwelveLabsClient({
          apiKey: config.apiKey!,
          onRequest: (r) => console.log(`[twelvelabs] ${r.method} ${r.path} → ${r.status} (${r.ms}ms)`),
        })
      : new MockTwelveLabsClient(seed, { bundles: () => store.allBundles(), latencyMs: config.mockLatencyMs });

  const pipeline: PipelineDeps = {
    client,
    store,
    config: {
      indexName: config.indexName,
      indexId: config.indexId,
      synopsisLanguages: config.synopsisLanguages,
      pollIntervalMs: config.mode === 'mock' ? 150 : 5000,
    },
  };

  const runner = new JobRunner(store, pipeline, config.concurrency);
  const stitches = new StitchQueue();

  // Mock mode: only fill the embedding (a label vector) so similarity works from the first request; never
  // synthesise content sections for seeded titles, so the demo stays real TwelveLabs output.
  // Live mode: finish whatever the seed left undone (e.g. a title whose fingerprint was never generated).
  const ALL_JOBS = ['ingest', 'fingerprint', 'embedding', 'emotions', 'markers', 'safety', 'adbreaks', 'thumbnails', 'clips'] as const;
  for (const item of store.allItems()) {
    const missing = ALL_JOBS.filter((k) => item.jobs[k] !== 'ready');
    // A seeded title can carry a real upstream asset that was never put in a Marengo index (e.g. uploaded via
    // Jockey or the playground): live mode indexes it in place so search covers it.
    if (config.mode === 'live' && !missing.includes('ingest') && needsIngest(item, client)) missing.unshift('ingest');
    if (missing.length === 0) continue;
    if (config.mode === 'mock') {
      if (item.jobs.embedding !== 'ready' && item.fingerprint) runner.enqueueEnrichment(item, { only: ['embedding'] });
    } else {
      runner.enqueueEnrichment(item, { only: [...missing] });
    }
  }

  const app = express();
  app.disable('x-powered-by');
  app.use(cors({ origin: config.corsOrigin }));
  if (config.basicAuth) app.use(basicAuth(config.basicAuth));
  app.use(express.json({ limit: '2mb' }));
  app.use((req, _res, next) => {
    if (req.path !== '/api/events') console.log(`[api] ${req.method} ${req.path}`);
    next();
  });
  app.use('/api', buildRouter({ store, runner, pipeline, config, startedAt: Date.now(), stitches }));
  app.use('/api', (_req, res) => res.status(404).json({ error: { code: 'not_found', message: 'No such route' } }));

  // Production: serve the built web app (apps/web/dist) from the same origin, with SPA fallback.
  const webDist = resolve(REPO_ROOT, 'apps/web/dist');
  if (existsSync(join(webDist, 'index.html'))) {
    app.use(express.static(webDist, { index: 'index.html', maxAge: '1h' }));
    app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(join(webDist, 'index.html')));
    console.log(`[api] serving web app from ${webDist}`);
  }
  app.use(errorHandler());

  console.log(`[api] mode=${config.mode} store=${config.storePath} items=${store.size}${imported ? ` (imported ${imported} from seed)` : ''}`);

  return {
    app,
    store,
    runner,
    stitches,
    config,
    client,
    close: async () => {
      runner.close();
      await store.close();
    },
  };
}

/** HTTP basic auth for public hosts: one shared credential, constant-time compare, health stays open for uptime checks. */
function basicAuth({ user, password }: NonNullable<ApiConfig['basicAuth']>) {
  const expected = Buffer.from(`${user}:${password}`);
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (req.path === '/api/health') return next();
    const header = req.headers.authorization ?? '';
    const given = header.startsWith('Basic ') ? Buffer.from(header.slice(6), 'base64') : Buffer.alloc(0);
    if (given.length === expected.length && timingSafeEqual(given, expected)) return next();
    res.setHeader('WWW-Authenticate', 'Basic realm="SGEUL", charset="UTF-8"');
    res.status(401).json({ error: { code: 'unauthorized', message: 'Sign in to use SGEUL' } });
  };
}

const isMain = process.argv[1] && /server\.(ts|js)$/.test(process.argv[1]);
if (isMain) {
  const config = loadConfig();
  const instance = await createApp(config);
  const onListen = () => console.log(`[api] listening on http://${config.host ?? 'localhost'}:${config.port}/api  (mode: ${config.mode}${config.basicAuth ? ', basic auth on' : ''})`);
  const server = config.host ? instance.app.listen(config.port, config.host, onListen) : instance.app.listen(config.port, onListen);
  const shutdown = async (signal: string) => {
    console.log(`[api] ${signal} — flushing store`);
    server.close();
    await instance.close();
    process.exit(0);
  };
  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
}
