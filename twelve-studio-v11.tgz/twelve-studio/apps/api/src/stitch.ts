/**
 * Stitched previews: burn an ad creative into a movie at its planned breaks,
 * snapped to keyframes so the movie itself is never re-encoded.
 *
 *   1. ffprobe the movie (codec, size, fps, audio).
 *   2. Per break, list keyframes inside the break window (`-read_intervals`)
 *      and pick the one nearest `at` → `snappedAt`.
 *   3. Transcode the creative ONCE to match the movie (scale+pad, fps, h264
 *      profile/level, aac sample-rate/channels) — cached per creative × format.
 *   4. Cut the movie into N+1 stream-copied segments at the snapped keyframes.
 *   5. Concat segment/ad/segment… with the concat demuxer (`-c copy`); if the
 *      copy concat fails or the result is the wrong length, fall back to a full
 *      re-encode through filter_complex concat (slower, always works).
 *
 * `dryRun` computes the insertions without running ffmpeg (tests, hosts
 * without ffmpeg). Everything here is local ffmpeg work — no model calls.
 */

import { execFile } from 'node:child_process';
import { mkdir, rm, stat, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { resolveMediaPath } from './media.js';
import { promisify } from 'node:util';
import { nowIso, type AdBreak, type AdCreative, type CatalogItem, type StitchJob } from '@twelve-studio/core';

const exec = promisify(execFile);
const EXEC_OPTS = { maxBuffer: 64 * 1024 * 1024 } as const;
/** ffprobe calls (local files or a URL header fetch) must never hang a request. */
const PROBE_OPTS = { ...EXEC_OPTS, timeout: 30_000 } as const;

export class StitchError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly log?: string,
  ) {
    super(message);
    this.name = 'StitchError';
  }
}

/* ------------------------------------------------------------------ */
/* ffprobe                                                             */
/* ------------------------------------------------------------------ */

export interface MediaInfo {
  durationSec: number;
  /** Format-level start time (seconds); ffmpeg's `-ss` is relative to it. */
  startTime: number;
  video?: {
    codec: string;
    width: number;
    height: number;
    fps: number;
    /** Exact frame rate as a fraction string, e.g. `24000/1001`. */
    fpsFraction: string;
    profile?: string;
    level?: number;
    pixFmt?: string;
    /** Denominator of the stream time base (used as the muxer timescale). */
    timeBaseDen?: number;
  };
  audio?: { codec: string; sampleRate: number; channels: number; channelLayout?: string };
}

let ffmpegChecked: Promise<boolean> | undefined;

/** True when `ffmpeg` and `ffprobe` are both on PATH (cached). */
export function hasFfmpeg(): Promise<boolean> {
  if (!ffmpegChecked) {
    ffmpegChecked = Promise.all([exec('ffmpeg', ['-version']), exec('ffprobe', ['-version'])])
      .then(() => true)
      .catch(() => false);
  }
  return ffmpegChecked;
}

function fraction(s: string | undefined): number {
  if (!s) return 0;
  const [n, d] = s.split('/').map(Number);
  if (!n || !Number.isFinite(n)) return 0;
  if (d === undefined) return n;
  return d ? n / d : 0;
}

/** ffprobe a file or URL: duration, first video stream, first audio stream. */
export async function probeMedia(input: string): Promise<MediaInfo> {
  let stdout: string;
  try {
    ({ stdout } = await exec(
      'ffprobe',
      [
        '-v',
        'error',
        '-show_entries',
        'stream=index,codec_type,codec_name,profile,level,width,height,pix_fmt,r_frame_rate,avg_frame_rate,sample_rate,channels,channel_layout,time_base,duration:format=duration,start_time',
        '-of',
        'json',
        input,
      ],
      PROBE_OPTS,
    ));
  } catch (err) {
    throw new StitchError('probe_failed', `ffprobe could not read ${input}: ${tail((err as { stderr?: string }).stderr ?? (err as Error).message)}`);
  }
  const parsed = JSON.parse(stdout) as {
    streams?: Array<Record<string, string | number | undefined>>;
    format?: { duration?: string; start_time?: string };
  };
  const streams = parsed.streams ?? [];
  const v = streams.find((s) => s.codec_type === 'video');
  const a = streams.find((s) => s.codec_type === 'audio');
  const info: MediaInfo = {
    durationSec: Number(parsed.format?.duration ?? v?.duration ?? a?.duration ?? 0) || 0,
    startTime: Math.max(0, Number(parsed.format?.start_time ?? 0) || 0),
  };
  if (v) {
    const fpsFraction = String((fraction(String(v.avg_frame_rate ?? '')) ? v.avg_frame_rate : v.r_frame_rate) ?? '');
    const tb = String(v.time_base ?? '').split('/');
    info.video = {
      codec: String(v.codec_name ?? ''),
      width: Number(v.width ?? 0),
      height: Number(v.height ?? 0),
      fps: Math.round(fraction(fpsFraction) * 1000) / 1000,
      fpsFraction,
      profile: v.profile ? String(v.profile) : undefined,
      level: typeof v.level === 'number' && v.level > 0 ? v.level : undefined,
      pixFmt: v.pix_fmt ? String(v.pix_fmt) : undefined,
      timeBaseDen: tb.length === 2 && tb[0] === '1' ? Number(tb[1]) : undefined,
    };
  }
  if (a) {
    info.audio = {
      codec: String(a.codec_name ?? ''),
      sampleRate: Number(a.sample_rate ?? 0),
      channels: Number(a.channels ?? 0),
      channelLayout: a.channel_layout ? String(a.channel_layout) : undefined,
    };
  }
  return info;
}

/**
 * Keyframe presentation times (seconds, relative to the format start) of the
 * first video stream inside [start, end]. `-read_intervals` keeps this cheap on
 * long files: only the packets of that window are demuxed.
 */
export async function listKeyframes(input: string, start: number, end: number, startTime = 0): Promise<number[]> {
  const from = Math.max(0, start + startTime);
  const to = Math.max(from, end + startTime) + 0.5;
  const args = [
    '-v',
    'error',
    '-select_streams',
    'v:0',
    ...(Number.isFinite(end) ? ['-read_intervals', `${from.toFixed(3)}%${to.toFixed(3)}`] : []),
    '-show_entries',
    'packet=pts_time,dts_time,flags',
    '-of',
    'csv=p=0',
    input,
  ];
  let stdout: string;
  try {
    ({ stdout } = await exec('ffprobe', args, PROBE_OPTS));
  } catch (err) {
    throw new StitchError('probe_failed', `ffprobe could not list keyframes: ${tail((err as { stderr?: string }).stderr ?? (err as Error).message)}`);
  }
  const out: number[] = [];
  for (const line of stdout.split('\n')) {
    const cols = line.trim().split(',');
    if (cols.length < 3) continue;
    const [pts, dts, flags] = cols as [string, string, string];
    if (!flags.includes('K')) continue;
    const t = Number(pts !== 'N/A' ? pts : dts);
    if (!Number.isFinite(t)) continue;
    const rel = t - startTime;
    if (rel + 1e-6 < start || rel - 1e-6 > end) continue;
    out.push(Math.round(rel * 1e6) / 1e6);
  }
  return [...new Set(out)].sort((x, y) => x - y);
}

/** The keyframe nearest `at` (ties → the earlier one). */
export function nearestKeyframe(keyframes: number[], at: number): number | undefined {
  let best: number | undefined;
  let bestDist = Infinity;
  for (const k of keyframes) {
    const d = Math.abs(k - at);
    if (d < bestDist) {
      best = k;
      bestDist = d;
    }
  }
  return best;
}

export interface Insertion {
  breakId: string;
  requestedAt: number;
  snappedAt: number;
}

/**
 * Snap every break to a keyframe: inside its window when possible, otherwise
 * the nearest keyframe overall. Returned in time order.
 */
export async function planInsertions(
  breaks: AdBreak[],
  keyframesIn: (start: number, end: number) => Promise<number[]>,
  durationSec: number,
  log?: (line: string) => void,
): Promise<Insertion[]> {
  const sorted = [...breaks].sort((a, b) => a.at - b.at);
  const insertions: Insertion[] = [];
  for (const b of sorted) {
    const wStart = Math.max(0, Math.min(b.window.start, b.at));
    const wEnd = Math.min(durationSec || Infinity, Math.max(b.window.end, b.at));
    let candidates = await keyframesIn(wStart, wEnd);
    let where = 'inside window';
    if (candidates.length === 0) {
      candidates = await keyframesIn(Math.max(0, wStart - 60), wEnd + 60);
      where = 'within ±60s of window';
    }
    if (candidates.length === 0) {
      candidates = await keyframesIn(0, Infinity);
      where = 'nearest overall';
    }
    const snapped = nearestKeyframe(candidates, b.at);
    if (snapped === undefined) {
      log?.(`break ${b.id}: no keyframes found; skipped`);
      continue;
    }
    if (snapped <= 0.05 || (durationSec && snapped >= durationSec - 0.05)) {
      log?.(`break ${b.id}: keyframe at ${snapped}s is at the edge of the asset; skipped`);
      continue;
    }
    log?.(`break ${b.id}: ${b.at}s → keyframe ${snapped}s (${where}, window ${wStart}–${wEnd}s)`);
    insertions.push({ breakId: b.id, requestedAt: b.at, snappedAt: snapped });
  }
  return insertions.sort((a, b) => a.snappedAt - b.snappedAt);
}

/* ------------------------------------------------------------------ */
/* The stitcher                                                        */
/* ------------------------------------------------------------------ */

export interface StitchOptions {
  item: CatalogItem;
  creative: AdCreative;
  /** Breaks to fill (any order; sorted by time here). */
  breaks: AdBreak[];
  /** `data/renders` — output, `cache/` and `tmp/` live under it. */
  rendersDir: string;
  /** Compute insertions only; never runs ffmpeg. */
  dryRun?: boolean;
  /** `auto` (default): stream-copy concat, re-encode on failure. `reencode` forces the fallback (tests). */
  concat?: 'auto' | 'copy' | 'reencode';
  /** Called with a fresh copy of the job after every state change. */
  onProgress?: (job: StitchJob, note?: string) => void;
}

const LOG_LIMIT = 6000;

/**
 * Run one stitch job to completion. Resolves with the final job (status
 * `ready` or `failed`); never rejects for ffmpeg problems — they land in
 * `job.error` / `job.log` so the API can show them.
 */
export async function runStitch(initial: StitchJob, opts: StitchOptions): Promise<StitchJob> {
  let job: StitchJob = { ...initial, insertions: [...initial.insertions] };
  const lines: string[] = job.log ? [job.log] : [];
  const note = (line: string) => {
    lines.push(line);
    job = { ...job, log: lines.join('\n').slice(-LOG_LIMIT) };
  };
  const emit = (patch: Partial<StitchJob>, line?: string) => {
    if (line) note(line);
    job = { ...job, ...patch };
    opts.onProgress?.(job, line);
  };

  let { item, creative } = opts;
  const { breaks } = opts;
  const tmpDir = join(opts.rendersDir, 'tmp', job.id);
  try {
    emit({ status: 'running' }, `stitch ${item.id} × ${creative.name}: ${breaks.length} break(s)${opts.dryRun ? ' (dry run)' : ''}`);

    if (opts.dryRun) {
      // No ffmpeg: keep `at` inside its window, in time order.
      const insertions = [...breaks]
        .sort((a, b) => a.at - b.at)
        .map((b) => ({ breakId: b.id, requestedAt: b.at, snappedAt: Math.min(Math.max(b.at, b.window.start), b.window.end) }));
      emit({ status: 'ready', insertions, finishedAt: nowIso() }, 'dry run: insertions computed without ffmpeg');
      return job;
    }

    if (!(await hasFfmpeg())) throw new StitchError('stitch_unavailable', 'ffmpeg/ffprobe are not on PATH on the API host; install ffmpeg to render stitched previews');
    if (!item.localPath) throw new StitchError('needs_local_file', `${item.id} has no local file; ingest it from disk (sourceUrl = absolute path) to render a stitched preview`);
    const moviePath = resolveMediaPath(item.localPath);
    item = { ...item, localPath: moviePath };
    creative = { ...creative, localPath: creative.localPath ? resolveMediaPath(creative.localPath) : creative.localPath };
    await stat(moviePath).catch(() => {
      throw new StitchError('needs_local_file', `Local file for ${item.id} is missing: ${moviePath}`);
    });
    const adInput = creative.localPath ?? creative.sourceUrl;
    if (!adInput) throw new StitchError('needs_local_file', `Creative ${creative.id} has neither a local file nor a URL`);

    // 1. Probe the movie.
    const movie = await probeMedia(moviePath);
    if (!movie.video) throw new StitchError('probe_failed', `${moviePath} has no video stream`);
    const mv = movie.video;
    emit(
      {},
      `movie: ${mv.codec} ${mv.width}x${mv.height} @ ${mv.fpsFraction} fps${mv.profile ? ` (${mv.profile}${mv.level ? ` L${mv.level}` : ''})` : ''}, ` +
        `${movie.audio ? `${movie.audio.codec} ${movie.audio.sampleRate} Hz ${movie.audio.channels}ch` : 'no audio'}, ${movie.durationSec.toFixed(2)}s`,
    );

    // 2. Snap to keyframes.
    const insertions = await planInsertions(breaks, (s, e) => listKeyframes(moviePath, s, e, movie.startTime), movie.durationSec, (l) => note(l));
    if (insertions.length === 0) throw new StitchError('no_insertions', 'No usable insertion point: every break snapped to the edge of the asset or had no keyframe');
    emit({ insertions }, `${insertions.length} insertion(s) at ${insertions.map((i) => i.snappedAt.toFixed(3)).join(', ')}s`);

    // 3. Ad transcode (cached).
    await mkdir(join(opts.rendersDir, 'cache'), { recursive: true });
    await mkdir(tmpDir, { recursive: true });
    const adPath = await transcodeAd(adInput, creative.id, movie, opts.rendersDir, (l) => emit({}, l));
    const ad = await probeMedia(adPath);
    if (!ad.video) throw new StitchError('transcode_failed', 'Transcoded creative has no video stream');

    // 4. Stream-copied movie segments.
    const cuts = insertions.map((i) => i.snappedAt);
    const segments: string[] = [];
    for (let i = 0; i <= cuts.length; i++) {
      const from = i === 0 ? 0 : cuts[i - 1]!;
      const to = i < cuts.length ? cuts[i]! : undefined;
      if (to !== undefined && to - from < 0.001) {
        segments.push(''); // two breaks on the same keyframe → ads back to back
        continue;
      }
      const seg = join(tmpDir, `seg${String(i).padStart(3, '0')}.mp4`);
      const args = ['-y', '-v', 'error', '-nostdin'];
      if (from > 0) args.push('-ss', from.toFixed(6));
      args.push('-i', moviePath);
      if (to !== undefined) args.push('-t', (to - from).toFixed(6));
      args.push('-map', '0:v:0', ...(movie.audio ? ['-map', '0:a:0'] : ['-an']), '-dn', '-sn', '-c', 'copy', '-avoid_negative_ts', 'make_zero', '-movflags', '+faststart', seg);
      await ffmpeg(args, 'segment_failed');
      segments.push(seg);
      emit({}, `segment ${i + 1}/${cuts.length + 1}: ${from.toFixed(3)}s → ${to === undefined ? 'end' : `${to.toFixed(3)}s`} (stream copy)`);
    }

    // 5. Concat.
    await mkdir(opts.rendersDir, { recursive: true });
    const outName = `${safeName(item.id)}-${Date.now()}.mp4`;
    const outPath = join(opts.rendersDir, outName);
    const order: string[] = [];
    segments.forEach((seg, i) => {
      if (seg) order.push(seg);
      if (i < cuts.length) order.push(adPath);
    });
    const expected = movie.durationSec + insertions.length * ad.durationSec;
    const mode = opts.concat ?? 'auto';
    let used: 'copy' | 'reencode' = 'copy';
    let copyProblem: string | undefined;
    if (mode !== 'reencode') {
      const list = join(tmpDir, 'concat.txt');
      await writeFile(list, order.map((p) => `file '${p.replace(/'/g, "'\\''")}'`).join('\n') + '\n', 'utf8');
      try {
        await ffmpeg(['-y', '-v', 'error', '-nostdin', '-f', 'concat', '-safe', '0', '-i', list, '-map', '0:v:0', ...(movie.audio ? ['-map', '0:a:0'] : []), '-c', 'copy', '-movflags', '+faststart', outPath], 'concat_failed');
        const got = await probeMedia(outPath).catch(() => undefined);
        if (!got || !got.video) copyProblem = 'output is unreadable';
        else if (Math.abs(got.durationSec - expected) > Math.max(1.5, expected * 0.02)) copyProblem = `output is ${got.durationSec.toFixed(2)}s, expected ≈${expected.toFixed(2)}s`;
      } catch (err) {
        copyProblem = err instanceof StitchError ? (err.log ?? err.message) : (err as Error).message;
      }
      if (copyProblem && mode === 'copy') throw new StitchError('concat_failed', `Stream-copy concat failed: ${copyProblem}`);
    }
    if (mode === 'reencode' || copyProblem) {
      used = 'reencode';
      emit({}, mode === 'reencode' ? 'concat: re-encode requested' : `concat: stream copy failed (${firstLine(copyProblem)}); falling back to a full re-encode`);
      await rm(outPath, { force: true });
      await concatReencode(order, outPath, movie, !!movie.audio);
    }
    const finalInfo = await probeMedia(outPath);
    emit(
      { status: 'ready', outputPath: outPath, outputUrl: `/api/renders/${outName}`, durationSec: Math.round(finalInfo.durationSec * 1000) / 1000, finishedAt: nowIso() },
      `concat: ${used === 'copy' ? 'stream copy (-f concat -c copy)' : 'full re-encode (filter_complex concat)'} → ${outName} (${finalInfo.durationSec.toFixed(2)}s, expected ≈${expected.toFixed(2)}s)`,
    );
    return job;
  } catch (err) {
    const e = err as StitchError;
    const code = e instanceof StitchError ? e.code : 'stitch_failed';
    if (e instanceof StitchError && e.log) note(e.log);
    emit({ status: 'failed', error: `${code}: ${e.message}`, finishedAt: nowIso() }, `failed: ${e.message}`);
    return job;
  } finally {
    await rm(tmpDir, { recursive: true, force: true }).catch(() => undefined);
  }
}

/* ------------------------------------------------------------------ */
/* ffmpeg helpers                                                      */
/* ------------------------------------------------------------------ */

async function ffmpeg(args: string[], code: string): Promise<string> {
  try {
    const { stderr } = await exec('ffmpeg', args, EXEC_OPTS);
    return stderr;
  } catch (err) {
    const e = err as { stderr?: string; message: string };
    throw new StitchError(code, `ffmpeg failed: ${firstLine(tail(e.stderr ?? e.message))}`, tail(e.stderr ?? e.message));
  }
}

function tail(text: string, max = 2500): string {
  const t = text.trim();
  return t.length > max ? `…${t.slice(-max)}` : t;
}

function firstLine(text: string | undefined): string {
  return (text ?? '').trim().split('\n').filter(Boolean).at(-1) ?? '';
}

function safeName(s: string): string {
  return s.replace(/[^A-Za-z0-9._-]+/g, '-').slice(0, 60) || 'item';
}

const X264_PROFILES: Record<string, string> = {
  'constrained baseline': 'baseline',
  baseline: 'baseline',
  main: 'main',
  high: 'high',
  'high 10': 'high10',
  'high 4:2:2': 'high422',
  'high 4:4:4 predictive': 'high444',
};

function fpsLabel(v: NonNullable<MediaInfo['video']>): string {
  return Number.isInteger(v.fps) ? String(v.fps) : v.fps.toFixed(2).replace(/0+$/, '');
}

/** Video filter that matches the movie: fit inside w×h, pad to it, same fps, yuv420p. */
function matchFilter(v: NonNullable<MediaInfo['video']>): string {
  return `scale=${v.width}:${v.height}:force_original_aspect_ratio=decrease:flags=lanczos,pad=${v.width}:${v.height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${v.fpsFraction || v.fps},format=yuv420p`;
}

/**
 * Transcode the creative once to the movie's format. Cached at
 * `cache/<creativeId>-<w>x<h>-<fps>.mp4`; the cache is re-validated by probe
 * so a movie with a different audio layout gets a fresh transcode.
 */
async function transcodeAd(input: string, creativeId: string, movie: MediaInfo, rendersDir: string, log: (line: string) => void): Promise<string> {
  const mv = movie.video!;
  const cachePath = join(rendersDir, 'cache', `${safeName(creativeId)}-${mv.width}x${mv.height}-${fpsLabel(mv)}.mp4`);
  const cached = await probeMedia(cachePath).catch(() => undefined);
  if (cached?.video && cached.video.width === mv.width && cached.video.height === mv.height && Math.abs(cached.video.fps - mv.fps) < 0.01) {
    const audioOk = movie.audio ? !!cached.audio && cached.audio.sampleRate === movie.audio.sampleRate && cached.audio.channels === movie.audio.channels : !cached.audio;
    if (audioOk) {
      log(`ad: cache hit ${cachePath} (${cached.durationSec.toFixed(2)}s)`);
      return cachePath;
    }
  }

  const src = await probeMedia(input);
  if (!src.video) throw new StitchError('transcode_failed', `Creative ${input} has no video stream`);
  const args = ['-y', '-v', 'error', '-nostdin', '-i', input];
  const silent = !!movie.audio && !src.audio;
  if (silent) args.push('-f', 'lavfi', '-i', `anullsrc=channel_layout=${movie.audio!.channels === 1 ? 'mono' : 'stereo'}:sample_rate=${movie.audio!.sampleRate}`);
  args.push('-map', '0:v:0');
  if (movie.audio) args.push('-map', silent ? '1:a:0' : '0:a:0');
  args.push('-vf', matchFilter(mv), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p');
  if (mv.codec === 'h264') {
    const profile = mv.profile ? X264_PROFILES[mv.profile.toLowerCase()] : undefined;
    if (profile) args.push('-profile:v', profile);
    if (mv.level && mv.level >= 10 && mv.level <= 62) args.push('-level', String(mv.level));
  }
  args.push('-g', String(Math.max(1, Math.round(mv.fps * 2))));
  if (mv.timeBaseDen && mv.timeBaseDen >= 1000 && mv.timeBaseDen <= 1_000_000) args.push('-video_track_timescale', String(mv.timeBaseDen));
  if (movie.audio) {
    args.push('-c:a', 'aac', '-ar', String(movie.audio.sampleRate), '-ac', String(movie.audio.channels), '-b:a', '160k');
    if (silent) args.push('-shortest');
  } else {
    args.push('-an');
  }
  args.push('-dn', '-sn', '-movflags', '+faststart', cachePath);
  log(`ad: transcoding ${input} → ${mv.width}x${mv.height} @ ${mv.fpsFraction} fps, ${movie.audio ? `aac ${movie.audio.sampleRate} Hz ${movie.audio.channels}ch` : 'no audio'}`);
  await ffmpeg(args, 'transcode_failed');
  log(`ad: cached at ${cachePath}`);
  return cachePath;
}

/** Fallback: decode everything and concat through filter_complex. */
async function concatReencode(inputs: string[], outPath: string, movie: MediaInfo, withAudio: boolean): Promise<void> {
  const mv = movie.video!;
  const args = ['-y', '-v', 'error', '-nostdin'];
  for (const p of inputs) args.push('-i', p);
  const parts: string[] = [];
  const refs: string[] = [];
  inputs.forEach((_, i) => {
    parts.push(`[${i}:v:0]${matchFilter(mv)}[v${i}]`);
    refs.push(`[v${i}]`);
    if (withAudio) {
      const layout = movie.audio!.channels === 1 ? 'mono' : movie.audio!.channels === 6 ? '5.1' : 'stereo';
      parts.push(`[${i}:a:0]aformat=sample_rates=${movie.audio!.sampleRate}:channel_layouts=${layout},aresample=async=1[a${i}]`);
      refs.push(`[a${i}]`);
    }
  });
  parts.push(`${refs.join('')}concat=n=${inputs.length}:v=1:a=${withAudio ? 1 : 0}[v]${withAudio ? '[a]' : ''}`);
  args.push('-filter_complex', parts.join(';'), '-map', '[v]');
  if (withAudio) args.push('-map', '[a]');
  args.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p');
  if (withAudio) args.push('-c:a', 'aac', '-b:a', '160k');
  args.push('-movflags', '+faststart', outPath);
  await ffmpeg(args, 'concat_failed');
}

/* ------------------------------------------------------------------ */
/* Queue                                                               */
/* ------------------------------------------------------------------ */

/** Renders run one at a time (ffmpeg saturates the CPU); jobs stay `queued` until their turn. */
export class StitchQueue {
  private chain: Promise<void> = Promise.resolve();
  private pending = 0;

  enqueue(job: StitchJob, opts: StitchOptions): void {
    this.pending += 1;
    this.chain = this.chain
      .then(() => runStitch(job, opts))
      .then(
        () => undefined,
        () => undefined,
      )
      .finally(() => {
        this.pending -= 1;
      });
  }

  get size(): number {
    return this.pending;
  }

  /** Resolves once every queued render has finished (tests). */
  idle(): Promise<void> {
    return this.chain;
  }
}
