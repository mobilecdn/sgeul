/**
 * Ad-ops and player exports derived from the review state:
 *   - VMAP 1.0 XML (approved mid-roll breaks, optional pre/post-roll)
 *   - SCTE-35-style splice list (90 kHz PTS)
 *   - Player markers JSON (skip intro / recap / credits / next episode)
 */

import type { AdBreak, AdBreakPlan, AdCreative, ItemBundle, Marker, MarkerSet } from '@twelve-studio/core';
import { toTimeOffset } from '@twelve-studio/core';

export interface ExportOptions {
  /** Include every ranked break, not only approved ones. */
  all?: boolean;
  preRoll?: boolean;
  postRoll?: boolean;
  /** Pod duration in seconds (default 30). */
  durationSec?: number;
  /** Resolve a break's `creativeId` to its creative → inline VAST instead of an AdTagURI. */
  creative?: (id: string) => AdCreative | undefined;
  /** Absolute origin (`https://host`) used to make relative `mediaUrl`s absolute in `<MediaFile>`. */
  baseUrl?: string;
}

export function isApproved(x: { review?: { status: string } }): boolean {
  return x.review?.status === 'approved';
}

export function isDeclined(x: { review?: { status: string } }): boolean {
  return x.review?.status === 'declined';
}

/** Breaks that an export should contain: approved by default, all non-declined with `all`. */
export function exportableBreaks(plan: AdBreakPlan | undefined, opts: ExportOptions): AdBreak[] {
  if (!plan) return [];
  const list = opts.all ? plan.breaks.filter((b) => !isDeclined(b)) : plan.breaks.filter(isApproved);
  return [...list].sort((a, b) => a.at - b.at);
}

function xmlEscape(s: string): string {
  return s.replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' })[c]!);
}

/** `HH:MM:SS` for VAST `<Duration>` (whole seconds, rounded). */
export function toVastDuration(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
}

/** Absolute URL for a creative's media (relative `/api/...` URLs get the request origin). */
export function absoluteMediaUrl(creative: AdCreative, baseUrl: string | undefined): string {
  const url = creative.mediaUrl;
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(url)) return url;
  const origin = (baseUrl ?? '').replace(/\/+$/, '');
  return `${origin}${url.startsWith('/') ? '' : '/'}${url}`;
}

/* ------------------------------------------------------------------ */
/* VMAP                                                                */
/* ------------------------------------------------------------------ */

export function toVmap(bundle: ItemBundle, opts: ExportOptions = {}): string {
  const breaks = exportableBreaks(bundle.adBreaks, opts);
  const item = bundle.item;
  const lines: string[] = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    `<vmap:VMAP xmlns:vmap="http://www.iab.net/videosuite/vmap" version="1.0">`,
    `  <!-- Twelve Studio · ${xmlEscape(item.title)} (${item.id}) · duration ${toTimeOffset(item.durationSec ?? 0)} · ${breaks.length} mid-roll break(s)${opts.all ? ' (all ranked)' : ' (approved)'} -->`,
  ];
  const adBreak = (timeOffset: string, breakId: string, extra: string[] = [], creative?: AdCreative) => {
    lines.push(`  <vmap:AdBreak timeOffset="${timeOffset}" breakType="linear" breakId="${xmlEscape(breakId)}">`);
    if (creative) {
      // Inline VAST 3.0: the assigned creative is served directly (no ad server round-trip).
      const media = absoluteMediaUrl(creative, opts.baseUrl);
      const dims = creative.width && creative.height ? ` width="${creative.width}" height="${creative.height}"` : '';
      lines.push(`    <vmap:AdSource id="${xmlEscape(breakId)}-src" allowMultipleAds="false" followRedirects="true">`);
      lines.push('      <vmap:VASTAdData>');
      lines.push('        <VAST version="3.0">');
      lines.push(`          <Ad id="${xmlEscape(creative.id)}" sequence="1">`);
      lines.push('            <InLine>');
      lines.push('              <AdSystem version="1.0">Twelve Studio</AdSystem>');
      lines.push(`              <AdTitle>${xmlEscape(creative.name)}</AdTitle>`);
      if (creative.advertiser) lines.push(`              <Advertiser>${xmlEscape(creative.advertiser)}</Advertiser>`);
      lines.push(`              <Impression id="twelve-studio"><![CDATA[${(opts.baseUrl ?? '').replace(/\/+$/, '')}/api/ads/${encodeURIComponent(creative.id)}/impression?item=${encodeURIComponent(item.id)}&break=${encodeURIComponent(breakId)}]]></Impression>`);
      lines.push('              <Creatives>');
      lines.push(`                <Creative id="${xmlEscape(creative.id)}" sequence="1">`);
      lines.push('                  <Linear>');
      lines.push(`                    <Duration>${toVastDuration(creative.durationSec)}</Duration>`);
      lines.push('                    <MediaFiles>');
      lines.push(`                      <MediaFile id="${xmlEscape(creative.id)}" delivery="progressive" type="video/mp4"${dims}><![CDATA[${media}]]></MediaFile>`);
      lines.push('                    </MediaFiles>');
      lines.push('                  </Linear>');
      lines.push('                </Creative>');
      lines.push('              </Creatives>');
      lines.push('            </InLine>');
      lines.push('          </Ad>');
      lines.push('        </VAST>');
      lines.push('      </vmap:VASTAdData>');
    } else {
      lines.push(`    <vmap:AdSource id="${xmlEscape(breakId)}-src" allowMultipleAds="true" followRedirects="true">`);
      lines.push(`      <vmap:AdTagURI templateType="vast3"><![CDATA[https://ads.example.com/vast?item=${encodeURIComponent(item.id)}&break=${encodeURIComponent(breakId)}]]></vmap:AdTagURI>`);
    }
    lines.push('    </vmap:AdSource>');
    if (extra.length) {
      lines.push('    <vmap:Extensions>');
      lines.push('      <vmap:Extension type="twelve-studio">');
      for (const e of extra) lines.push(`        ${e}`);
      lines.push('      </vmap:Extension>');
      lines.push('    </vmap:Extensions>');
    }
    lines.push('  </vmap:AdBreak>');
  };
  if (opts.preRoll) adBreak('start', 'preroll');
  for (const b of breaks) {
    const moods = Object.entries(b.mood)
      .sort((x, y) => y[1] - x[1])
      .slice(0, 3)
      .map(([k, v]) => `${k}:${v.toFixed(2)}`)
      .join(',');
    const creative = b.creativeId ? opts.creative?.(b.creativeId) : undefined;
    adBreak(
      toTimeOffset(b.at),
      b.id,
      [
        `<rank>${b.rank}</rank>`,
        `<confidence>${b.confidence.toFixed(3)}</confidence>`,
        `<window start="${toTimeOffset(b.window.start)}" end="${toTimeOffset(b.window.end)}"/>`,
        ...(b.snappedAt !== undefined ? [`<snappedAt>${toTimeOffset(b.snappedAt)}</snappedAt>`] : []),
        `<reason>${xmlEscape(b.reason)}</reason>`,
        `<mood>${xmlEscape(moods)}</mood>`,
        `<brandSafety suitable="${b.brandSafety.suitable}">${xmlEscape(Object.keys(b.brandSafety.flags).join(','))}</brandSafety>`,
        `<iab>${xmlEscape(b.iab.map((i) => i.id).join(','))}</iab>`,
        ...(creative ? [`<creative id="${xmlEscape(creative.id)}">${xmlEscape(creative.name)}</creative>`] : []),
      ],
      creative,
    );
  }
  if (opts.postRoll) adBreak('end', 'postroll');
  lines.push('</vmap:VMAP>');
  return lines.join('\n') + '\n';
}

/* ------------------------------------------------------------------ */
/* SCTE-35                                                             */
/* ------------------------------------------------------------------ */

export interface ScteSplice {
  id: string;
  /** 90 kHz presentation timestamp. */
  pts_time: number;
  splice_time_sec: number;
  duration_sec: number;
  out_of_network: boolean;
  rank?: number;
  confidence?: number;
  window?: { start: number; end: number };
}

export function toScte35(bundle: ItemBundle, opts: ExportOptions = {}): { itemId: string; title: string; splices: ScteSplice[] } {
  const breaks = exportableBreaks(bundle.adBreaks, opts);
  const duration = opts.durationSec ?? 30;
  const splices: ScteSplice[] = [];
  if (opts.preRoll) splices.push({ id: 'preroll', pts_time: 0, splice_time_sec: 0, duration_sec: duration, out_of_network: true });
  for (const b of breaks) {
    splices.push({
      id: b.id,
      pts_time: Math.round(b.at * 90_000),
      splice_time_sec: b.at,
      duration_sec: duration,
      out_of_network: true,
      rank: b.rank,
      confidence: b.confidence,
      window: b.window,
    });
  }
  if (opts.postRoll && bundle.item.durationSec) {
    const at = bundle.item.durationSec;
    splices.push({ id: 'postroll', pts_time: Math.round(at * 90_000), splice_time_sec: at, duration_sec: duration, out_of_network: true });
  }
  return { itemId: bundle.item.id, title: bundle.item.title, splices };
}

/* ------------------------------------------------------------------ */
/* Player markers                                                      */
/* ------------------------------------------------------------------ */

export interface PlayerMarkers {
  itemId: string;
  title: string;
  fps?: number;
  durationSec?: number;
  skipIntro?: { start: number; end: number; confidence: number };
  skipRecap?: { start: number; end: number; confidence: number };
  coldOpen?: { start: number; end: number; confidence: number };
  creditsStart?: number;
  creditsEnd?: number;
  postCredits?: { start: number; end: number; confidence: number };
  nextEpisodeAt?: number;
  chapters: Array<{ start: number; end: number; label?: string; confidence: number }>;
  /** Every non-declined marker with frames, for players that want the raw track. */
  markers: Array<Pick<Marker, 'id' | 'kind' | 'start' | 'end' | 'startFrame' | 'endFrame' | 'label' | 'confidence'> & { approved: boolean }>;
}

export function toPlayerMarkers(bundle: ItemBundle, set: MarkerSet | undefined = bundle.markers): PlayerMarkers {
  const markers = (set?.markers ?? []).filter((m) => !isDeclined(m)).sort((a, b) => a.start - b.start);
  const pick = (kind: Marker['kind']) => {
    // Prefer approved markers, then the most confident.
    const candidates = markers.filter((m) => m.kind === kind).sort((a, b) => Number(isApproved(b)) - Number(isApproved(a)) || b.confidence - a.confidence);
    return candidates[0];
  };
  const span = (m: Marker | undefined) => (m ? { start: m.start, end: m.end, confidence: m.confidence } : undefined);
  const intro = pick('intro') ?? pick('title_card');
  const credits = pick('credits');
  const hook = pick('next_episode_hook');
  return {
    itemId: bundle.item.id,
    title: bundle.item.title,
    fps: set?.fps ?? bundle.item.fps,
    durationSec: bundle.item.durationSec,
    skipIntro: span(intro),
    skipRecap: span(pick('recap')),
    coldOpen: span(pick('cold_open')),
    creditsStart: credits?.start,
    creditsEnd: credits?.end,
    postCredits: span(pick('post_credits')),
    // "Next episode" prompt: at the hook if there is one, otherwise when credits start.
    nextEpisodeAt: hook?.start ?? credits?.start,
    chapters: markers.filter((m) => m.kind === 'chapter').map((m) => ({ start: m.start, end: m.end, label: m.label, confidence: m.confidence })),
    markers: markers.map((m) => ({
      id: m.id,
      kind: m.kind,
      start: m.start,
      end: m.end,
      startFrame: m.startFrame,
      endFrame: m.endFrame,
      label: m.label,
      confidence: m.confidence,
      approved: isApproved(m),
    })),
  };
}
