# @twelve-studio/mcp

MCP (Model Context Protocol) server that gives any agent the Twelve Studio primitives: catalog, moment search, fingerprints, emotion arcs, markers, ad-break planning and review, safety reports, thumbnail and clip generation, smart lists, AI curation, and VMAP / SCTE-35 / player-marker exports. It talks to the REST API so the web app, the API and agents share one store.

## Run

```bash
npm run build -w @twelve-studio/mcp        # once
npm run dev -w @twelve-studio/api          # API on :8787 (mock mode without a key)
TWELVE_API_URL=http://localhost:8787 node apps/mcp/dist/server.js
# When the API runs with BASIC_AUTH, pass the same credential: TWELVE_API_AUTH=user:password
```

## Claude Desktop

`~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "twelve-studio": {
      "command": "node",
      "args": ["/ABSOLUTE/PATH/twelve-studio/apps/mcp/dist/server.js"],
      "env": { "TWELVE_API_URL": "http://localhost:8787" }
    }
  }
}
```

## Claude Code

```bash
claude mcp add twelve-studio -e TWELVE_API_URL=http://localhost:8787 -- node /ABSOLUTE/PATH/twelve-studio/apps/mcp/dist/server.js
```

## Tools

| Tool | What it does |
| --- | --- |
| `catalog_list`, `catalog_get`, `catalog_ingest`, `jobs_status` | Browse, inspect, add titles; wait for enrichment |
| `search_moments` | Any-to-video search across the catalog (Marengo) |
| `similar_titles` | Embedding similarity with "because" explanations |
| `fingerprint_get` | Genres, keywords, moods, themes, characters, rating, synopsis + translations |
| `emotion_arc_get` | Valence / arousal / dominance time series, acts, climax |
| `markers_get`, `markers_review` | Intro, recap, chapters, credits, post-credits with confidence |
| `safety_report` | Timestamped safety segments with severity |
| `adbreaks_plan`, `adbreaks_review` | Ranked break windows with context; approve / decline / rate |
| `twelvelabs_assets_list`, `catalog_import` | See what is already in the TwelveLabs account; link assets as titles or ad creatives without re-upload |
| `ads_list`, `ads_add`, `ads_fingerprint` | Ad creative library; one Pegasus call per spot for brand, mood, keywords, tone, IAB, sensitivities, family-safety, key moments |
| `adbreaks_fit`, `adbreaks_autoassign`, `adbreaks_assign_creative` | Creative-to-break fit with reasons; best-fit or manual assignment |
| `stitch_preview` | Render an MP4 with the assigned spot burned in at keyframe-snapped break points |
| `export_vmap`, `export_scte35`, `export_markers` | Player- and SSAI-ready exports |
| `thumbnails_generate`, `clips_generate` | Creative runs from a free-text brief |
| `smartlist_create`, `smartlists_list`, `curate_catalog` | Editorial rails |

Resources: `twelve://catalog`, `twelve://item/{id}`. Prompts: `editorial_brief`, `ad_ops_review`.

## Try these

- "Find every moment with the dragon and cut me three 9:16 clips."
- "Plan 4 ad breaks for Sintel, avoid the violent scenes, approve the good ones and give me the VMAP."
- "Write a programming brief for Tears of Steel." (uses the `editorial_brief` prompt)
- "Which of our titles is closest in mood to Cosmos Laundromat, and why?"
- "Give me skip-intro and credits markers for the whole catalog as JSON."
- "Pick five thumbnails for Sintel that show Scales, safe for a kids rail."
