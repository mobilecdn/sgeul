/**
 * Tiny REST client for the Twelve Studio API (apps/api). Every MCP tool goes
 * through here so one store serves the UI, the API and agents.
 *
 * API errors arrive as `{error:{code,message}}` and are rethrown as ApiError;
 * network failures become `api_unreachable` so the agent gets a useful hint.
 */

export class ApiError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly status: number,
    readonly details?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export interface ApiClientOptions {
  baseUrl: string;
  /** Per-request timeout in ms (default 60s). */
  timeoutMs?: number;
  /** `user:password` when the API runs with BASIC_AUTH (env TWELVE_API_AUTH). */
  auth?: string;
}

type Query = Record<string, string | number | boolean | undefined>;

export class ApiClient {
  readonly baseUrl: string;
  private readonly timeoutMs: number;
  private readonly authHeader?: string;

  constructor(opts: ApiClientOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/+$/, '');
    this.timeoutMs = opts.timeoutMs ?? 60_000;
    if (opts.auth) this.authHeader = `Basic ${Buffer.from(opts.auth).toString('base64')}`;
  }

  url(path: string, query?: Query): string {
    const u = new URL(`${this.baseUrl}/api${path.startsWith('/') ? path : `/${path}`}`);
    for (const [k, v] of Object.entries(query ?? {})) {
      if (v === undefined) continue;
      u.searchParams.set(k, String(v));
    }
    return u.toString();
  }

  get<T>(path: string, query?: Query): Promise<T> {
    return this.request<T>('GET', path, { query });
  }

  getText(path: string, query?: Query): Promise<string> {
    return this.request<string>('GET', path, { query, text: true });
  }

  post<T>(path: string, body?: unknown): Promise<T> {
    return this.request<T>('POST', path, { body });
  }

  put<T>(path: string, body?: unknown): Promise<T> {
    return this.request<T>('PUT', path, { body });
  }

  patch<T>(path: string, body?: unknown): Promise<T> {
    return this.request<T>('PATCH', path, { body });
  }

  delete(path: string): Promise<void> {
    return this.request<void>('DELETE', path, {});
  }

  private async request<T>(method: string, path: string, opts: { query?: Query; body?: unknown; text?: boolean }): Promise<T> {
    const url = this.url(path, opts.query);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    let res: Response;
    try {
      res = await fetch(url, {
        method,
        headers: { accept: '*/*', ...(opts.body !== undefined ? { 'content-type': 'application/json' } : {}), ...(this.authHeader ? { authorization: this.authHeader } : {}) },
        body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
        signal: controller.signal,
      });
    } catch (err) {
      const cause = (err as { cause?: { code?: string } }).cause?.code ?? (err as Error).name;
      const aborted = (err as Error).name === 'AbortError';
      throw new ApiError(
        aborted ? 'api_timeout' : 'api_unreachable',
        aborted
          ? `Twelve Studio API did not answer within ${Math.round(this.timeoutMs / 1000)}s (${method} ${url})`
          : `Cannot reach the Twelve Studio API at ${this.baseUrl} (${cause}). Start it with \`npm run dev -w @twelve-studio/api\` or set TWELVE_API_URL.`,
        0,
      );
    } finally {
      clearTimeout(timer);
    }

    const raw = await res.text();
    if (!res.ok) {
      let code = `http_${res.status}`;
      let message = raw || res.statusText;
      let details: unknown;
      try {
        const parsed = JSON.parse(raw) as { error?: { code?: string; message?: string; details?: unknown } };
        if (parsed?.error) {
          code = parsed.error.code ?? code;
          message = parsed.error.message ?? message;
          details = parsed.error.details;
        }
      } catch {
        /* non-JSON error body */
      }
      throw new ApiError(code, message, res.status, details);
    }
    if (opts.text) return raw as unknown as T;
    if (res.status === 204 || raw.length === 0) return undefined as unknown as T;
    try {
      return JSON.parse(raw) as T;
    } catch {
      throw new ApiError('bad_response', `API returned non-JSON for ${method} ${path}`, res.status);
    }
  }
}
