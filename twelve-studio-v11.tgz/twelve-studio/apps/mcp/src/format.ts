/**
 * Result shaping for agents: one human-readable summary line, then compact
 * JSON. Floats are rounded to 3 decimals and label maps are trimmed to the
 * top entries so tool results stay small enough to reason over.
 */

import type { CallToolResult } from '@modelcontextprotocol/sdk/types.js';
import type { ScoredLabels } from '@twelve-studio/core';
import { ApiError } from './api.js';

/** Recursively round non-integer numbers to 3 decimals. */
export function tidy<T>(value: T): T {
  if (typeof value === 'number') return (Number.isInteger(value) ? value : Math.round(value * 1000) / 1000) as T;
  if (Array.isArray(value)) return value.map(tidy) as T;
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v === undefined) continue;
      out[k] = tidy(v);
    }
    return out as T;
  }
  return value;
}

/** Top-N labels of a `{label: confidence}` map, sorted by confidence. */
export function topLabels(labels: ScoredLabels | undefined, n = 5): ScoredLabels {
  if (!labels) return {};
  return Object.fromEntries(
    Object.entries(labels)
      .sort((a, b) => b[1] - a[1])
      .slice(0, n)
      .map(([k, v]) => [k, Math.round(v * 1000) / 1000]),
  );
}

/** Label names only (no scores), top-N. */
export function labelNames(labels: ScoredLabels | undefined, n = 5): string[] {
  return Object.keys(topLabels(labels, n));
}

/** Seconds → `m:ss` (or `h:mm:ss`). */
export function hms(sec: number | undefined): string {
  if (sec === undefined || !Number.isFinite(sec)) return '?';
  const s = Math.max(0, Math.round(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}` : `${m}:${String(r).padStart(2, '0')}`;
}

/** Successful tool result: summary line, then compact JSON. */
export function ok(summary: string, data: unknown, structured?: Record<string, unknown>): CallToolResult {
  const body = typeof data === 'string' ? data : JSON.stringify(tidy(data));
  const result: CallToolResult = { content: [{ type: 'text', text: `${summary}\n${body}` }] };
  if (structured) result.structuredContent = structured;
  return result;
}

/** Tool error: `isError: true`, summary line + `{error:{code,message}}`. */
export function fail(err: unknown): CallToolResult {
  const e =
    err instanceof ApiError
      ? { code: err.code, message: err.message, status: err.status || undefined, details: err.details }
      : { code: 'internal', message: err instanceof Error ? err.message : String(err) };
  return {
    isError: true,
    content: [{ type: 'text', text: `Error ${e.code}: ${e.message}\n${JSON.stringify({ error: tidy(e) })}` }],
  };
}

/** Run a tool body, converting any thrown error into a tool error. */
export async function guard(fn: () => Promise<CallToolResult>): Promise<CallToolResult> {
  try {
    return await fn();
  } catch (err) {
    return fail(err);
  }
}

export function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}
