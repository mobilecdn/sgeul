import { existsSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

/**
 * Single-file demo: inline public/demo-bundle.json as window.__TWELVE_DEMO__ so the
 * published index.html works from any host or file:// with no extra requests.
 * (A src/demo/bundle.ts that assigns window.__TWELVE_DEMO__ at runtime wins over this.)
 */
function inlineDemoBundle(): Plugin {
  return {
    name: 'twelve:inline-demo-bundle',
    transformIndexHtml(html) {
      const file = resolve(dirname(fileURLToPath(import.meta.url)), 'public/demo-bundle.json');
      if (!existsSync(file)) return html;
      const json = readFileSync(file, 'utf8').replace(/<\/script/gi, '<\\/script');
      return html.replace('<head>', `<head>\n    <script>window.__TWELVE_DEMO__ = window.__TWELVE_DEMO__ || ${json};</script>`);
    },
  };
}

export default defineConfig(({ mode }) => {
  const single = mode === 'single';
  return {
    plugins: [react(), ...(single ? [inlineDemoBundle(), viteSingleFile({ removeViteModuleLoader: true })] : [])],
    define: single ? { 'import.meta.env.VITE_STATIC_DEMO': JSON.stringify('1') } : {},
    server: {
      port: 5173,
      proxy: {
        '/api': { target: 'http://localhost:8787', changeOrigin: true },
      },
    },
    build: {
      outDir: single ? 'dist-single' : 'dist',
      sourcemap: false,
      target: 'es2020',
      cssCodeSplit: !single,
      assetsInlineLimit: single ? 100_000_000 : 4096,
    },
  };
});
