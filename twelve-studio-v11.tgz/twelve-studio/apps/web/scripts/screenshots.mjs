// Serves dist/ statically (SPA fallback) and captures every route at 1440×900 with Playwright.
// Usage: VITE_STATIC_DEMO=1 npm run build && node scripts/screenshots.mjs
import http from 'node:http';
import { readFileSync, existsSync, mkdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { dirname, extname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const dist = resolve(here, '../dist');
const outDir = resolve(here, '../screenshots');
mkdirSync(outDir, { recursive: true });
const require = createRequire('/opt/node-tools/node_modules/');
const { chromium } = require('playwright');

// A 6s synthetic spot so the Ad library / inspector thumbs have real frames (skipped when ffmpeg is missing).
// VP8/WebM rather than H.264: Playwright's Chromium ships without proprietary codecs.
const fixtureFile = join(tmpdir(), 'twelve-studio-demo-ad.webm');
const ff = spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=640x360:rate=25', '-t', '6', '-c:v', 'libvpx', '-b:v', '400k', '-pix_fmt', 'yuv420p', fixtureFile]);
const haveFixture = ff.status === 0 && existsSync(fixtureFile);
if (!haveFixture) console.log('ffmpeg fixture unavailable — creative thumbs will show the film glyph');

// Seeded creative for static mode: a partial window.__TWELVE_DEMO__ is merged over the fetched bundle.
const DEMO_ADS = [
  // Linked to the TwelveLabs asset "Kinder Bueno - 30 second - ad.mp4" so the From TwelveLabs tab shows the ad linkage.
  { id: 'ad_demo_bueno', name: 'Kinder Bueno 30s', advertiser: 'Ferrero', durationSec: 30, sourceUrl: 'http://localhost:4173/fixtures/ad.webm', mediaUrl: 'http://localhost:4173/fixtures/ad.webm', width: 1920, height: 1080, upstream: { assetId: '6aa58b4a19212bdafaeadefa' }, createdAt: '2026-09-12T09:00:00.000Z' },
  { id: 'ad_demo_volvo', name: 'Volvo EX90 · Northern Lights 15s', advertiser: 'Volvo Cars', durationSec: 15, localPath: '/Volumes/ads/volvo-ex90-15.mp4', mediaUrl: 'http://localhost:4173/fixtures/ad.webm', width: 3840, height: 2160, createdAt: '2026-09-11T16:20:00.000Z' },
];

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.mp4': 'video/mp4', '.webm': 'video/webm' };
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/fixtures/ad.webm') {
    if (!haveFixture) {
      res.writeHead(404);
      return res.end();
    }
    const body = readFileSync(fixtureFile);
    res.writeHead(200, { 'content-type': 'video/webm', 'content-length': body.length, 'accept-ranges': 'bytes' });
    return res.end(body);
  }
  let file = join(dist, url.pathname);
  if (!existsSync(file) || url.pathname === '/') file = join(dist, 'index.html');
  try {
    const body = readFileSync(file);
    res.writeHead(200, { 'content-type': MIME[extname(file)] ?? 'application/octet-stream' });
    res.end(body);
  } catch {
    res.writeHead(404);
    res.end('not found');
  }
});
await new Promise((r) => server.listen(4173, r));

const browser = await chromium.launch({ executablePath: process.env.PW_CHROMIUM || undefined });
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
await ctx.addInitScript((ads) => {
  window.__TWELVE_DEMO__ = { ads };
}, DEMO_ADS);
const page = await ctx.newPage();
// The sandbox has no egress; abort external requests so fallbacks render immediately.
if (process.env.OFFLINE !== '0') await page.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
const errors = [];
page.on('console', (m) => {
  if (m.type() === 'error' && !/ERR_FAILED|ERR_TUNNEL|Failed to load resource/.test(m.text())) errors.push(`[console] ${m.text()}`);
});
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`));

const shots = [
  { name: '01-overview', path: '/' },
  { name: '02-editorial-library', path: '/editorial' },
  { name: '03-editorial-inspector', path: '/editorial?item=sintel' },
  { name: '04-editorial-lists', path: '/editorial/lists' },
  {
    name: '05-editorial-lists-builder',
    path: '/editorial/lists',
    after: async () => {
      await page.getByPlaceholder('Type a genre…').fill('anim');
      await page.keyboard.press('Enter');
      await page.waitForTimeout(400);
    },
  },
  {
    name: '06-editorial-curation',
    path: '/editorial/curation',
    after: async () => {
      await page.getByRole('button', { name: 'Curate catalog' }).click();
      await page.waitForTimeout(2200);
    },
  },
  { name: '07-creative', path: '/creative' },
  {
    name: '08-creative-results',
    path: '/creative',
    after: async () => {
      await page.getByRole('button', { name: 'Run on…' }).first().click();
      await page.getByRole('button', { name: 'Select all' }).click();
      await page.getByRole('button', { name: /^Run on \d/ }).click();
      await page.waitForTimeout(3000);
    },
  },
  {
    name: '09-creative-clips',
    path: '/creative',
    after: async () => {
      // The clips recipe in the seeded bundle is "Vertical teasers" (see make-demo-bundle.mjs).
      await page.locator('.recipe', { hasText: 'Vertical teasers' }).first().click();
      await page.waitForTimeout(200);
      await page.getByRole('button', { name: 'Run on…' }).first().click();
      await page.getByRole('button', { name: 'Select all' }).click();
      await page.getByRole('button', { name: /^Run on \d/ }).click();
      await page.waitForTimeout(3000);
    },
  },
  {
    name: '10-creative-builder',
    path: '/creative',
    after: async () => {
      await page.getByRole('button', { name: 'New recipe' }).click();
      await page.waitForTimeout(300);
    },
  },
  { name: '11-operations', path: '/operations?item=sintel' },
  {
    name: '12-operations-break',
    path: '/operations?item=sintel',
    after: async () => {
      await page.locator('.tl__marker').first().click();
      await page.waitForTimeout(400);
    },
  },
  {
    name: '13-operations-marker',
    path: '/operations?item=tears-of-steel',
    after: async () => {
      await page.locator('.tl__seg:not(.tl__seg--faint)').nth(2).click();
      await page.waitForTimeout(400);
    },
  },
  {
    name: '14-operations-safety',
    path: '/operations?item=sintel',
    after: async () => {
      await page.getByRole('tab', { name: /Safety/ }).click();
      await page.waitForTimeout(300);
    },
  },
  { name: '15-discovery', path: '/discovery' },
  {
    name: '16-discovery-results',
    path: '/discovery',
    after: async () => {
      await page.getByPlaceholder('Find moments across your catalog…').fill('dragon');
      await page.keyboard.press('Enter');
      await page.waitForTimeout(1500);
    },
  },
  {
    name: '17-discovery-modal',
    path: '/discovery',
    after: async () => {
      await page.getByPlaceholder('Find moments across your catalog…').fill('dragon');
      await page.keyboard.press('Enter');
      await page.waitForTimeout(1500);
      await page.locator('.hit').first().click();
      await page.waitForTimeout(600);
    },
  },
  { name: '18-api-docs', path: '/api-docs' },
  { name: '19-settings', path: '/settings' },
  {
    name: '20-upload-modal',
    path: '/editorial?upload=1',
    after: async () => {
      await page.waitForTimeout(300);
    },
  },
  // Narrow-laptop pass: same pages at 1100×800 to catch overflow.
  { name: '21-operations-1100w', path: '/operations?item=sintel', viewport: { width: 1100, height: 800 } },
  { name: '22-overview-1100w', path: '/', viewport: { width: 1100, height: 800 } },
  // Ad creatives + stitched previews (CONTRACT-ads.md). Static mode: ads seeded via window.__TWELVE_DEMO__.ads.
  {
    name: '23-operations-ad-library',
    path: '/operations?item=sintel',
    after: async () => {
      await page.getByLabel('Ad creative').selectOption('__manage');
      await page.waitForTimeout(700);
    },
  },
  {
    name: '24-operations-creative-row',
    path: '/operations?item=sintel',
    after: async () => {
      await page.getByRole('button', { name: /Assign/ }).click();
      await page.waitForTimeout(500);
      await page.locator('.tl__marker').first().click();
      await page.waitForTimeout(700);
    },
  },
  {
    name: '25-operations-render-confirm',
    path: '/operations?item=sintel',
    after: async () => {
      await page.getByRole('button', { name: /Assign/ }).click();
      await page.waitForTimeout(400);
      await page.getByRole('button', { name: 'Export' }).click();
      await page.waitForTimeout(200);
      await page.screenshot({ path: join(outDir, '25a-operations-export-vast.png') });
      await page.locator('.topbar__title').click();
      await page.getByRole('button', { name: 'Render preview' }).click();
      await page.waitForTimeout(500);
    },
  },
  // Asset sync from the TwelveLabs account: the "From TwelveLabs" tab of the Add assets modal, and the Settings card.
  {
    name: '30-add-assets-twelvelabs',
    path: '/editorial?upload=twelvelabs',
    after: async () => {
      await page.getByRole('tab', { name: /From TwelveLabs/ }).click();
      await page.waitForTimeout(700);
      await page.getByLabel('Import grok4.mp4').check();
      await page.waitForTimeout(200);
    },
  },
  {
    name: '31-add-assets-imported',
    path: '/editorial?upload=twelvelabs',
    after: async () => {
      await page.getByRole('tab', { name: /From TwelveLabs/ }).click();
      await page.waitForTimeout(700);
      await page.getByLabel('Import grok4.mp4').check();
      await page.getByRole('button', { name: 'Import as titles' }).click();
      await page.waitForTimeout(1800);
    },
  },
  { name: '32-settings-account', path: '/settings' },
  {
    name: '26-operations-ad-library-1100w',
    path: '/operations?item=sintel',
    viewport: { width: 1100, height: 800 },
    after: async () => {
      await page.getByLabel('Ad creative').selectOption('__manage');
      await page.waitForTimeout(700);
    },
  },
];

// ONLY=30,31 (name prefixes, comma-separated) restricts the run to a few shots.
const only = (process.env.ONLY ?? '').split(',').map((x) => x.trim()).filter(Boolean);
for (const s of shots) {
  if (only.length && !only.some((o) => s.name.startsWith(o))) continue;
  await page.setViewportSize(s.viewport ?? { width: 1440, height: 900 });
  await page.goto(`http://localhost:4173${s.path}`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(900);
  if (s.after) {
    try {
      await s.after();
    } catch (e) {
      errors.push(`[step ${s.name}] ${e.message.split('\n')[0]}`);
    }
  }
  await page.screenshot({ path: join(outDir, `${s.name}.png`) });
  console.log('shot', s.name);
}

await browser.close();
server.close();
if (errors.length) {
  console.log('\nERRORS:');
  for (const e of errors) console.log(' ', e);
} else console.log('\nno console/page errors');
