// Builds apps/web/public/demo-bundle.json from data/seed (real TwelveLabs output).
// Used by the static demo build (VITE_STATIC_DEMO=1) and inlined by `build:single`.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const seed = resolve(here, '../../../data/seed');
const catalog = JSON.parse(readFileSync(resolve(seed, 'catalog.json'), 'utf8'));
const lists = JSON.parse(readFileSync(resolve(seed, 'lists.json'), 'utf8'));
const ads = existsSync(resolve(seed, 'ads.json')) ? JSON.parse(readFileSync(resolve(seed, 'ads.json'), 'utf8')) : [];
// A real `GET /v1.3/assets` capture of the demo account, so static mode can show the "From TwelveLabs" tab.
const twelvelabsAssets = existsSync(resolve(seed, 'twelvelabs-assets.json')) ? JSON.parse(readFileSync(resolve(seed, 'twelvelabs-assets.json'), 'utf8')) : [];
// Local posters cannot be served in the static build: inline a small JPEG when one sits next to the seed.
for (const b of catalog) {
  const local = resolve(seed, `${b.item.id}-poster.jpg`);
  if (b.item.posterUrl?.startsWith('/api/') && existsSync(local)) b.item.posterUrl = `data:image/jpeg;base64,${readFileSync(local).toString('base64')}`;
  if (b.item.playback?.fileUrl?.startsWith('/api/')) delete b.item.playback.fileUrl; // static build streams HLS instead
}
const NOW = '2026-09-12T08:10:00.000Z';
const kinds = ['ingest', 'fingerprint', 'embedding', 'emotions', 'markers', 'safety', 'adbreaks', 'thumbnails', 'clips'];
for (const b of catalog) {
  if (b.fingerprint) b.item.jobs.embedding = 'ready';
  b.jobs = kinds.filter((kind) => b.item.jobs[kind] === 'ready').map((kind, i) => ({
    id: `job_${b.item.id}_${kind}`,
    itemId: b.item.id,
    kind,
    status: 'ready',
    startedAt: new Date(Date.parse(NOW) - (kinds.length - i) * 90_000).toISOString(),
    finishedAt: new Date(Date.parse(NOW) - (kinds.length - i) * 90_000 + 55_000).toISOString(),
    upstream: { model: kind === 'ingest' ? 'marengo3.0' : kind === 'embedding' ? 'marengo3.5' : 'pegasus1.5', assetId: b.item.upstream?.assetId, indexedAssetId: b.item.upstream?.indexedAssetId },
  }));
}
const recipes = [
  { id: 'rcp_hero-art', name: 'Hero art, faces first', target: 'thumbnails', brief: 'Key art frames with a clear character face, dramatic lighting, no violence.', count: 8, formats: ['16:9', '2:3', '9:16'], createdAt: NOW },
  { id: 'rcp-vertical-teasers', name: 'Vertical teasers', target: 'clips', brief: 'Three 12-20 second vertical cuts: the hook, the spectacle, the emotional beat.', count: 3, clipLengthSec: [12, 20], formats: ['9:16'], createdAt: NOW },
];
const out = resolve(here, '../public/demo-bundle.json');
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, JSON.stringify({ catalog, lists, recipes, ads, twelvelabsAssets }));
console.log(`wrote ${out}: ${catalog.length} bundles, ${lists.length} lists, ${ads.length} ads, ${twelvelabsAssets.length} TwelveLabs assets, ${(readFileSync(out).length / 1024).toFixed(0)} KB`);
