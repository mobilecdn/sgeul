import { chromium } from 'playwright';
const file = 'file:///home/claude/twelve-studio/apps/web/dist-single/index.html';
const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 1000 } });
await p.goto(file + '#/'); await p.waitForTimeout(2500);
await p.screenshot({ path: process.argv[2] + '/overview.png' });
await p.goto(file + '#/editorial'); await p.waitForTimeout(2500);
await p.screenshot({ path: process.argv[2] + '/editorial.png' });
await b.close();
