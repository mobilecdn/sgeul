import { useEffect, useState, type CSSProperties, type ReactNode } from 'react';
import { Timecode } from './Timecode';
import { gradientFor } from '../lib/colors';
import { attachMedia, isHls } from '../lib/media';

/* ------------------------------------------------------------------ */
/* Frame grabber: one hidden <video> per URL, sequential seeks, cache  */
/* ------------------------------------------------------------------ */
const cache = new Map<string, Promise<string | null>>();
const queues = new Map<string, Promise<unknown>>();
const elements = new Map<string, { v: HTMLVideoElement; failed: boolean; ready: Promise<boolean> }>();

function videoFor(url: string) {
  let entry = elements.get(url);
  if (!entry) {
    const v = document.createElement('video');
    v.crossOrigin = 'anonymous';
    v.muted = true;
    v.preload = 'auto';
    v.playsInline = true;
    v.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0;pointer-events:none';
    document.body.appendChild(v);
    const e = { v, failed: false, ready: Promise.resolve(false) };
    e.ready = new Promise<boolean>((resolve) => {
      const timer = setTimeout(() => resolve(false), 20000);
      const ok = () => {
        clearTimeout(timer);
        resolve(true);
      };
      v.addEventListener('loadedmetadata', ok, { once: true });
      attachMedia(v, url, {
        lightweight: true,
        onError: () => {
          e.failed = true;
          clearTimeout(timer);
          resolve(false);
        },
      });
      if (v.readyState >= 1) ok();
    });
    entry = e;
    elements.set(url, entry);
  }
  return entry;
}

function grabFrame(url: string, at: number): Promise<string | null> {
  const key = `${url}@${at.toFixed(2)}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const prev = queues.get(url) ?? Promise.resolve();
  const p = prev.then(async () => {
    const entry = videoFor(url);
    const ready = await entry.ready;
    if (!ready || entry.failed) return null;
    const v = entry.v;
    return new Promise<string | null>((resolve) => {
      let done = false;
      const finish = (val: string | null) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        v.removeEventListener('seeked', onSeeked);
        v.removeEventListener('error', onError);
        resolve(val);
      };
      // HLS seeks fetch a fresh fragment; give them a bit longer than a progressive file.
      const timer = setTimeout(() => finish(null), isHls(url) ? 15000 : 9000);
      const onError = () => {
        entry.failed = true;
        finish(null);
      };
      const onSeeked = () => {
        try {
          const w = 400;
          const ratio = v.videoWidth && v.videoHeight ? v.videoHeight / v.videoWidth : 9 / 16;
          const c = document.createElement('canvas');
          c.width = w;
          c.height = Math.round(w * ratio);
          const ctx = c.getContext('2d');
          if (!ctx) return finish(null);
          ctx.drawImage(v, 0, 0, c.width, c.height);
          finish(c.toDataURL('image/jpeg', 0.82));
        } catch {
          // CORS-tainted canvas: never try this URL again.
          entry.failed = true;
          finish(null);
        }
      };
      v.addEventListener('seeked', onSeeked);
      v.addEventListener('error', onError);
      const d = isFinite(v.duration) ? v.duration : Infinity;
      const target = Math.min(Math.max(0.05, at), d === Infinity ? at : Math.max(0.05, d - 0.05));
      if (Math.abs(v.currentTime - target) < 0.01 && v.readyState >= 2) onSeeked();
      else v.currentTime = target;
    });
  });
  cache.set(key, p);
  queues.set(url, p.catch(() => null));
  return p;
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */
export function FrameThumb({
  url,
  at,
  image,
  poster,
  mood,
  fps = 25,
  className = '',
  style,
  children,
  seed,
  showTimecode = true,
  bare,
  center,
}: {
  /** Playable media URL (from `playableSrc`). Undefined when the item has no in-browser source. */
  url?: string;
  at: number;
  /** A known frame image for exactly this moment (e.g. a search hit thumbnail). Shown first; grabbing starts only if it fails. */
  image?: string;
  /** Fallback image when a frame cannot be drawn (item poster). */
  poster?: string;
  mood?: string;
  fps?: number;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
  seed?: string;
  showTimecode?: boolean;
  /** No overlay at all — just the frame or gradient (poster art, queue thumbs). */
  bare?: boolean;
  /** Centre the placeholder label (no corner badge) — for cards that carry their own chrome. */
  center?: boolean;
}) {
  const [frame, setFrame] = useState<string | null | undefined>(undefined);
  const [imageOk, setImageOk] = useState(true);
  const [posterOk, setPosterOk] = useState(true);
  const useImage = !!image && imageOk;

  useEffect(() => {
    setImageOk(true);
  }, [image]);
  useEffect(() => {
    setPosterOk(true);
  }, [poster]);

  useEffect(() => {
    let alive = true;
    setFrame(undefined);
    if (useImage) return;
    if (!url) {
      setFrame(null);
      return;
    }
    void grabFrame(url, at).then((v) => alive && setFrame(v));
    return () => {
      alive = false;
    };
  }, [url, at, useImage]);

  const g = gradientFor(`${seed ?? url ?? poster ?? 'x'}#${Math.round(at / 15)}`);
  const loading = !useImage && !!url && frame === undefined;
  const failed = !useImage && frame === null;
  const showPoster = failed && !!poster && posterOk;
  const noSource = !useImage && !url;
  const showOverlay = !bare && (loading || failed);

  return (
    <div className={`ft ${className}`} style={style}>
      <div className="ft__bg" style={{ background: g, opacity: loading ? 0.5 : 1 }} />
      {useImage && <img src={image} alt="" draggable={false} onError={() => setImageOk(false)} />}
      {!useImage && frame && <img src={frame} alt="" draggable={false} />}
      {showPoster && <img src={poster} alt="" draggable={false} style={{ filter: 'brightness(.75)' }} onError={() => setPosterOk(false)} />}
      {loading && <div className="ft__shimmer" />}
      {showOverlay && (
        <div className={`ft__ph${center ? ' ft__ph--center' : ''}`}>
          {noSource && !center && <span className="ft__ph-badge">Frame preview unavailable</span>}
          {noSource && center && (
            <span className="ft__ph-mood" style={{ opacity: 0.6, fontSize: 10, letterSpacing: '.06em', textTransform: 'uppercase' }}>
              Frame preview unavailable
            </span>
          )}
          {showTimecode && <Timecode sec={at} fps={fps} />}
          {mood && <span className="ft__ph-mood">{mood}</span>}
        </div>
      )}
      {children}
    </div>
  );
}
