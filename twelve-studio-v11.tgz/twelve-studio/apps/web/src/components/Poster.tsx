import { useEffect, useState } from 'react';
import type { CatalogItem } from '@twelve-studio/core';
import { FrameThumb } from './FrameThumb';
import { StatusPill } from './ui';
import { gradientFor } from '../lib/colors';
import { duration, initials, titleCase } from '../lib/format';
import { playableSrc } from '../lib/media';

/**
 * Poster artwork: the real poster (TwelveLabs thumbnail) when it loads, else a
 * generated gradient with a grabbed frame and the title initials. A poster that
 * fails to load (offline, expired URL) falls through to the generated art
 * instead of leaving a broken-image glyph.
 */
export function PosterArt({ item, className, style, showFrame = true }: { item: CatalogItem; className?: string; style?: React.CSSProperties; showFrame?: boolean }) {
  const [posterOk, setPosterOk] = useState(true);
  useEffect(() => setPosterOk(true), [item.posterUrl]);
  if (item.posterUrl && posterOk) return <img src={item.posterUrl} alt={item.title} className={className} style={style} loading="lazy" onError={() => setPosterOk(false)} />;
  const at = Math.max(1, (item.durationSec ?? 600) * 0.3);
  const src = playableSrc(item);
  return (
    <div className={`poster__gen ${className ?? ''}`} style={{ background: gradientFor(item.id + item.title), ...style }}>
      <div className="poster__gen-frame">
        {showFrame && src && <FrameThumb url={src} at={at} seed={item.id} bare style={{ position: 'absolute', inset: 0, opacity: 0.85, background: 'transparent' }} />}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0) 30%, rgba(0,0,0,.55) 100%)' }} />
        <div className="poster__gen-title">{initials(item.title)}</div>
      </div>
    </div>
  );
}

export function PosterCard({ item, selected, onClick }: { item: CatalogItem; selected?: boolean; onClick?: () => void }) {
  return (
    <div className={`poster${selected ? ' is-selected' : ''}`} onClick={onClick} role="button">
      <div className="poster__art">
        <PosterArt item={item} />
        <div className="poster__status">
          <StatusPill status={item.status} />
        </div>
      </div>
      <div className="poster__meta">
        <div className="poster__title" title={item.title}>
          {item.title}
        </div>
        <div className="poster__sub">
          {item.year && <span>{item.year}</span>}
          <span>{titleCase(item.type)}</span>
          <span>·</span>
          <span>{duration(item.durationSec)}</span>
        </div>
      </div>
    </div>
  );
}
