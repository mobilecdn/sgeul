import { forwardRef, useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { Icon } from './Icon';
import { Timecode } from './Timecode';
import { attachMedia, isYouTube } from '../lib/media';

export interface PlayerHandle {
  seek(sec: number): void;
  play(): void;
  pause(): void;
  toggle(): void;
  currentTime(): number;
}

export interface PlayerProps {
  /** Playable source from `playableSrc` (HLS or a progressive file). Undefined → virtual clock. */
  src?: string;
  /** The customer-facing origin URL (YouTube etc.) — only used to explain why there is no picture. */
  originUrl?: string;
  poster?: string;
  /** Fallback duration when the media cannot load (YouTube etc.). */
  durationSec?: number;
  fps?: number;
  onTime?: (sec: number) => void;
  onDuration?: (sec: number) => void;
  /** Optional in/out points — loop between them when loop is on. */
  range?: { start: number; end: number };
  title?: string;
  autoPlay?: boolean;
  compact?: boolean;
  initialTime?: number;
}

const SPEEDS = [0.5, 1, 1.5, 2];

/**
 * Native <video> (hls.js for .m3u8) with a broadcast-style frame-step transport.
 * When the source cannot be played in-browser (YouTube links, missing media)
 * it falls back to a virtual clock so timeline scrubbing and review still work.
 */
export const Player = forwardRef<PlayerHandle, PlayerProps>(function Player(
  { src, originUrl, poster, durationSec, fps = 25, onTime, onDuration, range, title, autoPlay, compact, initialTime },
  ref,
) {
  const video = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [loop, setLoop] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [time, setTime] = useState(initialTime ?? 0);
  const [dur, setDur] = useState(durationSec ?? 0);
  const [virtual, setVirtual] = useState(!src);
  const [loaded, setLoaded] = useState(false);
  const [posterOk, setPosterOk] = useState(true);
  const [stepUnit, setStepUnit] = useState<'f' | 's'>('f');
  const raf = useRef<number>();
  const timeRef = useRef(time);
  timeRef.current = time;
  const vClock = useRef<{ base: number; at: number } | null>(null);
  /** Seek requested before media metadata arrived. */
  const pendingSeek = useRef<number | null>(null);

  const playable = !!src;

  useEffect(() => {
    setPosterOk(true);
  }, [poster]);

  // Attach media source (hls.js for HLS manifests).
  useEffect(() => {
    const v = video.current;
    if (!v || !playable) {
      setVirtual(true);
      return;
    }
    setVirtual(false);
    setLoaded(false);
    const detach = attachMedia(v, src!, { startPosition: initialTime, onError: () => setVirtual(true) });
    return detach;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src, playable]);

  useEffect(() => {
    if (durationSec && !dur) setDur(durationSec);
  }, [durationSec, dur]);

  // Time tracking loop (rAF for smooth playhead).
  useEffect(() => {
    const tick = () => {
      const v = video.current;
      let t = timeRef.current;
      if (virtual) {
        if (vClock.current && playing) {
          t = vClock.current.base + ((performance.now() - vClock.current.at) / 1000) * speed;
          const end = range && loop ? range.end : dur || Infinity;
          if (t >= end) {
            if (loop) {
              t = range ? range.start : 0;
              vClock.current = { base: t, at: performance.now() };
            } else {
              t = end === Infinity ? t : end;
              setPlaying(false);
              vClock.current = null;
            }
          }
          setTime(t);
          onTime?.(t);
        }
      } else if (v && v.readyState >= 1) {
        // Only trust the element once metadata is in — before that currentTime is a meaningless 0.
        t = v.currentTime;
        if (range && loop && t >= range.end) {
          v.currentTime = range.start;
          t = range.start;
        }
        if (Math.abs(t - timeRef.current) > 0.001) {
          setTime(t);
          onTime?.(t);
        }
      }
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
  }, [virtual, playing, speed, loop, range, dur, onTime]);

  const seek = useCallback(
    (sec: number) => {
      const max = dur || Infinity;
      const s = Math.max(0, Math.min(max === Infinity ? sec : max, sec));
      if (virtual) {
        if (vClock.current) vClock.current = { base: s, at: performance.now() };
        setTime(s);
        onTime?.(s);
      } else if (video.current) {
        const v = video.current;
        if (v.readyState >= 1) v.currentTime = s;
        else pendingSeek.current = s;
        setTime(s);
        onTime?.(s);
      }
    },
    [virtual, dur, onTime],
  );

  const play = useCallback(() => {
    if (virtual) {
      vClock.current = { base: timeRef.current, at: performance.now() };
      setPlaying(true);
    } else {
      void video.current?.play().catch(() => undefined);
    }
  }, [virtual]);

  const pause = useCallback(() => {
    if (virtual) {
      vClock.current = null;
      setPlaying(false);
    } else video.current?.pause();
  }, [virtual]);

  useImperativeHandle(ref, () => ({ seek, play, pause, toggle: () => (playing ? pause() : play()), currentTime: () => time }), [seek, play, pause, playing, time]);

  useEffect(() => {
    if (initialTime != null) seek(initialTime);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialTime, virtual]);

  useEffect(() => {
    if (autoPlay) play();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoPlay, virtual, loaded]);

  useEffect(() => {
    if (video.current) video.current.playbackRate = speed;
  }, [speed]);

  // Media failed after it had been running (e.g. a stalled stream): keep the clock where it was.
  useEffect(() => {
    if (virtual && playable && playing) {
      vClock.current = { base: timeRef.current, at: performance.now() };
    }
  }, [virtual, playable, playing]);

  const step = (n: number) => {
    seek(time + (stepUnit === 'f' ? n / fps : n));
  };

  const onScrub = (e: React.MouseEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    seek(((e.clientX - r.left) / r.width) * (dur || 0));
  };

  const youtube = !playable && isYouTube(originUrl);

  return (
    <div className="player">
      <div className="player__stage" style={compact ? { maxHeight: 'none' } : undefined}>
        {playable && (
          <video
            ref={video}
            muted={muted}
            loop={loop && !range}
            playsInline
            preload="metadata"
            crossOrigin="anonymous"
            style={virtual ? { visibility: 'hidden' } : undefined}
            onPlay={() => !virtual && setPlaying(true)}
            onPause={() => !virtual && setPlaying(false)}
            onLoadedMetadata={(e) => {
              const v = e.currentTarget;
              const d = v.duration;
              if (isFinite(d) && d > 0) {
                setDur(d);
                onDuration?.(d);
              }
              if (pendingSeek.current != null) {
                v.currentTime = pendingSeek.current;
                pendingSeek.current = null;
              }
            }}
            onLoadedData={() => setLoaded(true)}
            onClick={() => (playing ? pause() : play())}
          />
        )}
        {/* Poster behind the video until the first frame decodes, and as the picture for the virtual clock. */}
        {poster && posterOk && (!loaded || virtual) && <img className="player__poster" src={poster} alt="" draggable={false} onError={() => setPosterOk(false)} />}
        {virtual && (
          <div className={`player__ph${poster && posterOk ? ' player__ph--over' : ''}`} onClick={() => (playing ? pause() : play())}>
            <Icon name={youtube ? 'external' : 'film'} size={26} />
            <b>{title ?? 'Preview unavailable'}</b>
            <span>
              {youtube
                ? 'YouTube source — analysed by TwelveLabs, in-browser playback is not permitted. Transport runs a virtual clock.'
                : playable
                  ? 'Stream could not be loaded — transport runs a virtual clock.'
                  : 'No playable source — transport runs a virtual clock.'}
            </span>
          </div>
        )}
        {playable && !virtual && !loaded && <div className="player__loading" aria-hidden />}
      </div>
      <div className="player__scrub" onClick={onScrub} role="slider" aria-valuenow={time}>
        <div style={{ width: `${dur ? (time / dur) * 100 : 0}%` }} />
      </div>
      <div className="player__bar">
        {[-10, -5, -1].map((n) => (
          <button key={n} className="player__step" onClick={() => step(n)} title={`Step ${n} ${stepUnit === 'f' ? 'frames' : 'seconds'}`}>
            {n}
          </button>
        ))}
        <button className="player__play" onClick={() => (playing ? pause() : play())} aria-label={playing ? 'Pause' : 'Play'}>
          <Icon name={playing ? 'pause' : 'play'} size={14} />
        </button>
        {[1, 5, 10].map((n) => (
          <button key={n} className="player__step" onClick={() => step(n)} title={`Step +${n} ${stepUnit === 'f' ? 'frames' : 'seconds'}`}>
            +{n}
          </button>
        ))}
        <button className={`player__ctl${stepUnit === 'f' ? ' is-on' : ''}`} onClick={() => setStepUnit(stepUnit === 'f' ? 's' : 'f')} title="Step unit">
          {stepUnit === 'f' ? 'frames' : 'seconds'}
        </button>
        <button className="player__ctl" onClick={() => setSpeed(SPEEDS[(SPEEDS.indexOf(speed) + 1) % SPEEDS.length]!)} title="Playback speed">
          {speed}×
        </button>
        <button className={`player__ctl${muted ? '' : ' is-on'}`} onClick={() => setMuted(!muted)} title={muted ? 'Unmute' : 'Mute'}>
          <Icon name={muted ? 'mute' : 'volume'} size={14} />
        </button>
        <button className={`player__ctl${loop ? ' is-on' : ''}`} onClick={() => setLoop(!loop)} title="Loop">
          <Icon name="loop" size={14} />
        </button>
        <div className="player__tc">
          <Timecode sec={time} fps={fps} />
          <span className="muted small">/</span>
          <Timecode sec={dur} fps={fps} muted />
        </div>
      </div>
    </div>
  );
});
