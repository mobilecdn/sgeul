import { useState, type CSSProperties } from 'react';
import { Icon } from './Icon';
import { sortedLabels } from '../lib/format';

export type ChipTone = 'default' | 'active' | 'violet' | 'red' | 'green';

export function TagChip({
  label,
  score,
  onRemove,
  onClick,
  tone = 'default',
  title,
  style,
}: {
  label: string;
  score?: number;
  onRemove?: () => void;
  onClick?: () => void;
  tone?: ChipTone;
  title?: string;
  style?: CSSProperties;
}) {
  const cls = ['chip', tone !== 'default' && `chip--${tone}`, onClick && 'chip--click', !onRemove && 'chip--pad'].filter(Boolean).join(' ');
  return (
    <span className={cls} onClick={onClick} title={title ?? (score != null ? `${label} · confidence ${score.toFixed(2)}` : label)} style={style} role={onClick ? 'button' : undefined}>
      <span className="chip__label">{label}</span>
      {score != null && <span className="chip__score">{score.toFixed(2)}</span>}
      {onRemove && (
        <button
          className="chip__x"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          aria-label={`Remove ${label}`}
        >
          <Icon name="x" size={10} stroke={2.5} />
        </button>
      )}
    </span>
  );
}

export function TagRow({
  labels,
  max = 8,
  tone,
  onClick,
  onRemove,
  empty = 'None',
  min = 0,
}: {
  labels: Record<string, number> | Array<{ label: string; score?: number }> | undefined;
  max?: number;
  tone?: ChipTone;
  onClick?: (label: string) => void;
  onRemove?: (label: string) => void;
  empty?: string;
  /** Hide labels below this confidence. */
  min?: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const items = (Array.isArray(labels) ? labels : sortedLabels(labels).map(([label, score]) => ({ label, score }))).filter((x) => (x.score ?? 1) >= min);
  if (!items.length) return <span className="muted small">{empty}</span>;
  const shown = expanded ? items : items.slice(0, max);
  const rest = items.length - shown.length;
  return (
    <div className="chiprow">
      {shown.map((it) => (
        <TagChip key={it.label} label={it.label} score={it.score} tone={tone} onClick={onClick ? () => onClick(it.label) : undefined} onRemove={onRemove ? () => onRemove(it.label) : undefined} />
      ))}
      {rest > 0 && (
        <span className="chip chip--more" onClick={() => setExpanded(true)} role="button">
          +{rest}
        </span>
      )}
      {expanded && items.length > max && (
        <span className="chip chip--more" onClick={() => setExpanded(false)} role="button">
          less
        </span>
      )}
    </div>
  );
}
