import type { CSSProperties } from 'react';
import { timecode } from '../lib/format';

export function Timecode({ sec, fps = 25, muted, style, className = '', small }: { sec: number; fps?: number; muted?: boolean; style?: CSSProperties; className?: string; small?: boolean }) {
  return (
    <span className={`tc${muted ? ' tc--muted' : ''} ${className}`} style={small ? { fontSize: 11, ...style } : style} title={`${sec.toFixed(2)}s @ ${fps}fps`}>
      {timecode(sec, fps)}
    </span>
  );
}

export function TimecodeRange({ start, end, fps = 25, muted, small }: { start: number; end: number; fps?: number; muted?: boolean; small?: boolean }) {
  return (
    <span className="row" style={{ gap: small ? 4 : 6, flexWrap: 'wrap' }}>
      <Timecode sec={start} fps={fps} muted={muted} small={small} />
      <span className="muted" style={small ? { fontSize: 11 } : undefined}>→</span>
      <Timecode sec={end} fps={fps} muted={muted} small={small} />
    </span>
  );
}
