import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Icon } from './Icon';
import { timecode } from '../lib/format';
import { reviewColor } from '../lib/colors';

export type SegState = 'pending' | 'approved' | 'declined' | 'none';

export interface TLSegment {
  id: string;
  start: number;
  end: number;
  color: string;
  label?: string;
  state?: SegState;
  /** Render as a faint window (e.g. ad-break tolerance) — not selectable. */
  faint?: boolean;
  title?: string;
}

export interface TLMarker {
  id: string;
  at: number;
  color?: string;
  state?: SegState;
  label?: string;
  title?: string;
}

export interface TLTrack {
  id: string;
  label: string;
  color?: string;
  height?: number;
  segments?: TLSegment[];
  markers?: TLMarker[];
  /** Custom content, sized to the full canvas width (e.g. an emotion arc). */
  render?: (ctx: { width: number; height: number; pxPerSec: number }) => ReactNode;
}

const TICKS = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600];
const LANE_H = 20;
const LANE_GAP = 3;
const LANE_PAD = 7;
const MAX_LANES = 3;

/**
 * Greedy interval packing: overlapping segments (a title card inside a chapter,
 * two safety flags at once) go to separate rows so nothing is hidden.
 */
function packLanes(segments: TLSegment[]): Map<string, number> {
  const lanes = new Map<string, number>();
  const ends: number[] = [];
  const sorted = [...segments].filter((s) => !s.faint).sort((a, b) => a.start - b.start || b.end - b.start - (a.end - a.start));
  for (const s of sorted) {
    let lane = ends.findIndex((e) => e <= s.start + 1e-6);
    if (lane === -1) {
      if (ends.length < MAX_LANES) {
        lane = ends.length;
        ends.push(s.end);
      } else {
        // Overflow: stack on the lane that frees up first.
        lane = ends.indexOf(Math.min(...ends));
        ends[lane] = Math.max(ends[lane]!, s.end);
      }
    } else ends[lane] = s.end;
    lanes.set(s.id, lane);
  }
  return lanes;
}

export function Timeline({
  duration,
  fps = 25,
  tracks,
  playhead,
  onSeek,
  selectedId,
  onSelect,
  toolbarExtra,
}: {
  duration: number;
  fps?: number;
  tracks: TLTrack[];
  playhead: number;
  onSeek: (sec: number) => void;
  selectedId?: string | null;
  onSelect?: (id: string, trackId: string) => void;
  toolbarExtra?: ReactNode;
}) {
  const scroller = useRef<HTMLDivElement>(null);
  const [viewW, setViewW] = useState(800);
  const [pxPerSec, setPxPerSec] = useState<number | null>(null);
  const [hoverX, setHoverX] = useState<number | null>(null);
  const dur = Math.max(1, duration || 1);

  useLayoutEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setViewW(el.clientWidth));
    ro.observe(el);
    setViewW(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const fitPx = viewW / dur;
  const pps = pxPerSec ?? fitPx;
  const width = Math.max(viewW, dur * pps);

  const fit = useCallback(() => setPxPerSec(null), []);
  const zoom = (f: number) => {
    const next = Math.min(200, Math.max(fitPx, pps * f));
    setPxPerSec(next);
    // keep playhead in view
    requestAnimationFrame(() => {
      const el = scroller.current;
      if (el) el.scrollLeft = Math.max(0, playhead * next - el.clientWidth / 2);
    });
  };

  // Auto-scroll to keep playhead visible while playing.
  useEffect(() => {
    const el = scroller.current;
    if (!el || pxPerSec == null) return;
    const x = playhead * pps;
    if (x < el.scrollLeft || x > el.scrollLeft + el.clientWidth) el.scrollLeft = Math.max(0, x - el.clientWidth * 0.2);
  }, [playhead, pps, pxPerSec]);

  const tick = useMemo(() => TICKS.find((t) => t * pps >= 90) ?? 3600, [pps]);
  const ticks = useMemo(() => {
    const out: number[] = [];
    for (let t = 0; t <= dur; t += tick) out.push(t);
    return out;
  }, [dur, tick]);

  const secAt = (clientX: number) => {
    const el = scroller.current!;
    const r = el.getBoundingClientRect();
    return Math.max(0, Math.min(dur, (clientX - r.left + el.scrollLeft) / pps));
  };

  const startScrub = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('.tl__seg, .tl__marker')) return;
    e.preventDefault();
    onSeek(secAt(e.clientX));
    const move = (ev: PointerEvent) => onSeek(secAt(ev.clientX));
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const rows = useMemo(
    () =>
      tracks.map((t) => {
        const lanes = t.segments ? packLanes(t.segments) : new Map<string, number>();
        const n = lanes.size ? Math.max(...lanes.values()) + 1 : 1;
        const h = t.height ?? Math.max(34, LANE_PAD * 2 + n * LANE_H + (n - 1) * LANE_GAP);
        return { ...t, h, lanes };
      }),
    [tracks],
  );

  return (
    <div className="tl">
      <div className="tl__toolbar">
        <span className="row" style={{ gap: 6 }}>
          <Icon name="layers" size={13} /> Timeline
        </span>
        <span className="tl__zoom" style={{ marginLeft: 8 }}>
          <button onClick={() => zoom(1 / 1.5)} title="Zoom out">
            <Icon name="zoomOut" size={13} />
          </button>
          <button onClick={() => zoom(1.5)} title="Zoom in">
            <Icon name="zoomIn" size={13} />
          </button>
          <button onClick={fit} title="Fit">
            <Icon name="fit" size={13} />
          </button>
        </span>
        <span className="mono tl__meta" style={{ fontSize: 11, whiteSpace: 'nowrap' }}>
          {pps.toFixed(1)} px/s · tick {tick >= 60 ? `${tick / 60}m` : `${tick}s`}
        </span>
        <span style={{ marginLeft: 'auto' }} className="row">
          {toolbarExtra}
        </span>
      </div>
      <div className="tl__body">
        <div className="tl__labels">
          <div className="tl__label tl__label--ruler">{timecode(playhead, fps)}</div>
          {rows.map((t) => (
            <div key={t.id} className="tl__label" style={{ ['--track-h' as string]: `${t.h}px` }}>
              {t.color && <i style={{ background: t.color }} />}
              {t.label}
            </div>
          ))}
        </div>
        <div className="tl__scroll" ref={scroller} onPointerLeave={() => setHoverX(null)} onPointerMove={(e) => setHoverX(secAt(e.clientX))}>
          <div className="tl__canvas" style={{ width, ['--grid-px' as string]: `${tick * pps}px` }} onPointerDown={startScrub}>
            <div className="tl__ruler">
              {ticks.map((t) => (
                <div key={t} className="tl__tick" style={{ left: t * pps }}>
                  {t * pps > 0 || t === 0 ? timecode(t, fps).slice(0, 8) : ''}
                </div>
              ))}
              {tick >= 10 &&
                ticks.flatMap((t) =>
                  [1, 2, 3, 4].map((k) => {
                    const s = t + (tick / 5) * k;
                    return s <= dur ? <div key={`${t}-${k}`} className="tl__tick tl__tick--minor" style={{ left: s * pps }} /> : null;
                  }),
                )}
            </div>
            {rows.map((t) => (
              <div key={t.id} className={`tl__track${t.render ? ' tl__track--custom' : ''}`} style={{ ['--track-h' as string]: `${t.h}px` }}>
                {t.render?.({ width, height: t.h, pxPerSec: pps })}
                {t.segments?.map((s) => {
                  const left = s.start * pps;
                  const w = Math.max(6, (s.end - s.start) * pps);
                  const border = s.state && s.state !== 'none' ? reviewColor(s.state === 'pending' ? 'open' : s.state) : undefined;
                  const lane = t.lanes.get(s.id) ?? 0;
                  const laneTop = s.faint ? LANE_PAD : LANE_PAD + lane * (LANE_H + LANE_GAP);
                  const laneH = s.faint ? t.h - LANE_PAD * 2 : LANE_H;
                  const full = `${s.label ?? ''}${s.label ? ' · ' : ''}${timecode(s.start, fps)} → ${timecode(s.end, fps)}`;
                  return (
                    <div
                      key={s.id}
                      className={['tl__seg', s.faint && 'tl__seg--faint', selectedId === s.id && 'is-selected'].filter(Boolean).join(' ')}
                      style={{
                        left,
                        width: w,
                        top: laneTop,
                        height: laneH,
                        background: s.color,
                        borderColor: selectedId === s.id ? '#fff' : border,
                        opacity: s.state === 'declined' ? 0.45 : undefined,
                        textDecoration: s.state === 'declined' ? 'line-through' : undefined,
                      }}
                      title={s.title ? `${s.title}\n${full}` : full}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (s.faint) return;
                        onSelect?.(s.id, t.id);
                        onSeek(s.start);
                      }}
                    >
                      {w > 40 && s.label && <span className="tl__seg-label">{s.label}</span>}
                    </div>
                  );
                })}
                {t.markers?.map((m) => {
                  const color = m.state && m.state !== 'none' ? reviewColor(m.state === 'pending' ? 'open' : m.state) : (m.color ?? t.color ?? 'var(--blue)');
                  return (
                    <div
                      key={m.id}
                      className={`tl__marker${selectedId === m.id ? ' is-selected' : ''}`}
                      style={{ left: m.at * pps, ['--m' as string]: color, opacity: m.state === 'declined' ? 0.5 : 1 }}
                      title={m.title ?? `${m.label ?? ''} ${timecode(m.at, fps)}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelect?.(m.id, t.id);
                        onSeek(m.at);
                      }}
                    />
                  );
                })}
              </div>
            ))}
            {hoverX != null && (
              <div className="tl__hover" style={{ left: hoverX * pps }}>
                <span>{timecode(hoverX, fps)}</span>
              </div>
            )}
            <div className="tl__playhead" style={{ left: playhead * pps }} />
            <div className="tl__playhead-grab" style={{ left: playhead * pps }} onPointerDown={startScrub} />
          </div>
        </div>
      </div>
    </div>
  );
}
