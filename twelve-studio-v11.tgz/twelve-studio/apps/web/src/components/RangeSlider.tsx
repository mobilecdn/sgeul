import { useCallback, useRef } from 'react';

export function RangeSlider({
  value,
  onChange,
  min = 0,
  max = 1,
  step = 0.01,
  label,
  compact,
}: {
  value: [number, number];
  onChange: (v: [number, number]) => void;
  min?: number;
  max?: number;
  step?: number;
  label?: string;
  compact?: boolean;
}) {
  const track = useRef<HTMLDivElement>(null);
  const [lo, hi] = value;
  const pct = (v: number) => ((v - min) / (max - min)) * 100;

  const fromClientX = useCallback(
    (x: number) => {
      const r = track.current!.getBoundingClientRect();
      const t = Math.min(1, Math.max(0, (x - r.left) / r.width));
      const raw = min + t * (max - min);
      return Math.round(raw / step) * step;
    },
    [min, max, step],
  );

  const startDrag = (which: 0 | 1) => (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const move = (ev: PointerEvent) => {
      const v = fromClientX(ev.clientX);
      if (which === 0) onChange([Math.min(v, hi), hi]);
      else onChange([lo, Math.max(v, lo)]);
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const onTrackDown = (e: React.PointerEvent) => {
    const v = fromClientX(e.clientX);
    // Move the nearest handle.
    if (Math.abs(v - lo) <= Math.abs(v - hi)) onChange([Math.min(v, hi), hi]);
    else onChange([lo, Math.max(v, lo)]);
  };

  return (
    <div className="rs">
      {!compact && (
        <div className="rs__readout">
          <span>{label ?? 'Confidence'}</span>
          <span>
            <b>{lo.toFixed(2)}</b> – <b>{hi.toFixed(2)}</b>
          </span>
        </div>
      )}
      <div className="rs__track" ref={track} onPointerDown={onTrackDown}>
        <div className="rs__rail" />
        <div className="rs__range" style={{ left: `${pct(lo)}%`, width: `${pct(hi) - pct(lo)}%` }} />
        <div className="rs__handle" style={{ left: `${pct(lo)}%` }} onPointerDown={startDrag(0)} role="slider" aria-valuenow={lo} aria-valuemin={min} aria-valuemax={max} />
        <div className="rs__handle" style={{ left: `${pct(hi)}%` }} onPointerDown={startDrag(1)} role="slider" aria-valuenow={hi} aria-valuemin={min} aria-valuemax={max} />
      </div>
      {compact && (
        <div className="rs__readout" style={{ marginTop: -4 }}>
          <b>{lo.toFixed(2)}</b>
          <b>{hi.toFixed(2)}</b>
        </div>
      )}
    </div>
  );
}
