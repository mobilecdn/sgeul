import { useMemo, useRef, useState } from 'react';
import type { EmotionArc, EmotionSample } from '@twelve-studio/core';
import { timecode, topLabels } from '../lib/format';

export interface ArcSeries {
  arc: EmotionArc;
  color?: string;
  label?: string;
}

/**
 * SVG area chart: arousal as a filled area from the baseline, valence as a line
 * around the centre. Act bands, climax pin, hover tooltip with the beat text.
 */
export function EmotionArcChart({
  arc,
  overlay,
  duration,
  width,
  height = 120,
  onSeek,
  playhead,
  compact,
  fps = 25,
  color = '#0068e0',
  showActs = true,
  axis = 'time',
}: {
  arc: EmotionArc;
  overlay?: ArcSeries;
  duration: number;
  /** Pixel width; when omitted the chart is responsive (100%). */
  width?: number;
  height?: number;
  onSeek?: (sec: number) => void;
  playhead?: number;
  compact?: boolean;
  fps?: number;
  color?: string;
  showActs?: boolean;
  /** X-axis labels: broadcast time, percent of runtime, or none. */
  axis?: 'time' | 'percent' | 'none';
}) {
  const [hover, setHover] = useState<{ x: number; s: EmotionSample } | null>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const W = width ?? 1000;
  const H = height;
  const padT = compact ? 4 : 14;
  const padB = compact ? 4 : 18;
  const plotH = H - padT - padB;
  const dur = Math.max(1, duration || arc.samples[arc.samples.length - 1]?.end || 1);
  const x = (t: number) => (t / dur) * W;
  const yA = (a: number) => padT + plotH - a * plotH;
  const yV = (v: number) => padT + plotH / 2 - v * (plotH / 2) * 0.9;

  const paths = useMemo(() => {
    const build = (samples: EmotionSample[]) => {
      if (!samples.length) return { area: '', line: '' };
      const pts = samples.map((s) => ({ t: (s.start + s.end) / 2, a: s.arousal, v: s.valence }));
      const first = pts[0]!;
      const last = pts[pts.length - 1]!;
      const smooth = (get: (p: { t: number; a: number; v: number }) => number) => {
        let d = `M ${x(first.t).toFixed(1)} ${get(first).toFixed(1)}`;
        for (let i = 1; i < pts.length; i++) {
          const p0 = pts[i - 1]!;
          const p1 = pts[i]!;
          const cx = (x(p0.t) + x(p1.t)) / 2;
          d += ` C ${cx.toFixed(1)} ${get(p0).toFixed(1)}, ${cx.toFixed(1)} ${get(p1).toFixed(1)}, ${x(p1.t).toFixed(1)} ${get(p1).toFixed(1)}`;
        }
        return d;
      };
      const lineA = smooth((p) => yA(p.a));
      const area = `${lineA} L ${x(last.t).toFixed(1)} ${yA(0)} L ${x(first.t).toFixed(1)} ${yA(0)} Z`;
      return { area, line: smooth((p) => yV(p.v)), lineA };
    };
    return { main: build(arc.samples), over: overlay ? build(overlay.arc.samples) : null };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [arc, overlay, W, H, dur]);

  const onMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * W;
    const t = (px / W) * dur;
    let best: EmotionSample | null = null;
    let bd = Infinity;
    for (const s of arc.samples) {
      const d = Math.abs((s.start + s.end) / 2 - t);
      if (d < bd) {
        bd = d;
        best = s;
      }
    }
    if (best) setHover({ x: e.clientX - r.left, s: best });
  };

  const onClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    onSeek?.(((e.clientX - r.left) / r.width) * dur);
  };

  const gid = useMemo(() => `g${Math.random().toString(36).slice(2, 7)}`, []);
  const overColor = overlay?.color ?? '#e05ab0';

  return (
    <div ref={wrap} style={{ position: 'relative', width: width ?? '100%', height: H }}>
      <svg
        width={width ?? '100%'}
        height={H}
        viewBox={`0 0 ${W} ${H}`}
        preserveAspectRatio="none"
        style={{ display: 'block', cursor: onSeek ? 'pointer' : 'default' }}
        onMouseMove={onMove}
        onMouseLeave={() => setHover(null)}
        onClick={onClick}
      >
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.55" />
            <stop offset="100%" stopColor={color} stopOpacity="0.04" />
          </linearGradient>
          <linearGradient id={`${gid}o`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={overColor} stopOpacity="0.4" />
            <stop offset="100%" stopColor={overColor} stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {showActs &&
          arc.acts.map((a, i) => {
            const w = Math.max(0, x(a.end) - x(a.start));
            // Labels are clipped to their act band and shortened to what fits (≈6 viewBox units per glyph at 10px).
            const maxChars = Math.floor((w - 12) / 6);
            const label = a.name.length > maxChars ? (maxChars > 3 ? `${a.name.slice(0, maxChars - 1).trimEnd()}…` : '') : a.name;
            return (
              <g key={a.name + i}>
                <clipPath id={`${gid}a${i}`}>
                  <rect x={x(a.start)} y={0} width={w} height={H} />
                </clipPath>
                <rect x={x(a.start)} y={0} width={w} height={H} fill={i % 2 ? 'rgba(255,255,255,0.025)' : 'transparent'}>
                  <title>
                    {a.name} · {a.summary}
                  </title>
                </rect>
                <line x1={x(a.start)} x2={x(a.start)} y1={0} y2={H} stroke="rgba(255,255,255,0.1)" strokeDasharray="3 3" />
                {!compact && label && (
                  <text x={x(a.start) + 6} y={11} fontSize={10} fill="rgba(255,255,255,0.45)" fontFamily="Inter, system-ui" fontWeight={600} clipPath={`url(#${gid}a${i})`}>
                    {label}
                    <title>{a.name}</title>
                  </text>
                )}
              </g>
            );
          })}
        {/* centre line for valence */}
        <line x1={0} x2={W} y1={yV(0)} y2={yV(0)} stroke="rgba(255,255,255,0.12)" strokeDasharray="2 4" />
        <path d={paths.main.area} fill={`url(#${gid})`} />
        <path d={paths.main.lineA ?? ''} fill="none" stroke={color} strokeWidth={1.5} vectorEffect="non-scaling-stroke" strokeOpacity={0.9} />
        <path d={paths.main.line} fill="none" stroke="#fff" strokeWidth={1.5} strokeOpacity={0.85} vectorEffect="non-scaling-stroke" />
        {paths.over && (
          <>
            <path d={paths.over.area} fill={`url(#${gid}o)`} />
            <path d={paths.over.lineA ?? ''} fill="none" stroke={overColor} strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
            <path d={paths.over.line} fill="none" stroke={overColor} strokeWidth={1.5} strokeDasharray="4 3" vectorEffect="non-scaling-stroke" strokeOpacity={0.9} />
          </>
        )}
        {arc.climax && (
          <g>
            <line x1={x(arc.climax.at)} x2={x(arc.climax.at)} y1={padT - 2} y2={H - padB} stroke="#f56300" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
            <circle cx={x(arc.climax.at)} cy={padT + 2} r={4} fill="#f56300" />
            {!compact && (
              <text x={x(arc.climax.at) + 8} y={H - padB - 4} fontSize={10} fill="#ffa361" fontFamily="Inter, system-ui" fontWeight={600}>
                climax
              </text>
            )}
          </g>
        )}
        {!compact &&
          axis !== 'none' &&
          [0, 0.25, 0.5, 0.75, 1].map((f) => (
            <text key={f} x={x(dur * f) + (f === 1 ? -4 : 2)} y={H - 4} fontSize={9.5} fill="rgba(255,255,255,0.35)" fontFamily="ui-monospace, monospace" textAnchor={f === 1 ? 'end' : 'start'}>
              {axis === 'percent' ? `${Math.round(f * 100)}%` : timecode(dur * f, fps).slice(0, 8)}
            </text>
          ))}
        {hover && <line x1={x((hover.s.start + hover.s.end) / 2)} x2={x((hover.s.start + hover.s.end) / 2)} y1={0} y2={H} stroke="rgba(255,255,255,0.5)" vectorEffect="non-scaling-stroke" />}
        {playhead != null && <line x1={x(playhead)} x2={x(playhead)} y1={0} y2={H} stroke="#fff" strokeWidth={1.5} vectorEffect="non-scaling-stroke" strokeOpacity={0.9} />}
      </svg>
      {hover && (
        <div className="arc-tip" style={{ left: Math.min(Math.max(130, hover.x), (wrap.current?.clientWidth ?? 400) - 130), top: padT + 8 }}>
          <small>
            {axis === 'percent' ? `${Math.round(hover.s.start * 100)}–${Math.round(hover.s.end * 100)}%` : `${timecode(hover.s.start, fps)} → ${timecode(hover.s.end, fps)}`} · valence {hover.s.valence >= 0 ? '+' : ''}
            {hover.s.valence.toFixed(2)} · arousal {hover.s.arousal.toFixed(2)}
          </small>
          {hover.s.beat}
          <small style={{ marginTop: 3 }}>{topLabels(hover.s.emotions, 3).join(' · ')}</small>
        </div>
      )}
    </div>
  );
}

export function ArcLegend({ overlayLabel, overlayColor = '#e05ab0', mainLabel = 'arousal', color = '#0068e0' }: { overlayLabel?: string; overlayColor?: string; mainLabel?: string; color?: string }) {
  return (
    <div className="legend">
      <span>
        <i style={{ background: color }} /> {mainLabel}
      </span>
      <span>
        <i style={{ background: '#fff' }} /> valence
      </span>
      <span>
        <i style={{ background: '#f56300' }} /> climax
      </span>
      {overlayLabel && (
        <span>
          <i style={{ background: overlayColor }} /> {overlayLabel}
        </span>
      )}
    </div>
  );
}
