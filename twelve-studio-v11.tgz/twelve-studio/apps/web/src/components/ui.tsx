import { useEffect, useState, type CSSProperties, type ReactNode } from 'react';
import { Icon, type IconName } from './Icon';
import { ToastContext, type ToastItem } from '../lib/hooks';

/* ------------------------------------------------------------------ */
/* Button                                                              */
/* ------------------------------------------------------------------ */
export type ButtonVariant = 'default' | 'primary' | 'ghost' | 'ai' | 'danger' | 'success';

export function Button({
  variant = 'default',
  size,
  icon,
  loading,
  children,
  className = '',
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: ButtonVariant;
  size?: 'sm' | 'lg';
  icon?: IconName;
  loading?: boolean;
}) {
  const cls = ['btn', variant !== 'default' && `btn--${variant}`, size && `btn--${size}`, !children && icon && 'btn--icon', className]
    .filter(Boolean)
    .join(' ');
  return (
    <button className={cls} disabled={loading || rest.disabled} {...rest}>
      {loading ? <span className="btn__spin" /> : variant === 'ai' ? <Icon name="sparkle" size={13} /> : icon ? <Icon name={icon} size={size === 'sm' ? 13 : 15} /> : null}
      {children}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* Card                                                                */
/* ------------------------------------------------------------------ */
export function Card({
  title,
  sub,
  actions,
  children,
  soft,
  flush,
  className = '',
  style,
  icon,
}: {
  title?: ReactNode;
  sub?: ReactNode;
  actions?: ReactNode;
  children?: ReactNode;
  soft?: boolean;
  flush?: boolean;
  className?: string;
  style?: CSSProperties;
  icon?: IconName;
}) {
  return (
    <section className={['card', soft && 'card--soft', flush && 'card--flush', className].filter(Boolean).join(' ')} style={style}>
      {(title || actions) && (
        <header className="card__head" style={flush ? { padding: '16px 20px 0' } : undefined}>
          <div>
            <h2>
              {icon && <Icon name={icon} size={16} style={{ color: 'var(--muted)' }} />}
              {title}
            </h2>
            {sub && <div className="card__sub">{sub}</div>}
          </div>
          {actions && <div className="row">{actions}</div>}
        </header>
      )}
      {children}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* StatTile                                                            */
/* ------------------------------------------------------------------ */
export function StatTile({
  label,
  value,
  unit,
  hint,
  accent = '#0068e0',
  loading,
}: {
  label: string;
  value: string | number | undefined;
  unit?: string;
  hint?: ReactNode;
  accent?: string;
  loading?: boolean;
}) {
  return (
    <div className="stat">
      <span className="stat__accent" style={{ background: accent }} />
      <div className="stat__label">{label}</div>
      {loading ? (
        <div className="skeleton" style={{ height: 46, width: '55%' }} />
      ) : (
        <div className="stat__value">
          {value ?? '—'}
          {unit && <small>{unit}</small>}
        </div>
      )}
      {hint && <div className="stat__hint">{hint}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* StatusPill                                                          */
/* ------------------------------------------------------------------ */
export type PillTone = 'neutral' | 'blue' | 'green' | 'red' | 'orange' | 'violet' | 'info';

const STATUS_TONE: Record<string, PillTone> = {
  ready: 'green',
  approved: 'green',
  running: 'blue',
  enriching: 'blue',
  indexing: 'blue',
  ingesting: 'orange',
  queued: 'orange',
  open: 'blue',
  pending: 'blue',
  failed: 'red',
  declined: 'red',
  skipped: 'neutral',
  safe: 'green',
  unsafe: 'red',
  live: 'green',
  mock: 'orange',
  static: 'info',
};

export function StatusPill({ status, tone, dot = true, children, style }: { status: string; tone?: PillTone; dot?: boolean; children?: ReactNode; style?: CSSProperties }) {
  const t = tone ?? STATUS_TONE[status] ?? 'neutral';
  return (
    <span className={`pill pill--${t}`} style={style}>
      {dot && <span className="pill__dot" />}
      {children ?? status.replace(/_/g, ' ')}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Tabs                                                                */
/* ------------------------------------------------------------------ */
export interface TabDef<T extends string> {
  id: T;
  label: ReactNode;
  count?: number;
  icon?: IconName;
}
export function Tabs<T extends string>({
  tabs,
  value,
  onChange,
  underline,
  full,
}: {
  tabs: TabDef<T>[];
  value: T;
  onChange: (v: T) => void;
  underline?: boolean;
  full?: boolean;
}) {
  return (
    <div className={['tabs', underline && 'tabs--underline', full && 'tabs--full'].filter(Boolean).join(' ')} role="tablist">
      {tabs.map((t) => (
        <button key={t.id} role="tab" className={`tab${t.id === value ? ' is-active' : ''}`} onClick={() => onChange(t.id)} aria-selected={t.id === value}>
          {t.icon && <Icon name={t.icon} size={14} />}
          {t.label}
          {t.count != null && <span className="tab__count">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Modal                                                               */
/* ------------------------------------------------------------------ */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal${wide ? ' modal--wide' : ''}`} role="dialog" aria-modal>
        <div className="modal__head">
          <h2>{title}</h2>
          <Button icon="x" variant="ghost" size="sm" onClick={onClose} aria-label="Close" />
        </div>
        <div className="modal__body">{children}</div>
        {footer && <div className="modal__foot">{footer}</div>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* EmptyState                                                          */
/* ------------------------------------------------------------------ */
export function EmptyState({ icon = 'film', title, text, action, style }: { icon?: IconName; title: string; text?: string; action?: ReactNode; style?: CSSProperties }) {
  return (
    <div className="empty" style={style}>
      <div className="empty__icon">
        <Icon name={icon} size={20} />
      </div>
      <h3>{title}</h3>
      {text && <p>{text}</p>}
      {action && <div style={{ marginTop: 8 }}>{action}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Meter                                                               */
/* ------------------------------------------------------------------ */
export function Meter({ value, color = 'var(--blue)', thin, style }: { value: number; color?: string; thin?: boolean; style?: CSSProperties }) {
  return (
    <div className={`meter${thin ? ' meter--thin' : ''}`} style={style}>
      <div className="meter__fill" style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%`, background: color }} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Toast provider                                                      */
/* ------------------------------------------------------------------ */
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const push = (text: string, kind: ToastItem['kind'] = 'info') => {
    const id = Date.now() + Math.random();
    setItems((s) => [...s, { id, text, kind }]);
    setTimeout(() => setItems((s) => s.filter((t) => t.id !== id)), 3800);
  };
  return (
    <ToastContext.Provider value={{ push }}>
      {children}
      <div className="toasts">
        {items.map((t) => (
          <div key={t.id} className={`toast toast--${t.kind}`}>
            <span className="toast__bar" />
            {t.kind === 'ai' && <Icon name="sparkle" size={13} style={{ color: '#c8b0ff' }} />}
            <span>{t.text}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

/* ------------------------------------------------------------------ */
/* Misc                                                                */
/* ------------------------------------------------------------------ */
export function Skeleton({ h = 16, w = '100%', style }: { h?: number; w?: string | number; style?: CSSProperties }) {
  return <div className="skeleton" style={{ height: h, width: w, ...style }} />;
}

export function ErrorNote({ error }: { error: Error | null }) {
  if (!error) return null;
  return (
    <div className="row" style={{ color: '#ff8a97', fontSize: 12.5, gap: 6 }}>
      <Icon name="alert" size={14} /> {error.message}
    </div>
  );
}

export function Sparkle() {
  return <Icon name="sparkle" size={12} className="sparkle" />;
}
