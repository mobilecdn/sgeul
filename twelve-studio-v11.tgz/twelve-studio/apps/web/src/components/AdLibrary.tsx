import { useState } from 'react';
import type { AdCreative } from '@twelve-studio/core';
import { Button, Modal, StatusPill, Tabs } from './ui';
import { Icon } from './Icon';
import { TagChip } from './TagChip';
import { sortedLabels } from '../lib/format';
import { useApi, useToast } from '../lib/hooks';
import { mmss } from '../lib/format';

/** Tiny muted <video> that shows the creative's first frame; a film glyph sits behind it until frames decode. */
export function AdThumb({ ad, className = '' }: { ad: Pick<AdCreative, 'mediaUrl' | 'name'>; className?: string }) {
  const src = ad.mediaUrl.includes('#') ? ad.mediaUrl : `${ad.mediaUrl}#t=0.5`;
  return (
    <span className={`adthumb ${className}`.trim()} title={ad.name}>
      <Icon name="film" size={14} />
      <video muted playsInline preload="metadata" src={src} aria-hidden />
    </span>
  );
}

export function adMeta(ad: AdCreative): string {
  const parts = [mmss(ad.durationSec)];
  if (ad.width && ad.height) parts.push(`${ad.width}×${ad.height}`);
  return parts.join(' · ');
}

type Source = 'url' | 'path';

/**
 * Ad library: every creative the API knows about, with add (URL or a file on the API host)
 * and delete. The list is owned by the caller so assignments elsewhere stay in sync.
 */
export function AdLibrary({
  open,
  onClose,
  ads,
  onChanged,
  assignedIds,
}: {
  open: boolean;
  onClose: () => void;
  ads: AdCreative[];
  /** Called after any mutation so the owner can refetch. */
  onChanged: () => void;
  /** Creatives currently assigned to a break of the open title (shown as a pill). */
  assignedIds?: Set<string>;
}) {
  const api = useApi();
  const toast = useToast();
  const [source, setSource] = useState<Source>('url');
  const [name, setName] = useState('');
  const [advertiser, setAdvertiser] = useState('');
  const [url, setUrl] = useState('');
  const [path, setPath] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [fingerprinting, setFingerprinting] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  const fingerprint = async (ad: AdCreative) => {
    setFingerprinting(ad.id);
    try {
      const next = await api.fingerprintAd(ad.id);
      const fp = next.fingerprint;
      toast.push(fp ? `${next.name}: ${fp.brand} · ${sortedLabels(fp.mood).slice(0, 3).map(([l]) => l).join(', ')}` : `Fingerprinted ${next.name}`, 'success');
      setExpanded(ad.id);
      onChanged();
    } catch (e) {
      toast.push((e as Error).message, 'error');
    } finally {
      setFingerprinting(null);
    }
  };

  const location = source === 'url' ? url.trim() : path.trim();
  const canAdd = !!name.trim() && !!location && !busy;

  const add = async () => {
    if (!canAdd) return;
    setBusy(true);
    try {
      const ad = await api.addAd({ name: name.trim(), advertiser: advertiser.trim() || undefined, ...(source === 'url' ? { sourceUrl: location } : { localPath: location }) });
      toast.push(`Added "${ad.name}" · ${adMeta(ad)}`, 'success');
      setName('');
      setAdvertiser('');
      setUrl('');
      setPath('');
      onChanged();
    } catch (e) {
      toast.push((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const remove = async (ad: AdCreative) => {
    setDeleting(ad.id);
    try {
      await api.deleteAd(ad.id);
      toast.push(`Deleted "${ad.name}"`, 'info');
      setConfirmId(null);
      onChanged();
    } catch (e) {
      toast.push((e as Error).message, 'error');
    } finally {
      setDeleting(null);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Ad library" wide>
      <div className="adlib">
        <div className="adlib__list">
          <div className="section__title">
            <span>Creatives</span>
            <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>{ads.length}</span>
          </div>
          {ads.length === 0 && (
            <div className="muted small" style={{ padding: '18px 0' }}>
              No creatives yet. Add one from a public URL or a file on the API host — duration and dimensions are probed automatically.
            </div>
          )}
          {ads.map((ad) => (
            <div key={ad.id} className="adrow">
              <AdThumb ad={ad} />
              <div className="adrow__body">
                <div className="adrow__name">
                  <span className="truncate">{ad.name}</span>
                  {assignedIds?.has(ad.id) && (
                    <StatusPill status="assigned" tone="violet" dot={false}>
                      assigned
                    </StatusPill>
                  )}
                </div>
                <div className="adrow__meta">
                  {ad.advertiser && <span>{ad.advertiser}</span>}
                  <span className="mono">{mmss(ad.durationSec)}</span>
                  {ad.width && ad.height ? <span className="mono">{ad.width}×{ad.height}</span> : <span className="muted">size unknown</span>}
                  <span className="truncate muted" title={ad.localPath ?? ad.sourceUrl} style={{ maxWidth: 260 }}>
                    {ad.localPath ? `file · ${ad.localPath}` : ad.sourceUrl}
                  </span>
                </div>
                {ad.fingerprint ? (
                  <div className="adrow__fp">
                    <div className="row row--wrap" style={{ gap: 4 }}>
                      {sortedLabels(ad.fingerprint.mood)
                        .slice(0, expanded === ad.id ? 6 : 3)
                        .map(([l, p]) => (
                          <TagChip key={l} label={l} score={p} tone="violet" />
                        ))}
                      {sortedLabels(ad.fingerprint.keywords)
                        .slice(0, expanded === ad.id ? 8 : 3)
                        .map(([l, p]) => (
                          <TagChip key={l} label={l} score={p} />
                        ))}
                      <TagChip label={ad.fingerprint.familySafe >= 0.7 ? 'family-safe' : 'not family-safe'} score={ad.fingerprint.familySafe} tone={ad.fingerprint.familySafe >= 0.7 ? 'green' : 'red'} />
                      {ad.fingerprint.sensitivities.map((x) => (
                        <TagChip key={x.category} label={`${x.category} · ${x.severity}`} score={x.confidence} tone="red" />
                      ))}
                      <button className="linkish small" onClick={() => setExpanded(expanded === ad.id ? null : ad.id)}>
                        {expanded === ad.id ? 'less' : 'more'}
                      </button>
                    </div>
                    {expanded === ad.id && (
                      <div className="small" style={{ color: 'var(--body)', lineHeight: 1.5 }}>
                        <div>
                          <b style={{ color: 'var(--heading)' }}>{ad.fingerprint.brand}</b> · {ad.fingerprint.product}
                          {ad.fingerprint.tagline ? <span className="muted"> · "{ad.fingerprint.tagline}"</span> : null}
                        </div>
                        <div>{ad.fingerprint.synopsis}</div>
                        <div className="row row--wrap" style={{ gap: 4, marginTop: 4 }}>
                          {ad.fingerprint.iab.map((i) => (
                            <TagChip key={i.id} label={`${i.name} · ${i.id}`} score={i.confidence} />
                          ))}
                          {Object.entries(ad.fingerprint.tone).map(([k, v]) => (
                            <TagChip key={k} label={`tone ${k}`} score={v} />
                          ))}
                        </div>
                        <div className="muted" style={{ marginTop: 4 }}>
                          {ad.fingerprint.moments.map((m) => `${mmss(m.at)} ${m.label}`).join(' · ')} · {ad.fingerprint.model}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="adrow__fp muted small">Not fingerprinted yet: no fit scores until Pegasus has seen it.</div>
                )}
              </div>
              <Button
                size="sm"
                variant={ad.fingerprint ? 'ghost' : 'ai'}
                icon="sparkle"
                loading={fingerprinting === ad.id}
                title={ad.fingerprint ? 'Re-run creative intelligence (one Pegasus call)' : 'Creative intelligence: brand, mood, keywords, IAB, sensitivities (one Pegasus call)'}
                onClick={() => void fingerprint(ad)}
              >
                {ad.fingerprint ? 'Re-fingerprint' : 'Fingerprint'}
              </Button>
              {confirmId === ad.id ? (
                <span className="row" style={{ gap: 6 }}>
                  <span className="small" style={{ color: 'var(--heading)' }}>
                    Delete?
                  </span>
                  <Button size="sm" variant="danger" loading={deleting === ad.id} onClick={() => void remove(ad)}>
                    Yes
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setConfirmId(null)}>
                    No
                  </Button>
                </span>
              ) : (
                <Button size="sm" variant="ghost" icon="trash" aria-label={`Delete ${ad.name}`} title="Delete creative" onClick={() => setConfirmId(ad.id)} />
              )}
            </div>
          ))}
        </div>

        <div className="adlib__form">
          <div className="section__title">
            <span>Add creative</span>
          </div>
          <Tabs<Source>
            full
            tabs={[
              { id: 'url', label: 'URL' },
              { id: 'path', label: 'Local path' },
            ]}
            value={source}
            onChange={setSource}
          />
          <div className="field">
            <label htmlFor="ad-name">Name</label>
            <input id="ad-name" className="input" placeholder="Kinder Bueno 30s" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="ad-advertiser">Advertiser (optional)</label>
            <input id="ad-advertiser" className="input" placeholder="Ferrero" value={advertiser} onChange={(e) => setAdvertiser(e.target.value)} />
          </div>
          {source === 'url' ? (
            <div className="field">
              <label htmlFor="ad-url">Public MP4 URL</label>
              <input id="ad-url" className="input" placeholder="https://cdn.example.com/spots/bueno-30.mp4" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && void add()} />
            </div>
          ) : (
            <div className="field">
              <label htmlFor="ad-path">Absolute path on the API host</label>
              <input id="ad-path" className="input mono" placeholder="/Volumes/ads/bueno-30.mp4" value={path} onChange={(e) => setPath(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && void add()} />
              <span className="muted small">Served back to the player as /api/ads/:id/media with Range support; ffprobe fills in duration and size.</span>
            </div>
          )}
          <Button variant="primary" icon="plus" loading={busy} disabled={!canAdd} onClick={() => void add()}>
            Add creative
          </Button>
        </div>
      </div>
    </Modal>
  );
}
