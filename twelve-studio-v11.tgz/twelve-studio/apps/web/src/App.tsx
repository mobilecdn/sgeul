import sgeulMark from './assets/sgeul-mark-mono.png';
import sgeulFooter from './assets/sgeul-footer.jpg';
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { BrowserRouter, HashRouter, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import { Icon, type IconName } from './components/Icon';
import { ToastProvider } from './components/ui';
import { ApiContext, useHealth } from './lib/hooks';
import { getApi, isStaticMode } from './lib/api';
import { Overview } from './pages/Overview';
import { Editorial } from './pages/Editorial';
import { Creative } from './pages/Creative';
import { Operations } from './pages/Operations';
import { Discovery } from './pages/Discovery';
import { Recommend } from './pages/Recommend';
import { ApiDocs } from './pages/ApiDocs';
import { Settings } from './pages/Settings';

const NAV: Array<{ to: string; label: string; icon: IconName; sub?: string }> = [
  { to: '/', label: 'Overview', icon: 'overview', sub: 'Catalog health, pipeline and spend' },
  { to: '/editorial', label: 'Editorial Lab', icon: 'editorial', sub: 'Fingerprints, smart lists, AI curation' },
  { to: '/creative', label: 'Creative Lab', icon: 'creative', sub: 'Thumbnails and preview clips from a brief' },
  { to: '/operations', label: 'Operations Lab', icon: 'operations', sub: 'Markers, ad breaks, safety — review & export' },
  { to: '/discovery', label: 'Discovery', icon: 'discovery', sub: 'Search moments, similar titles, arc compare' },
  { to: '/recommend', label: 'Recommendations', icon: 'layers', sub: 'Taste profiles, weighted rows, up next' },
  { to: '/api-docs', label: 'API', icon: 'api', sub: 'REST + MCP surface' },
  { to: '/settings', label: 'Settings', icon: 'settings', sub: 'Keys, models, pricing' },
];

/* Top bar actions are owned by pages. */
const TopbarContext = createContext<{ setActions: (n: ReactNode) => void; setTitle: (n: ReactNode | null) => void }>({ setActions: () => undefined, setTitle: () => undefined });

export function useTopbar(actions: ReactNode, deps: unknown[] = []) {
  const { setActions } = useContext(TopbarContext);
  useEffect(() => {
    setActions(actions);
    return () => setActions(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}

function ModePill() {
  const h = useHealth();
  const mode = h?.mode ?? (isStaticMode() ? 'static' : undefined);
  const label = !h ? 'connecting…' : h.ok === false ? 'API offline' : `mode: ${mode}`;
  const cls = h?.ok === false ? 'modepill' : `modepill modepill--${mode ?? 'mock'}`;
  return (
    <span className={cls} title={h?.index ? `Index ${h.index}` : undefined}>
      <span className="modepill__dot" />
      {label}
    </span>
  );
}

function Shell() {
  const loc = useLocation();
  const [actions, setActions] = useState<ReactNode>(null);
  const [title, setTitle] = useState<ReactNode | null>(null);
  const current = NAV.find((n) => (n.to === '/' ? loc.pathname === '/' : loc.pathname.startsWith(n.to))) ?? NAV[0]!;
  const ctx = useMemo(() => ({ setActions, setTitle }), []);
  useEffect(() => {
    document.title = `${current.label} · SGEUL`;
  }, [current]);
  return (
    <TopbarContext.Provider value={ctx}>
      <div className="shell">
        <nav className="rail" aria-label="Primary">
          <div className="rail__logo" title="SGEUL · Story AI">
            <img src={sgeulMark} alt="SGEUL" />
          </div>
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.to === '/'} className={({ isActive }) => `rail__item${isActive ? ' is-active' : ''}`} aria-label={n.label}>
              <Icon name={n.icon} size={19} />
              <span className="tooltip">{n.label}</span>
            </NavLink>
          ))}
          <div className="rail__spacer" />
          <a className="rail__item" href="https://docs.twelvelabs.io" target="_blank" rel="noreferrer" aria-label="TwelveLabs docs">
            <Icon name="external" size={17} />
            <span className="tooltip">TwelveLabs docs</span>
          </a>
        </nav>
        <div className="main">
          <header className="topbar">
            <div className="topbar__title">
              {title ?? current.label}
              {!title && current.sub && <small>{current.sub}</small>}
            </div>
            <div className="topbar__actions">
              {actions}
              <ModePill />
            </div>
          </header>
          <Routes>
            <Route path="/" element={<Overview />} />
            <Route path="/editorial/*" element={<Editorial />} />
            <Route path="/creative" element={<Creative />} />
            <Route path="/operations" element={<Operations />} />
            <Route path="/discovery" element={<Discovery />} />
            <Route path="/recommend" element={<Recommend />} />
            <Route path="/api-docs" element={<ApiDocs />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<Overview />} />
          </Routes>
          <footer className="foot">
            <img className="foot__brand" src={sgeulFooter} alt="SGEUL · Story AI" />
            <div className="foot__text">
              <strong>SGEUL</strong> Story AI · media intelligence built on TwelveLabs Marengo + Pegasus
            </div>
            <div className="foot__meta">Editorial · Creative · Operations · Discovery · API · MCP</div>
          </footer>
        </div>
      </div>
    </TopbarContext.Provider>
  );
}

export default function App() {
  const api = useMemo(() => getApi(), []);
  // The single-file demo is opened from disk / any host: hash routing keeps deep links working.
  const Router = isStaticMode() && (location.protocol === 'file:' || import.meta.env.MODE === 'single') ? HashRouter : BrowserRouter;
  return (
    <ApiContext.Provider value={api}>
      <ToastProvider>
        <Router>
          <Shell />
        </Router>
      </ToastProvider>
    </ApiContext.Provider>
  );
}
