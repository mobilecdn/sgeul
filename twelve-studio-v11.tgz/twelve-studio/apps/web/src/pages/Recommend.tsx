/**
 * Recommendations — the viewer-facing engine, with every weight exposed.
 *
 * Left: a viewer to play with (what they watched, liked, skipped) and the taste
 * profile that falls out of it. Right: the rows a player would render, and what
 * plays next after the title that is on. Every dial re-scores the catalog live
 * through `POST /reco/simulate`, so an editor can see what a weighting does
 * before saving it as the app's own.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CatalogItem, RecoWeights, Recommendation, RecoRail } from '@twelve-studio/core';
import { Button, Card, EmptyState, ErrorNote, Meter, Skeleton, StatusPill, Tabs } from '../components/ui';
import { TagChip } from '../components/TagChip';
import { PosterArt } from '../components/Poster';
import { Icon } from '../components/Icon';
import { useApi, useQuery, useToast } from '../lib/hooks';
import type { ViewerProfile } from '../lib/api';
import { duration, pct } from '../lib/format';
import { useTopbar } from '../App';

type SimAction = 'watch' | 'like' | 'skip';
interface SimEvent {
  key: string;
  itemId: string;
  action: SimAction;
  completion: number;
}

const ACTION_LABEL: Record<SimAction, string> = { watch: 'watched', like: 'liked', skip: 'skipped' };

/** One weight dial. */
function Dial({
  label,
  hint,
  value,
  min = 0,
  max = 3,
  step = 0.05,
  format = (v: number) => v.toFixed(2),
  onChange,
}: {
  label: string;
  hint?: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  format?: (v: number) => string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="dial" title={hint}>
      <span className="dial__label">
        {label}
        <b className="mono">{format(value)}</b>
      </span>
      <input className="dial__input" type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
      {hint && <span className="dial__hint">{hint}</span>}
    </label>
  );
}

function ScoreCard({ rec, item, onPlay }: { rec: Recommendation; item?: CatalogItem; onPlay?: () => void }) {
  return (
    <div className="recocard" onClick={onPlay} role={onPlay ? 'button' : undefined}>
      <div className="recocard__art">
        {item ? <PosterArt item={item} /> : <div className="recocard__blank" />}
        <span className="recocard__score mono">{Math.round(Math.max(0, rec.score) * 100)}</span>
      </div>
      <div className="recocard__body">
        <div className="recocard__title" title={rec.title}>
          {rec.title}
        </div>
        <div className="recocard__because">
          {rec.because.slice(0, 3).map((b) => (
            <span key={b} className="recocard__reason" title={b}>
              {b}
            </span>
          ))}
          {rec.because.length === 0 && <span className="recocard__reason">new to this viewer</span>}
        </div>
        <div className="recocard__parts">
          {(
            [
              ['combo', rec.parts.combo, 'var(--violet)'],
              ['genre', rec.parts.genres, 'var(--blue)'],
              ['mood', rec.parts.moodTags, 'var(--green)'],
              ['vector', rec.parts.embedding, 'var(--info)'],
            ] as Array<[string, number, string]>
          ).map(([name, v, color]) => (
            <span key={name} className="recocard__part" title={`${name} match ${pct(v)}`}>
              <i style={{ width: `${Math.round(Math.max(0, v) * 100)}%`, background: color }} />
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function Rail({ rail, items, onPlay }: { rail: RecoRail; items: Map<string, CatalogItem>; onPlay: (id: string) => void }) {
  return (
    <div className="stack" style={{ gap: 8 }}>
      <div className="row row--between" style={{ alignItems: 'baseline' }}>
        <h3 style={{ fontSize: 15, margin: 0 }}>
          {rail.title}
          <span className="muted small" style={{ marginLeft: 8, fontWeight: 400 }}>
            {rail.reason}
          </span>
        </h3>
        <StatusPill status={rail.kind} tone={rail.kind === 'combo' ? 'violet' : rail.kind === 'next' ? 'blue' : 'neutral'} dot={false} />
      </div>
      <div className="recorail">
        {rail.items.map((rec) => (
          <ScoreCard key={rec.itemId} rec={rec} item={items.get(rec.itemId)} onPlay={() => onPlay(rec.itemId)} />
        ))}
      </div>
    </div>
  );
}

export function Recommend() {
  const api = useApi();
  const toast = useToast();
  const catalog = useQuery(() => api.catalog(), []);
  const saved = useQuery(() => api.recoWeights(), []);
  const viewers = useQuery(() => api.viewers(), []);

  const [weights, setWeights] = useState<RecoWeights | null>(null);
  const [events, setEvents] = useState<SimEvent[]>([]);
  const [seedId, setSeedId] = useState<string | null>(null);
  const [rails, setRails] = useState<RecoRail[]>([]);
  const [next, setNext] = useState<Recommendation[]>([]);
  const [profile, setProfile] = useState<ViewerProfile | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<Error | null>(null);
  const [mode, setMode] = useState<'sim' | 'saved'>('sim');
  const [profileId, setProfileId] = useState('viewer-1');
  const [completion, setCompletion] = useState(1);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (saved.data && !weights) setWeights(saved.data.weights);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saved.data]);

  const ready = useMemo(() => (catalog.data ?? []).filter((i) => i.fingerprint || i.status === 'ready'), [catalog.data]);
  const items = useMemo(() => new Map((catalog.data ?? []).map((i) => [i.id, i])), [catalog.data]);

  const score = useCallback(async () => {
    if (!weights) return;
    setBusy(true);
    setErr(null);
    try {
      if (mode === 'saved') {
        const home = await api.recoHome(profileId, { seedId: seedId ?? undefined, limit: 12 });
        const upNext = seedId ? await api.upNext(seedId, { profileId, limit: 12 }) : undefined;
        setRails(home.rails);
        setNext(upNext?.items ?? []);
        setProfile({ profileId, ...home.profile } as ViewerProfile);
      } else {
        const sim = await api.simulateReco({
          profileId: 'simulated',
          events: events.map((e) => ({ itemId: e.itemId, action: e.action, completion: e.action === 'watch' ? e.completion : undefined })),
          weights,
          seedId: seedId ?? undefined,
          limit: 12,
        });
        setRails(sim.rails);
        setNext(sim.next);
        setProfile(sim.profile);
      }
    } catch (e) {
      setErr(e as Error);
    } finally {
      setBusy(false);
    }
  }, [api, events, weights, seedId, mode, profileId]);

  // Every change re-scores, debounced so dragging a dial stays smooth.
  useEffect(() => {
    if (!weights) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => void score(), 220);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [events, weights, seedId, mode, profileId]);

  useTopbar(
    <div className="row" style={{ gap: 8 }}>
      {busy && <span className="muted small">scoring…</span>}
      <span className="mono muted" style={{ fontSize: 11 }}>
        {mode === 'sim' ? 'POST /reco/simulate' : 'GET /reco/home'}
      </span>
    </div>,
    [busy, mode],
  );

  const add = (itemId: string, action: SimAction) => {
    setEvents((cur) => [...cur, { key: `${itemId}_${action}_${cur.length}`, itemId, action, completion: action === 'watch' ? completion : 1 }]);
    if (action === 'watch') setSeedId(itemId);
    if (mode === 'saved') void persist(itemId, action);
  };

  const persist = async (itemId: string, action: SimAction) => {
    try {
      await api.recordWatch([{ itemId, action, completion: action === 'watch' ? completion : undefined }], profileId);
      viewers.refetch();
    } catch (e) {
      setErr(e as Error);
    }
  };

  const setW = (patch: Partial<RecoWeights>) => setWeights((cur) => (cur ? { ...cur, ...patch } : cur));
  const setFacet = (facet: keyof RecoWeights['facets'], v: number) =>
    setWeights((cur) => (cur ? { ...cur, facets: { ...cur.facets, [facet]: v } } : cur));

  const saveWeights = async () => {
    if (!weights) return;
    try {
      const res = await api.saveRecoWeights(weights);
      setWeights(res.weights);
      saved.refetch();
      toast.push('Weighting saved — every player request now uses it', 'success');
    } catch (e) {
      setErr(e as Error);
    }
  };

  const resetWeights = async () => {
    try {
      const res = await api.resetRecoWeights();
      setWeights(res.weights);
      saved.refetch();
      toast.push('Back to the engine defaults', 'info');
    } catch (e) {
      setErr(e as Error);
    }
  };

  const seed = seedId ? items.get(seedId) : undefined;
  // The "Because you watched" row is already the Up next card above it.
  const rows = useMemo(() => rails.filter((r) => r.kind !== 'next' || next.length === 0), [rails, next]);

  return (
    <div className="content">
      <div className="stack stack--lg" style={{ maxWidth: 1600 }}>
        <div className="row row--between row--wrap" style={{ gap: 12 }}>
          <Tabs
            tabs={[
              { id: 'sim', label: 'Simulated viewer' },
              { id: 'saved', label: 'Saved viewer' },
            ]}
            value={mode}
            onChange={(v) => setMode(v as 'sim' | 'saved')}
          />
          {mode === 'saved' && (
            <div className="row" style={{ gap: 8 }}>
              <select className="select select--sm" value={profileId} onChange={(e) => setProfileId(e.target.value)}>
                {(viewers.data ?? [{ profileId: 'viewer-1', events: 0 }]).map((v) => (
                  <option key={v.profileId} value={v.profileId}>
                    {v.profileId} · {v.events} events
                  </option>
                ))}
              </select>
              <Button
                size="sm"
                variant="ghost"
                icon="trash"
                onClick={async () => {
                  await api.forgetViewer(profileId);
                  viewers.refetch();
                  void score();
                  toast.push(`Forgot everything about ${profileId}`, 'info');
                }}
              >
                Forget viewer
              </Button>
            </div>
          )}
        </div>

        <ErrorNote error={err} />

        <div className="reco">
          {/* ---------------- left: the viewer ---------------- */}
          <div className="stack">
            <Card
              title="What they watched"
              icon="play"
              sub={mode === 'sim' ? 'Click a title to build a history — nothing is stored' : `Recorded against ${profileId}`}
              actions={
                events.length > 0 ? (
                  <Button size="sm" variant="ghost" icon="x" onClick={() => setEvents([])}>
                    Clear
                  </Button>
                ) : undefined
              }
            >
              <div className="stack" style={{ gap: 10 }}>
                <Dial label="Completion of a play" value={completion} min={0.05} max={1} step={0.05} format={(v) => pct(v)} onChange={setCompletion} hint="How much of the title the viewer got through" />
                <div className="recolist">
                  {catalog.loading && Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} h={34} />)}
                  {ready.map((item) => (
                    <div key={item.id} className={`recolist__row${seedId === item.id ? ' is-seed' : ''}`}>
                      <button className="recolist__name" onClick={() => setSeedId(item.id)} title="Treat as the title now playing">
                        {item.title}
                        <span className="muted small">{duration(item.durationSec)}</span>
                      </button>
                      <div className="row" style={{ gap: 4 }}>
                        <button className="iconbtn" title="Watched" onClick={() => add(item.id, 'watch')}>
                          <Icon name="play" size={12} />
                        </button>
                        <button className="iconbtn" title="Liked" onClick={() => add(item.id, 'like')}>
                          <Icon name="check" size={12} />
                        </button>
                        <button className="iconbtn" title="Skipped" onClick={() => add(item.id, 'skip')}>
                          <Icon name="x" size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                {events.length > 0 && (
                  <div className="row row--wrap" style={{ gap: 6 }}>
                    {events.map((e, i) => (
                      <TagChip
                        key={e.key}
                        label={`${items.get(e.itemId)?.title ?? e.itemId} · ${ACTION_LABEL[e.action]}${e.action === 'watch' ? ` ${pct(e.completion)}` : ''}`}
                        tone={e.action === 'skip' ? 'red' : e.action === 'like' ? 'green' : 'active'}
                        onRemove={() => setEvents((cur) => cur.filter((_, j) => j !== i))}
                      />
                    ))}
                  </div>
                )}
              </div>
            </Card>

            <Card title="Taste profile" icon="sparkle" sub={profile ? `${profile.events} events · the labels the engine learned` : 'Add a watch to see the profile'}>
              {!profile || profile.top.length === 0 ? (
                <EmptyState icon="info" title="No signal yet" text="Watch a couple of titles on the left and the profile appears here." />
              ) : (
                <div className="stack" style={{ gap: 12 }}>
                  {profile.topCombos.length > 0 && (
                    <div className="stack" style={{ gap: 6 }}>
                      <span className="eyebrow">Combinations</span>
                      <div className="row row--wrap" style={{ gap: 6 }}>
                        {profile.topCombos.slice(0, 4).map((c) => (
                          <TagChip key={c.label} label={c.label} score={c.weight} tone="violet" />
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="stack" style={{ gap: 6 }}>
                    <span className="eyebrow">Labels</span>
                    <div className="row row--wrap" style={{ gap: 6 }}>
                      {profile.top.slice(0, 10).map((t) => (
                        <TagChip key={`${t.facet}_${t.label}`} label={t.label} score={t.weight} title={`${t.label} · ${t.facet}`} />
                      ))}
                    </div>
                  </div>
                  {(profile.pacing !== undefined || profile.rating !== undefined) && (
                    <div className="row" style={{ gap: 16 }}>
                      {profile.pacing !== undefined && (
                        <div style={{ flex: 1 }}>
                          <span className="eyebrow">Pacing</span>
                          <Meter value={profile.pacing} />
                        </div>
                      )}
                      {profile.rating !== undefined && (
                        <div style={{ flex: 1 }}>
                          <span className="eyebrow">Maturity</span>
                          <Meter value={profile.rating} color="var(--orange)" />
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </Card>

            <Card
              title="Weighting"
              icon="settings"
              sub={saved.data?.custom ? 'The app is running a custom weighting' : 'Running the engine defaults'}
              actions={
                <>
                  <Button size="sm" variant="ghost" icon="refresh" onClick={() => void resetWeights()}>
                    Defaults
                  </Button>
                  <Button size="sm" variant="primary" icon="check" onClick={() => void saveWeights()}>
                    Save
                  </Button>
                </>
              }
            >
              {!weights ? (
                <Skeleton h={300} />
              ) : (
                <div className="stack" style={{ gap: 10 }}>
                  <span className="eyebrow">Combination and facets</span>
                  <Dial label="Combination bonus" value={weights.combo} onChange={(v) => setW({ combo: v })} hint="Romantic horror scored as its own taste, not two genres" />
                  <Dial label="Genres" value={weights.facets.genres} onChange={(v) => setFacet('genres', v)} />
                  <Dial label="Mood tags" value={weights.facets.moodTags} onChange={(v) => setFacet('moodTags', v)} />
                  <Dial label="Moods" value={weights.facets.moods} onChange={(v) => setFacet('moods', v)} />
                  <Dial label="Themes" value={weights.facets.themes} onChange={(v) => setFacet('themes', v)} />
                  <Dial label="Keywords" value={weights.facets.keywords} onChange={(v) => setFacet('keywords', v)} />
                  <span className="eyebrow">Signals</span>
                  <Dial label="Marengo embedding" value={weights.embedding} onChange={(v) => setW({ embedding: v })} hint="How much the raw video similarity counts" />
                  <Dial label="Title now playing" value={weights.seed} onChange={(v) => setW({ seed: v })} hint="Up next: what is on versus the long-run profile" />
                  <Dial label="Pacing" value={weights.pacing} onChange={(v) => setW({ pacing: v })} />
                  <Dial label="Audience rating" value={weights.rating} onChange={(v) => setW({ rating: v })} />
                  <Dial label="Popularity" value={weights.popularity} onChange={(v) => setW({ popularity: v })} />
                  <span className="eyebrow">Behaviour</span>
                  <Dial label="Variety in a row" value={weights.diversity} max={1} onChange={(v) => setW({ diversity: v })} hint="0 = pure relevance, 1 = maximum spread" />
                  <Dial label="Repeat penalty" value={weights.repeatPenalty} max={1} onChange={(v) => setW({ repeatPenalty: v })} />
                  <Dial label="Like boost" value={weights.likeBoost} max={5} onChange={(v) => setW({ likeBoost: v })} />
                  <Dial label="Dislike weight" value={weights.dislikePenalty} max={5} onChange={(v) => setW({ dislikePenalty: v })} />
                  <Dial
                    label="Recency half-life"
                    value={weights.recencyHalfLifeDays}
                    min={1}
                    max={365}
                    step={1}
                    format={(v) => `${Math.round(v)} d`}
                    onChange={(v) => setW({ recencyHalfLifeDays: v })}
                    hint="How fast an old watch stops counting"
                  />
                  <Dial label="Minimum score" value={weights.minScore} max={1} step={0.01} onChange={(v) => setW({ minScore: v })} />
                </div>
              )}
            </Card>
          </div>

          {/* ---------------- right: what the viewer sees ---------------- */}
          <div className="stack stack--lg">
            <Card
              title={seed ? `Up next after ${seed.title}` : 'Up next'}
              icon="layers"
              sub={seed ? 'GET /catalog/:id/recommendations — seed similarity blended with the profile' : 'Pick a title on the left to treat as the one now playing'}
              flush={false}
            >
              {next.length > 0 ? (
                <div className="recorail">
                  {next.map((rec) => (
                    <ScoreCard key={rec.itemId} rec={rec} item={items.get(rec.itemId)} onPlay={() => setSeedId(rec.itemId)} />
                  ))}
                </div>
              ) : (
                <EmptyState icon="play" title="Nothing playing" text="Choose the title now playing on the left, or press play on a title to watch it." />
              )}
            </Card>

            {rows.length > 0 ? (
              <div className="stack stack--lg">
                {rows.map((rail) => (
                  <Rail key={rail.id} rail={rail} items={items} onPlay={(id) => setSeedId(id)} />
                ))}
              </div>
            ) : (
              <EmptyState
                icon="discovery"
                title="No rows yet"
                text="Watch something on the left. The engine builds rows from what the viewer watches: the combination first, then each taste it is made of."
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Recommend;
