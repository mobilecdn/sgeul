import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import type { CatalogItem, EmotionArc, SearchHit, SearchResponse, SimilarTitle } from '@twelve-studio/core';
import { Button, Card, EmptyState, ErrorNote, Meter, Modal, Skeleton, StatusPill } from '../components/ui';
import { FrameThumb } from '../components/FrameThumb';
import { Player } from '../components/Player';
import { Icon } from '../components/Icon';
import { TagChip } from '../components/TagChip';
import { Timecode, TimecodeRange } from '../components/Timecode';
import { EmotionArcChart, ArcLegend } from '../components/EmotionArcChart';
import { PosterArt } from '../components/Poster';
import { useApi, useQuery, useToast } from '../lib/hooks';
import type { Modality } from '../lib/api';
import { duration, hours } from '../lib/format';
import { playableSrc } from '../lib/media';
import { useTopbar } from '../App';

const SUGGESTIONS = ['a tense standoff at night', 'someone crying alone', 'crowd celebrating', 'car chase through the city', 'quiet conversation by the sea', 'a dragon'];

export function Discovery() {
  const api = useApi();
  const toast = useToast();
  const catalog = useQuery(() => api.catalog(), []);
  const [q, setQ] = useState('');
  const [mods, setMods] = useState<Modality[]>(['visual', 'audio', 'transcription']);
  const [res, setRes] = useState<SearchResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<Error | null>(null);
  const [open, setOpen] = useState<SearchHit | null>(null);
  const items = useMemo(() => new Map((catalog.data ?? []).map((i) => [i.id, i])), [catalog.data]);
  const [simId, setSimId] = useState<string | null>(null);
  const [cmpA, setCmpA] = useState<string | null>(null);
  const [cmpB, setCmpB] = useState<string | null>(null);

  useEffect(() => {
    const ready = (catalog.data ?? []).filter((i) => i.status === 'ready');
    if (!simId && ready[0]) setSimId(ready[0].id);
    if (!cmpA && ready[0]) setCmpA(ready[0].id);
    if (!cmpB && ready[1]) setCmpB(ready[1].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catalog.data]);

  useTopbar(
    <span className="muted small">
      {catalog.data ? `${catalog.data.length} titles · ${hours(catalog.data.reduce((s, i) => s + (i.durationSec ?? 0), 0)).toFixed(1)} h indexed` : ''}
    </span>,
    [catalog.data],
  );

  const search = async (query = q) => {
    if (!query.trim()) return;
    setBusy(true);
    setErr(null);
    try {
      const r = await api.search({ query, modalities: mods, limit: 12 });
      setRes(r);
      if (!r.hits.length) toast.push('No moments matched — try a broader description', 'info');
    } catch (e) {
      setErr(e as Error);
    } finally {
      setBusy(false);
    }
  };

  const toggleMod = (m: Modality) => setMods((cur) => (cur.includes(m) ? (cur.length > 1 ? cur.filter((x) => x !== m) : cur) : [...cur, m]));

  return (
    <div className="content">
      <div className="stack stack--lg" style={{ maxWidth: 1400 }}>
        <div className="stack">
          <form
            className="hero-search"
            onSubmit={(e) => {
              e.preventDefault();
              void search();
            }}
          >
            <Icon name="search" size={20} />
            <input className="input" placeholder="Find moments across your catalog…" value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
            <Button variant="primary" type="submit" loading={busy} icon="search">
              Search
            </Button>
          </form>
          <div className="row row--wrap" style={{ gap: 8 }}>
            <span className="muted small">Modalities</span>
            {(['visual', 'audio', 'transcription'] as Modality[]).map((m) => (
              <TagChip key={m} label={m} tone={mods.includes(m) ? 'active' : 'default'} onClick={() => toggleMod(m)} />
            ))}
            <span style={{ width: 10 }} />
            <span className="muted small">Try</span>
            {SUGGESTIONS.map((s) => (
              <TagChip
                key={s}
                label={s}
                onClick={() => {
                  setQ(s);
                  void search(s);
                }}
              />
            ))}
            <span className="mono muted" style={{ marginLeft: 'auto', fontSize: 11 }}>
              POST /search · marengo3.0 · group_by=clip
            </span>
          </div>
        </div>

        <ErrorNote error={err} />
        {busy && (
          <div className="hits">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} h={230} style={{ borderRadius: 16 }} />
            ))}
          </div>
        )}
        {!busy && res && (
          <Card
            title={`${res.hits.length} moments`}
            sub={`for “${res.query}” across ${res.pool.items} titles · ${duration(res.pool.totalDurationSec)} of video`}
            actions={res.nextPageToken ? <Button variant="ghost" size="sm">More results</Button> : undefined}
          >
            {res.hits.length === 0 ? (
              <EmptyState icon="search" title="No moments found" text="Marengo searches what is seen, heard and said. Try describing the scene differently." />
            ) : (
              <div className="hits">
                {res.hits.map((h) => {
                  const it = items.get(h.itemId);
                  return (
                    <div key={`${h.itemId}-${h.start}`} className="hit" onClick={() => setOpen(h)}>
                      <div className="hit__art">
                        <FrameThumb url={playableSrc(it)} at={h.start} image={h.thumbnailUrl} poster={it?.posterUrl} fps={it?.fps} seed={h.itemId} center style={{ position: 'absolute', inset: 0 }} />
                        <span className="hit__rank">{h.rank}</span>
                        {h.score != null && (
                          <span className="hit__score" title="relevance">
                            {h.score.toFixed(2)}
                          </span>
                        )}
                        {h.modality && (
                          <span style={{ position: 'absolute', bottom: 8, right: 8 }}>
                            <StatusPill status={h.modality} tone="neutral" dot={false} />
                          </span>
                        )}
                      </div>
                      <div className="hit__body">
                        <div className="hit__title">{h.title}</div>
                        <div style={{ marginTop: 3 }}>
                          <TimecodeRange start={h.start} end={h.end} fps={it?.fps ?? 25} muted />
                        </div>
                        {h.transcript && <div className="hit__snip">“{h.transcript}”</div>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        )}
        {!busy && !res && (
          <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
            <Card soft icon="eye" title="Visual">
              <p className="small muted">Objects, actions, settings, on-screen text. “a red car crashing through a fence”.</p>
            </Card>
            <Card soft icon="volume" title="Audio">
              <p className="small muted">Music, ambience, sound events. “thunder rolling over a quiet street”.</p>
            </Card>
            <Card soft icon="message" title="Transcription">
              <p className="small muted">What is said. “someone promising to come back”.</p>
            </Card>
          </div>
        )}

        <div className="grid" style={{ gridTemplateColumns: '1fr 1.3fr' }}>
          <SimilarPanel items={catalog.data ?? []} id={simId} onPick={setSimId} onCompare={(a, b) => { setCmpA(a); setCmpB(b); }} />
          <ComparePanel items={catalog.data ?? []} a={cmpA} b={cmpB} onA={setCmpA} onB={setCmpB} />
        </div>
      </div>

      <Modal open={!!open} onClose={() => setOpen(null)} title={open ? `${open.title} · rank ${open.rank}` : ''} wide>
        {open && (
          <>
            <Player
              src={playableSrc(items.get(open.itemId))}
              originUrl={items.get(open.itemId)?.sourceUrl}
              poster={open.thumbnailUrl ?? items.get(open.itemId)?.posterUrl}
              durationSec={items.get(open.itemId)?.durationSec}
              fps={items.get(open.itemId)?.fps}
              initialTime={open.start}
              range={{ start: open.start, end: open.end }}
              title={open.title}
              autoPlay
            />
            <div className="row row--between">
              <TimecodeRange start={open.start} end={open.end} fps={items.get(open.itemId)?.fps ?? 25} />
              <div className="row">
                <Link to={`/operations?item=${open.itemId}`}>
                  <Button variant="ghost" size="sm" icon="operations">
                    Open in Operations
                  </Button>
                </Link>
                <Link to={`/editorial?item=${open.itemId}`}>
                  <Button variant="ghost" size="sm" icon="editorial">
                    Inspect title
                  </Button>
                </Link>
              </div>
            </div>
            {open.transcript && <p style={{ color: 'var(--heading)' }}>“{open.transcript}”</p>}
          </>
        )}
      </Modal>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Similar titles                                                      */
/* ------------------------------------------------------------------ */
function SimilarPanel({ items, id, onPick, onCompare }: { items: CatalogItem[]; id: string | null; onPick: (id: string) => void; onCompare: (a: string, b: string) => void }) {
  const api = useApi();
  const sim = useQuery(() => (id ? api.similar(id, 8) : Promise.resolve([] as SimilarTitle[])), [id], { enabled: !!id });
  const anchor = items.find((i) => i.id === id);
  return (
    <Card
      title="Similar titles"
      icon="compare"
      sub="Marengo 3.5 embedding cosine, explained by shared fingerprint facets"
      actions={
        <select className="select select--sm" value={id ?? ''} onChange={(e) => onPick(e.target.value)} style={{ width: 200 }}>
          {items.map((i) => (
            <option key={i.id} value={i.id}>
              {i.title}
            </option>
          ))}
        </select>
      }
    >
      {anchor && (
        <div className="row" style={{ gap: 12, marginBottom: 14 }}>
          <div style={{ width: 44, height: 64, borderRadius: 8, overflow: 'hidden', flex: '0 0 44px' }}>
            <PosterArt item={anchor} showFrame={false} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </div>
          <div style={{ minWidth: 0 }}>
            <div style={{ color: 'var(--heading)', fontWeight: 600 }}>{anchor.title}</div>
            <div className="small muted truncate">{anchor.fingerprint?.synopsis.short}</div>
          </div>
        </div>
      )}
      {sim.loading && (
        <div className="stack">
          <Skeleton h={40} />
          <Skeleton h={40} />
          <Skeleton h={40} />
        </div>
      )}
      <ErrorNote error={sim.error} />
      {!sim.loading && sim.data?.length === 0 && <span className="muted small">Add more titles to see neighbours.</span>}
      {sim.data?.map((s) => (
        <div key={s.itemId} className="simrow">
          <div style={{ minWidth: 0 }}>
            <button className="link" style={{ color: 'var(--heading)', fontWeight: 600 }} onClick={() => onPick(s.itemId)}>
              {s.title}
            </button>
            <div className="chiprow" style={{ marginTop: 4 }}>
              {s.because.slice(0, 4).map((b) => (
                <span key={b} className="pill pill--neutral">
                  {b}
                </span>
              ))}
            </div>
          </div>
          <Meter value={s.score} color="#8cbaff" />
          <span className="num" style={{ color: 'var(--heading)', fontWeight: 600, textAlign: 'right' }}>
            {s.score.toFixed(2)}
          </span>
          <div style={{ gridColumn: '1 / -1', marginTop: -4 }}>
            <button className="link small" onClick={() => id && onCompare(id, s.itemId)}>
              Compare emotion arcs →
            </button>
          </div>
        </div>
      ))}
    </Card>
  );
}

/* ------------------------------------------------------------------ */
/* Compare arcs                                                        */
/* ------------------------------------------------------------------ */
function ComparePanel({ items, a, b, onA, onB }: { items: CatalogItem[]; a: string | null; b: string | null; onA: (v: string) => void; onB: (v: string) => void }) {
  const api = useApi();
  const arcA = useQuery(() => (a ? api.emotions(a) : Promise.resolve(undefined)), [a], { enabled: !!a });
  const arcB = useQuery(() => (b ? api.emotions(b) : Promise.resolve(undefined)), [b], { enabled: !!b });
  const ia = items.find((i) => i.id === a);
  const ib = items.find((i) => i.id === b);
  const normalise = (arc: EmotionArc | undefined, dur: number | undefined): EmotionArc | undefined => {
    if (!arc) return undefined;
    const d = dur ?? arc.samples[arc.samples.length - 1]?.end ?? 1;
    const f = (t: number) => t / d;
    return { ...arc, samples: arc.samples.map((s) => ({ ...s, start: f(s.start), end: f(s.end) })), acts: arc.acts.map((x) => ({ ...x, start: f(x.start), end: f(x.end) })), climax: arc.climax ? { ...arc.climax, at: f(arc.climax.at) } : undefined };
  };
  const na = normalise(arcA.data, ia?.durationSec);
  const nb = normalise(arcB.data, ib?.durationSec);
  const Select = ({ value, onChange }: { value: string | null; onChange: (v: string) => void }) => (
    <select className="select select--sm" value={value ?? ''} onChange={(e) => onChange(e.target.value)} style={{ width: 180 }}>
      {items.map((i) => (
        <option key={i.id} value={i.id}>
          {i.title}
        </option>
      ))}
    </select>
  );
  return (
    <Card
      title="Compare emotion arcs"
      icon="heart"
      sub="Time-normalised valence and arousal — does the second title build the same way?"
      actions={
        <>
          <Select value={a} onChange={onA} />
          <span className="muted small">vs</span>
          <Select value={b} onChange={onB} />
        </>
      }
    >
      {(arcA.loading || arcB.loading) && <Skeleton h={180} />}
      {!arcA.loading && !arcB.loading && na && (
        <>
          <EmotionArcChart arc={na} overlay={nb ? { arc: nb, color: '#e05ab0' } : undefined} duration={1} height={200} fps={25} showActs axis="percent" />
          <div className="row row--between" style={{ marginTop: 8 }}>
            <ArcLegend mainLabel={ia?.title ?? 'A'} overlayLabel={ib?.title} />
            <span className="muted small">
              {na.climax && (
                <>
                  climax A at {(na.climax.at * 100).toFixed(0)}% {nb?.climax && `· B at ${(nb.climax.at * 100).toFixed(0)}%`}
                </>
              )}
            </span>
          </div>
        </>
      )}
      {!arcA.loading && !na && <EmptyState icon="heart" title="No emotion arc" text="The emotions job has not run for this title." style={{ minHeight: 120 }} />}
      {na && ia && (
        <div className="row small muted" style={{ marginTop: 10, gap: 14 }}>
          <span>
            A · {ia.title} · <Timecode sec={ia.durationSec ?? 0} muted />
          </span>
          {ib && (
            <span>
              B · {ib.title} · <Timecode sec={ib.durationSec ?? 0} muted />
            </span>
          )}
        </div>
      )}
    </Card>
  );
}
