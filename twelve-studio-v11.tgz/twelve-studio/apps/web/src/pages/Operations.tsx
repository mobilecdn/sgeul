import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import type { AdBreak, AdCreative, CatalogItem, CreativeFit, EmotionArc, ItemBundle, Marker, ReviewState, SafetySegment, StitchJob } from '@twelve-studio/core';
import { rankCreatives } from '@twelve-studio/core/creativefit';
import { Button, EmptyState, ErrorNote, Meter, Modal, Skeleton, StatusPill, Tabs } from '../components/ui';
import { Player, type PlayerHandle } from '../components/Player';
import { Timeline, type TLTrack } from '../components/Timeline';
import { EmotionArcChart } from '../components/EmotionArcChart';
import { FrameThumb } from '../components/FrameThumb';
import { Timecode, TimecodeRange } from '../components/Timecode';
import { TagRow, TagChip } from '../components/TagChip';
import { Icon } from '../components/Icon';
import { AdLibrary, AdThumb, adMeta } from '../components/AdLibrary';
import { useApi, useClickOutside, useEvents, useQuery, useToast } from '../lib/hooks';
import { MARKER_COLORS, SAFETY_LABELS, SEVERITY_COLORS } from '../lib/colors';
import { download, duration, mmss, pct, titleCase } from '../lib/format';
import { playableSrc } from '../lib/media';
import { useTopbar } from '../App';

type Sel = { kind: 'marker' | 'break' | 'safety'; id: string } | null;
type InspTab = 'marker' | 'metadata' | 'safety' | 'comments';

const stateOf = (r?: ReviewState): 'approved' | 'declined' | 'pending' => (r?.status === 'approved' ? 'approved' : r?.status === 'declined' ? 'declined' : 'pending');
const AD_POD_COLOR = '#6d3fd4';
const isActive = (j?: StitchJob | null) => !!j && (j.status === 'queued' || j.status === 'running');

/**
 * Human phase for the progress pill. The API may expose a `stage`/`step` field or just the
 * ffmpeg log tail; both are optional in the contract so we sniff and fall back to a generic label.
 */
function stitchPhase(job: StitchJob): string | undefined {
  const j = job as StitchJob & { stage?: string; step?: string; phase?: string };
  const raw = j.stage ?? j.step ?? j.phase ?? job.log?.trim().split('\n').filter(Boolean).pop();
  if (!raw) return job.status === 'queued' ? 'queued' : undefined;
  const s = raw.toLowerCase();
  if (/keyframe|snap|probe/.test(s)) return 'snapping keyframes';
  if (/transcod|encod|scale|creative/.test(s)) return 'transcoding ad';
  if (/concat|segment|cut|copy|mux/.test(s)) return 'concatenating';
  return raw.length <= 32 ? raw : undefined;
}

export function Operations() {
  const api = useApi();
  const toast = useToast();
  const catalog = useQuery(() => api.catalog(), []);
  const [params, setParams] = useSearchParams();
  const items = useMemo(() => (catalog.data ?? []).filter((i) => i.status !== 'ingesting'), [catalog.data]);
  const activeId = params.get('item') ?? items[0]?.id ?? null;
  const setActive = (id: string) => {
    params.set('item', id);
    setParams(params, { replace: true });
  };
  const bundle = useQuery(() => (activeId ? api.item(activeId) : Promise.resolve(undefined)), [activeId], { enabled: !!activeId });
  const [sel, setSel] = useState<Sel>(null);
  const [tab, setTab] = useState<InspTab>('marker');
  const [time, setTime] = useState(0);
  const player = useRef<PlayerHandle>(null);
  const [exportOpen, setExportOpen] = useState(false);
  /** Bumped after every review mutation so queue counts refresh. */
  const [rev, setRev] = useState(0);
  const exportRef = useRef<HTMLDivElement>(null);
  useClickOutside(exportRef, useCallback(() => setExportOpen(false), []));

  /* --- ad creatives + stitched preview --------------------------- */
  const ads = useQuery(() => api.listAds().catch(() => [] as AdCreative[]), [], { keep: true });
  const adList = useMemo(() => ads.data ?? [], [ads.data]);
  const [creativeId, setCreativeId] = useState('');
  const [libOpen, setLibOpen] = useState(false);
  const [stitchJob, setStitchJob] = useState<StitchJob | null>(null);
  const [preview, setPreview] = useState(false);
  const [confirmAll, setConfirmAll] = useState(false);
  const [failJob, setFailJob] = useState<StitchJob | null>(null);
  const [rendering, setRendering] = useState(false);
  const creativeOf = useCallback((id?: string | null) => (id ? adList.find((a) => a.id === id) : undefined), [adList]);

  useEffect(() => {
    setSel(null);
    setTime(0);
    setStitchJob(null);
    setPreview(false);
    if (!activeId) return;
    // Pick up a render that already exists for this title (page reload, another client).
    let alive = true;
    api
      .listStitches(activeId)
      .then((jobs) => {
        if (!alive) return;
        const usable = jobs.filter((j) => j.itemId === activeId && (isActive(j) || (j.status === 'ready' && j.outputUrl))).sort((a, c) => c.createdAt.localeCompare(a.createdAt));
        if (usable[0]) setStitchJob(usable[0]);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [activeId, api]);

  const b = bundle.data;
  const item = b?.item;
  const fps = item?.fps ?? b?.markers?.fps ?? 25;
  const dur = item?.durationSec ?? Math.max(b?.emotions?.samples[b.emotions.samples.length - 1]?.end ?? 0, ...(b?.markers?.markers.map((m) => m.end) ?? [0]), ...(b?.adBreaks?.breaks.map((x) => x.window.end) ?? [0])) ?? 0;

  // Default top-bar creative: whatever the plan already uses, else the first in the library.
  useEffect(() => {
    if (creativeId && adList.some((a) => a.id === creativeId)) return;
    const assigned = b?.adBreaks?.breaks.map((x) => x.creativeId).find((id) => id && adList.some((a) => a.id === id));
    setCreativeId(assigned ?? adList[0]?.id ?? '');
  }, [adList, b?.adBreaks, creativeId]);

  // Live progress via SSE, with polling as a fallback when the stream is not delivering.
  useEvents(
    (e) => {
      if (e.type !== 'stitch' || e.job.itemId !== activeId) return;
      setStitchJob((prev) => (!prev || prev.id === e.job.id || !isActive(prev) || e.job.createdAt >= prev.createdAt ? e.job : prev));
    },
    [activeId],
  );
  useEffect(() => {
    if (!isActive(stitchJob)) return;
    const id = stitchJob!.id;
    const t = setInterval(() => {
      api
        .getStitch(id)
        .then((j) => setStitchJob((prev) => (prev && prev.id === j.id && (prev.status !== j.status || prev.log !== j.log) ? j : prev)))
        .catch(() => undefined);
    }, 2500);
    return () => clearInterval(t);
  }, [stitchJob?.id, stitchJob?.status, api]); // eslint-disable-line react-hooks/exhaustive-deps

  // React once to a terminal state of a render started (or seen running) in this session:
  // enter preview, or open the failure modal. A finished job found on load just shows the strip.
  const watched = useRef(new Set<string>());
  const seenRef = useRef<string>('');
  useEffect(() => {
    if (!stitchJob) return;
    if (isActive(stitchJob)) watched.current.add(stitchJob.id);
    if (!watched.current.has(stitchJob.id)) return;
    const key = `${stitchJob.id}:${stitchJob.status}`;
    if (seenRef.current === key) return;
    seenRef.current = key;
    if (stitchJob.status === 'ready' && stitchJob.outputUrl) {
      setPreview(true);
      toast.push(`Stitched preview ready · ${stitchJob.insertions.length} ad break${stitchJob.insertions.length === 1 ? '' : 's'}`, 'success');
      // Snapped insertion points come back on the plan too.
      bundle.setData((prev) => {
        if (!prev?.adBreaks) return prev;
        const snapped = new Map(stitchJob.insertions.map((i) => [i.breakId, i.snappedAt]));
        return { ...prev, adBreaks: { ...prev.adBreaks, breaks: prev.adBreaks.breaks.map((x) => (snapped.has(x.id) ? { ...x, snappedAt: snapped.get(x.id) } : x)) } };
      });
    } else if (stitchJob.status === 'failed') {
      setFailJob(stitchJob);
      setPreview(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stitchJob?.id, stitchJob?.status]);

  const stitchAd = creativeOf(stitchJob?.creativeId);
  const insertions = useMemo(() => [...(stitchJob?.insertions ?? [])].sort((a, c) => a.snappedAt - c.snappedAt), [stitchJob]);
  const adDur = stitchAd?.durationSec ?? (stitchJob?.durationSec && dur && insertions.length ? Math.max(0, (stitchJob.durationSec - dur) / insertions.length) : 30);
  const inPreview = preview && stitchJob?.status === 'ready' && !!stitchJob.outputUrl;
  /** Source time → stitched-timeline time (identity outside preview). Pure; data is never mutated. */
  const shift = useCallback((t: number) => (inPreview ? t + adDur * insertions.filter((i) => i.snappedAt <= t).length : t), [inPreview, adDur, insertions]);
  const tlDur = inPreview ? (stitchJob?.durationSec ?? dur + adDur * insertions.length) : dur;
  const addedSec = inPreview ? Math.max(0, tlDur - dur) : 0;

  const seek = useCallback((s: number) => {
    player.current?.seek(s);
    setTime(s);
  }, []);
  /** Seek to a source-time position (inspector links) — shifted while previewing. */
  const seekSrc = useCallback((s: number) => seek(shift(s)), [seek, shift]);

  /* --- mutations ------------------------------------------------- */
  const patch = async (kind: 'marker' | 'break', id: string, p: Partial<ReviewState>) => {
    if (!activeId || !b) return;
    try {
      if (kind === 'marker') {
        const m = await api.patchMarker(activeId, id, p);
        bundle.setData((prev) => (prev && prev.markers ? { ...prev, markers: { ...prev.markers, markers: prev.markers.markers.map((x) => (x.id === id ? m : x)) } } : prev));
      } else {
        const br = await api.patchAdBreak(activeId, id, p);
        bundle.setData((prev) => (prev && prev.adBreaks ? { ...prev, adBreaks: { ...prev.adBreaks, breaks: prev.adBreaks.breaks.map((x) => (x.id === id ? br : x)) } } : prev));
      }
      setRev((r) => r + 1);
    } catch (e) {
      toast.push((e as Error).message, 'error');
    }
  };

  const batch = async (status: 'approved' | 'declined') => {
    if (!b) return;
    const ms = (b.markers?.markers ?? []).filter((m) => stateOf(m.review) === 'pending');
    const bs = (b.adBreaks?.breaks ?? []).filter((x) => stateOf(x.review) === 'pending');
    await Promise.all([...ms.map((m) => patch('marker', m.id, { status })), ...bs.map((x) => patch('break', x.id, { status }))]);
    toast.push(`${status === 'approved' ? 'Approved' : 'Declined'} ${ms.length + bs.length} open elements`, status === 'approved' ? 'success' : 'info');
  };

  const replan = async (policy: { targetBreaks: number; minSpacingSec: number }) => {
    if (!activeId) return;
    try {
      const plan = await api.planAdBreaks(activeId, policy);
      bundle.setData((prev) => (prev ? { ...prev, adBreaks: plan } : prev));
      setRev((r) => r + 1);
      setSel(null);
      toast.push(`Re-planned ${plan.breaks.length} breaks deterministically (no model call)`, 'success');
    } catch (e) {
      toast.push((e as Error).message, 'error');
    }
  };

  const assign = async (id: string | null, breakIds?: string[]) => {
    if (!activeId || !b?.adBreaks) return;
    try {
      const plan = await api.assignCreative(activeId, { creativeId: id, breakIds });
      bundle.setData((prev) => (prev ? { ...prev, adBreaks: plan } : prev));
      const ad = creativeOf(id);
      const n = breakIds?.length ?? plan.breaks.length;
      toast.push(ad ? `Assigned "${ad.name}" to ${n} break${n === 1 ? '' : 's'}` : `Cleared creative on ${n} break${n === 1 ? '' : 's'}`, 'success');
    } catch (e) {
      toast.push((e as Error).message, 'error');
    }
  };

  const [autoAssigning, setAutoAssigning] = useState(false);
  const autoAssignByFit = async () => {
    if (!activeId || !b?.adBreaks) return;
    if (!adList.some((a) => a.fingerprint)) {
      toast.push('Fingerprint a creative first (Ad library → Fingerprint)', 'error');
      return setLibOpen(true);
    }
    setAutoAssigning(true);
    try {
      const r = await api.autoAssign(activeId, {});
      bundle.setData((prev) => (prev ? { ...prev, adBreaks: r.plan } : prev));
      const done = r.assignments.filter((a) => a.creativeId);
      const avg = done.length ? done.reduce((n, a) => n + (a.fit?.score ?? 0), 0) / done.length : 0;
      toast.push(`Best-fit creative on ${done.length} break${done.length === 1 ? '' : 's'} · mean fit ${avg.toFixed(2)}`, 'success');
    } catch (e) {
      toast.push((e as Error).message, 'error');
    } finally {
      setAutoAssigning(false);
    }
  };

  const render = async (includeUnapproved = false) => {
    if (!activeId || !b?.adBreaks) return;
    setConfirmAll(false);
    const breaks = b.adBreaks.breaks;
    const approved = breaks.filter((x) => x.review?.status === 'approved');
    if (!breaks.length) return toast.push('No breaks planned for this title', 'error');
    if (!includeUnapproved && !approved.length) return setConfirmAll(true);
    if (!adList.length) {
      toast.push('Add an ad creative first', 'error');
      return setLibOpen(true);
    }
    const scope = includeUnapproved ? breaks : approved;
    const assigned = scope.some((x) => creativeOf(x.creativeId));
    if (!assigned && !creativeId) return toast.push('Pick an ad creative first', 'error');
    setRendering(true);
    try {
      const job = await api.stitch(activeId, { includeUnapproved: includeUnapproved || undefined, creativeId: assigned ? undefined : creativeId });
      watched.current.add(job.id);
      setPreview(false);
      setStitchJob(job);
      if (isActive(job)) toast.push(`Rendering ${job.insertions.length || scope.length} ad break${scope.length === 1 ? '' : 's'}…`, 'ai');
    } catch (e) {
      toast.push((e as Error).message, 'error');
    } finally {
      setRendering(false);
    }
  };

  const exportAs = async (kind: 'vmap' | 'scte35' | 'markers') => {
    if (!activeId || !item) return;
    setExportOpen(false);
    const slug = item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    try {
      if (kind === 'vmap') download(`${slug}.vmap.xml`, await api.exportVmap(activeId), 'application/xml');
      else if (kind === 'scte35') download(`${slug}.scte35.json`, JSON.stringify(await api.exportScte35(activeId), null, 2), 'application/json');
      else download(`${slug}.markers.json`, JSON.stringify(await api.exportMarkers(activeId), null, 2), 'application/json');
      toast.push(`Exported ${kind.toUpperCase()}`, 'success');
    } catch (e) {
      toast.push((e as Error).message, 'error');
    }
  };

  /* --- top bar ---------------------------------------------------- */
  const [target, setTarget] = useState(3);
  const [spacing, setSpacing] = useState(420);
  useEffect(() => {
    if (b?.adBreaks) {
      setTarget(b.adBreaks.policy.targetBreaks);
      setSpacing(b.adBreaks.policy.minSpacingSec);
    }
  }, [b?.adBreaks?.policy.targetBreaks, b?.adBreaks?.policy.minSpacingSec, b?.adBreaks]);

  const vastAd = useMemo(() => adList.find((a) => b?.adBreaks?.breaks.some((x) => x.creativeId === a.id)), [adList, b?.adBreaks]);
  const selectedAd = creativeOf(creativeId);
  const phase = stitchJob && isActive(stitchJob) ? stitchPhase(stitchJob) : undefined;

  useTopbar(
    <>
      <div className="ops__policy">
        <label>
          breaks
          <input className="input input--sm" type="number" min={0} max={12} value={target} title="Target breaks" onChange={(e) => setTarget(Number(e.target.value))} />
        </label>
        <label>
          spacing (s)
          <input className="input input--sm" type="number" min={30} step={30} value={spacing} title="Minimum spacing (s)" onChange={(e) => setSpacing(Number(e.target.value))} />
        </label>
        <Button size="sm" variant="ghost" icon="refresh" onClick={() => void replan({ targetBreaks: target, minSpacingSec: spacing })} disabled={!b?.adBreaks} title="Re-plan breaks deterministically">
          Re-plan
        </Button>
      </div>
      <div className="ops__ads">
        <label className="ops__creative" title="Ad creative">
          <Icon name="film" size={13} />
          <select
            className="select select--sm"
            aria-label="Ad creative"
            value={adList.length ? creativeId : '__none'}
            onChange={(e) => {
              if (e.target.value === '__manage') setLibOpen(true);
              else setCreativeId(e.target.value);
            }}
          >
            {!adList.length && (
              <option value="__none" disabled>
                No ad creatives
              </option>
            )}
            {adList.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name} · {mmss(a.durationSec)}
              </option>
            ))}
            <option value="__manage">Manage…</option>
          </select>
        </label>
        <Button size="sm" variant="ghost" icon="tag" disabled={!b?.adBreaks || !selectedAd} title={selectedAd ? `Assign "${selectedAd.name}" to every planned break` : 'Pick a creative first'} onClick={() => void assign(creativeId)}>
          Assign to breaks
        </Button>
        <Button size="sm" variant="ai" icon="sparkle" loading={autoAssigning} disabled={!b?.adBreaks || !adList.length} title="Pick the best-fitting fingerprinted creative for each break (mood, keywords, IAB, safety agreement)" onClick={() => void autoAssignByFit()}>
          Auto by fit
        </Button>
      </div>
      {stitchJob && isActive(stitchJob) && (
        <span className="pill pill--violet ops__progress" title={stitchJob.log?.split('\n').slice(-3).join('\n')}>
          <span className="btn__spin" />
          Rendering…{phase ? ` ${phase}` : ''}
        </span>
      )}
      <Button size="sm" variant="primary" icon="play" loading={rendering} disabled={!b?.adBreaks || isActive(stitchJob)} onClick={() => void render(false)} title="Render an MP4 with the ad stitched into the approved breaks">
        Render preview
      </Button>
      <div ref={exportRef} style={{ position: 'relative' }}>
        <Button size="sm" variant="primary" icon="download" onClick={() => setExportOpen((o) => !o)} disabled={!b}>
          Export
        </Button>
        {exportOpen && (
          <div className="menu menu--wide">
            <button onClick={() => void exportAs('vmap')}>
              <span className="truncate">{vastAd ? `VMAP (inline VAST: ${vastAd.name})` : 'VMAP'}</span> <small>approved breaks</small>
            </button>
            <button onClick={() => void exportAs('scte35')}>
              SCTE-35 <small>splice points</small>
            </button>
            <button onClick={() => void exportAs('markers')}>
              Markers JSON <small>player-ready</small>
            </button>
          </div>
        )}
      </div>
    </>,
    [target, spacing, b, exportOpen, adList, creativeId, stitchJob, rendering, vastAd, phase, autoAssigning],
  );

  /* --- tracks ----------------------------------------------------- */
  const tracks = useMemo<TLTrack[]>(() => {
    if (!b) return [];
    const t: TLTrack[] = [];
    if (inPreview && stitchJob) {
      // Ad pods sit at snappedAt + k×adDuration in the stitched timeline (k = index in time order).
      const breaksById = new Map((b.adBreaks?.breaks ?? []).map((x) => [x.id, x]));
      t.push({
        id: 'adpods',
        label: 'Ad pods',
        color: AD_POD_COLOR,
        segments: insertions.map((ins, k) => {
          const start = ins.snappedAt + k * adDur;
          const br = breaksById.get(ins.breakId);
          return { id: `pod:${ins.breakId}`, start, end: start + adDur, color: AD_POD_COLOR, label: stitchAd?.name ?? 'Ad', state: 'none' as const, title: `${stitchAd?.name ?? 'Ad creative'} · ${mmss(adDur)} · break${br ? ` #${br.rank}` : ''} snapped to keyframe ${ins.snappedAt.toFixed(2)}s (requested ${ins.requestedAt.toFixed(2)}s)` };
        }),
      });
    }
    t.push({
      id: 'markers',
      label: 'Markers',
      color: '#0068e0',
      segments: (b.markers?.markers ?? []).map((m) => ({ id: m.id, start: shift(m.start), end: shift(m.end), color: MARKER_COLORS[m.kind], label: m.label ?? titleCase(m.kind), state: stateOf(m.review), title: `${m.label ?? titleCase(m.kind)} — ${titleCase(m.kind)} · confidence ${m.confidence.toFixed(2)}` })),
    });
    for (const rank of [1, 2, 3]) {
      const bs = (b.adBreaks?.breaks ?? []).filter((x) => (rank === 3 ? x.rank >= 3 : x.rank === rank));
      t.push({
        id: `breaks-${rank}`,
        label: rank === 3 ? 'Breaks · Rank 3+' : `Breaks · Rank ${rank}`,
        color: rank === 1 ? '#0068e0' : rank === 2 ? '#8cbaff' : '#7a8797',
        segments: bs.map((x) => ({ id: `${x.id}-win`, start: shift(x.window.start), end: shift(x.window.end), color: '#8cbaff', faint: true })),
        markers: bs.map((x) => {
          const ad = creativeOf(x.creativeId);
          return { id: x.id, at: shift(x.at), state: stateOf(x.review), title: `Break #${x.rank} · ${x.confidence.toFixed(2)} · ${x.reason}${ad ? `\nCreative: ${ad.name} (${mmss(ad.durationSec)})` : ''}` };
        }),
      });
    }
    t.push({
      id: 'safety',
      label: 'Safety',
      color: '#ea384c',
      segments: (b.safety?.segments ?? []).map((s) => ({ id: s.id, start: shift(s.start), end: shift(s.end), color: SEVERITY_COLORS[s.severity], label: SAFETY_LABELS[s.category], title: `${SAFETY_LABELS[s.category]} · ${s.severity} · ${s.confidence.toFixed(2)}` })),
    });
    if (b.emotions) {
      // Shift a copy of the arc — the bundle itself is never mutated.
      const src = b.emotions;
      const arc: EmotionArc = inPreview
        ? { ...src, samples: src.samples.map((s) => ({ ...s, start: shift(s.start), end: shift(s.end) })), acts: src.acts.map((a) => ({ ...a, start: shift(a.start), end: shift(a.end) })), climax: src.climax ? { ...src.climax, at: shift(src.climax.at) } : src.climax }
        : src;
      t.push({
        id: 'emotion',
        label: 'Emotion arc',
        color: '#6d3fd4',
        height: 84,
        render: ({ width, height }) => <EmotionArcChart arc={arc} duration={tlDur} width={width} height={height} compact color="#6d3fd4" />,
      });
    }
    return t;
  }, [b, tlDur, inPreview, stitchJob, insertions, adDur, stitchAd, shift, creativeOf]);

  const onSelect = (id: string, trackId: string) => {
    if (trackId === 'markers') setSel({ kind: 'marker', id });
    else if (trackId.startsWith('breaks')) setSel({ kind: 'break', id });
    else if (trackId === 'adpods') setSel({ kind: 'break', id: id.replace(/^pod:/, '') });
    else if (trackId === 'safety') setSel({ kind: 'safety', id });
    setTab(trackId === 'safety' ? 'safety' : 'marker');
  };

  const selMarker = sel?.kind === 'marker' ? b?.markers?.markers.find((m) => m.id === sel.id) : undefined;
  const selBreak = sel?.kind === 'break' ? b?.adBreaks?.breaks.find((m) => m.id === sel.id) : undefined;
  const selSafety = sel?.kind === 'safety' ? b?.safety?.segments.find((m) => m.id === sel.id) : undefined;

  const openCount = b ? (b.markers?.markers.filter((m) => stateOf(m.review) === 'pending').length ?? 0) + (b.adBreaks?.breaks.filter((x) => stateOf(x.review) === 'pending').length ?? 0) : 0;

  return (
    <div className="content content--flush">
      <div className="ops">
        {/* ---------------- Queue ---------------- */}
        <aside className="ops__queue">
          <div className="row row--between" style={{ padding: '14px 16px 8px' }}>
            <span className="eyebrow">Review queue</span>
            <span className="muted small">{items.length}</span>
          </div>
          <div className="ops__queue-list">
            {catalog.loading && (
              <div className="stack" style={{ padding: 8 }}>
                <Skeleton h={52} />
                <Skeleton h={52} />
                <Skeleton h={52} />
              </div>
            )}
            <ErrorNote error={catalog.error} />
            {!catalog.loading && items.length === 0 && <EmptyState icon="film" title="Queue is empty" text="Ingested titles show up here for QC." style={{ minHeight: 120, margin: 8 }} />}
            {items.map((i) => (
              <QueueItem key={i.id} item={i} active={i.id === activeId} rev={i.id === activeId ? rev : 0} onClick={() => setActive(i.id)} />
            ))}
          </div>
          <div className="ops__queue-foot">
            <Button variant="success" size="sm" icon="check" style={{ flex: 1 }} disabled={!openCount} onClick={() => void batch('approved')}>
              Approve ({openCount})
            </Button>
            <Button variant="danger" size="sm" icon="x" style={{ flex: 1 }} disabled={!openCount} onClick={() => void batch('declined')}>
              Decline
            </Button>
          </div>
        </aside>

        {/* ---------------- Centre ---------------- */}
        <div className="ops__center">
          {!activeId && !catalog.loading && <EmptyState icon="operations" title="Select a title to review" />}
          {activeId && bundle.loading && !b && (
            <>
              <Skeleton h={380} style={{ borderRadius: 16 }} />
              <Skeleton h={240} style={{ borderRadius: 16 }} />
            </>
          )}
          <ErrorNote error={bundle.error} />
          {b && item && (
            <>
              {stitchJob?.status === 'ready' && stitchJob.outputUrl && (
                <div className={`ops__stitched${inPreview ? ' is-on' : ''}`}>
                  <span className="pill pill--violet">
                    <Icon name="sparkle" size={12} />
                    Stitched preview · {insertions.length} ad break{insertions.length === 1 ? '' : 's'} · +{mmss(stitchJob.durationSec != null ? Math.max(0, stitchJob.durationSec - dur) : adDur * insertions.length)}
                  </span>
                  {stitchAd && (
                    <span className="muted small truncate" style={{ minWidth: 0 }}>
                      {stitchAd.name}
                      {stitchAd.advertiser ? ` · ${stitchAd.advertiser}` : ''} · {mmss(stitchAd.durationSec)} each · keyframe-snapped
                    </span>
                  )}
                  <span className="row" style={{ gap: 6, marginLeft: 'auto' }}>
                    <Button size="sm" variant={inPreview ? 'ghost' : 'ai'} icon={inPreview ? 'film' : undefined} onClick={() => setPreview((p) => !p)}>
                      {inPreview ? 'Back to source' : 'Show stitched preview'}
                    </Button>
                    <a className="btn btn--ghost btn--sm" href={stitchJob.outputUrl} download={`${item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-stitched.mp4`} title="Download the rendered MP4">
                      <Icon name="download" size={13} /> Download MP4
                    </a>
                  </span>
                </div>
              )}
              <Player
                key={inPreview ? `stitch:${stitchJob!.id}` : `src:${item.id}`}
                ref={player}
                src={inPreview ? stitchJob!.outputUrl : playableSrc(item)}
                originUrl={inPreview ? undefined : item.sourceUrl}
                poster={item.posterUrl}
                durationSec={inPreview ? tlDur : item.durationSec}
                fps={fps}
                onTime={setTime}
                title={inPreview ? `${item.title} · stitched preview` : item.title}
              />
              <Timeline
                duration={tlDur}
                fps={fps}
                tracks={tracks}
                playhead={time}
                onSeek={seek}
                selectedId={sel?.id ?? null}
                onSelect={onSelect}
                toolbarExtra={
                  <span className="legend">
                    {inPreview && (
                      <span>
                        <i style={{ background: AD_POD_COLOR }} /> ad pod (+{mmss(addedSec)})
                      </span>
                    )}
                    <span>
                      <i style={{ background: '#0068e0' }} /> pending
                    </span>
                    <span>
                      <i style={{ background: '#5ec16a' }} /> approved
                    </span>
                    <span>
                      <i style={{ background: '#ea384c' }} /> declined
                    </span>
                  </span>
                }
              />
              <div className="row row--wrap small muted" style={{ gap: 10 }}>
                <span className="row" style={{ gap: 6 }}>
                  <Icon name="tag" size={12} /> Marker kinds:
                </span>
                {Object.entries(MARKER_COLORS).map(([k, c]) => (
                  <span key={k} className="row" style={{ gap: 4 }}>
                    <i style={{ width: 8, height: 8, borderRadius: 2, background: c, display: 'inline-block' }} /> {titleCase(k)}
                  </span>
                ))}
              </div>
            </>
          )}
        </div>

        {/* ---------------- Inspector ---------------- */}
        <aside className="ops__inspector">
          <div style={{ padding: '10px 12px 0' }}>
            <Tabs<InspTab>
              full
              tabs={[
                { id: 'marker', label: 'Marker' },
                { id: 'metadata', label: 'Metadata' },
                { id: 'safety', label: 'Safety', count: b?.safety?.segments.length },
                { id: 'comments', label: 'Comments' },
              ]}
              value={tab}
              onChange={setTab}
            />
          </div>
          <div className="ops__inspector-body">
            {!b && <span className="muted small">Select a title.</span>}
            {b && tab === 'marker' && (
              <>
                {selMarker && <MarkerDetail m={selMarker} fps={fps} onSeek={seekSrc} onPatch={(p) => patch('marker', selMarker.id, p)} />}
                {selBreak && <BreakDetail x={selBreak} fps={fps} onSeek={seekSrc} onPatch={(p) => patch('break', selBreak.id, p)} ads={adList} onAssign={(id) => void assign(id, [selBreak.id])} onManage={() => setLibOpen(true)} />}
                {selSafety && <SafetyDetail s={selSafety} fps={fps} />}
                {!sel && (
                  <>
                    <EmptyState icon="layers" title="Nothing selected" text="Click a marker, break or safety segment on the timeline to review it." style={{ minHeight: 120 }} />
                    <ElementList b={b} fps={fps} onPick={(s) => { setSel(s); const el = s.kind === 'marker' ? b.markers?.markers.find((m) => m.id === s.id) : s.kind === 'break' ? b.adBreaks?.breaks.find((m) => m.id === s.id) : undefined; if (el) seekSrc('at' in el ? el.at : el.start); }} />
                  </>
                )}
              </>
            )}
            {b && tab === 'metadata' && <Metadata b={b} />}
            {b && tab === 'safety' && <SafetyTab b={b} fps={fps} onPick={(id) => { setSel({ kind: 'safety', id }); const s = b.safety?.segments.find((x) => x.id === id); if (s) seekSrc(s.start); }} selected={sel?.kind === 'safety' ? sel.id : null} />}
            {b && tab === 'comments' && (
              <CommentsTab
                target={selMarker ? { kind: 'marker', el: selMarker } : selBreak ? { kind: 'break', el: selBreak } : null}
                onAdd={(text) => {
                  const target = selMarker ?? selBreak;
                  if (!target) return;
                  const comments = [...(target.review?.comments ?? []), { id: `c_${Date.now()}`, author: 'You', text, at: new Date().toISOString() }];
                  void patch(selMarker ? 'marker' : 'break', target.id, { comments });
                }}
                all={[...(b.markers?.markers ?? []).map((m) => ({ label: m.label ?? titleCase(m.kind), at: m.start, comments: m.review?.comments ?? [] })), ...(b.adBreaks?.breaks ?? []).map((x) => ({ label: `Break #${x.rank}`, at: x.at, comments: x.review?.comments ?? [] }))].filter((x) => x.comments.length)}
                fps={fps}
              />
            )}
          </div>
        </aside>
      </div>

      <AdLibrary open={libOpen} onClose={() => setLibOpen(false)} ads={adList} onChanged={() => void ads.refetch().then(() => bundle.refetch())} assignedIds={new Set((b?.adBreaks?.breaks ?? []).map((x) => x.creativeId).filter((x): x is string => !!x))} />

      <Modal
        open={confirmAll}
        onClose={() => setConfirmAll(false)}
        title="No approved breaks yet"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmAll(false)}>
              Cancel
            </Button>
            <Button variant="primary" icon="play" onClick={() => void render(true)}>
              Render all {b?.adBreaks?.breaks.length ?? 0} planned breaks
            </Button>
          </>
        }
      >
        <p style={{ margin: 0, color: 'var(--heading)', fontSize: 14, lineHeight: 1.6 }}>
          Stitched previews normally use only the breaks you have approved. None are approved on <b>{item?.title}</b> — render the ad into every planned break instead? You can approve breaks first and re-render later.
        </p>
        {selectedAd && (
          <div className="creative-row">
            <AdThumb ad={selectedAd} />
            <div style={{ minWidth: 0 }}>
              <div className="truncate" style={{ color: 'var(--heading)', fontWeight: 600 }}>
                {selectedAd.name}
              </div>
              <div className="muted small">{adMeta(selectedAd)}</div>
            </div>
          </div>
        )}
      </Modal>

      <Modal
        open={!!failJob}
        onClose={() => setFailJob(null)}
        title={
          <span className="row" style={{ gap: 8 }}>
            <Icon name="alert" size={16} style={{ color: '#ff8a97' }} /> Render failed
          </span>
        }
        footer={
          <>
            <Button variant="ghost" onClick={() => setFailJob(null)}>
              Close
            </Button>
            <Button variant="primary" icon="refresh" onClick={() => { setFailJob(null); void render(false); }}>
              Try again
            </Button>
          </>
        }
        wide
      >
        <div className="row" style={{ gap: 8 }}>
          <StatusPill status="failed" />
          <span style={{ color: 'var(--heading)', fontSize: 14 }}>{failJob?.error ?? 'The stitcher reported an error.'}</span>
        </div>
        {failJob?.error === 'stitch_unavailable' && <span className="muted small">ffmpeg/ffprobe were not found on the API host's PATH.</span>}
        {failJob?.error === 'needs_local_file' && <span className="muted small">Stitching cuts the source with stream copy, so the title must be ingested from a local file (POST /api/catalog with an absolute path).</span>}
        <div className="section">
          <div className="section__title">
            <span>ffmpeg log</span>
            <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>tail</span>
          </div>
          <pre className="logpre">{failJob?.log?.trim() || 'No log captured.'}</pre>
        </div>
      </Modal>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Queue item                                                          */
/* ------------------------------------------------------------------ */
function QueueItem({ item, active, rev, onClick }: { item: CatalogItem; active: boolean; rev: number; onClick: () => void }) {
  const api = useApi();
  const counts = useQuery(async () => {
    const [m, a] = await Promise.all([api.markers(item.id).catch(() => null), api.adbreaks(item.id).catch(() => null)]);
    const els = [...(m?.markers ?? []), ...(a?.breaks ?? [])];
    const open = els.filter((e) => stateOf(e.review) === 'pending').length;
    const declined = els.filter((e) => stateOf(e.review) === 'declined').length;
    return { markers: m?.markers.length ?? 0, breaks: a?.breaks.length ?? 0, open, total: els.length, declined };
  }, [item.id, active, rev], { keep: true });
  const c = counts.data;
  const review = !c ? item.status : c.total === 0 ? 'pending' : c.open === 0 ? (c.declined === c.total ? 'declined' : 'approved') : 'open';
  return (
    <div className={`qitem${active ? ' is-active' : ''}`} onClick={onClick}>
      <div className="qitem__thumb">
        <FrameThumb url={playableSrc(item)} at={(item.durationSec ?? 600) * 0.3} poster={item.posterUrl} seed={item.id} bare />
      </div>
      <div style={{ minWidth: 0 }}>
        <div className="qitem__title" title={item.title}>
          {item.title}
        </div>
        <div className="qitem__meta">
          <span>{c ? `${c.markers} markers · ${c.breaks} breaks` : duration(item.durationSec)}</span>
        </div>
        <div style={{ marginTop: 4 }}>
          <StatusPill status={review}>{review === 'open' ? `${c?.open} open` : review}</StatusPill>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Detail panels                                                       */
/* ------------------------------------------------------------------ */
function ReviewControls({ review, onPatch }: { review?: ReviewState; onPatch: (p: Partial<ReviewState>) => void }) {
  const st = stateOf(review);
  return (
    <>
      <div className="section">
        <div className="section__title">
          <span>Rate 0–5</span>
          <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>{review?.rating != null ? `${review.rating}/5` : 'unrated'}</span>
        </div>
        <div className="rating">
          {([0, 1, 2, 3, 4, 5] as const).map((n) => (
            <button key={n} className={review?.rating === n ? 'is-on' : ''} onClick={() => onPatch({ rating: n })} aria-label={`Rate ${n}`}>
              {n}
            </button>
          ))}
        </div>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <Button variant={st === 'approved' ? 'success' : 'ghost'} icon="check" style={{ flex: 1 }} onClick={() => onPatch({ status: st === 'approved' ? 'open' : 'approved' })}>
          {st === 'approved' ? 'Approved' : 'Approve'}
        </Button>
        <Button variant={st === 'declined' ? 'danger' : 'ghost'} icon="x" style={{ flex: 1 }} onClick={() => onPatch({ status: st === 'declined' ? 'open' : 'declined' })}>
          {st === 'declined' ? 'Declined' : 'Decline'}
        </Button>
      </div>
      {review?.reviewedAt && (
        <span className="muted small">
          Reviewed by {review.reviewedBy ?? 'unknown'} · {new Date(review.reviewedAt).toLocaleString()}
        </span>
      )}
    </>
  );
}

function MarkerDetail({ m, fps, onSeek, onPatch }: { m: Marker; fps: number; onSeek: (s: number) => void; onPatch: (p: Partial<ReviewState>) => void }) {
  return (
    <>
      <div className="stack" style={{ gap: 6 }}>
        <div className="row" style={{ gap: 8, alignItems: 'flex-start' }}>
          <i style={{ width: 10, height: 10, borderRadius: 3, background: MARKER_COLORS[m.kind], flex: '0 0 10px', marginTop: 6 }} />
          <h2 style={{ flex: 1, minWidth: 0 }}>{m.label ?? titleCase(m.kind)}</h2>
          <span style={{ marginLeft: 'auto' }}>
            <StatusPill status={stateOf(m.review) === 'pending' ? 'open' : stateOf(m.review)} />
          </span>
        </div>
        <span className="muted small">{titleCase(m.kind)} marker</span>
      </div>
      <div className="kv">
        <dt>In</dt>
        <dd>
          <button className="link" onClick={() => onSeek(m.start)}>
            <Timecode sec={m.start} fps={fps} />
          </button>
          {m.startFrame != null && <span className="muted small"> · f{m.startFrame}</span>}
        </dd>
        <dt>Out</dt>
        <dd>
          <button className="link" onClick={() => onSeek(m.end)}>
            <Timecode sec={m.end} fps={fps} />
          </button>
          {m.endFrame != null && <span className="muted small"> · f{m.endFrame}</span>}
        </dd>
        <dt>Duration</dt>
        <dd>{(m.end - m.start).toFixed(2)}s</dd>
        <dt>Confidence</dt>
        <dd className="row" style={{ gap: 8 }}>
          <Meter value={m.confidence} color={MARKER_COLORS[m.kind]} style={{ maxWidth: 120 }} /> {m.confidence.toFixed(2)}
        </dd>
      </div>
      <ReviewControls review={m.review} onPatch={onPatch} />
      <CommentThread comments={m.review?.comments ?? []} onAdd={(text) => onPatch({ comments: [...(m.review?.comments ?? []), { id: `c_${Date.now()}`, author: 'You', text, at: new Date().toISOString() }] })} />
    </>
  );
}

const fitColor = (v: number) => (v >= 0.6 ? '#5ec16a' : v >= 0.35 ? '#f5c518' : 'rgba(255,255,255,.55)');

function BreakDetail({
  x,
  fps,
  onSeek,
  onPatch,
  ads,
  onAssign,
  onManage,
}: {
  x: AdBreak;
  fps: number;
  onSeek: (s: number) => void;
  onPatch: (p: Partial<ReviewState>) => void;
  ads: AdCreative[];
  /** Per-break override; `null` clears it. */
  onAssign: (creativeId: string | null) => void;
  onManage: () => void;
}) {
  const ad = ads.find((a) => a.id === x.creativeId);
  // Deterministic, so it is computed client-side from the same core module the API uses.
  const fits: CreativeFit[] = useMemo(() => (ads.length ? rankCreatives(x, ads) : []), [x, ads]);
  return (
    <>
      <div className="stack" style={{ gap: 6 }}>
        <div className="row" style={{ gap: 8 }}>
          <h2>Ad break · Rank {x.rank}</h2>
          <span style={{ marginLeft: 'auto' }}>
            <StatusPill status={stateOf(x.review) === 'pending' ? 'open' : stateOf(x.review)} />
          </span>
        </div>
        <span className="muted small">{x.reason}</span>
      </div>
      <div className="kv">
        <dt>Insert at</dt>
        <dd>
          <button className="link" onClick={() => onSeek(x.at)}>
            <Timecode sec={x.at} fps={fps} />
          </button>
          {x.frame != null && <span className="muted small"> · f{x.frame}</span>}
        </dd>
        {x.snappedAt != null && (
          <>
            <dt>Snapped to</dt>
            <dd>
              <button className="link" onClick={() => onSeek(x.snappedAt!)}>
                <Timecode sec={x.snappedAt} fps={fps} />
              </button>
              <span className="muted small"> · keyframe, {x.snappedAt - x.at >= 0 ? '+' : '−'}{Math.abs(x.snappedAt - x.at).toFixed(2)}s</span>
            </dd>
          </>
        )}
        <dt>Window</dt>
        <dd>
          <TimecodeRange start={x.window.start} end={x.window.end} fps={fps} muted />
        </dd>
        <dt>Confidence</dt>
        <dd className="row" style={{ gap: 8 }}>
          <Meter value={x.confidence} style={{ maxWidth: 120 }} /> {x.confidence.toFixed(2)}
        </dd>
        <dt>Brand safety</dt>
        <dd>
          <StatusPill status={x.brandSafety.suitable ? 'safe' : 'unsafe'}>{x.brandSafety.suitable ? 'suitable' : 'flagged'}</StatusPill>
        </dd>
      </div>
      <div className="section">
        <div className="section__title">
          <span>Creative</span>
          <button className="link small" onClick={onManage} style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>
            Manage…
          </button>
        </div>
        {ad ? (
          <div className="creative-row">
            <AdThumb ad={ad} />
            <div style={{ minWidth: 0, flex: 1 }}>
              <div className="truncate" style={{ color: 'var(--heading)', fontWeight: 600, fontSize: 13 }}>
                {ad.name}
              </div>
              <div className="muted small">
                {ad.advertiser ? `${ad.advertiser} · ` : ''}
                {adMeta(ad)}
              </div>
            </div>
          </div>
        ) : (
          <span className="muted small">No creative assigned — this break exports as a VAST ad-tag URI.</span>
        )}
        <select className="select select--sm" aria-label="Override creative for this break" value={x.creativeId ?? ''} onChange={(e) => onAssign(e.target.value || null)} disabled={!ads.length}>
          <option value="">{ads.length ? '— no creative —' : 'No creatives in the library'}</option>
          {ads.map((a) => (
            <option key={a.id} value={a.id}>
              {a.name} · {mmss(a.durationSec)}
            </option>
          ))}
        </select>
        {fits.length > 0 && (
          <div className="fitlist">
            <div className="section__title" style={{ marginTop: 4 }}>
              <span>Creative fit</span>
              <span className="muted" style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>
                mood · keywords · IAB · safety
              </span>
            </div>
            {fits.map((f) => {
              const c = ads.find((a) => a.id === f.creativeId)!;
              const active = x.creativeId === f.creativeId;
              return (
                <button key={f.creativeId} className={`fitrow ${active ? 'fitrow--active' : ''}`} onClick={() => onAssign(f.creativeId)} title={f.because.join('\n')}>
                  <span className="fitrow__head">
                    <span className="truncate" style={{ color: 'var(--heading)', fontWeight: 600 }}>
                      {c.name}
                    </span>
                    <span className="fitrow__score" style={{ color: fitColor(f.score) }}>
                      {c.fingerprint ? f.score.toFixed(2) : '—'}
                    </span>
                  </span>
                  {c.fingerprint ? (
                    <span className="fitrow__bars" aria-hidden>
                      <i style={{ width: `${Math.round(f.mood * 100)}%`, background: '#6d3fd4' }} title={`mood ${f.mood.toFixed(2)}`} />
                      <i style={{ width: `${Math.round(f.keywords * 100)}%`, background: '#0068e0' }} title={`keywords ${f.keywords.toFixed(2)}`} />
                      <i style={{ width: `${Math.round(f.iab * 100)}%`, background: '#2fbfa6' }} title={`IAB ${f.iab.toFixed(2)}`} />
                      <i style={{ width: `${Math.round(f.safety * 100)}%`, background: '#5ec16a' }} title={`safety ${f.safety.toFixed(2)}`} />
                    </span>
                  ) : null}
                  <span className="fitrow__why truncate">{f.because[0]}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
      <div className="stack" style={{ gap: 8 }}>
        <div className="scene">
          <b>Scene before</b>
          {x.sceneBefore}
        </div>
        <div className="scene" style={{ borderLeftColor: '#0068e0' }}>
          <b>Scene after</b>
          {x.sceneAfter}
        </div>
      </div>
      <div className="section">
        <div className="section__title">
          <span>Mood entering the break</span>
        </div>
        <TagRow labels={x.mood} max={5} tone="violet" />
      </div>
      <div className="section">
        <div className="section__title">
          <span>Keywords</span>
        </div>
        <TagRow labels={x.keywords} max={6} />
      </div>
      <div className="section">
        <div className="section__title">
          <span>IAB categories</span>
        </div>
        <div className="chiprow">
          {x.iab.map((c) => (
            <TagChip key={c.id} label={`${c.name}`} score={c.confidence} title={`${c.id} · tier ${c.tier}`} />
          ))}
          {!x.iab.length && <span className="muted small">None</span>}
        </div>
      </div>
      <div className="section">
        <div className="section__title">
          <span>Brand-safety flags (±60s)</span>
        </div>
        <TagRow labels={x.brandSafety.flags} tone="red" empty="No GARM flags near this break" />
      </div>
      <ReviewControls review={x.review} onPatch={onPatch} />
      <CommentThread comments={x.review?.comments ?? []} onAdd={(text) => onPatch({ comments: [...(x.review?.comments ?? []), { id: `c_${Date.now()}`, author: 'You', text, at: new Date().toISOString() }] })} />
    </>
  );
}

function SafetyDetail({ s, fps }: { s: SafetySegment; fps: number }) {
  return (
    <>
      <div className="row" style={{ gap: 8 }}>
        <i style={{ width: 10, height: 10, borderRadius: 3, background: SEVERITY_COLORS[s.severity] }} />
        <h2>{SAFETY_LABELS[s.category]}</h2>
        <span style={{ marginLeft: 'auto' }}>
          <StatusPill status={s.severity} tone={s.severity === 'high' ? 'red' : s.severity === 'medium' ? 'orange' : 'neutral'}>
            {s.severity}
          </StatusPill>
        </span>
      </div>
      <div className="kv">
        <dt>Range</dt>
        <dd>
          <TimecodeRange start={s.start} end={s.end} fps={fps} />
        </dd>
        <dt>Duration</dt>
        <dd>{(s.end - s.start).toFixed(1)}s</dd>
        <dt>Confidence</dt>
        <dd className="row" style={{ gap: 8 }}>
          <Meter value={s.confidence} color={SEVERITY_COLORS[s.severity]} style={{ maxWidth: 120 }} /> {s.confidence.toFixed(2)}
        </dd>
      </div>
      <div className="scene" style={{ borderLeftColor: SEVERITY_COLORS[s.severity] }}>
        <b>What Pegasus saw</b>
        {s.description}
      </div>
    </>
  );
}

function ElementList({ b, fps, onPick }: { b: ItemBundle; fps: number; onPick: (s: NonNullable<Sel>) => void }) {
  const ms = b.markers?.markers ?? [];
  const bs = b.adBreaks?.breaks ?? [];
  return (
    <div className="stack" style={{ gap: 14 }}>
      <div className="section">
        <div className="section__title">
          <span>Markers</span>
          <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>{ms.length}</span>
        </div>
        {ms.map((m) => (
          <div key={m.id} className="row" style={{ gap: 8, cursor: 'pointer', padding: '4px 0' }} onClick={() => onPick({ kind: 'marker', id: m.id })}>
            <i style={{ width: 8, height: 8, borderRadius: 2, background: MARKER_COLORS[m.kind], flex: '0 0 8px' }} />
            <span className="truncate" style={{ color: 'var(--heading)', flex: 1, fontSize: 13 }}>
              {m.label ?? titleCase(m.kind)}
            </span>
            <Timecode sec={m.start} fps={fps} muted />
            <StatusPill status={stateOf(m.review) === 'pending' ? 'open' : stateOf(m.review)} dot={false} />
          </div>
        ))}
        {!ms.length && <span className="muted small">No markers</span>}
      </div>
      <div className="section">
        <div className="section__title">
          <span>Ad breaks</span>
          <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>{bs.length}</span>
        </div>
        {[...bs]
          .sort((a, c) => a.at - c.at)
          .map((x) => (
            <div key={x.id} className="row" style={{ gap: 8, cursor: 'pointer', padding: '4px 0' }} onClick={() => onPick({ kind: 'break', id: x.id })}>
              <span className="pill pill--neutral" style={{ height: 18, padding: '0 6px' }}>
                #{x.rank}
              </span>
              <span className="truncate" style={{ color: 'var(--heading)', flex: 1, fontSize: 13 }}>
                {x.reason}
              </span>
              <Timecode sec={x.at} fps={fps} muted />
              <StatusPill status={stateOf(x.review) === 'pending' ? 'open' : stateOf(x.review)} dot={false} />
            </div>
          ))}
        {!bs.length && <span className="muted small">No breaks planned</span>}
      </div>
    </div>
  );
}

function Metadata({ b }: { b: ItemBundle }) {
  const fp = b.fingerprint ?? b.item.fingerprint;
  const item = b.item;
  return (
    <>
      <div>
        <h2>{item.title}</h2>
        <div className="muted small">
          {item.year ? `${item.year} · ` : ''}
          {titleCase(item.type)} · {duration(item.durationSec)} · {item.fps ?? '—'} fps{item.width ? ` · ${item.width}×${item.height}` : ''}
        </div>
      </div>
      {!fp && <span className="muted small">Fingerprint not available yet.</span>}
      {fp && (
        <>
          <p className="small" style={{ color: 'var(--heading)' }}>
            {fp.synopsis.short}
          </p>
          <div className="section">
            <div className="section__title">
              <span>Genres</span>
            </div>
            <TagRow labels={fp.genres} max={6} />
          </div>
          <div className="section">
            <div className="section__title">
              <span>Moods</span>
            </div>
            <TagRow labels={fp.moods} max={6} />
          </div>
          <div className="section">
            <div className="section__title">
              <span>Keywords</span>
            </div>
            <TagRow labels={fp.keywords} max={8} />
          </div>
          <div className="kv">
            <dt>Rating</dt>
            <dd>{fp.audienceRating.suggested}</dd>
            <dt>Pacing</dt>
            <dd>{fp.pacing.score.toFixed(2)}</dd>
            <dt>Language</dt>
            <dd>{fp.language.primary}</dd>
            <dt>Model</dt>
            <dd className="mono">{fp.model}</dd>
          </div>
        </>
      )}
      <div className="section">
        <div className="section__title">
          <span>Ad policy</span>
        </div>
        {b.adBreaks ? (
          <div className="kv">
            <dt>Target</dt>
            <dd>{b.adBreaks.policy.targetBreaks} breaks</dd>
            <dt>Min spacing</dt>
            <dd>{b.adBreaks.policy.minSpacingSec}s</dd>
            <dt>Avoid first</dt>
            <dd>{b.adBreaks.policy.avoidFirstSec}s</dd>
            <dt>Avoid last</dt>
            <dd>{b.adBreaks.policy.avoidLastSec}s</dd>
            <dt>Planned</dt>
            <dd>{new Date(b.adBreaks.generatedAt).toLocaleString()}</dd>
          </div>
        ) : (
          <span className="muted small">No plan yet</span>
        )}
      </div>
      {b.emotions && (
        <div className="section">
          <div className="section__title">
            <span>Acts</span>
          </div>
          {b.emotions.acts.map((a) => (
            <div key={a.name} className="scene" style={{ borderLeftColor: '#6d3fd4' }}>
              <b>
                {a.name} · {duration(a.end - a.start)}
              </b>
              {a.summary}
            </div>
          ))}
          {b.emotions.climax && (
            <div className="scene" style={{ borderLeftColor: '#f56300' }}>
              <b>Climax · {duration(b.emotions.climax.at)}</b>
              {b.emotions.climax.description}
            </div>
          )}
        </div>
      )}
    </>
  );
}

function SafetyTab({ b, fps, onPick, selected }: { b: ItemBundle; fps: number; onPick: (id: string) => void; selected: string | null }) {
  const rep = b.safety;
  if (!rep) return <span className="muted small">Safety report not available yet.</span>;
  const summary = Object.entries(rep.summary);
  return (
    <>
      <div className="section">
        <div className="section__title">
          <span>Rollup</span>
          <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>{rep.segments.length} segments</span>
        </div>
        {summary.length === 0 && <span className="muted small">Nothing flagged — clean title.</span>}
        {summary.map(([cat, v]) => (
          <div key={cat} className="row" style={{ gap: 10 }}>
            <i style={{ width: 8, height: 8, borderRadius: 2, background: SEVERITY_COLORS[v!.maxSeverity], flex: '0 0 8px' }} />
            <span style={{ color: 'var(--heading)', flex: 1, fontSize: 13 }}>{SAFETY_LABELS[cat as keyof typeof SAFETY_LABELS]}</span>
            <span className="muted small">{v!.maxSeverity}</span>
            <span className="muted small num">{v!.totalSec.toFixed(0)}s</span>
          </div>
        ))}
      </div>
      <div className="section">
        <div className="section__title">
          <span>Segments</span>
        </div>
        {rep.segments.map((s) => (
          <div key={s.id} className="scene" style={{ borderLeftColor: SEVERITY_COLORS[s.severity], cursor: 'pointer', outline: selected === s.id ? '1px solid rgba(255,255,255,.5)' : undefined }} onClick={() => onPick(s.id)}>
            <b>
              {SAFETY_LABELS[s.category]} · {s.severity} · {s.confidence.toFixed(2)}
            </b>
            <TimecodeRange start={s.start} end={s.end} fps={fps} muted />
            <div style={{ marginTop: 4 }}>{s.description}</div>
          </div>
        ))}
      </div>
      <span className="muted small">
        {pct(rep.segments.reduce((a, s) => a + (s.end - s.start), 0) / Math.max(1, b.item.durationSec ?? 1))} of runtime flagged · {rep.model}
      </span>
    </>
  );
}

function CommentThread({ comments, onAdd }: { comments: ReviewState['comments']; onAdd: (text: string) => void }) {
  const [text, setText] = useState('');
  return (
    <div className="section">
      <div className="section__title">
        <span>Comments</span>
        <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>{comments.length}</span>
      </div>
      {comments.map((c) => (
        <div key={c.id} className="comment">
          <div className="comment__avatar">{c.author.slice(0, 2).toUpperCase()}</div>
          <div style={{ minWidth: 0 }}>
            <div className="comment__meta">
              {c.author} · {new Date(c.at).toLocaleString()}
            </div>
            <div className="comment__text">{c.text}</div>
          </div>
        </div>
      ))}
      <div className="row" style={{ gap: 6 }}>
        <input
          className="input input--sm"
          placeholder="Add a comment…"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && text.trim()) {
              onAdd(text.trim());
              setText('');
            }
          }}
        />
        <Button
          size="sm"
          variant="primary"
          icon="message"
          disabled={!text.trim()}
          onClick={() => {
            onAdd(text.trim());
            setText('');
          }}
        />
      </div>
    </div>
  );
}

function CommentsTab({ target, onAdd, all, fps }: { target: { kind: 'marker' | 'break'; el: Marker | AdBreak } | null; onAdd: (text: string) => void; all: Array<{ label: string; at: number; comments: ReviewState['comments'] }>; fps: number }) {
  return (
    <>
      {target ? (
        <>
          <div className="muted small">
            Thread on <b style={{ color: 'var(--heading)' }}>{'kind' in target.el ? (target.el.label ?? titleCase(target.el.kind)) : `Break #${target.el.rank}`}</b>
          </div>
          <CommentThread comments={target.el.review?.comments ?? []} onAdd={onAdd} />
        </>
      ) : (
        <span className="muted small">Select a marker or break to comment on it.</span>
      )}
      <div className="divider" />
      <div className="section">
        <div className="section__title">
          <span>All threads on this title</span>
          <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>{all.reduce((n, x) => n + x.comments.length, 0)}</span>
        </div>
        {all.length === 0 && <span className="muted small">No comments yet.</span>}
        {all.map((t) => (
          <div key={t.label + t.at} className="stack" style={{ gap: 6 }}>
            <div className="row small">
              <span style={{ color: 'var(--heading)', fontWeight: 600 }}>{t.label}</span>
              <Timecode sec={t.at} fps={fps} muted />
            </div>
            {t.comments.map((c) => (
              <div key={c.id} className="comment">
                <div className="comment__avatar">{c.author.slice(0, 2).toUpperCase()}</div>
                <div>
                  <div className="comment__meta">
                    {c.author} · {new Date(c.at).toLocaleString()}
                  </div>
                  <div className="comment__text">{c.text}</div>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </>
  );
}

