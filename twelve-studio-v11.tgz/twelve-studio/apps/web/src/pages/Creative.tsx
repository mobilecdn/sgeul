import { useEffect, useMemo, useRef, useState } from 'react';
import type { CatalogItem, CreativeRun, PreviewClip, Recipe, SafetyCategory, ThumbnailCandidate } from '@twelve-studio/core';
import { Button, Card, EmptyState, Modal, Skeleton, StatusPill, Tabs } from '../components/ui';
import { FrameThumb } from '../components/FrameThumb';
import { Icon } from '../components/Icon';
import { TagRow } from '../components/TagChip';
import { Timecode, TimecodeRange } from '../components/Timecode';
import { RangeSlider } from '../components/RangeSlider';
import { PosterArt } from '../components/Poster';
import { useApi, useEvents, useQuery, useToast, useLocalState } from '../lib/hooks';
import type { RecipeInput } from '../lib/api';
import { SAFETY_CATEGORIES, SAFETY_LABELS } from '../lib/colors';
import { topLabels } from '../lib/format';
import { attachMedia, playableSrc } from '../lib/media';
import { useTopbar } from '../App';

const EXAMPLES = ['epic battle scenes', 'quiet emotional beats', 'moments with the dragon', 'romantic tension, close-ups', 'high-energy chase, neon city', 'family-safe wonder and awe', 'villain reveals'];
const FORMATS = ['16:9', '2:3', '1:1', '9:16'] as const;
type Format = (typeof FORMATS)[number];

export function Creative() {
  const api = useApi();
  const toast = useToast();
  const recipes = useQuery(() => api.recipes(), []);
  const catalog = useQuery(() => api.catalog(), []);
  const [selected, setSelected] = useLocalState<string | null>('creative.recipe', null);
  const [builder, setBuilder] = useState(false);
  const [picker, setPicker] = useState(false);
  const [runs, setRuns] = useState<CreativeRun[]>([]);
  const [running, setRunning] = useState(false);

  const recipe = recipes.data?.find((r) => r.id === selected) ?? recipes.data?.[0] ?? null;
  const items = useMemo(() => new Map((catalog.data ?? []).map((i) => [i.id, i])), [catalog.data]);

  useEffect(() => {
    if (recipes.data && !recipes.data.some((r) => r.id === selected) && recipes.data[0]) setSelected(recipes.data[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recipes.data]);

  useTopbar(
    <>
      <Button variant="ghost" size="sm" icon="plus" onClick={() => setBuilder(true)}>
        New recipe
      </Button>
      <Button variant="ai" size="sm" disabled={!recipe} onClick={() => setPicker(true)}>
        Run on…
      </Button>
    </>,
    [recipe?.id],
  );

  // Poll runs until ready (SSE gives us the nudge; polling covers HTTP mode without events).
  useEffect(() => {
    const pending = runs.filter((r) => r.status === 'running' || r.status === 'queued');
    if (!pending.length) return;
    const t = setInterval(async () => {
      const updated = await Promise.all(pending.map((r) => api.run(r.id).catch(() => r)));
      setRuns((prev) => prev.map((r) => updated.find((u) => u.id === r.id) ?? r));
    }, 900);
    return () => clearInterval(t);
  }, [runs, api]);

  useEvents((e) => {
    if (e.type === 'job' && (e.job.kind === 'thumbnails' || e.job.kind === 'clips') && e.job.status === 'ready') {
      // A run finished upstream — pull the full result (thumbnails/clips) for that item.
      setRuns((prev) => {
        for (const r of prev) if (r.itemId === e.job.itemId && r.status !== 'ready') void api.run(r.id).then((u) => setRuns((cur) => cur.map((x) => (x.id === u.id ? u : x)))).catch(() => undefined);
        return prev;
      });
    }
  });

  const run = async (ids: string[]) => {
    if (!recipe) return;
    setPicker(false);
    setRunning(true);
    try {
      const out = await api.runRecipe(recipe.id, ids);
      setRuns(out);
      toast.push(`Running "${recipe.name}" on ${ids.length} title${ids.length === 1 ? '' : 's'} — Pegasus with the brief injected`, 'ai');
    } catch (e) {
      toast.push((e as Error).message, 'error');
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="content">
      <div className="creative">
        <div className="stack">
          <div className="row row--between">
            <span className="eyebrow">Recipes</span>
            <span className="muted small">{recipes.data?.length ?? 0}</span>
          </div>
          {recipes.loading && (
            <>
              <Skeleton h={90} style={{ borderRadius: 14 }} />
              <Skeleton h={90} style={{ borderRadius: 14 }} />
            </>
          )}
          {!recipes.loading && recipes.data?.length === 0 && <EmptyState icon="wand" title="No recipes" text="A recipe is a creative brief plus constraints. Create one to generate thumbnails or clips on demand." action={<Button variant="primary" size="sm" onClick={() => setBuilder(true)}>New recipe</Button>} style={{ minHeight: 140 }} />}
          {recipes.data?.map((r) => (
            <div
              key={r.id}
              className={`recipe${recipe?.id === r.id ? ' is-active' : ''}`}
              onClick={() => {
                setSelected(r.id);
                setRuns([]);
              }}
            >
              <div className="row row--between">
                <span style={{ color: 'var(--heading)', fontWeight: 600 }} className="truncate">
                  {r.name}
                </span>
                <StatusPill status={r.target} tone={r.target === 'thumbnails' ? 'info' : 'violet'} dot={false}>
                  {r.target}
                </StatusPill>
              </div>
              <div className="recipe__brief">“{r.brief}”</div>
              <div className="row small muted" style={{ gap: 6, flexWrap: 'wrap' }}>
                <span>{r.count} candidates</span>
                {r.clipLengthSec && (
                  <span>
                    · {r.clipLengthSec[0]}–{r.clipLengthSec[1]}s
                  </span>
                )}
                <span>· {r.formats.join(' ')}</span>
                {r.requireCharacters?.length ? <span>· needs {r.requireCharacters.join(', ')}</span> : null}
                {r.excludeSafetyCategories?.length ? <span>· excl. {r.excludeSafetyCategories.length} safety</span> : null}
              </div>
            </div>
          ))}
        </div>

        <div className="stack stack--lg" style={{ minWidth: 0 }}>
          {recipe ? (
            <>
              <Card
                title={
                  <>
                    {recipe.name}
                    <StatusPill status={recipe.target} tone={recipe.target === 'thumbnails' ? 'info' : 'violet'} dot={false}>
                      {recipe.target}
                    </StatusPill>
                  </>
                }
                sub={`“${recipe.brief}”`}
                actions={
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      icon="trash"
                      onClick={async () => {
                        await api.deleteRecipe(recipe.id);
                        setRuns([]);
                        void recipes.refetch();
                      }}
                    >
                      Delete
                    </Button>
                    <Button variant="ai" size="sm" loading={running} onClick={() => setPicker(true)}>
                      Run on…
                    </Button>
                  </>
                }
              >
                <div className="row row--wrap small muted" style={{ gap: 14 }}>
                  <span>
                    <b style={{ color: 'var(--heading)' }}>{recipe.count}</b> per title
                  </span>
                  {recipe.clipLengthSec && (
                    <span>
                      length <b style={{ color: 'var(--heading)' }}>{recipe.clipLengthSec[0]}–{recipe.clipLengthSec[1]}s</b>
                    </span>
                  )}
                  <span>
                    formats <b style={{ color: 'var(--heading)' }}>{recipe.formats.join(', ')}</b>
                  </span>
                  {recipe.requireCharacters?.length ? (
                    <span>
                      requires <b style={{ color: 'var(--heading)' }}>{recipe.requireCharacters.join(', ')}</b>
                    </span>
                  ) : null}
                  {recipe.excludeSafetyCategories?.length ? (
                    <span>
                      excludes <b style={{ color: 'var(--heading)' }}>{recipe.excludeSafetyCategories.map((c) => SAFETY_LABELS[c]).join(', ')}</b>
                    </span>
                  ) : null}
                  <span style={{ marginLeft: 'auto' }} className="mono">
                    pegasus1.5 · json_schema · brief injected
                  </span>
                </div>
              </Card>

              {runs.length === 0 && !running && <EmptyState icon="sparkle" title="No results yet" text="Choose titles to run this recipe against. Each run is one Pegasus analyze call with the brief injected into the prompt." action={<Button variant="ai" onClick={() => setPicker(true)}>Run on…</Button>} />}
              {runs.map((r) => (
                <RunResults key={r.id} run={r} item={items.get(r.itemId)} recipe={recipe} />
              ))}
            </>
          ) : (
            !recipes.loading && <EmptyState icon="wand" title="Select or create a recipe" />
          )}
        </div>
      </div>

      <RecipeBuilder
        open={builder}
        onClose={() => setBuilder(false)}
        characters={[...new Set((catalog.data ?? []).flatMap((i) => i.fingerprint?.characters.map((c) => c.name) ?? []))]}
        onSave={async (input) => {
          const r = await api.createRecipe(input);
          toast.push(`Recipe "${r.name}" saved`, 'success');
          setBuilder(false);
          await recipes.refetch();
          setSelected(r.id);
          setRuns([]);
        }}
      />
      <ItemPicker open={picker} onClose={() => setPicker(false)} items={catalog.data ?? []} onRun={run} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Results                                                             */
/* ------------------------------------------------------------------ */
function RunResults({ run, item, recipe }: { run: CreativeRun; item?: CatalogItem; recipe: Recipe }) {
  const [format, setFormat] = useState<Format | 'off'>('off');
  const [showLogo, setShowLogo] = useState(true);
  const src = playableSrc(item);
  const fps = item?.fps ?? 25;
  const pending = run.status === 'running' || run.status === 'queued';
  return (
    <Card
      title={
        <>
          {item?.title ?? run.itemId}
          <StatusPill status={run.status} />
        </>
      }
      sub={pending ? 'Pegasus is scanning the title with your brief…' : `${run.thumbnails?.length ?? run.clips?.length ?? 0} ${recipe.target}`}
      actions={
        recipe.target === 'thumbnails' ? (
          <>
            <span className="small muted">Crop guide</span>
            <Tabs<Format | 'off'> tabs={[{ id: 'off', label: 'Off' }, ...recipe.formats.map((f) => ({ id: f, label: f }))]} value={format} onChange={setFormat} />
            <Button variant={showLogo ? 'default' : 'ghost'} size="sm" icon="logo" onClick={() => setShowLogo(!showLogo)}>
              Logo zone
            </Button>
          </>
        ) : undefined
      }
    >
      {pending && (
        <div className={recipe.target === 'thumbnails' ? 'thumbs' : 'clipstrip'}>
          {Array.from({ length: Math.min(recipe.count, 4) }).map((_, i) => (
            <div key={i} className="skeleton" style={recipe.target === 'thumbnails' ? { aspectRatio: '16/11', borderRadius: 16 } : { flex: '0 0 210px', aspectRatio: '9/19', borderRadius: 16 }} />
          ))}
        </div>
      )}
      {!pending && recipe.target === 'thumbnails' && (
        <div className="thumbs">
          {(run.thumbnails ?? []).map((t) => (
            <ThumbCard key={t.id} t={t} src={src} fps={fps} format={format} showLogo={showLogo} poster={item?.posterUrl} />
          ))}
          {run.thumbnails?.length === 0 && <span className="muted small">No candidates satisfied the brief and constraints.</span>}
        </div>
      )}
      {!pending && recipe.target === 'clips' && (
        <div className="clipstrip">
          {(run.clips ?? []).map((c) => (
            <ClipCard key={c.id} c={c} src={src} fps={fps} poster={item?.posterUrl} />
          ))}
          {run.clips?.length === 0 && <span className="muted small">No clips satisfied the brief and constraints.</span>}
        </div>
      )}
    </Card>
  );
}

const FACTOR_KEYS: Array<[keyof ThumbnailCandidate['factors'], string]> = [
  ['relevance', 'rel'],
  ['aesthetics', 'aesth'],
  ['faceProminence', 'face'],
  ['stillness', 'still'],
  ['brightness', 'light'],
  ['safeArea', 'safe'],
];

function ThumbCard({ t, src, fps, format, showLogo, poster }: { t: ThumbnailCandidate; src?: string; fps: number; format: Format | 'off'; showLogo: boolean; poster?: string }) {
  const crop = format !== 'off' ? t.crops[format] : null;
  const logoPos: React.CSSProperties =
    t.logoSafeZone === 'top-left'
      ? { top: '6%', left: '4%' }
      : t.logoSafeZone === 'top-right'
        ? { top: '6%', right: '4%' }
        : t.logoSafeZone === 'bottom-left'
          ? { bottom: '6%', left: '4%' }
          : t.logoSafeZone === 'bottom-right'
            ? { bottom: '6%', right: '4%' }
            : { top: '39%', left: '39%' };
  return (
    <div className="thumb">
      <div className="thumb__art">
        <FrameThumb url={src} at={t.at} fps={fps} mood={topLabels(t.mood, 1)[0]} poster={poster} center style={{ position: 'absolute', inset: 0 }}>
          {crop && <div className="thumb__crop" style={{ left: `${crop.x * 100}%`, top: `${crop.y * 100}%`, width: `${crop.w * 100}%`, height: `${crop.h * 100}%` }} />}
          {showLogo && (
            <div className="thumb__logo" style={logoPos} title={`Logo-safe zone: ${t.logoSafeZone}`}>
              LOGO
            </div>
          )}
        </FrameThumb>
      </div>
      <div className="thumb__body">
        <div className="row row--between">
          <span className="row" style={{ gap: 8 }}>
            <span className="thumb__score" title="composite score">
              {t.score.toFixed(2)}
            </span>
            <Timecode sec={t.at} fps={fps} muted />
          </span>
          <StatusPill status={t.safe ? 'safe' : 'unsafe'}>{t.safe ? 'brand safe' : 'flagged'}</StatusPill>
        </div>
        <div className="thumb__caption">{t.caption}</div>
        {t.characters.length > 0 && (
          <div className="small muted truncate" title={t.characters.join(', ')}>
            {t.characters.join(', ')}
          </div>
        )}
        <div className="factors">
          {FACTOR_KEYS.map(([k, l]) => (
            <div key={k} className="factor" title={`${k} ${t.factors[k].toFixed(2)}`}>
              <div className="factor__bar">
                <div style={{ width: `${t.factors[k] * 100}%`, background: k === 'relevance' ? '#6d3fd4' : '#0068e0' }} />
              </div>
              <span className="factor__lbl">{l}</span>
            </div>
          ))}
        </div>
        <TagRow labels={t.mood} max={3} />
      </div>
    </div>
  );
}

function ClipCard({ c, src, fps, poster }: { c: PreviewClip; src?: string; fps: number; poster?: string }) {
  const v = useRef<HTMLVideoElement>(null);
  const [hover, setHover] = useState(false);
  const [armed, setArmed] = useState(false);
  const [ready, setReady] = useState(false);
  const [broken, setBroken] = useState(false);
  const [t, setT] = useState(c.start);
  const playable = !!src && !broken;
  // Lazy: the stream is only attached on first hover (hls.js for .m3u8), then kept.
  useEffect(() => {
    const el = v.current;
    if (!el || !playable || !armed) return;
    setReady(false);
    const detach = attachMedia(el, src!, { startPosition: c.start, lightweight: true, onError: () => setBroken(true) });
    return detach;
  }, [armed, playable, src, c.start]);
  useEffect(() => {
    const el = v.current;
    if (!el || !playable || !armed) return;
    if (hover) {
      if (el.readyState >= 1) el.currentTime = c.start;
      void el.play().catch(() => undefined);
    } else {
      el.pause();
    }
  }, [hover, playable, armed, c.start]);
  const cx = (() => {
    const path = c.reframe916 ?? [];
    if (!path.length) return 0.5;
    let prev = path[0]!;
    for (const k of path) {
      if (k.at <= t) prev = k;
      else {
        const span = k.at - prev.at || 1;
        return prev.cx + ((k.cx - prev.cx) * (t - prev.at)) / span;
      }
    }
    return prev.cx;
  })();
  const mood = topLabels(c.mood, 1)[0];
  return (
    <div
      className="clip"
      onMouseEnter={() => {
        setArmed(true);
        setHover(true);
      }}
      onMouseLeave={() => setHover(false)}
    >
      <div className="clip__stage">
        <FrameThumb url={src} at={c.posterAt} fps={fps} mood={mood} poster={poster} center style={{ position: 'absolute', inset: 0 }} />
        {playable && (
          <video
            ref={v}
            muted
            playsInline
            preload="metadata"
            crossOrigin="anonymous"
            data-ready={ready && hover ? 'true' : 'false'}
            style={{ transform: `translateX(${-cx * 100}%)`, left: '50%' }}
            onCanPlay={() => setReady(true)}
            onTimeUpdate={(e) => {
              const el = e.currentTarget;
              setT(el.currentTime);
              if (el.currentTime >= c.end) el.currentTime = c.start;
            }}
          />
        )}
        {!hover && playable && (
          <div className="clip__hint">
            <span className="row" style={{ gap: 6, background: 'rgba(0,0,0,.55)', padding: '4px 10px', borderRadius: 999 }}>
              <Icon name="play" size={11} /> hover to play
            </span>
          </div>
        )}
        <span className="clip__badge" style={{ zIndex: 2 }}>
          <StatusPill status={c.safe ? 'safe' : 'unsafe'} dot={false}>
            {mood ?? c.clipType}
          </StatusPill>
        </span>
        <span className="clip__rel" style={{ zIndex: 2 }} title="query relevance">
          {(c.queryRelevance ?? c.relevance).toFixed(2)}
        </span>
      </div>
      <div className="clip__body">
        <div className="small" style={{ color: 'var(--heading)', fontWeight: 500 }}>
          {c.caption}
        </div>
        <TimecodeRange start={c.start} end={c.end} fps={fps} muted small />
        <div className="row small muted">
          <span>{c.clipType}</span>
          <span>· {(c.end - c.start).toFixed(1)}s</span>
          {!c.safe && <span style={{ color: '#ff8a97' }}>· flagged</span>}
        </div>
        <ReframePath path={c.reframe916} start={c.start} end={c.end} now={hover ? t : undefined} />
      </div>
    </div>
  );
}

/** Mini-visual of the 9:16 reframe path: x-centre over time inside a 16:9 frame. */
function ReframePath({ path, start, end, now }: { path?: Array<{ at: number; cx: number }>; start: number; end: number; now?: number }) {
  const W = 180;
  const H = 34;
  const pts = path?.length ? path : [{ at: start, cx: 0.5 }, { at: end, cx: 0.5 }];
  const x = (at: number) => ((at - start) / Math.max(0.1, end - start)) * W;
  const y = (cx: number) => 4 + cx * (H - 8);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'} ${x(p.at).toFixed(1)} ${y(p.cx).toFixed(1)}`).join(' ');
  return (
    <div className="reframe" title="9:16 reframe path (x-centre over time)">
      <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block' }}>
        <line x1={0} x2={W} y1={H / 2} y2={H / 2} stroke="rgba(255,255,255,.12)" strokeDasharray="2 3" />
        <path d={d} fill="none" stroke="#c8b0ff" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
        {pts.map((p, i) => (
          <circle key={i} cx={x(p.at)} cy={y(p.cx)} r={2.2} fill="#c8b0ff" />
        ))}
        {now != null && <line x1={x(now)} x2={x(now)} y1={0} y2={H} stroke="#fff" strokeOpacity={0.8} vectorEffect="non-scaling-stroke" />}
        <text x={3} y={9} fontSize={7} fill="rgba(255,255,255,.4)" fontFamily="Inter, system-ui">
          L
        </text>
        <text x={3} y={H - 3} fontSize={7} fill="rgba(255,255,255,.4)" fontFamily="Inter, system-ui">
          R
        </text>
      </svg>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Builder modal                                                       */
/* ------------------------------------------------------------------ */
function RecipeBuilder({ open, onClose, onSave, characters }: { open: boolean; onClose: () => void; onSave: (r: RecipeInput) => Promise<void>; characters: string[] }) {
  const [name, setName] = useState('');
  const [target, setTarget] = useState<Recipe['target']>('thumbnails');
  const [brief, setBrief] = useState('');
  const [count, setCount] = useState(6);
  const [len, setLen] = useState<[number, number]>([8, 30]);
  const [formats, setFormats] = useState<Format[]>(['16:9', '9:16']);
  const [req, setReq] = useState<string[]>([]);
  const [excl, setExcl] = useState<SafetyCategory[]>(['nudity', 'gore']);
  const [busy, setBusy] = useState(false);
  const toggle = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={
        <span className="row" style={{ gap: 8 }}>
          <Icon name="sparkle" size={15} style={{ color: '#c8b0ff' }} /> New creative recipe
        </span>
      }
      wide
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="ai"
            loading={busy}
            disabled={!brief.trim() || !formats.length}
            onClick={async () => {
              setBusy(true);
              try {
                await onSave({
                  name: name.trim() || brief.slice(0, 32),
                  target,
                  brief: brief.trim(),
                  count,
                  clipLengthSec: target === 'clips' ? len : undefined,
                  formats,
                  requireCharacters: req.length ? req : undefined,
                  excludeSafetyCategories: excl.length ? excl : undefined,
                });
              } finally {
                setBusy(false);
              }
            }}
          >
            Save recipe
          </Button>
        </>
      }
    >
      <div className="grid" style={{ gridTemplateColumns: '1.3fr 1fr', gap: 24 }}>
        <div className="stack stack--lg">
          <div className="row" style={{ gap: 14 }}>
            <div className="field" style={{ flex: 1 }}>
              <label>Name</label>
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Key art — action" />
            </div>
            <div className="field">
              <label>Target</label>
              <Tabs<Recipe['target']> tabs={[{ id: 'thumbnails', label: 'Thumbnails', icon: 'grid' }, { id: 'clips', label: 'Clips', icon: 'film' }]} value={target} onChange={setTarget} />
            </div>
          </div>
          <div className="field">
            <label className="row" style={{ gap: 6 }}>
              <Icon name="sparkle" size={12} style={{ color: '#c8b0ff' }} /> Creative brief — open vocabulary
            </label>
            <textarea className="textarea" rows={4} value={brief} onChange={(e) => setBrief(e.target.value)} placeholder="Describe what you want in plain language. Pegasus reads the whole title against this brief." style={{ borderColor: 'rgba(109,63,212,.5)' }} />
            <div className="example-chips">
              {EXAMPLES.map((ex) => (
                <span key={ex} className="chip chip--click chip--pad chip--violet" onClick={() => setBrief(ex)} role="button">
                  {ex}
                </span>
              ))}
            </div>
          </div>
          <div className="row" style={{ gap: 20, alignItems: 'flex-start' }}>
            <div className="field" style={{ width: 120 }}>
              <label>Count</label>
              <input className="input" type="number" min={1} max={24} value={count} onChange={(e) => setCount(Math.max(1, Math.min(24, Number(e.target.value) || 1)))} />
            </div>
            {target === 'clips' && (
              <div className="field" style={{ flex: 1 }}>
                <label>Clip length (seconds)</label>
                <RangeSlider value={len} min={2} max={90} step={1} onChange={setLen} label="Length" />
              </div>
            )}
          </div>
        </div>
        <div className="stack stack--lg">
          <div className="field">
            <label>Formats</label>
            <div className="row row--wrap" style={{ gap: 12 }}>
              {FORMATS.map((f) => (
                <label key={f} className="checkbox">
                  <input type="checkbox" checked={formats.includes(f)} onChange={() => setFormats(toggle(formats, f))} /> {f}
                </label>
              ))}
            </div>
          </div>
          <div className="field">
            <label>Require characters</label>
            {characters.length ? (
              <div className="chiprow">
                {characters.slice(0, 14).map((c) => (
                  <span key={c} className={`chip chip--click chip--pad${req.includes(c) ? ' chip--active' : ''}`} onClick={() => setReq(toggle(req, c))} role="button">
                    {c}
                  </span>
                ))}
              </div>
            ) : (
              <span className="muted small">No characters known yet</span>
            )}
          </div>
          <div className="field">
            <label>Exclude safety categories</label>
            <div className="chiprow">
              {SAFETY_CATEGORIES.map((c) => (
                <span key={c} className={`chip chip--click chip--pad${excl.includes(c) ? ' chip--red' : ''}`} onClick={() => setExcl(toggle(excl, c))} role="button">
                  {SAFETY_LABELS[c]}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function ItemPicker({ open, onClose, items, onRun }: { open: boolean; onClose: () => void; items: CatalogItem[]; onRun: (ids: string[]) => void }) {
  const [sel, setSel] = useState<Set<string>>(new Set());
  const ready = items.filter((i) => i.status === 'ready');
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Run recipe on…"
      footer={
        <>
          <Button variant="ghost" onClick={() => setSel(new Set(ready.map((i) => i.id)))}>
            Select all
          </Button>
          <Button variant="ai" disabled={!sel.size} onClick={() => onRun([...sel])}>
            Run on {sel.size || ''} {sel.size === 1 ? 'title' : 'titles'}
          </Button>
        </>
      }
    >
      {ready.length === 0 && <EmptyState icon="film" title="No ready titles" text="Titles become available once their pipeline finishes." style={{ minHeight: 100 }} />}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 8 }}>
        {ready.map((i) => (
          <label key={i.id} className="checkbox" style={{ padding: 8, borderRadius: 10, background: sel.has(i.id) ? 'var(--blue-soft)' : 'var(--surface-2)', border: '1px solid var(--hairline)' }}>
            <input
              type="checkbox"
              checked={sel.has(i.id)}
              onChange={() => {
                const n = new Set(sel);
                if (n.has(i.id)) n.delete(i.id);
                else n.add(i.id);
                setSel(n);
              }}
            />
            <span style={{ width: 28, height: 40, borderRadius: 4, overflow: 'hidden', flex: '0 0 28px' }}>
              <PosterArt item={i} showFrame={false} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </span>
            <span className="truncate">{i.title}</span>
          </label>
        ))}
      </div>
    </Modal>
  );
}
