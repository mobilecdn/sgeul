/** TwelveLabs list pricing (Sept 2026) surfaced in the UI. */
export const PRICING = {
  indexPerHour: 2.5,
  analyzePerHourIn: 1.75,
  analyzePerMTokensOut: 7.5,
  searchPer1kQueries: 4,
  embedPerMTokens: 0.26,
  /** Pegasus calls per item in the standard pipeline (fingerprint, emotions, markers, safety, adbreaks, thumbnails, clips). */
  analyzeCallsPerItem: 7,
  /** Rough JSON output size per Pegasus call. */
  outputTokensPerCall: 1800,
  /** Marengo video embedding ≈ tokens per hour of video. */
  embedTokensPerHour: 45_000,
} as const;

export interface CostBreakdown {
  index: number;
  analyze: number;
  analyzeTokens: number;
  embed: number;
  search: number;
  total: number;
}

export function estimateCost(hoursOfVideo: number, items: number, searchQueries = 0): CostBreakdown {
  const index = hoursOfVideo * PRICING.indexPerHour;
  const analyze = hoursOfVideo * PRICING.analyzeCallsPerItem * PRICING.analyzePerHourIn;
  const analyzeTokens =
    (items * PRICING.analyzeCallsPerItem * PRICING.outputTokensPerCall * PRICING.analyzePerMTokensOut) / 1_000_000;
  const embed = (hoursOfVideo * PRICING.embedTokensPerHour * PRICING.embedPerMTokens) / 1_000_000;
  const search = (searchQueries / 1000) * PRICING.searchPer1kQueries;
  return { index, analyze, analyzeTokens, embed, search, total: index + analyze + analyzeTokens + embed + search };
}

export const MODELS = {
  index: 'marengo3.0',
  embed: 'marengo3.5',
  analyze: 'pegasus1.5',
} as const;
