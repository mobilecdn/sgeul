/**
 * Media source resolution + attachment shared by every <video> in the app.
 *
 * Catalog items carry two URLs: `sourceUrl` (what the customer gave us — often a
 * YouTube link the browser cannot play) and `playback.hlsUrl` (the HLS playlist
 * TwelveLabs returns after indexing, publicly served from CloudFront). Everything
 * that renders frames goes through `playableSrc` so the choice lives in one place.
 */
import type { CatalogItem } from '@twelve-studio/core';

type MediaItem = Pick<CatalogItem, 'sourceUrl'> & Partial<Pick<CatalogItem, 'playback'>>;

export function isHls(url?: string | null): boolean {
  return !!url && /\.m3u8(\?|#|$)/i.test(url);
}

/** A URL a <video> can play directly (progressive file or an HLS manifest). */
export function isDirectMedia(url?: string | null): boolean {
  return !!url && /\.(mp4|m4v|mov|webm|ogv|m3u8)(\?|#|$)/i.test(url);
}

export function isYouTube(url?: string | null): boolean {
  return !!url && /(youtube\.com|youtu\.be)/i.test(url);
}

/**
 * Best in-browser source for an item, or undefined when nothing is playable (YouTube etc).
 * Order: TwelveLabs HLS → the API's progressive file stream (`/api/catalog/:id/media`,
 * set when the item was ingested from disk) → a direct media URL the customer gave us.
 *
 * Relative `/api/...` URLs are left as-is: the browser resolves them against the page
 * origin, which is the Vite dev proxy in development and the API host in production.
 */
export function playableSrc(item?: MediaItem | null): string | undefined {
  if (!item) return undefined;
  if (item.playback?.hlsUrl) return item.playback.hlsUrl;
  if (item.playback?.fileUrl) return item.playback.fileUrl;
  if (isDirectMedia(item.sourceUrl)) return item.sourceUrl;
  return undefined;
}

export interface AttachOptions {
  /** Called once when the media cannot be loaded (network, CORS, unsupported). */
  onError?: () => void;
  /** Where to begin — hls.js honours this before the first fragment loads. */
  startPosition?: number;
  /** Keep buffers small for hidden frame-grab players. */
  lightweight?: boolean;
}

/**
 * Attach `src` to a <video>: native for progressive files and Safari HLS,
 * hls.js (lazy-loaded) for HLS elsewhere. Returns a detach function.
 */
export function attachMedia(video: HTMLVideoElement, src: string, opts: AttachOptions = {}): () => void {
  let disposed = false;
  let hls: { destroy(): void } | undefined;
  let errored = false;
  const fail = () => {
    if (errored || disposed) return;
    errored = true;
    opts.onError?.();
  };
  const onNativeError = () => fail();
  video.addEventListener('error', onNativeError);

  if (isHls(src) && !video.canPlayType('application/vnd.apple.mpegurl')) {
    void import('hls.js')
      .then(({ default: Hls }) => {
        if (disposed) return;
        if (!Hls.isSupported()) return fail();
        const h = new Hls({
          enableWorker: true,
          startPosition: opts.startPosition ?? -1,
          manifestLoadingMaxRetry: 2,
          levelLoadingMaxRetry: 2,
          fragLoadingMaxRetry: 3,
          ...(opts.lightweight ? { maxBufferLength: 6, maxMaxBufferLength: 12, backBufferLength: 0, capLevelToPlayerSize: false } : {}),
        });
        h.on(Hls.Events.ERROR, (_e, data) => {
          if (data.fatal) fail();
        });
        h.loadSource(src);
        h.attachMedia(video);
        hls = h;
      })
      .catch(fail);
  } else {
    video.src = src;
    video.load();
  }

  return () => {
    disposed = true;
    video.removeEventListener('error', onNativeError);
    hls?.destroy();
    hls = undefined;
    if (!isHls(src)) {
      video.removeAttribute('src');
      video.load();
    }
  };
}
