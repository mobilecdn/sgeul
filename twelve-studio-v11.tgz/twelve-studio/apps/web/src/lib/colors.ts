import type { MarkerKind, SafetyCategory } from '@twelve-studio/core';
import { hash } from './format';

export const C = {
  blue: '#0068e0',
  violet: '#6d3fd4',
  green: '#5ec16a',
  red: '#ea384c',
  orange: '#f56300',
  info: '#8cbaff',
  yellow: '#f5c542',
  teal: '#2fbfa6',
  pink: '#e05ab0',
} as const;

export const MARKER_COLORS: Record<MarkerKind, string> = {
  cold_open: '#2fbfa6',
  recap: '#8cbaff',
  intro: '#0068e0',
  title_card: '#6d3fd4',
  chapter: '#7a8797',
  credits: '#f5c542',
  post_credits: '#f56300',
  next_episode_hook: '#e05ab0',
  preview: '#5ec16a',
};

export const SEVERITY_COLORS = {
  low: '#f5c542',
  medium: '#f56300',
  high: '#ea384c',
} as const;

export const SAFETY_LABELS: Record<SafetyCategory, string> = {
  nudity: 'Nudity',
  sexual_content: 'Sexual content',
  violence: 'Violence',
  gore: 'Gore',
  profanity: 'Profanity',
  drugs: 'Drugs',
  alcohol: 'Alcohol',
  tobacco: 'Tobacco',
  weapons: 'Weapons',
  hate: 'Hate',
  self_harm: 'Self-harm',
  flashing_lights: 'Flashing lights',
};

export const SAFETY_CATEGORIES = Object.keys(SAFETY_LABELS) as SafetyCategory[];

export function reviewColor(status?: 'open' | 'approved' | 'declined'): string {
  if (status === 'approved') return C.green;
  if (status === 'declined') return C.red;
  return C.blue;
}

const GRADIENTS = [
  ['#1c2b5a', '#0068e0'],
  ['#3b1f66', '#6d3fd4'],
  ['#0f3d3a', '#2fbfa6'],
  ['#4a1f2a', '#e05ab0'],
  ['#4d2a08', '#f56300'],
  ['#1f3a1f', '#5ec16a'],
  ['#3a2a0a', '#f5c542'],
  ['#2a1f4a', '#8cbaff'],
];

/** Deterministic dark gradient for generated posters. */
export function gradientFor(seed: string): string {
  const [a, b] = GRADIENTS[hash(seed) % GRADIENTS.length]!;
  const angle = 120 + (hash(seed + 'x') % 90);
  return `linear-gradient(${angle}deg, ${a} 0%, ${b} 100%)`;
}
