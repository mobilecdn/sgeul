import { createContext, useCallback, useContext, useEffect, useRef, useState, type DependencyList } from 'react';
import type { Api, Health, StudioEvent } from './api';
import { getApi } from './api';

export const ApiContext = createContext<Api>(getApi());

export function useApi(): Api {
  return useContext(ApiContext);
}

export interface QueryState<T> {
  data: T | undefined;
  loading: boolean;
  error: Error | null;
  refetch: () => Promise<void>;
  /** Mutate the cached value locally (optimistic updates). */
  setData: (updater: T | ((prev: T | undefined) => T | undefined)) => void;
}

/** Tiny fetch-on-mount helper with loading/error states and manual refetch. */
export function useQuery<T>(fn: () => Promise<T>, deps: DependencyList, opts?: { enabled?: boolean; keep?: boolean }): QueryState<T> {
  const [data, setData] = useState<T | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const seq = useRef(0);
  const enabled = opts?.enabled ?? true;

  const run = useCallback(async () => {
    const id = ++seq.current;
    setLoading(true);
    setError(null);
    try {
      const v = await fnRef.current();
      if (id === seq.current) setData(v);
    } catch (e) {
      if (id === seq.current) setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!enabled) {
      setLoading(false);
      return;
    }
    if (!opts?.keep) setData(undefined);
    void run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, ...deps]);

  const set = useCallback((u: T | ((prev: T | undefined) => T | undefined)) => {
    setData((prev) => (typeof u === 'function' ? (u as (p: T | undefined) => T | undefined)(prev) : u));
  }, []);

  return { data, loading, error, refetch: run, setData: set };
}

export function useHealth(): Health | undefined {
  const api = useApi();
  const [h, setH] = useState<Health | undefined>();
  useEffect(() => {
    let alive = true;
    const tick = () =>
      api
        .health()
        .then((v) => alive && setH(v))
        .catch(() => alive && setH({ ok: false, mode: 'mock' }));
    void tick();
    const t = setInterval(tick, 15000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [api]);
  return h;
}

/** Subscribe to the event stream for the lifetime of a component. */
export function useEvents(cb: (e: StudioEvent) => void, deps: DependencyList = []) {
  const api = useApi();
  const ref = useRef(cb);
  ref.current = cb;
  useEffect(() => {
    return api.subscribeEvents((e) => ref.current(e));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api, ...deps]);
}

/* Toasts */
export interface ToastItem {
  id: number;
  text: string;
  kind: 'info' | 'success' | 'error' | 'ai';
}
export interface ToastApi {
  push: (text: string, kind?: ToastItem['kind']) => void;
}
export const ToastContext = createContext<ToastApi>({ push: () => undefined });
export function useToast() {
  return useContext(ToastContext);
}

export function useLocalState<T>(key: string, initial: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  const set = useCallback(
    (n: T) => {
      setV(n);
      try {
        localStorage.setItem(key, JSON.stringify(n));
      } catch {
        /* ignore */
      }
    },
    [key],
  );
  return [v, set];
}

export function useClickOutside(ref: React.RefObject<HTMLElement>, onOut: () => void) {
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onOut();
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [ref, onOut]);
}
