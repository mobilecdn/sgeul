# SGEUL · Story AI (Twelve Studio)

**The media-intelligence suite TwelveLabs should sell to streamers, broadcasters and publishers.** Product brand: **SGEUL** (Story AI); package namespace stays `@twelve-studio/*`.
A Vionlabs-class product (Editorial Lab, Creative Lab, Operations Lab, Discovery, Recommendations) plus a REST API and an MCP server, where every intelligence primitive is a TwelveLabs model call: Marengo for search and embeddings, Pegasus for structured video analysis.

```
apps/web        React app: Editorial · Creative · Operations · Discovery · Recommendations · API docs · Settings
apps/api        REST API + enrichment pipeline + review workflow + VMAP / SCTE-35 / marker exports
apps/mcp        MCP server: the same primitives for Claude, Cursor and custom agents
packages/core   TwelveLabs client, Pegasus prompts + JSON schemas, deterministic ad-break planner, similarity
data/seed       Demo catalog: real TwelveLabs output for three Blender open movies
data/real       The raw model output the seed is built from (provenance)
```

## Quick start

Prebuilt (no install, needs Node 20+): double-click `start.command` (macOS) or run `./start.sh`, then open http://localhost:8787. The API serves the built web app from the same origin.

Development:

```bash
npm install
npm run dev            # API on http://localhost:8787, web on http://localhost:5173 (hot reload)
```

Without a key the API runs in **mock mode**: the three demo titles are fully enriched with real TwelveLabs output, playback streams from TwelveLabs' CDN, and every workflow (review, re-plan, exports, smart lists, curation, creative runs) works. New URLs you ingest are synthesised and marked "(mock)".

## Live mode

```bash
cp .env.example .env   # paste your key from https://playground.twelvelabs.io
npm run dev
```

With `TWELVELABS_API_KEY` set the pipeline runs for real: `POST /assets` → `POST /indexes/:id/indexed-assets` (Marengo 3.0 index with the thumbnail add-on) → seven `POST /analyze` calls (Pegasus 1.5, `response_format: json_schema`) → `POST /embed-v2` (Marengo 3.5, video scope) → planner. Upload a title from Editorial Lab or `POST /api/catalog`.

## What each Lab does, and the TwelveLabs call behind it

| Surface | Capability | TwelveLabs primitive |
| --- | --- | --- |
| Editorial | Fingerprint: genres, keywords, moods, mood tags, themes, characters, pacing, rating, synopsis in 9 languages | Pegasus analyze, one JSON-schema call |
| Editorial | Smart lists (confidence-range rules), NL lists, AI curation | Marengo text embed + cosine; k-means over video embeddings |
| Discovery | Any-to-video moment search, similar titles with reasons | Marengo search; Marengo 3.5 video embeddings |
| Recommendations | Taste profiles from watch events, up-next and home rows, every weight set by the app (a viewer who watches romantic horror gets romantic horror first, then horror and romance) | Pegasus fingerprints; Marengo 3.5 embeddings |
| Operations | Emotion arc: valence / arousal / dominance every ~30 s, acts, climax | Pegasus analyze (time-based) |
| Operations | Markers: intro, recap, title card, chapters, credits, post-credits, with frames + confidence | Pegasus analyze |
| Operations | Ad breaks: candidate pauses → deterministic pod planner (spacing, fences, brand safety, never on rising arousal) → ranked windows with mood, keywords, IAB, flags | Pegasus analyze + `packages/core/src/adbreaks.ts` |
| Operations | Safety: timestamped segments with category + severity | Pegasus analyze |
| Operations | Creative intelligence: brand, product, tagline, mood, keywords, tone, IAB, sensitivities, family-safety, key moments for every ad spot; creative-to-break **fit** (mood + keyword + IAB + safety agreement) and one-click best-fit assignment | Pegasus analyze (one call per creative) + `packages/core/src/creativefit.ts` |
| Operations | Review workflow, VMAP 1.0, SCTE-35 splice list, player markers JSON | API |
| Creative | Thumbnails from a free-text brief: factor scores, crops for 4 aspect ratios, logo-safe zone | Pegasus analyze with the brief injected |
| Creative | Preview clips from a brief: in/out, mood, safety, 9:16 reframe path | Pegasus analyze with the brief injected |
| MCP | 29 tools, 2 resources, 2 prompts for agents | REST API |

Where this goes past Vionlabs: continuous emotion arcs (not just mood tags), break **windows** with calibrated confidence (not ranked points), open vocabularies and free-text creative briefs (no fixed enums), 9 synopsis languages including ar/hi/ko, natural-language search at the API layer, SCTE-35/VMAP out of the box, and an MCP surface so the product is usable from any agent.

## Ad insertion demo: David and Goliath × Kinder Bueno

Operations Lab → David and Goliath. TwelveLabs (Pegasus) proposed 12 natural pauses for the 1960 feature; the planner
(5 breaks, 8-minute spacing, 3-minute head fence, 4-minute tail fence, no break within 45 s of a high-severity
safety segment, never on rising arousal) kept five: **18:50, 31:24, 47:28, 55:41, 70:34**. Each carries the mood
entering the break, keywords, IAB categories and brand-safety flags. The Kinder Bueno 30 s spot is assigned to all
five; "Render preview" stream-copies the film, snaps each insertion to the nearest keyframe inside the break window
(within ±0.5 s here), transcodes the spot once to 640×480/24fps/AAC and concatenates: 91:41 → 94:12, rendered in
74 s. Exports: VMAP 1.0 with inline VAST (MediaFile = the spot), SCTE-35 splice list, player markers.

Paths for the demo are configured in `.env`: `TWELVE_MEDIA_DIR=/Users/euan.mcleod/Downloads` (film, spots, poster)
and renders land in `data/renders/` (or `RENDERS_DIR`). The first render of this session is in
`~/Claude/Projects/Twelve/renders/`.

## Deploying to a web server

See `deploy/README.md`: `deploy/install.sh` sets up Node 22, nginx, ffmpeg and a systemd service on Ubuntu; `.env.production.example` has the production settings including `BASIC_AUTH=user:password`, which gates every route on a public host, and `HOST=127.0.0.1` for running behind the proxy. The single-file demo (`apps/web/dist-single/index.html`) can be dropped on any static host instead.

## Scripts

```bash
npm run dev          # api + web
npm run build        # everything
npm test             # core + api tests (33)
npm run mcp          # MCP server on stdio (needs the API running)
npm run build:single -w @twelve-studio/web   # single-file demo (apps/web/dist-single/index.html)
npx tsx data/seed/build-seed-real.ts         # rebuild the seed from data/real
```

Both Kinder Bueno spots also carry a Pegasus **creative fingerprint** (Ad library → Fingerprint): brand, product,
tagline, mood, keywords, tone, IAB, sensitivities, family-safety and key moments. The break inspector ranks every
creative for the selected break ("Creative fit": 0.35 mood + 0.30 keywords + 0.20 IAB + 0.15 safety agreement, each
with the overlaps that produced it) and "Auto by fit" assigns the best spot per break. A chocolate ad in a biblical
epic scores honestly low (0.15–0.32); the same spots next to the Grok 4 promo's space imagery score higher on keywords
and IAB, which is the point: contextual placement with numbers a buyer can audit.

## Provenance of the demo data

Every fingerprint, emotion arc, marker, safety segment, ad-break candidate, thumbnail, clip and creative fingerprint in `data/seed` was produced by TwelveLabs Pegasus on 12 September 2026 from the video itself, using the prompts in `packages/core/src/prompts.ts` with a JSON schema: three Blender Foundation open movies (Sintel, Tears of Steel, Cosmos Laundromat; CC-BY) through the Jockey knowledge store, David and Goliath (1960) and the Grok 4 promo through `POST /v1.3/analyze/tasks`, and the two Kinder Bueno spots through `POST /v1.3/analyze`. Raw outputs are in `data/real` (with token usage in each `provenance.json`). Ad-break ranking, creative fit, frame maths and composite thumbnail scores are computed by the same code the live pipeline uses.

## Pricing surfaced in the app (TwelveLabs list, Sept 2026)

Index $2.50/h · Analyze $1.75/h in + $7.50/M tokens out · Search $4/1k queries · Embed video $0.26/M tokens. A 2-hour film costs roughly $30 to fully enrich (seven Pegasus passes dominate); a 10,000-hour catalog roughly $150k, versus a per-title editorial cost that is typically an order of magnitude higher.
