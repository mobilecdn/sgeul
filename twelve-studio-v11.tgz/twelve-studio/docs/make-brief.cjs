/* Builds the Head of Applications brief (v2 story) as a .docx.  node docs/make-brief.cjs <arch.png> <out.docx> */
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, BorderStyle, Table, TableRow, TableCell, WidthType, ShadingType,
  LevelFormat, AlignmentType, ImageRun, ExternalHyperlink,
} = require('docx');
const { readFileSync, writeFileSync } = require('node:fs');

const [archPng, out] = process.argv.slice(2);
const font = 'Calibri';
const SIZE = 21;
const run = (text, o = {}) => new TextRun({ text, font, size: SIZE, ...o });
const P = (runs, o = {}) => new Paragraph({ spacing: { after: 110, line: 270 }, ...o, children: runs.map((r) => (typeof r === 'string' ? run(r) : Array.isArray(r) ? run(r[0], r[1]) : r)) });
const body = (t, o = {}) => P([[t, o]]);
const lead = (b, t) => P([[b, { bold: true }], t]);
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, keepNext: true, spacing: { before: 280, after: 90 }, children: [new TextRun({ text: t, font, size: 26, bold: true, color: '111111' })] });
const h3 = (t) => new Paragraph({ keepNext: true, spacing: { before: 160, after: 60 }, children: [new TextRun({ text: t, font, size: 22, bold: true, color: '111111' })] });
const bullet = (b, t) => new Paragraph({ numbering: { reference: 'bullets', level: 0 }, spacing: { after: 60, line: 264 }, children: [run(b, { bold: true }), run(t)] });
const link = (text, url) => new ExternalHyperlink({ link: url, children: [new TextRun({ text, font, size: SIZE, style: 'Hyperlink' })] });

const cell = (children, w, o = {}) =>
  new TableCell({
    width: { size: w, type: WidthType.DXA },
    margins: { top: 70, bottom: 70, left: 110, right: 110 },
    shading: o.shade ? { type: ShadingType.CLEAR, fill: o.shade, color: 'auto' } : undefined,
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: 'DDDDDD' },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: 'DDDDDD' },
      left: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
      right: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
    },
    children,
  });
const cp = (runs, o = {}) => new Paragraph({ spacing: { after: 40, line: 250 }, children: runs.map((r) => (typeof r === 'string' ? run(r, { size: 19, ...o }) : run(r[0], { size: 19, ...o, ...r[1] }))) });
const table = (header, rows, widths, mono = false) =>
  new Table({
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: widths,
    rows: [
      new TableRow({ tableHeader: true, children: header.map((h, i) => cell([cp([h], { bold: true })], widths[i], { shade: 'F3F3F3' })) }),
      ...rows.map((r) => new TableRow({ cantSplit: true, children: r.map((c, i) => cell([cp(Array.isArray(c) ? c : [c], i === 0 ? (mono ? { font: 'Consolas' } : { bold: true }) : {})], widths[i])) })),
    ],
  });

const png = readFileSync(archPng);
const figure = new Paragraph({
  keepNext: true,
  alignment: AlignmentType.CENTER,
  spacing: { before: 60, after: 60 },
  children: [new ImageRun({ type: 'png', data: png, transformation: { width: 624, height: 300 }, altText: { title: 'SGEUL architecture', description: 'Four-layer architecture', name: 'arch' } })],
});

const doc = new Document({
  styles: { default: { document: { run: { font, size: SIZE } } } },
  numbering: { config: [{ reference: 'bullets', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 440, hanging: 240 } } } }] }] },
  sections: [
    {
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1150, bottom: 1000, left: 1440, right: 1440 } } },
      children: [
        new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: 'Euan McLeod for Head of Applications', font, size: 34, bold: true, color: '111111' })] }),
        new Paragraph({
          spacing: { after: 240 },
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'F5C518', space: 6 } },
          children: [run('A brief for Jae Lee, CEO of TwelveLabs, in support of my application for the Head of Applications role', { color: '666666' })],
        }),

        body('Jae, you have built the models that understand video. What TwelveLabs does not yet sell is the layer that media companies actually buy: the applications that turn Marengo and Pegasus into ad revenue, faster operations and better audience experiences. Your posting calls it a builder-GM role. I did not want to describe how I would do that job. I wanted to show it. So I built the product on your API and MCP, put it in front of a real streaming service, and wrote this brief around what it proves.'),
        body('The short version: I have run video technology at Amazon, HBO Max, WarnerMedia and Comcast, I have founded and sold a company, I am currently the customer for exactly this product as CTO of a streaming platform, and the prototype your job description asks for in the first 90 days is already live at sgeul.com.'),

        h2('The prototype is already in users’ hands'),
        body('SGEUL (Scots Gaelic for “story”, at sgeul.com) is a media intelligence suite built entirely on Marengo and Pegasus, using the Jockey MCP as the agent path. It is what the posting describes: a working prototype, placed with a user (Pure Flix, where I am CTO), with production quality thresholds defined and every number traceable to a model call. It is monetisable now, and it is proof of how quickly I deliver. It includes:'),
        bullet('Editorial Lab: ', 'title fingerprints (genres, moods, themes, characters, pacing, rating, synopsis in nine languages), smart lists with confidence-range rules, natural-language lists and AI curation over Marengo embeddings.'),
        bullet('Operations Lab: ', 'continuous emotion arcs, intro/recap/credits markers to the frame, timestamped brand safety, ad-break windows from a deterministic pod planner, creative intelligence for every ad spot with contextual fit scoring, review workflow, VMAP with inline VAST, SCTE-35 and a stitched MP4 preview.'),
        bullet('Creative Lab and Discovery: ', 'thumbnails and vertical clips from a free-text brief, any-to-video moment search, similar titles with reasons.'),
        bullet('Platform surface: ', 'a REST API, an MCP server with 29 tools so any agent can run ad operations end to end, account asset sync so anything uploaded to TwelveLabs is enriched without re-upload, and a cost ledger that shows the list price of every hour indexed.'),
        body('The proof point is a 92-minute feature with five mid-rolls chosen by the planner, a Kinder Bueno spot fingerprinted by Pegasus and scored for fit against each break, then stitched into a watchable preview at keyframe-accurate insertion points. The whole catalog was enriched for roughly 34 dollars of API usage. Vionlabs needed years and its own models to reach this feature surface; on TwelveLabs each capability is a prompt and a JSON schema. That is the strongest product argument the company can make, and the applications team should be making it every day.'),

        h2('How my record maps to the posting'),
        table(
          ['What the role asks for', 'Where I have done it'],
          [
            ['Zero to meaningful adoption', 'Founded a CDN startup and took it from nothing to an acquisition by Limelight Networks. Built SGEUL from an empty folder to a deployed, tested product on your API in two weeks. Stood up new video platforms at Turner/CNN and Comcast (VIPER) that customers still run on.'],
            ['Product judgment that simplifies complex technology', ['Every SGEUL screen turns a model response into a decision a media operator already understands: a break window with a confidence, a fit score with the words that produced it, a VMAP file a player can load. As ', ['SVP Technology at HBO Max and WarnerMedia', { bold: true }], ' I did the same at the scale of one of the largest premium catalogs in the world. SGEUL makes monetisation more efficient through a simple interface.']],
            ['Technical fluency on architecture, latency, reliability and cost', ['As ', ['Global Head of Live Video at Amazon', { bold: true }], ', including NFL Thursday Night Football, I owned delivery where latency and reliability were measured live by millions of viewers and every ad pod had to land on the frame. Deep background in encoding, DRM, CDN and device ecosystems at global scale.']],
            ['Understands AI-native product challenges', 'SGEUL is designed around model behaviour: calibrated probabilities instead of booleans, open vocabularies bounded in count, schema-constrained outputs with a sanitiser for what Pegasus rejects, deterministic post-processing so re-planning never re-spends tokens, and honest scores when the answer is “this creative does not fit here”.'],
            ['Growth leadership beyond acquisition', ['As ', ['CTO of Great American Media', { bold: true }], ' (Pure Flix) I own the streaming platform, the AVOD tier and the subscriber, billing and entitlement stack, so activation, engagement, retention and monetisation are my operating numbers today.']],
            ['Recruiting and leading lean early-stage teams', 'Hired and led the founding team at the CDN startup, built the live video organisation at Amazon Channels, and today run a lean technology group at Great American Media alongside McLeod Studios, a content and technology studio.'],
            ['Hands-on with product and user research', 'I am the customer for this product. Pure Flix has a catalog to enrich and an ad stack to feed, with AVOD launching in Q1 2027, and our studio brings editorial and creative judgment to the demo, not only engineering.'],
            ['Data-driven, rapid iteration, cross-functional', 'SGEUL went through seven shipped versions in less than a week, each with tests, a status doc and a published demo. Emmy Award winner, BEng from Edinburgh Napier University, executive education from Harvard Business School.'],
          ],
          [3000, 6360],
        ),

        h2('The plan, on the posting’s own clock'),
        lead('First 90 days. ', 'Run customer discovery with the buyers I already know across streamers, studios and publishers, and narrow to two wedges. My starting hypothesis is ad operations (break planning, brand safety, creative fit, SSAI-ready exports) because it has the clearest ROI and the shortest path to revenue, with editorial metadata as the second wedge because every catalog needs it and it compounds into search and discovery. Place SGEUL-derived prototypes with three to five design partners, define production quality thresholds per capability (marker accuracy to the frame, break acceptance rate by human reviewers, fit-score agreement), and close the first hires: a product engineer, a media-workflow designer and a forward-deployed engineer. Two further products are already scoped: a discovery product that improves recommendations and content discovery for media companies, and an operations “flow” product that streamlines day-to-day operations for streamers, film and TV distributors of every size.'),
        lead('By month three. ', 'Launch a real product to the focused users with usage instrumentation on every model call and every human override, so we can show time saved per title, faster ad-ops decisions and the cost per enriched hour. Feed what we learn back to the platform and model teams as concrete asks: schema features Pegasus rejects, the vocabulary drift we see across titles, latency on long-form analyze tasks. Turn the reusable parts (the planner, the fit scorer, the exports, the MCP surface) into capabilities any future application inherits.'),
        lead('By month six. ', 'A credible path to product-market fit in the first wedge with paying design partners, a pricing model that sits on top of API consumption, and a portfolio thesis for what comes next: sports highlights and clipping, compliance and localisation, and agent-first workflows where the MCP server is the product. The compounding advantage is that every application makes the models more valuable and every customer conversation makes the applications sharper.'),

        h2('Four paths into this role, and I have walked all four'),
        body('The posting lists four acceptable backgrounds. Founder who validated a wedge and built a team: the CDN startup, sold to Limelight. Zero-to-one product leader with post-launch growth accountability: the platforms at Turner/CNN and Comcast, then live video at Amazon. Technical leader who owned business outcomes: HBO Max and WarnerMedia, and today Great American Media. What none of those paths captures is that I have also spent years as the customer for this exact product category, which shortens discovery and gives the team a live catalog and ad stack to ship against from day one.'),
        h3('The fourth path: the Snowflake investment proposal and technical analysis'),
        body('I developed the investment proposition and technical analysis for Snowflake that led to its investment in TwelveLabs, so I have already made the case for your models once, to a demanding audience, and it landed. I believe Bill Stratton tried to make an introduction after that investment closed. This brief is the second time I am making the case, and this time it comes with a working product.'),

        h2('Architecture'),
        figure,
        P([['Figure 1. SGEUL on TwelveLabs: customer media on the left, TwelveLabs models in the middle, a thin deterministic application core, and the surfaces where the value lands. The three dollar lines are the three ways revenue accrues.', { italics: true, color: '555555', size: 19 }]], { spacing: { after: 160 } }),
        body('The architecture is deliberately thin. TwelveLabs does all of the understanding: assets are uploaded or synced from the account, Marengo indexes and embeds them, Pegasus answers one JSON-schema prompt per capability, and Jockey provides the agent path over the same knowledge store. The application core adds only what the models should not be asked to do: prompts and schemas kept in one file so a new capability is an afternoon of work; a pipeline runner that sequences nine jobs per title and streams progress; deterministic engines for pod planning, creative fit, similarity, curation and exports so a re-plan, a policy change or a new creative never re-spends a model call; and a store that keeps human review state next to every model output. The surfaces are the same primitives three ways: the web Labs for non-technical operators, the REST API for customer systems, and an MCP server so agents can run the whole ad-ops or editorial workflow. Deliverables leave in the formats the industry already consumes: VMAP with inline VAST and SCTE-35 for server-side ad insertion, markers, thumbnails and clips for CMS and players, and a stitched preview for sign-off.'),
        body('Two properties matter commercially. Every application feature maps to metered consumption of index, analyze, embed and search, so application adoption is model revenue. And because the core is small, the same code ships as a hosted product, an on-prem package for studios with rights constraints, or a white-label module inside a partner platform.'),

        h2('Code overview'),
        body('SGEUL is a TypeScript monorepo of about 20,000 lines across four packages, with 62 automated tests. Nothing in it is a wrapper around a vendor SDK: the TwelveLabs client is a small fetch layer so a reader can see exactly which endpoint each feature calls.'),
        table(
          ['Package', 'What it holds', 'Size'],
          [
            ['packages/core', 'TwelveLabs client (assets, indexes, search, analyze, embed) with schema sanitiser; the seven Pegasus prompts and JSON schemas plus the ad-creative prompt; the nine-job enrichment pipeline; the deterministic pod planner, creative-fit scorer and embedding similarity; shared types that every surface speaks; a mock client that replays real captured output so the product runs with no key.', '4,300 lines, 10 files'],
            ['apps/api', 'Express 5 REST API: catalog, jobs, search, lists, recipes, ad creatives, fit and auto-assign, stitched previews, TwelveLabs account sync and import, VMAP / SCTE-35 / marker exports, Server-Sent Events, Range-capable media streaming, ffmpeg stitcher, atomic JSON store, optional basic-auth gate. Serves the built web app in production.', '3,200 lines, 11 files'],
            ['apps/web', 'Vite + React app: Overview, Editorial Lab, Creative Lab, Operations Lab, Discovery, API docs and Settings, with a frame-accurate player and timeline, emotion-arc chart, probability tag chips, ad library and creative-fit inspector. Two data providers: live HTTP and a static bundle, so the same UI ships as a single HTML file.', '11,100 lines, 27 files'],
            ['apps/mcp', 'Model Context Protocol server exposing 29 tools, 2 resources and 2 prompts over the same API, so Claude or any agent can ingest, search, plan breaks, fingerprint creatives, assign by fit, render previews and export.', '1,100 lines, 3 files'],
            ['data/', 'Seed catalog (five titles, two creatives) built from raw TwelveLabs responses kept in data/real with token usage per call; the runtime store; renders.', 'real model output'],
          ],
          [2000, 5760, 1600],
          true,
        ),
        new Paragraph({ spacing: { after: 60 } }),
        h3('How a title flows through the pipeline'),
        body('Ingest uploads or links an asset and indexes it in Marengo (HLS and thumbnails come back with it). Then seven Pegasus calls, each a prompt plus a JSON schema: fingerprint (genres, keywords, moods, themes, characters, pacing, rating, synopsis in nine languages), emotion arc (valence, arousal, dominance every 20 to 30 seconds with acts and a climax), markers (intro, recap, chapters, credits to the frame), safety (timestamped segments by category and severity), ad-break candidates (natural pauses with the mood, keywords and IAB categories on either side), thumbnails (factor scores and crops for four aspect ratios) and clips (in and out points with a 9:16 reframe path). A Marengo embedding closes the run. Every model output is stamped with the model version and time and stored next to the human review state for that title.'),
        h3('What is deliberately not a model call'),
        body('The pod planner takes Pegasus candidates and applies policy: target count, minimum spacing, head and tail fences, no cut within 45 seconds of a high-severity safety segment, never on rising arousal, ranked and windowed. The creative-fit scorer compares a break to a creative on mood, keywords, IAB and safety agreement and returns the overlaps that produced the number. Similarity, curation, frame maths, SCTE-35 timing and VMAP generation are pure code too. That is why re-planning is instant, results are reproducible, every number can be audited, and a policy change costs nothing in tokens.'),
        h3('How a new capability is added'),
        body('One prompt-and-schema function in core, one job in the pipeline, one route in the API, one tool in the MCP server, one panel in the web app. The ad-creative fingerprint added in the latest version followed exactly that path, with tests at each layer, in a few hours. The same shape carries to sports clipping, compliance review or localisation prep: new prompts and new exports on an unchanged core.'),
        h3('Operating modes and deployment'),
        body('With no API key the product runs in mock mode against the captured real output, so a prospect can try every screen in a browser with zero setup. With a key it runs live against the TwelveLabs account, syncing assets already uploaded there and enriching new ones. The repo ships with prebuilt bundles, a one-click start script and a server install script (Node, nginx, ffmpeg, systemd), and the single-file demo runs from any host. Tests cover the client, the schemas, the planner, the fit scorer, the API end to end and the ffmpeg stitcher.'),

        h2('Strategy to grow TwelveLabs revenue'),
        body('TwelveLabs today earns consumption revenue from developers who build on the API. The applications business adds layers on top of that, each of which also pulls consumption through, and it changes who the buyer is: from an engineering lead with a budget line to a head of ad sales, a head of content operations or a head of product with a P&L. I look at the market through three lenses, and every product we ship should score on at least one: improving content creation, production and management; enhancing and personalising the audience experience; and improving monetisation, whether directly through advertising and subscription or indirectly through retention and operating cost.'),
        bullet('Sell outcomes, price on top of consumption. ', 'Package the Labs as products with a price per enriched hour and per operator seat, sitting above list consumption. At list rates a fully enriched hour today costs roughly 15 dollars of models (index, seven analyze passes, embedding); the demo catalog cost about 34 dollars for 2.2 hours. Metadata and ad-intelligence vendors charge several times that per hour, so there is room for an application margin that still undercuts incumbents while every enriched hour books model revenue. Contracts start with a design-partner tier (fixed fee, capped hours) and graduate to annual commits with consumption drawdown.'),
        bullet('Lead with ad operations, because it is measured in dollars. ', 'A publisher moving from fixed-interval to context-aware mid-rolls can show fill, CPM and completion changes within a quarter, and brand-safety exports remove a manual review step they already pay for. Wedge one is the Operations Lab sold to AVOD and FAST operators, with the stitched preview and SSAI exports as the closing demo. Wedge two is editorial metadata sold to catalog owners, which every title needs and which compounds into search and discovery spend.'),
        bullet('Make partners the distribution. ', 'The exports are the integration. Certify VMAP and SCTE-35 output with the SSAI vendors, ship the markers and thumbnail formats into the major OVPs and players, and offer the enrichment pipeline as a module inside MAM and CMS platforms on a revenue share. A partner that embeds TwelveLabs brings hundreds of catalogs without a direct sales cycle for each, and consumption follows the catalogs.'),
        bullet('Own the agent channel. ', 'The MCP server turns every capability into a tool an agent can call, which is how ad-ops and editorial work will increasingly be done. Publish it as an official TwelveLabs MCP, meter tool calls the same way as API calls, and make Jockey plus the application tools the default video stack in the agent ecosystems. This is a channel no incumbent metadata vendor has.'),
        bullet('Expand by vertical from the same core. ', 'Once the core is proven on entertainment catalogs, the next products are largely new prompts and new exports: sports highlights and clipping, news and compliance review, localisation and dubbing prep, and creative testing for agencies. Each vertical adds a buyer, a price list and more indexed hours on the same platform.'),
        bullet('Land with a customer who is already in hand. ', 'Pure Flix is a live catalog with an AVOD launch planned for Q1 2027. Using it as the first design partner gives the applications team real usage data, an honest ROI case study and a reference in the first quarter rather than the first year.'),
        body('The measure of success is simple: application revenue as its own line, the share of TwelveLabs consumption that arrives through applications and partners rather than direct API integration, and net revenue retention of application customers as they add hours, seats and verticals.'),

        h2('In summary'),
        body('TwelveLabs provides the AI that finds and understands video, and Jockey is the agent that lets anyone ask questions of an entire video and photo library and have the system work out how to answer. What I add is the ability to turn that into applications and products that bring new revenue streams to TwelveLabs quickly, judged through the three lenses above: better content creation, production and management; richer and more personal audience experiences; and stronger monetisation, direct or indirect. I have run this playbook at the largest media companies in the world and at a startup I sold. Now I want to run it for the company whose models make it possible.'),
        P([['The demo at ', { italics: true, color: '444444' }], link('sgeul.com', 'http://sgeul.com'), [', the code, and this brief are ready to walk through whenever you are.', { italics: true, color: '444444' }]], { spacing: { before: 120, after: 200 } }),
        P([['Euan McLeod', { bold: true }]], { spacing: { after: 40 } }),
        P([link('www.euanmcleod.com', 'http://www.euanmcleod.com')], { spacing: { after: 40 } }),
        P([link('linkedin.com/in/euanmcleod', 'https://www.linkedin.com/in/euanmcleod/')], { spacing: { after: 40 } }),
        P([['Demo: ', { bold: true }], link('sgeul.com', 'http://sgeul.com')]),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  writeFileSync(out, buf);
  console.log('wrote', out);
});
