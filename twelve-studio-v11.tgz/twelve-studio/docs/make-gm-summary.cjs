const {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  BorderStyle,
  Table,
  TableRow,
  TableCell,
  WidthType,
  ShadingType,
  LevelFormat,
  AlignmentType,
} = require('docx');
const { writeFileSync } = require('node:fs');

const font = 'Calibri';
const SIZE = 21;
const run = (text, opts = {}) => new TextRun({ text, font, size: SIZE, ...opts });
const body = (text, opts = {}) => new Paragraph({ spacing: { after: 110, line: 270 }, children: [run(text, opts)] });
const mixed = (runs, para = {}) => new Paragraph({ spacing: { after: 110, line: 270 }, ...para, children: runs.map(([t, o]) => run(t, o || {})) });
const h = (text) =>
  new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 260, after: 90 },
    children: [new TextRun({ text, font, size: 26, bold: true, color: '111111' })],
  });
const bullet = (runs) =>
  new Paragraph({
    numbering: { reference: 'bullets', level: 0 },
    spacing: { after: 60, line: 264 },
    children: (Array.isArray(runs) ? runs : [[runs, {}]]).map(([t, o]) => run(t, o || {})),
  });

const cell = (children, opts = {}) =>
  new TableCell({
    width: { size: opts.width, type: WidthType.DXA },
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    shading: opts.shade ? { type: ShadingType.CLEAR, fill: opts.shade, color: 'auto' } : undefined,
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: 'DDDDDD' },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: 'DDDDDD' },
      left: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
      right: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
    },
    children: children.map((c) => (typeof c === 'string' ? new Paragraph({ spacing: { after: 40, line: 250 }, children: [run(c, { size: 19 })] }) : c)),
  });

const W1 = 3000;
const W2 = 6360;
const fitTable = (rows) =>
  new Table({
    width: { size: W1 + W2, type: WidthType.DXA },
    columnWidths: [W1, W2],
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          cell([new Paragraph({ children: [run('What the role asks for', { bold: true, size: 19 })] })], { width: W1, shade: 'F3F3F3' }),
          cell([new Paragraph({ children: [run('Where I have done it', { bold: true, size: 19 })] })], { width: W2, shade: 'F3F3F3' }),
        ],
      }),
      ...rows.map(
        ([ask, evidence]) =>
          new TableRow({
            children: [cell([new Paragraph({ spacing: { after: 40, line: 250 }, children: [run(ask, { bold: true, size: 19 })] })], { width: W1 }), cell([evidence], { width: W2 })],
          }),
      ),
    ],
  });

const doc = new Document({
  styles: { default: { document: { run: { font, size: SIZE } } } },
  numbering: {
    config: [
      {
        reference: 'bullets',
        levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 440, hanging: 240 } } } }],
      },
    ],
  },
  sections: [
    {
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1150, bottom: 1000, left: 1440, right: 1440 } } },
      children: [
        new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: 'Euan McLeod for Head of Applications', font, size: 34, bold: true, color: '111111' })] }),
        new Paragraph({
          spacing: { after: 240 },
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'F5C518', space: 6 } },
          children: [run('A brief for the TwelveLabs CEO, written against the Head of Applications posting', { color: '666666' })],
        }),

        body(
          'The posting describes a builder-GM: someone who sets the application-layer strategy, finds the wedge through customer discovery and rapid prototyping, ships AI-native products for non-technical users, owns activation through monetization, and recruits a lean team that moves fast. That is the job I have been doing for two weeks on your API without being asked, and it is the job I have done at company scale at Amazon, WarnerMedia and Comcast. This brief maps what you are hiring for to what I have already delivered.',
        ),

        h('The prototype is already in users’ hands'),
        body(
          'SGEUL is a Vionlabs-class media intelligence suite built entirely on Marengo and Pegasus. It is the kind of application the posting asks for in the first 90 days: a working prototype, placed with a user (Pure Flix, where I am CTO), with production quality thresholds defined and every number traceable to a model call.',
        ),
        bullet([['Editorial Lab: ', { bold: true }], ['title fingerprints (genres, moods, themes, characters, pacing, rating, synopsis in nine languages), smart lists with confidence-range rules, natural-language lists and AI curation over Marengo embeddings.', {}]]),
        bullet([['Operations Lab: ', { bold: true }], ['continuous emotion arcs, intro/recap/credits markers to the frame, timestamped brand safety, ad-break windows from a deterministic pod planner, creative intelligence for every ad spot with contextual fit scoring, review workflow, VMAP with inline VAST, SCTE-35 and a stitched MP4 preview.', {}]]),
        bullet([['Creative Lab and Discovery: ', { bold: true }], ['thumbnails and vertical clips from a free-text brief, any-to-video moment search, similar titles with reasons.', {}]]),
        bullet([['Platform surface: ', { bold: true }], ['a REST API, an MCP server with 29 tools so any agent can run ad operations end to end, account asset sync so anything uploaded to TwelveLabs is enriched without re-upload, and a cost ledger that shows the list price of every hour indexed.', {}]]),
        body(
          'The proof point is a 92-minute feature with five mid-rolls chosen by the planner, a Kinder Bueno spot fingerprinted by Pegasus and scored for fit against each break, then stitched into a watchable preview at keyframe-accurate insertion points. The whole catalog was enriched for roughly 34 dollars of API usage. Vionlabs needed years and its own models to reach this feature surface; on TwelveLabs each capability is a prompt and a JSON schema, which is the strongest product argument the company can make and the one the applications team should be making every day.',
        ),

        h('How my record maps to the posting'),
        fitTable([
          [
            'Zero to meaningful adoption',
            mixed([
              ['Founded a CDN startup and took it from nothing to an acquisition by Limelight Networks. Built SGEUL from an empty folder to a deployed, tested product on your API in two weeks. Stood up new video platforms at Turner/CNN and Comcast (VIPER) that customers still run on.', {}],
            ]),
          ],
          [
            'Product judgment that simplifies complex technology',
            mixed([
              ['Every SGEUL screen turns a model response into a decision a media operator already understands: a break window with a confidence, a fit score with the words that produced it, a VMAP file a player can load. As ', {}],
              ['SVP Technology at HBO Max and WarnerMedia', { bold: true }],
              [' I did the same at the scale of one of the largest premium catalogs in the world.', {}],
            ]),
          ],
          [
            'Technical fluency on architecture, latency, reliability and cost',
            mixed([
              ['As ', {}],
              ['Global Head of Live Video at Amazon', { bold: true }],
              [', including NFL Thursday Night Football, I owned delivery where latency and reliability were measured live by millions of viewers and every ad pod had to land on the frame. Deep background in encoding, DRM, CDN and device ecosystems. I read and write the code in the demo.', {}],
            ]),
          ],
          [
            'Understands AI-native product challenges',
            mixed([
              ['SGEUL is designed around model behaviour: calibrated probabilities instead of booleans, open vocabularies bounded in count, schema-constrained outputs with a sanitiser for what Pegasus rejects, deterministic post-processing so re-planning never re-spends tokens, and honest scores when the answer is “this creative does not fit here”.', {}],
            ]),
          ],
          [
            'Growth leadership beyond acquisition',
            mixed([
              ['As ', {}],
              ['CTO of Great American Media', { bold: true }],
              [' (Pure Flix) I own the streaming platform, the AVOD tier and the subscriber, billing and entitlement stack, so activation, engagement, retention and monetization are my operating numbers today, not a job description.', {}],
            ]),
          ],
          [
            'Recruiting and leading lean early-stage teams',
            mixed([['Hired and led the founding team at the CDN startup, built the live video organisation at Amazon, and today run a lean technology group at Great American Media plus McLeod Studios, a content and technology studio.', {}]]),
          ],
          [
            'Hands-on with product and user research',
            mixed([['I am the customer for this product. Pure Flix has a catalog to enrich and an ad stack to feed, and McLeod Studios brings editorial and creative judgment to the demo, not only engineering.', {}]]),
          ],
          [
            'Data-driven, rapid iteration, cross-functional',
            mixed([['SGEUL went through seven shipped versions in two weeks, each with tests, a status doc and a published demo. Emmy Award winner, BEng from Edinburgh Napier University, executive education from Harvard Business School.', {}]]),
          ],
        ]),

        h('The plan, on the posting’s own clock'),
        mixed([['First 90 days. ', { bold: true }], ['Run customer discovery with the buyers I already know across streamers, studios and publishers, and narrow to two wedges. My starting hypothesis is ad operations (break planning, brand safety, creative fit, SSAI-ready exports) because it has the clearest ROI and the shortest path to revenue, with editorial metadata as the second wedge because every catalog needs it and it compounds into search and discovery. Place SGEUL-derived prototypes with three to five design partners, define production quality thresholds per capability (marker accuracy to the frame, break acceptance rate by human reviewers, fit score agreement), and close the first hires: a product engineer, a media-workflow designer and a forward-deployed engineer.', {}]]),
        mixed([['By month three. ', { bold: true }], ['Launch a real product to the focused users with usage instrumentation on every model call and every human override, so we can show time saved per title, faster ad-ops decisions and the cost per enriched hour. Feed what we learn back to the platform and model teams as concrete asks: schema features Pegasus rejects, the vocabulary drift we see across titles, latency on long-form analyze tasks. Turn the reusable parts (the planner, the fit scorer, the exports, the MCP surface) into capabilities any future application inherits.', {}]]),
        mixed([['By month six. ', { bold: true }], ['A credible path to product-market fit in the first wedge with paying design partners, a pricing model that sits on top of API consumption, and a portfolio thesis for what comes next: sports highlights and clipping, compliance and localisation, and agent-first workflows where the MCP server is the product. The compounding advantage is that every application makes the models more valuable and every customer conversation makes the applications sharper.', {}]]),

        h('Why the background path fits'),
        body(
          'The posting lists four acceptable paths. I have walked three of them: founder who validated a wedge and built a team, zero-to-one product leader with post-launch growth accountability, and a technical leader who owned business outcomes. The one thing I would add is that I have also spent years as the customer for this exact product category, which shortens discovery and gives the team a live catalog and ad stack to ship against from day one.',
        ),

        body('The demo, the code, and this brief are ready to walk through whenever you are.', { italics: true, color: '444444' }),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  writeFileSync(process.argv[2], buf);
  console.log('wrote', process.argv[2]);
});
