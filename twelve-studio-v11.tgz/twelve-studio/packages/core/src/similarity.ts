/**
 * Vector maths for discovery: cosine similarity, deterministic k-means and
 * cluster labelling. Marengo embeddings are the primary signal; when an item
 * has no embedding yet, `labelVector()` builds a hashed bag-of-labels vector
 * from its fingerprint so similarity/curation still work (and the mock client
 * uses the same construction, which keeps demos coherent).
 */

import type { CatalogItem, Fingerprint, SimilarTitle } from './types.js';
import { hash32, seededRandom, topLabels } from './util.js';

export function cosine(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length);
  if (n === 0) return 0;
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < n; i++) {
    const x = a[i] ?? 0;
    const y = b[i] ?? 0;
    dot += x * y;
    na += x * x;
    nb += y * y;
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

export function normalise(v: number[]): number[] {
  const n = Math.sqrt(v.reduce((acc, x) => acc + x * x, 0));
  return n === 0 ? v.slice() : v.map((x) => x / n);
}

/* ------------------------------------------------------------------ */
/* Hashed label vectors (fallback embedding)                           */
/* ------------------------------------------------------------------ */

export const LABEL_VECTOR_DIM = 512;

/** Deterministic pseudo-random unit vector for a token. */
export function tokenVector(token: string, dim = LABEL_VECTOR_DIM): number[] {
  const rnd = seededRandom(hash32(token.toLowerCase().trim()));
  const v = new Array<number>(dim);
  for (let i = 0; i < dim; i++) v[i] = rnd() * 2 - 1;
  return normalise(v);
}

/** Weighted sum of token vectors for free text (used for NL queries in fallback/mock mode). */
export function textVector(text: string, dim = LABEL_VECTOR_DIM): number[] {
  const tokens = text
    .toLowerCase()
    .split(/[^a-z0-9À-ɏ]+/)
    .filter((t) => t.length > 2 && !STOPWORDS.has(t));
  const acc = new Array<number>(dim).fill(0);
  for (const t of tokens) {
    const tv = tokenVector(t, dim);
    for (let i = 0; i < dim; i++) acc[i] = (acc[i] ?? 0) + (tv[i] ?? 0);
  }
  return normalise(acc);
}

/** Bag-of-labels vector from a fingerprint: every scored label contributes weight × token vector. */
export function labelVector(fp: Pick<Fingerprint, 'genres' | 'keywords' | 'moods' | 'moodTags' | 'themes'>, dim = LABEL_VECTOR_DIM): number[] {
  const acc = new Array<number>(dim).fill(0);
  const facets: Array<[Record<string, number>, number]> = [
    [fp.genres, 1.2],
    [fp.keywords, 1.0],
    [fp.moods, 0.9],
    [fp.moodTags, 0.8],
    [fp.themes, 0.9],
  ];
  for (const [labels, facetWeight] of facets) {
    for (const [label, score] of Object.entries(labels ?? {})) {
      for (const token of label.toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 2)) {
        const tv = tokenVector(token, dim);
        const w = facetWeight * score;
        for (let i = 0; i < dim; i++) acc[i] = (acc[i] ?? 0) + w * (tv[i] ?? 0);
      }
    }
  }
  return normalise(acc);
}

const STOPWORDS = new Set([
  'the', 'and', 'with', 'for', 'that', 'this', 'from', 'about', 'into', 'over', 'movie', 'film', 'video', 'show', 'title', 'titles',
  'find', 'give', 'want', 'something', 'like', 'very', 'has', 'have', 'are', 'was', 'were', 'not',
]);

/* ------------------------------------------------------------------ */
/* k-means                                                              */
/* ------------------------------------------------------------------ */

export interface KMeansResult {
  assignments: number[];
  centroids: number[][];
  iterations: number;
}

/** Deterministic k-means (seeded k-means++ init, cosine distance on normalised vectors). */
export function kmeans(vectors: number[][], k: number, opts: { seed?: number; maxIterations?: number } = {}): KMeansResult {
  const n = vectors.length;
  if (n === 0) return { assignments: [], centroids: [], iterations: 0 };
  const kk = Math.max(1, Math.min(k, n));
  const rnd = seededRandom(opts.seed ?? 12);
  const data = vectors.map(normalise);
  const dist = (a: number[], b: number[]) => 1 - cosine(a, b);

  // k-means++ seeding
  const centroids: number[][] = [data[Math.floor(rnd() * n)]!.slice()];
  while (centroids.length < kk) {
    const d2 = data.map((v) => Math.min(...centroids.map((c) => dist(v, c))) ** 2);
    const total = d2.reduce((a, b) => a + b, 0);
    let r = rnd() * total;
    let idx = 0;
    for (let i = 0; i < n; i++) {
      r -= d2[i] ?? 0;
      if (r <= 0) {
        idx = i;
        break;
      }
      idx = i;
    }
    centroids.push(data[idx]!.slice());
  }

  let assignments = new Array<number>(n).fill(0);
  let iterations = 0;
  const maxIter = opts.maxIterations ?? 50;
  for (; iterations < maxIter; iterations++) {
    const next = data.map((v) => {
      let best = 0;
      let bestD = Infinity;
      centroids.forEach((c, ci) => {
        const d = dist(v, c);
        if (d < bestD) {
          bestD = d;
          best = ci;
        }
      });
      return best;
    });
    const changed = next.some((a, i) => a !== assignments[i]);
    assignments = next;
    // recompute centroids
    const dim = data[0]!.length;
    for (let ci = 0; ci < kk; ci++) {
      const members = data.filter((_, i) => assignments[i] === ci);
      if (members.length === 0) continue;
      const sum = new Array<number>(dim).fill(0);
      for (const m of members) for (let i = 0; i < dim; i++) sum[i] = (sum[i] ?? 0) + (m[i] ?? 0);
      centroids[ci] = normalise(sum.map((x) => x / members.length));
    }
    if (!changed) break;
  }
  return { assignments, centroids, iterations };
}

/** k for AI curation: clamp(items / 6, 3, 12) but never more than items. */
export function curationK(itemCount: number): number {
  return Math.max(1, Math.min(itemCount, Math.max(3, Math.min(12, Math.round(itemCount / 6)))));
}

/* ------------------------------------------------------------------ */
/* Labelling + explanations                                            */
/* ------------------------------------------------------------------ */

export interface ClusterLabel {
  name: string;
  description: string;
  /** Labels shared by most members, best first. */
  sharedLabels: string[];
}

/** Name a cluster by the moods/keywords/genres its members share most strongly. */
export function labelCluster(items: Array<Pick<CatalogItem, 'title' | 'fingerprint'>>): ClusterLabel {
  const fps = items.map((i) => i.fingerprint).filter((f): f is Fingerprint => !!f);
  if (fps.length === 0) {
    return { name: 'Untagged titles', description: 'Titles without a fingerprint yet.', sharedLabels: [] };
  }
  const score = (facet: keyof Pick<Fingerprint, 'moods' | 'keywords' | 'genres' | 'themes' | 'moodTags'>) => {
    const acc = new Map<string, { sum: number; count: number }>();
    for (const fp of fps) {
      for (const [label, s] of Object.entries(fp[facet] ?? {})) {
        const cur = acc.get(label) ?? { sum: 0, count: 0 };
        cur.sum += s;
        cur.count += 1;
        acc.set(label, cur);
      }
    }
    // Reward labels present in many members with high confidence.
    return [...acc.entries()]
      .map(([label, { sum, count }]) => ({ label, score: (sum / fps.length) * (0.5 + 0.5 * (count / fps.length)) }))
      .sort((a, b) => b.score - a.score);
  };
  const moods = score('moods');
  const genres = score('genres');
  const keywords = score('keywords');
  const themes = score('themes');

  const mood = moods[0]?.label;
  const genre = genres[0]?.label;
  const name = [mood, genre].filter((x): x is string => !!x).map(titleCase).join(' ') || titleCase(keywords[0]?.label ?? 'Mixed');
  const shared = [...moods.slice(0, 2), ...keywords.slice(0, 3), ...themes.slice(0, 2)].map((x) => x.label);
  const description = `${fps.length} title${fps.length === 1 ? '' : 's'} sharing ${shared.slice(0, 4).join(', ')}.`;
  return { name, description, sharedLabels: Array.from(new Set(shared)) };
}

function titleCase(s: string): string {
  return s.replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Explain a similarity match by the facets two fingerprints share. */
export function sharedFacets(a: Fingerprint, b: Fingerprint, limit = 4): string[] {
  const out: Array<{ label: string; w: number }> = [];
  const facets: Array<keyof Pick<Fingerprint, 'genres' | 'moods' | 'themes' | 'keywords' | 'moodTags'>> = [
    'genres',
    'moods',
    'themes',
    'keywords',
    'moodTags',
  ];
  for (const facet of facets) {
    for (const [label, sa] of topLabels(a[facet], 8)) {
      const sb = b[facet]?.[label];
      if (sb !== undefined) out.push({ label: `${label} (${facet})`, w: Math.min(sa, sb) });
    }
  }
  return out
    .sort((x, y) => y.w - x.w)
    .slice(0, limit)
    .map((x) => x.label);
}

/** Rank other items by embedding (or label-vector) cosine similarity. */
export function similarTitles(
  target: CatalogItem,
  pool: CatalogItem[],
  limit = 8,
): SimilarTitle[] {
  const vec = (i: CatalogItem): number[] | undefined =>
    i.fingerprint?.embedding && i.fingerprint.embedding.length > 0
      ? i.fingerprint.embedding
      : i.fingerprint
        ? labelVector(i.fingerprint)
        : undefined;
  const tv = vec(target);
  if (!tv) return [];
  // Compare like with like: if the target has a Marengo embedding but a candidate only has a label
  // vector (different spaces), fall back to label vectors for that pair.
  const tLabel = target.fingerprint ? labelVector(target.fingerprint) : undefined;
  return pool
    .filter((i) => i.id !== target.id && i.fingerprint)
    .map((i) => {
      const iv = vec(i)!;
      const sameSpace = iv.length === tv.length;
      const score = sameSpace ? cosine(tv, iv) : tLabel ? cosine(tLabel, labelVector(i.fingerprint!)) : 0;
      return {
        itemId: i.id,
        title: i.title,
        score: Math.round(Math.max(0, score) * 1000) / 1000,
        because: sharedFacets(target.fingerprint!, i.fingerprint!),
      };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}
