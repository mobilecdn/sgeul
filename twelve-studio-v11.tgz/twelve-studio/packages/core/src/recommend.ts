/**
 * Recommendations — taste profiles, weighted scoring and rails.
 *
 * The signal is the Fingerprint+ every title already carries (genres, mood
 * tags, moods, themes, keywords, pacing, rating) plus the Marengo embedding.
 * Watch events build a *taste profile*: per-facet label affinities, decayed by
 * recency and weighted by how much of the title the viewer actually watched.
 *
 * The combination case is first class. Watching romantic horror does not only
 * raise "horror" and "romance" separately — every pair of signature labels in a
 * watched title is stored in `combos`, so a candidate that carries *both*
 * labels outscores one that carries either alone, and plain horror and plain
 * romance still surface below it. `RecoWeights.combo` is the dial for how
 * strongly that pairing counts, and every weight is set by the app.
 *
 * Everything here is deterministic and dependency-free: the same events and
 * weights always produce the same ranking, which is what makes the weight
 * sliders in the Recommendations lab honest.
 */

import type { CatalogItem, Fingerprint, ScoredLabels } from './types.js';
import { cosine, labelVector } from './similarity.js';
import { clamp, round } from './util.js';

/* ------------------------------------------------------------------ */
/* Vocabulary                                                          */
/* ------------------------------------------------------------------ */

export type RecoFacet = 'genres' | 'moodTags' | 'moods' | 'themes' | 'keywords';

export const RECO_FACETS: RecoFacet[] = ['genres', 'moodTags', 'moods', 'themes', 'keywords'];

/** Facets whose labels form the "signature" of a title (what combos are built from). */
const SIGNATURE_FACETS: RecoFacet[] = ['genres', 'moodTags', 'themes'];

const RATING_ORDER = ['TV-Y', 'G', 'TV-PG', 'PG', 'TV-14', 'PG-13', 'TV-MA', 'R'] as const;

/** Adjective/synonym forms collapse so "romantic" and "romance" are one affinity. */
const ALIASES: Record<string, string> = {
  romantic: 'romance',
  romcom: 'romance',
  'romantic comedy': 'romance',
  love: 'romance',
  scary: 'horror',
  horrific: 'horror',
  terror: 'horror',
  frightening: 'horror',
  comedic: 'comedy',
  funny: 'comedy',
  humour: 'comedy',
  humor: 'comedy',
  dramatic: 'drama',
  thrilling: 'thriller',
  suspense: 'thriller',
  suspenseful: 'thriller',
  'sci fi': 'science fiction',
  'sci-fi': 'science fiction',
  scifi: 'science fiction',
  documentaries: 'documentary',
  animated: 'animation',
  'action-adventure': 'adventure',
  faith: 'faith and family',
  'faith-based': 'faith and family',
  inspirational: 'uplifting',
  heartwarming: 'uplifting',
  hopeful: 'uplifting',
};

/** Lowercase, de-punctuate and fold known synonyms. */
export function canonicalLabel(label: string): string {
  const base = label.toLowerCase().trim().replace(/[_/]+/g, ' ').replace(/\s+/g, ' ');
  return ALIASES[base] ?? base;
}

const comboKey = (a: string, b: string): string => (a < b ? `${a} + ${b}` : `${b} + ${a}`);

/* ------------------------------------------------------------------ */
/* Events + weights                                                    */
/* ------------------------------------------------------------------ */

export type WatchAction = 'watch' | 'like' | 'dislike' | 'skip' | 'impression';

/** One thing a viewer did with one title. The only input the engine needs. */
export interface WatchEvent {
  id: string;
  profileId: string;
  itemId: string;
  action: WatchAction;
  /** 0..1 of the title watched (watch events); absent means "played". */
  completion?: number;
  /** Seconds watched, when the player reports them. */
  seconds?: number;
  at: string;
}

export interface RecoWeights {
  /** How hard each fingerprint facet pulls. Genres and mood tags lead by default. */
  facets: Record<RecoFacet, number>;
  /** Marengo embedding (or hashed label-vector) cosine. */
  embedding: number;
  /** Bonus for matching a *combination* the viewer watches (romance + horror). */
  combo: number;
  /** How much the title just watched steers "up next" versus the long-run profile. */
  seed: number;
  /** Pull towards the viewer's usual pacing. */
  pacing: number;
  /** Pull towards the viewer's usual audience rating. */
  rating: number;
  /** Catalog-wide popularity prior. */
  popularity: number;
  /** 0..1 penalty for a title the viewer already finished. */
  repeatPenalty: number;
  /** MMR trade-off: 0 = pure relevance, 1 = maximum variety within a row. */
  diversity: number;
  /** Half-life in days for recency decay of watch signal. */
  recencyHalfLifeDays: number;
  /** Watches below this completion count as a sample, not a signal. */
  completionFloor: number;
  /** Multiplier on a liked title's contribution. */
  likeBoost: number;
  /** Strength of the negative signal from a dislike or an early skip. */
  dislikePenalty: number;
  /** Drop recommendations scoring below this. */
  minScore: number;
}

export const DEFAULT_RECO_WEIGHTS: RecoWeights = {
  facets: { genres: 1.0, moodTags: 0.8, moods: 0.6, themes: 0.6, keywords: 0.4 },
  embedding: 0.9,
  combo: 1.2,
  seed: 1.0,
  pacing: 0.25,
  rating: 0.35,
  popularity: 0.2,
  repeatPenalty: 0.8,
  diversity: 0.25,
  recencyHalfLifeDays: 30,
  completionFloor: 0.15,
  likeBoost: 1.5,
  dislikePenalty: 1.0,
  minScore: 0.05,
};

/** Merge a partial weight set over the defaults and clamp every dial to a sane range. */
export function normaliseWeights(partial?: Partial<RecoWeights> | null): RecoWeights {
  const p = partial ?? {};
  const facets = { ...DEFAULT_RECO_WEIGHTS.facets, ...(p.facets ?? {}) };
  for (const f of RECO_FACETS) facets[f] = clamp(Number(facets[f] ?? 0) || 0, 0, 3);
  const num = (v: unknown, fallback: number, min: number, max: number) =>
    clamp(typeof v === 'number' && Number.isFinite(v) ? v : fallback, min, max);
  return {
    facets,
    embedding: num(p.embedding, DEFAULT_RECO_WEIGHTS.embedding, 0, 3),
    combo: num(p.combo, DEFAULT_RECO_WEIGHTS.combo, 0, 3),
    seed: num(p.seed, DEFAULT_RECO_WEIGHTS.seed, 0, 3),
    pacing: num(p.pacing, DEFAULT_RECO_WEIGHTS.pacing, 0, 3),
    rating: num(p.rating, DEFAULT_RECO_WEIGHTS.rating, 0, 3),
    popularity: num(p.popularity, DEFAULT_RECO_WEIGHTS.popularity, 0, 3),
    repeatPenalty: num(p.repeatPenalty, DEFAULT_RECO_WEIGHTS.repeatPenalty, 0, 1),
    diversity: num(p.diversity, DEFAULT_RECO_WEIGHTS.diversity, 0, 1),
    recencyHalfLifeDays: num(p.recencyHalfLifeDays, DEFAULT_RECO_WEIGHTS.recencyHalfLifeDays, 0.5, 3650),
    completionFloor: num(p.completionFloor, DEFAULT_RECO_WEIGHTS.completionFloor, 0, 1),
    likeBoost: num(p.likeBoost, DEFAULT_RECO_WEIGHTS.likeBoost, 0, 5),
    dislikePenalty: num(p.dislikePenalty, DEFAULT_RECO_WEIGHTS.dislikePenalty, 0, 5),
    minScore: num(p.minScore, DEFAULT_RECO_WEIGHTS.minScore, 0, 1),
  };
}

/* ------------------------------------------------------------------ */
/* Taste profile                                                       */
/* ------------------------------------------------------------------ */

export interface TasteProfile {
  profileId: string;
  /** Affinity 0..1 per canonical label, per facet. */
  facets: Record<RecoFacet, ScoredLabels>;
  /** Affinity 0..1 for label *pairs* ("horror + romance"). */
  combos: ScoredLabels;
  /** Mean embedding of watched titles (empty when none carried one). */
  vector: number[];
  /** Mean hashed label vector — always present, used when spaces differ. */
  labelVec: number[];
  /** itemId → strongest completion seen (1 = finished). */
  watched: Record<string, number>;
  /** Every title this viewer has played, liked, skipped or rejected — not recommended again. */
  interacted: string[];
  disliked: string[];
  pacing?: number;
  /** Mean position in RATING_ORDER, 0..1. */
  rating?: number;
  events: number;
  /** Headline labels for the UI, strongest first. */
  top: Array<{ label: string; facet: RecoFacet; weight: number }>;
  topCombos: Array<{ label: string; weight: number }>;
  updatedAt: string;
}

export function emptyProfile(profileId: string): TasteProfile {
  return {
    profileId,
    facets: { genres: {}, moodTags: {}, moods: {}, themes: {}, keywords: {} },
    combos: {},
    vector: [],
    labelVec: [],
    watched: {},
    interacted: [],
    disliked: [],
    events: 0,
    top: [],
    topCombos: [],
    updatedAt: new Date(0).toISOString(),
  };
}

/** Signed engagement for one event: recency-decayed, completion-weighted. */
export function eventWeight(ev: WatchEvent, weights: RecoWeights, now = Date.now()): number {
  const ageDays = Math.max(0, (now - Date.parse(ev.at || '')) / 86_400_000);
  const decay = Number.isFinite(ageDays) ? 2 ** (-ageDays / weights.recencyHalfLifeDays) : 1;
  const completion = clamp(ev.completion ?? 0.5, 0, 1);
  switch (ev.action) {
    case 'like':
      return weights.likeBoost * decay;
    case 'dislike':
      return -weights.dislikePenalty * decay;
    case 'skip':
      return -weights.dislikePenalty * 0.5 * decay;
    case 'impression':
      return 0.05 * decay;
    case 'watch':
    default:
      // Below the floor a play is barely evidence; above it, completion is the signal.
      return (completion < weights.completionFloor ? 0.15 * completion : 0.3 + 0.7 * completion) * decay;
  }
}

/** Build a taste profile from this viewer's events. Deterministic for a fixed `now`. */
export function buildTasteProfile(
  profileId: string,
  events: WatchEvent[],
  items: CatalogItem[],
  weights: RecoWeights = DEFAULT_RECO_WEIGHTS,
  now = Date.now(),
): TasteProfile {
  const byId = new Map(items.map((i) => [i.id, i]));
  const profile = emptyProfile(profileId);
  const acc: Record<RecoFacet, Map<string, number>> = {
    genres: new Map(),
    moodTags: new Map(),
    moods: new Map(),
    themes: new Map(),
    keywords: new Map(),
  };
  const combos = new Map<string, number>();
  const vecSum: number[] = [];
  const labelSum: number[] = [];
  let vecWeight = 0;
  let labelWeight = 0;
  let pacingSum = 0;
  let pacingWeight = 0;
  let ratingSum = 0;
  let ratingWeight = 0;

  const mine = events.filter((e) => e.profileId === profileId);
  for (const ev of mine) {
    const item = byId.get(ev.itemId);
    const fp = item?.fingerprint;
    profile.events += 1;
    if (ev.action !== 'impression' && !profile.interacted.includes(ev.itemId)) profile.interacted.push(ev.itemId);
    if (ev.action === 'watch') {
      profile.watched[ev.itemId] = Math.max(profile.watched[ev.itemId] ?? 0, clamp(ev.completion ?? 0.5, 0, 1));
    }
    if ((ev.action === 'dislike' || ev.action === 'skip') && !profile.disliked.includes(ev.itemId)) {
      profile.disliked.push(ev.itemId);
    }
    if (!fp) continue;
    const w = eventWeight(ev, weights, now);
    if (w === 0) continue;

    for (const facet of RECO_FACETS) {
      for (const [raw, score] of Object.entries(fp[facet] ?? {})) {
        const label = canonicalLabel(raw);
        acc[facet].set(label, (acc[facet].get(label) ?? 0) + w * clamp(score, 0, 1));
      }
    }

    // Pairs of signature labels: this is what makes "romantic horror" its own taste.
    const signature = signatureLabels(fp);
    for (let i = 0; i < signature.length; i++) {
      for (let j = i + 1; j < signature.length; j++) {
        const a = signature[i]!;
        const b = signature[j]!;
        if (a.label === b.label) continue;
        const key = comboKey(a.label, b.label);
        combos.set(key, (combos.get(key) ?? 0) + w * Math.min(a.score, b.score));
      }
    }

    if (w > 0) {
      const lv = labelVector(fp);
      addScaled(labelSum, lv, w);
      labelWeight += w;
      if (fp.embedding && fp.embedding.length > 0) {
        addScaled(vecSum, fp.embedding, w);
        vecWeight += w;
      }
      if (typeof fp.pacing?.score === 'number') {
        pacingSum += w * clamp(fp.pacing.score, 0, 1);
        pacingWeight += w;
      }
      const ri = ratingIndex(fp);
      if (ri !== undefined) {
        ratingSum += w * ri;
        ratingWeight += w;
      }
    }
  }

  for (const facet of RECO_FACETS) profile.facets[facet] = normaliseMap(acc[facet]);
  profile.combos = normaliseMap(combos);
  profile.vector = vecWeight > 0 ? vecSum.map((x) => x / vecWeight) : [];
  profile.labelVec = labelWeight > 0 ? labelSum.map((x) => x / labelWeight) : [];
  if (pacingWeight > 0) profile.pacing = round(pacingSum / pacingWeight, 3);
  if (ratingWeight > 0) profile.rating = round(ratingSum / ratingWeight, 3);
  profile.top = RECO_FACETS.flatMap((facet) =>
    Object.entries(profile.facets[facet]).map(([label, weight]) => ({ label, facet, weight })),
  )
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 12);
  profile.topCombos = Object.entries(profile.combos)
    .map(([label, weight]) => ({ label, weight }))
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 6);
  profile.updatedAt = new Date(now).toISOString();
  return profile;
}

/** The strongest genre/mood-tag/theme labels of a title, canonicalised. */
export function signatureLabels(fp: Fingerprint, perFacet = 3): Array<{ label: string; score: number; facet: RecoFacet }> {
  const out = new Map<string, { label: string; score: number; facet: RecoFacet }>();
  for (const facet of SIGNATURE_FACETS) {
    const entries = Object.entries(fp[facet] ?? {})
      .map(([raw, score]) => ({ label: canonicalLabel(raw), score: clamp(score, 0, 1), facet }))
      .sort((a, b) => b.score - a.score)
      .slice(0, perFacet);
    for (const e of entries) {
      const prev = out.get(e.label);
      if (!prev || prev.score < e.score) out.set(e.label, e);
    }
  }
  return [...out.values()].sort((a, b) => b.score - a.score);
}

function ratingIndex(fp: Fingerprint): number | undefined {
  const i = RATING_ORDER.indexOf(fp.audienceRating?.suggested as (typeof RATING_ORDER)[number]);
  return i < 0 ? undefined : i / (RATING_ORDER.length - 1);
}

function addScaled(acc: number[], v: number[], w: number): void {
  for (let i = 0; i < v.length; i++) acc[i] = (acc[i] ?? 0) + w * (v[i] ?? 0);
}

/** Scale a map so its strongest entry is 1; drop non-positive entries. */
function normaliseMap(m: Map<string, number>): ScoredLabels {
  let max = 0;
  for (const v of m.values()) max = Math.max(max, v);
  const out: ScoredLabels = {};
  if (max <= 0) return out;
  for (const [k, v] of m) {
    if (v <= 0) continue;
    out[k] = round(v / max, 4);
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Scoring                                                             */
/* ------------------------------------------------------------------ */

export interface RecoReason {
  label: string;
  kind: RecoFacet | 'combo' | 'embedding' | 'pacing' | 'rating' | 'popularity' | 'seed';
  weight: number;
}

export interface Recommendation {
  itemId: string;
  title: string;
  score: number;
  /** Each contribution before weighting, 0..1 — what the UI bars show. */
  parts: Record<RecoFacet, number> & {
    combo: number;
    embedding: number;
    pacing: number;
    rating: number;
    popularity: number;
    seed: number;
    penalty: number;
  };
  because: string[];
  reasons: RecoReason[];
  /** Fraction already watched, when the viewer has seen it. */
  seen?: number;
}

export interface ScoreContext {
  profile: TasteProfile;
  weights: RecoWeights;
  /** itemId → 0..1 catalog popularity. */
  popularity?: Record<string, number>;
  /** The title just watched, for "up next". */
  seed?: CatalogItem;
}

/** Weighted affinity between a candidate's labels and the profile's, 0..1. */
function facetMatch(cand: ScoredLabels | undefined, prof: ScoredLabels): number {
  let dot = 0;
  let mass = 0;
  for (const [raw, score] of Object.entries(cand ?? {})) {
    const s = clamp(score, 0, 1);
    mass += s;
    dot += s * (prof[canonicalLabel(raw)] ?? 0);
  }
  return mass > 0 ? clamp(dot / mass, 0, 1) : 0;
}

/**
 * Combination match. Every pair of the candidate's signature labels is looked up
 * in the profile's pair affinities, so a romantic horror scores on
 * "horror + romance" where plain horror only scores on its single labels.
 */
function comboMatch(fp: Fingerprint, profile: TasteProfile): { score: number; hits: Array<{ label: string; weight: number }> } {
  const sig = signatureLabels(fp);
  const hits: Array<{ label: string; weight: number }> = [];
  let best = 0;
  let sum = 0;
  for (let i = 0; i < sig.length; i++) {
    for (let j = i + 1; j < sig.length; j++) {
      const key = comboKey(sig[i]!.label, sig[j]!.label);
      const affinity = profile.combos[key];
      if (!affinity) continue;
      const strength = affinity * Math.min(sig[i]!.score, sig[j]!.score);
      hits.push({ label: key, weight: round(strength, 3) });
      best = Math.max(best, strength);
      sum += strength;
    }
  }
  hits.sort((a, b) => b.weight - a.weight);
  // Strongest pair dominates; further pairs add a little (a title matching two of
  // the viewer's combinations is a better bet than one matching a single pair).
  return { score: clamp(best + 0.25 * Math.max(0, sum - best), 0, 1), hits: hits.slice(0, 4) };
}

/** Cosine between a candidate and a vector, comparing like with like. */
function vectorMatch(fp: Fingerprint, profile: TasteProfile): number {
  if (profile.vector.length > 0 && fp.embedding && fp.embedding.length === profile.vector.length) {
    return clamp(cosine(fp.embedding, profile.vector), 0, 1);
  }
  if (profile.labelVec.length > 0) return clamp(cosine(labelVector(fp), profile.labelVec), 0, 1);
  return 0;
}

function seedMatch(fp: Fingerprint, seed: Fingerprint): number {
  const embed =
    seed.embedding && fp.embedding && seed.embedding.length === fp.embedding.length
      ? clamp(cosine(fp.embedding, seed.embedding), 0, 1)
      : clamp(cosine(labelVector(fp), labelVector(seed)), 0, 1);
  let overlap = 0;
  let n = 0;
  for (const facet of SIGNATURE_FACETS) {
    overlap += facetMatch(fp[facet], canonicalise(seed[facet]));
    n += 1;
  }
  return clamp(0.5 * embed + 0.5 * (n ? overlap / n : 0), 0, 1);
}

function canonicalise(labels: ScoredLabels | undefined): ScoredLabels {
  const out: ScoredLabels = {};
  for (const [raw, score] of Object.entries(labels ?? {})) {
    const k = canonicalLabel(raw);
    out[k] = Math.max(out[k] ?? 0, clamp(score, 0, 1));
  }
  return out;
}

/** Score one candidate against a taste profile (and optionally the title just watched). */
export function scoreItem(item: CatalogItem, ctx: ScoreContext): Recommendation | undefined {
  const fp = item.fingerprint;
  if (!fp) return undefined;
  const { profile, weights } = ctx;

  const parts = {
    genres: 0,
    moodTags: 0,
    moods: 0,
    themes: 0,
    keywords: 0,
    combo: 0,
    embedding: 0,
    pacing: 0,
    rating: 0,
    popularity: 0,
    seed: 0,
    penalty: 0,
  } as Recommendation['parts'];
  const reasons: RecoReason[] = [];

  let total = 0;
  let mass = 0;

  for (const facet of RECO_FACETS) {
    const w = weights.facets[facet] ?? 0;
    const match = facetMatch(fp[facet], profile.facets[facet]);
    parts[facet] = round(match, 3);
    if (w > 0) {
      total += w * match;
      mass += w;
      // Name the individual labels that carried this facet.
      for (const [raw, score] of Object.entries(fp[facet] ?? {})) {
        const label = canonicalLabel(raw);
        const affinity = profile.facets[facet][label] ?? 0;
        if (affinity > 0.15 && score > 0.2) reasons.push({ label, kind: facet, weight: round(w * affinity * score, 3) });
      }
    }
  }

  const combo = comboMatch(fp, profile);
  parts.combo = round(combo.score, 3);
  if (weights.combo > 0) {
    total += weights.combo * combo.score;
    mass += weights.combo;
    for (const hit of combo.hits) reasons.push({ label: hit.label, kind: 'combo', weight: round(weights.combo * hit.weight, 3) });
  }

  const embed = vectorMatch(fp, profile);
  parts.embedding = round(embed, 3);
  if (weights.embedding > 0) {
    total += weights.embedding * embed;
    mass += weights.embedding;
    if (embed > 0.5) reasons.push({ label: 'looks and sounds like what you watch', kind: 'embedding', weight: round(weights.embedding * embed, 3) });
  }

  if (weights.pacing > 0 && profile.pacing !== undefined && typeof fp.pacing?.score === 'number') {
    const match = 1 - Math.abs(clamp(fp.pacing.score, 0, 1) - profile.pacing);
    parts.pacing = round(match, 3);
    total += weights.pacing * match;
    mass += weights.pacing;
    if (match > 0.8) reasons.push({ label: 'similar pacing', kind: 'pacing', weight: round(weights.pacing * match, 3) });
  }

  if (weights.rating > 0 && profile.rating !== undefined) {
    const ri = ratingIndex(fp);
    if (ri !== undefined) {
      const match = 1 - Math.abs(ri - profile.rating);
      parts.rating = round(match, 3);
      total += weights.rating * match;
      mass += weights.rating;
      if (match > 0.85) reasons.push({ label: `rated ${fp.audienceRating.suggested}`, kind: 'rating', weight: round(weights.rating * match, 3) });
    }
  }

  if (weights.popularity > 0) {
    const pop = clamp(ctx.popularity?.[item.id] ?? 0, 0, 1);
    parts.popularity = round(pop, 3);
    total += weights.popularity * pop;
    mass += weights.popularity;
    if (pop > 0.6) reasons.push({ label: 'popular in this catalog', kind: 'popularity', weight: round(weights.popularity * pop, 3) });
  }

  if (ctx.seed?.fingerprint && weights.seed > 0 && ctx.seed.id !== item.id) {
    const match = seedMatch(fp, ctx.seed.fingerprint);
    parts.seed = round(match, 3);
    total += weights.seed * match;
    mass += weights.seed;
    if (match > 0.45) reasons.push({ label: `close to ${ctx.seed.title}`, kind: 'seed', weight: round(weights.seed * match, 3) });
  }

  let score = mass > 0 ? total / mass : 0;

  const seen = profile.watched[item.id];
  if (seen !== undefined) {
    parts.penalty = round(weights.repeatPenalty * seen, 3);
    score -= parts.penalty;
  }
  if (profile.disliked.includes(item.id)) {
    const p = round(weights.dislikePenalty * 0.5, 3);
    parts.penalty = round(parts.penalty + p, 3);
    score -= p;
  }

  reasons.sort((a, b) => b.weight - a.weight);
  return {
    itemId: item.id,
    title: item.title,
    score: round(clamp(score, -1, 1), 4),
    parts,
    reasons: reasons.slice(0, 8),
    because: dedupe(reasons.map((r) => r.label)).slice(0, 4),
    ...(seen !== undefined ? { seen } : {}),
  };
}

function dedupe(values: string[]): string[] {
  return [...new Set(values)];
}

/* ------------------------------------------------------------------ */
/* Ranking + diversity                                                 */
/* ------------------------------------------------------------------ */

export interface RecommendOptions extends ScoreContext {
  pool: CatalogItem[];
  limit?: number;
  /** Titles never to return (the one playing, anything already on another row). */
  exclude?: Iterable<string>;
  /** Keep titles the viewer already watched (off by default). */
  includeWatched?: boolean;
  /** Only titles carrying all of these canonical labels. */
  requireLabels?: string[];
}

/**
 * Rank the catalog for a viewer. `seed` (the title just watched) blends in via
 * `weights.seed`, so this one function serves both "up next" and the home rows.
 */
export function recommend(opts: RecommendOptions): Recommendation[] {
  const { pool, weights, profile } = opts;
  const limit = opts.limit ?? 12;
  const exclude = new Set(opts.exclude ?? []);
  if (opts.seed) exclude.add(opts.seed.id);
  const required = (opts.requireLabels ?? []).map(canonicalLabel);

  const byId = new Map(pool.map((i) => [i.id, i]));
  // Cold start: no history and nothing playing, so popularity and variety carry the row.
  const cold = isColdStart(profile) && !opts.seed;
  const scored: Recommendation[] = [];
  for (const item of pool) {
    if (exclude.has(item.id)) continue;
    // A title the viewer has already played, liked or rejected is not a recommendation;
    // part-watched ones come back in the Continue watching row instead.
    if (!opts.includeWatched && profile.interacted.includes(item.id)) continue;
    if (required.length > 0 && !hasLabels(item, required)) continue;
    const rec = cold ? coldStartRec(item, opts.popularity?.[item.id] ?? 0) : scoreItem(item, opts);
    if (rec && (cold || rec.score >= weights.minScore)) scored.push(rec);
  }
  scored.sort((a, b) => b.score - a.score || a.itemId.localeCompare(b.itemId));
  if (weights.diversity <= 0 || scored.length <= 1) return scored.slice(0, limit);
  return diversify(scored, byId, weights.diversity, limit);
}

/** Ranking for a viewer with no history: popularity, then whatever the catalog offers. */
function coldStartRec(item: CatalogItem, popularity: number): Recommendation | undefined {
  if (!item.fingerprint) return undefined;
  return {
    itemId: item.id,
    title: item.title,
    score: round(0.2 + 0.8 * clamp(popularity, 0, 1), 4),
    parts: {
      genres: 0,
      moodTags: 0,
      moods: 0,
      themes: 0,
      keywords: 0,
      combo: 0,
      embedding: 0,
      pacing: 0,
      rating: 0,
      popularity: round(popularity, 3),
      seed: 0,
      penalty: 0,
    } as Recommendation['parts'],
    because: popularity > 0 ? ['popular in this catalog'] : ['new viewer — no history yet'],
    reasons: [],
  };
}

/** True when the item carries every one of these canonical labels in any facet. */
export function hasLabels(item: CatalogItem, labels: string[]): boolean {
  const fp = item.fingerprint;
  if (!fp) return false;
  const present = new Set<string>();
  for (const facet of RECO_FACETS) for (const raw of Object.keys(fp[facet] ?? {})) present.add(canonicalLabel(raw));
  return labels.every((l) => present.has(l));
}

/**
 * Maximal marginal relevance: each pick trades its score against how close it
 * already is to what the row holds, so a row is not five near-identical titles.
 */
export function diversify(
  ranked: Recommendation[],
  byId: Map<string, CatalogItem>,
  lambda: number,
  limit: number,
): Recommendation[] {
  const vec = (id: string): number[] => {
    const fp = byId.get(id)?.fingerprint;
    if (!fp) return [];
    return fp.embedding && fp.embedding.length > 0 ? fp.embedding : labelVector(fp);
  };
  const picked: Recommendation[] = [];
  const rest = ranked.slice();
  while (picked.length < limit && rest.length > 0) {
    let bestIdx = 0;
    let bestValue = -Infinity;
    for (let i = 0; i < rest.length; i++) {
      const cand = rest[i]!;
      let maxSim = 0;
      for (const p of picked) {
        const a = vec(cand.itemId);
        const b = vec(p.itemId);
        if (a.length && b.length && a.length === b.length) maxSim = Math.max(maxSim, clamp(cosine(a, b), 0, 1));
      }
      const value = (1 - lambda) * cand.score - lambda * maxSim;
      if (value > bestValue) {
        bestValue = value;
        bestIdx = i;
      }
    }
    picked.push(rest.splice(bestIdx, 1)[0]!);
  }
  return picked;
}

/* ------------------------------------------------------------------ */
/* Rails (the home screen)                                             */
/* ------------------------------------------------------------------ */

export type RailKind = 'next' | 'combo' | 'facet' | 'because' | 'foryou' | 'popular' | 'continue';

export interface RecoRail {
  id: string;
  title: string;
  /** One line explaining to an editor why this row exists. */
  reason: string;
  kind: RailKind;
  /** Canonical labels this row is built on. */
  labels: string[];
  items: Recommendation[];
}

export interface RailsOptions {
  profile: TasteProfile;
  pool: CatalogItem[];
  weights: RecoWeights;
  popularity?: Record<string, number>;
  /** Title just watched — drives the "Because you watched" and "Up next" rows. */
  seed?: CatalogItem;
  /** Titles per row. */
  limit?: number;
  /** Maximum rows. */
  maxRails?: number;
}

const titleCase = (s: string): string => s.replace(/\b\w/g, (c) => c.toUpperCase());

/**
 * The rows a player would render. Order is deliberate: the combination the
 * viewer actually watches first, then each single taste that combination is
 * made of, then the broader profile.
 */
export function recommendRails(opts: RailsOptions): RecoRail[] {
  const { profile, pool, weights } = opts;
  const limit = opts.limit ?? 10;
  const maxRails = opts.maxRails ?? 6;
  const rails: RecoRail[] = [];
  // Rows may repeat a title (a romantic horror belongs in both "More Horror + Romance" and
  // "More Horror"), but a label row never repeats what an earlier label row showed, and the
  // catch-all row only holds what no label row covered. What plays next is exempt entirely.
  const used = new Set<string>();
  const take = (rail: RecoRail, claim = true) => {
    if (rail.items.length === 0) return;
    rails.push(rail);
    if (claim) for (const r of rail.items) used.add(r.itemId);
  };

  if (opts.seed) {
    take({
      id: `rail_next`,
      title: `Because you watched ${opts.seed.title}`,
      reason: `Closest titles to ${opts.seed.title}, steered by this viewer's profile.`,
      kind: 'next',
      labels: [],
      items: recommend({ profile, pool, weights, popularity: opts.popularity, seed: opts.seed, limit }),
    }, false);
  }

  // Combination rows: "romantic horror" before "horror" and before "romance".
  const combos = profile.topCombos.filter((c) => c.weight > 0.2).slice(0, 2);
  const comboLabels = new Set<string>();
  for (const combo of combos) {
    if (rails.length >= maxRails) break;
    const labels = combo.label.split(' + ').map(canonicalLabel);
    labels.forEach((l) => comboLabels.add(l));
    const items = recommend({
      profile,
      pool,
      weights,
      popularity: opts.popularity,
      limit,
      exclude: used,
      requireLabels: labels,
    });
    take({
      id: `rail_combo_${labels.join('_')}`,
      title: `More ${labels.map(titleCase).join(' + ')}`,
      reason: `This viewer watches ${labels.join(' and ')} together, so titles carrying both rank first.`,
      kind: 'combo',
      labels,
      items,
    });
  }

  // Then each ingredient on its own, strongest taste first.
  const singles = profile.top
    .filter((t) => t.facet === 'genres' || t.facet === 'moodTags' || t.facet === 'themes')
    .filter((t) => t.weight > 0.25)
    .slice(0, 4);
  for (const single of singles) {
    if (rails.length >= maxRails) break;
    const items = recommend({
      profile,
      pool,
      weights,
      popularity: opts.popularity,
      limit,
      exclude: used,
      requireLabels: [single.label],
    });
    take({
      id: `rail_facet_${single.label.replace(/\s+/g, '_')}`,
      title: `More ${titleCase(single.label)}`,
      reason: comboLabels.has(single.label)
        ? `Part of this viewer's strongest combination, also served on its own.`
        : `A ${single.facet} affinity of ${Math.round(single.weight * 100)}%.`,
      kind: 'facet',
      labels: [single.label],
      items,
    });
  }

  if (rails.length < maxRails) {
    take({
      id: 'rail_foryou',
      title: 'Picked for you',
      reason: 'Whole-profile ranking across every facet, with the row diversified.',
      kind: 'foryou',
      labels: [],
      items: recommend({ profile, pool, weights, popularity: opts.popularity, limit, exclude: used }),
    });
  }

  // Half-finished titles come back regardless of the rest.
  const continueItems = Object.entries(profile.watched)
    .filter(([, c]) => c >= 0.05 && c < 0.9)
    .sort((a, b) => b[1] - a[1])
    .map(([id, c]) => {
      const item = pool.find((i) => i.id === id);
      return item ? { item, completion: c } : undefined;
    })
    .filter((x): x is { item: CatalogItem; completion: number } => !!x)
    .slice(0, limit)
    .map(({ item, completion }) => ({
      itemId: item.id,
      title: item.title,
      score: round(completion, 3),
      parts: {
        genres: 0,
        moodTags: 0,
        moods: 0,
        themes: 0,
        keywords: 0,
        combo: 0,
        embedding: 0,
        pacing: 0,
        rating: 0,
        popularity: 0,
        seed: 0,
        penalty: 0,
      } as Recommendation['parts'],
      because: [`${Math.round(completion * 100)}% watched`],
      reasons: [],
      seen: completion,
    }));
  if (continueItems.length > 0) {
    rails.unshift({
      id: 'rail_continue',
      title: 'Continue watching',
      reason: 'Started but not finished.',
      kind: 'continue',
      labels: [],
      items: continueItems,
    });
  }

  return rails;
}

/* ------------------------------------------------------------------ */
/* Popularity                                                          */
/* ------------------------------------------------------------------ */

/** Catalog popularity 0..1 from every viewer's events (completion-weighted, recency-decayed). */
export function popularityIndex(
  events: WatchEvent[],
  weights: RecoWeights = DEFAULT_RECO_WEIGHTS,
  now = Date.now(),
): Record<string, number> {
  const acc = new Map<string, number>();
  for (const ev of events) {
    const w = eventWeight(ev, weights, now);
    if (w <= 0) continue;
    acc.set(ev.itemId, (acc.get(ev.itemId) ?? 0) + w);
  }
  return normaliseMap(acc);
}

/** A cold-start profile: no history, so popularity and variety carry the ranking. */
export function isColdStart(profile: TasteProfile): boolean {
  return profile.events === 0 || profile.top.length === 0;
}
