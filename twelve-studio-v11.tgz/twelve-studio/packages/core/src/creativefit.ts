/**
 * Creative-to-break fit.
 *
 * An `AdBreak` carries the mood, keywords and IAB categories of the content on
 * either side of the cut; an `AdFingerprint` carries the same three facets for
 * the commercial. `scoreCreativeFit` compares them so ad ops can see, per pod,
 * which spot sits most naturally in the story — the contextual-advertising
 * promise Vionlabs sells, done with one Pegasus call per creative.
 *
 * Pure and deterministic: no model calls, so it re-runs instantly whenever a
 * creative library changes and it is unit-testable.
 *
 * Score = 0.35·mood + 0.30·keywords + 0.20·iab + 0.15·safety, each 0..1.
 *   - mood/keywords: soft label overlap (exact label, shared token, or shared
 *     affect for moods) weighted by both sides' probabilities.
 *   - iab: same id → 1, else category-name overlap (+ tier-1 family bonus).
 *   - safety: 1 when the break is brand-safe and the creative carries no
 *     sensitivities; lower otherwise.
 */

import type { AdBreak, AdCreative, AdFingerprint, CreativeFit, ScoredLabels } from './types.js';
import { round } from './util.js';

/* ------------------------------------------------------------------ */
/* Affect lexicon (valence, arousal) for mood words                    */
/* ------------------------------------------------------------------ */

/** Small hand-made lexicon so "playful" and "lighthearted" agree even though the strings differ. */
const AFFECT: Record<string, [number, number]> = {
  // positive / high arousal
  playful: [0.8, 0.7], humorous: [0.8, 0.6], funny: [0.8, 0.6], whimsical: [0.7, 0.5], lighthearted: [0.8, 0.4], joyful: [0.9, 0.7],
  excited: [0.8, 0.9], energetic: [0.6, 0.9], triumphant: [0.9, 0.8], hopeful: [0.7, 0.4], uplifting: [0.8, 0.6], adventurous: [0.6, 0.8],
  romantic: [0.8, 0.4], tender: [0.7, 0.2], warm: [0.8, 0.3], celebratory: [0.9, 0.8], festive: [0.9, 0.7], cheerful: [0.9, 0.6],
  // positive / low arousal
  serene: [0.7, 0.1], calm: [0.6, 0.1], peaceful: [0.7, 0.1], reflective: [0.3, 0.2], contemplative: [0.3, 0.2], nostalgic: [0.4, 0.2],
  solemn: [0.1, 0.2], reverent: [0.4, 0.2], regal: [0.4, 0.4], awe: [0.6, 0.6], 'awe-inspiring': [0.6, 0.6], wonder: [0.7, 0.5], curious: [0.5, 0.5],
  mysterious: [0.1, 0.5], futuristic: [0.4, 0.6], epic: [0.5, 0.8], grand: [0.5, 0.6], cinematic: [0.4, 0.5], premium: [0.5, 0.3],
  // negative / high arousal
  tense: [-0.5, 0.8], suspenseful: [-0.3, 0.8], anxious: [-0.6, 0.8], fearful: [-0.7, 0.8], scary: [-0.7, 0.8], ominous: [-0.5, 0.6], menacing: [-0.7, 0.7],
  angry: [-0.7, 0.9], violent: [-0.8, 0.9], chaotic: [-0.3, 0.9], dramatic: [-0.1, 0.7], urgent: [-0.2, 0.9], desperate: [-0.7, 0.8], aggressive: [-0.6, 0.9],
  // negative / low arousal
  sad: [-0.7, 0.2], melancholic: [-0.5, 0.2], melancholy: [-0.5, 0.2], somber: [-0.5, 0.2], grief: [-0.8, 0.3], mournful: [-0.7, 0.2], lonely: [-0.6, 0.2],
  uneasy: [-0.4, 0.5], bleak: [-0.7, 0.2], despair: [-0.9, 0.3], tragic: [-0.8, 0.4], bittersweet: [-0.1, 0.3], gloomy: [-0.6, 0.2], isolation: [-0.5, 0.3],
  // neutral-ish
  determined: [0.3, 0.7], determination: [0.3, 0.7], anticipation: [0.3, 0.7], anticipatory: [0.3, 0.7], authoritative: [0.2, 0.5], intense: [-0.1, 0.9],
  informative: [0.2, 0.3], serious: [-0.1, 0.4], quiet: [0.2, 0.1], stillness: [0.2, 0.1],
};

const norm = (s: string) => s.toLowerCase().trim();
const tokens = (s: string) => norm(s).split(/[^a-z0-9]+/).filter((t) => t.length > 2);

/** 0..1 similarity between two labels: exact, token overlap, or (for moods) affect proximity. */
export function labelSimilarity(a: string, b: string, kind: 'mood' | 'keyword' = 'keyword'): number {
  const na = norm(a);
  const nb = norm(b);
  if (na === nb) return 1;
  const ta = tokens(na);
  const tb = tokens(nb);
  const shared = ta.filter((t) => tb.includes(t) || tb.some((u) => u.startsWith(t) || t.startsWith(u))).length;
  const jaccard = shared ? shared / new Set([...ta, ...tb]).size : 0;
  if (kind === 'keyword') return jaccard;
  const fa = AFFECT[na] ?? AFFECT[ta[0] ?? ''];
  const fb = AFFECT[nb] ?? AFFECT[tb[0] ?? ''];
  if (!fa || !fb) return jaccard;
  // Euclidean distance in (valence ∈ [-1,1], arousal ∈ [0,1]) space; max distance ≈ 2.24.
  const d = Math.hypot(fa[0] - fb[0], fa[1] - fb[1]);
  const affect = Math.max(0, 1 - d / 1.2);
  return Math.max(jaccard, affect);
}

/** Probability-weighted soft overlap of two label maps, symmetric, 0..1. */
export function labelOverlap(a: ScoredLabels, b: ScoredLabels, kind: 'mood' | 'keyword' = 'keyword'): { score: number; pairs: Array<[string, string, number]> } {
  const ea = Object.entries(a ?? {}).filter(([, w]) => w > 0);
  const eb = Object.entries(b ?? {}).filter(([, w]) => w > 0);
  if (!ea.length || !eb.length) return { score: 0, pairs: [] };
  const side = (from: Array<[string, number]>, to: Array<[string, number]>) => {
    let num = 0;
    let den = 0;
    const pairs: Array<[string, string, number]> = [];
    for (const [la, wa] of from) {
      // Each label is matched by its best counterpart; the credit is the shared probability mass (min of the two
      // weights) scaled by label similarity, so identical maps score exactly 1 and a strong label met by a weak one is discounted.
      let best = 0;
      let bestLabel = '';
      let bestSim = 0;
      for (const [lb, wb] of to) {
        const sim = labelSimilarity(la, lb, kind);
        const s = sim * Math.min(wa, wb);
        if (s > best) {
          best = s;
          bestLabel = lb;
          bestSim = sim;
        }
      }
      num += best;
      den += wa;
      if (best > 0.2 && bestSim > 0.5) pairs.push([la, bestLabel, round(best, 2)]);
    }
    return { score: den ? num / den : 0, pairs };
  };
  const ab = side(ea, eb);
  const ba = side(eb, ea);
  const pairs = [...ab.pairs].sort((x, y) => y[2] - x[2]);
  return { score: round((ab.score + ba.score) / 2, 3), pairs };
}

/**
 * IAB agreement, weighted by confidences: exact id → 1; otherwise category-name
 * overlap (so "Science Fiction" still meets "Science & Technology"), boosted when
 * the ids share a tier-1 family. Names matter because models are not always
 * consistent about taxonomy ids.
 */
export function iabOverlap(a: AdBreak['iab'], b: AdFingerprint['iab']): { score: number; matches: string[] } {
  if (!a?.length || !b?.length) return { score: 0, matches: [] };
  const family = (id: string) => id.toUpperCase().split('-')[0] ?? id;
  let num = 0;
  let den = 0;
  const matches: string[] = [];
  for (const x of a) {
    let best = 0;
    let label = '';
    for (const y of b) {
      const nameSim = labelSimilarity(x.name, y.name, 'keyword');
      const s = x.id.toUpperCase() === y.id.toUpperCase() ? 1 : nameSim > 0 ? Math.min(1, nameSim * 0.8 + (family(x.id) === family(y.id) ? 0.2 : 0)) : 0;
      const v = s * y.confidence;
      if (v > best) {
        best = v;
        label = s === 1 ? y.name : `${x.name} ~ ${y.name}`;
      }
    }
    num += x.confidence * best;
    den += x.confidence;
    if (best > 0) matches.push(label);
  }
  return { score: den ? round(num / den, 3) : 0, matches };
}

/** Safety agreement: brand-safe break and a clean creative → 1. */
export function safetyAgreement(brk: AdBreak, fp: AdFingerprint): { score: number; notes: string[] } {
  const notes: string[] = [];
  let score = brk.brandSafety?.suitable === false ? 0.4 : 1;
  if (brk.brandSafety?.suitable === false) notes.push('break is flagged as not brand-safe');
  for (const s of fp.sensitivities ?? []) {
    const penalty = s.severity === 'high' ? 0.4 : s.severity === 'medium' ? 0.25 : 0.1;
    score -= penalty * s.confidence;
    notes.push(`creative contains ${s.category} (${s.severity})`);
  }
  // A creative aimed at families placed after a flagged scene is a mismatch both ways.
  const flags = Object.entries(brk.brandSafety?.flags ?? {}).filter(([, p]) => p >= 0.5);
  if (flags.length && fp.familySafe >= 0.7) {
    score -= 0.15;
    notes.push(`family-safe creative after ${flags.map(([f]) => f).join(', ')}`);
  }
  return { score: round(Math.max(0, Math.min(1, score)), 3), notes };
}

export const FIT_WEIGHTS = { mood: 0.35, keywords: 0.3, iab: 0.2, safety: 0.15 } as const;

/** Score one creative against one break. Creatives without a fingerprint score 0 with an explanation. */
export function scoreCreativeFit(brk: AdBreak, creative: Pick<AdCreative, 'id' | 'fingerprint'>): CreativeFit {
  const fp = creative.fingerprint;
  if (!fp) {
    return { creativeId: creative.id, breakId: brk.id, score: 0, mood: 0, keywords: 0, iab: 0, safety: 0, because: ['creative has no fingerprint yet — run POST /api/ads/:id/fingerprint'] };
  }
  const mood = labelOverlap(brk.mood, fp.mood, 'mood');
  const keywords = labelOverlap(brk.keywords, fp.keywords, 'keyword');
  const iab = iabOverlap(brk.iab, fp.iab);
  const safety = safetyAgreement(brk, fp);
  const score = round(FIT_WEIGHTS.mood * mood.score + FIT_WEIGHTS.keywords * keywords.score + FIT_WEIGHTS.iab * iab.score + FIT_WEIGHTS.safety * safety.score, 3);
  const because: string[] = [];
  for (const [a, b] of mood.pairs.slice(0, 2)) because.push(a === b ? `mood "${a}"` : `mood "${a}" ~ "${b}"`);
  for (const [a, b] of keywords.pairs.slice(0, 2)) because.push(a === b ? `keyword "${a}"` : `keyword "${a}" ~ "${b}"`);
  for (const m of iab.matches.slice(0, 1)) because.push(`IAB ${m}`);
  because.push(...safety.notes);
  if (!because.length) because.push(mood.score > 0.3 ? `mood tone partly compatible (${round(mood.score, 2)})` : 'no shared mood, keywords or IAB category');
  return { creativeId: creative.id, breakId: brk.id, score, mood: mood.score, keywords: keywords.score, iab: iab.score, safety: safety.score, because };
}

/** Every creative ranked for one break, best first. */
export function rankCreatives(brk: AdBreak, creatives: Array<Pick<AdCreative, 'id' | 'fingerprint'>>): CreativeFit[] {
  return creatives.map((c) => scoreCreativeFit(brk, c)).sort((a, b) => b.score - a.score || a.creativeId.localeCompare(b.creativeId));
}

/** Best creative per break (only fingerprinted creatives; `minScore` leaves weak breaks unassigned). */
export function autoAssign(breaks: AdBreak[], creatives: AdCreative[], minScore = 0): Array<{ breakId: string; creativeId?: string; fit?: CreativeFit }> {
  const pool = creatives.filter((c) => c.fingerprint);
  return breaks.map((brk) => {
    const [best] = rankCreatives(brk, pool);
    if (!best || best.score < minScore) return { breakId: brk.id };
    return { breakId: brk.id, creativeId: best.creativeId, fit: best };
  });
}
