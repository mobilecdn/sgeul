/**
 * Mock TwelveLabs client.
 *
 * Implements `TwelveLabsClientLike` without the network so the whole product
 * runs with zero setup. Data comes from `data/seed` (real-shaped enrichment
 * for the demo titles); anything it has never seen is synthesised
 * deterministically from the title hash and clearly labelled "(mock)".
 *
 * Search does keyword matching over synopses/keywords/beats and returns hits
 * with real start/end taken from emotion samples, so the Discovery UI behaves
 * like the live one.
 */

import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import type {
  AdCreative,
  AdBreakPlan,
  CatalogItem,
  EmotionArc,
  ItemBundle,
  MarkerSet,
  SafetyReport,
  SmartList,
  ThumbnailCandidate,
  PreviewClip,
  Fingerprint,
} from './types.js';
import {
  MODELS,
  TwelveLabsError,
  type AnalyzeParams,
  type AnalyzeResult,
  type AnalyzeTaskParams,
  type SearchParams,
  type TLAnalyzeTask,
  type TLAsset,
  type TLEmbedTask,
  type TLIndex,
  type TLIndexedAsset,
  type TLSearchHit,
  type TLSearchPage,
  type TwelveLabsAsset,
  type TwelveLabsAssetPage,
  type TwelveLabsClientLike,
  toPageInfo,
} from './twelvelabs.js';
import type {
  AdBreakCandidate,
  AdBreakCandidatesPayload,
  AdFingerprintPayload,
  ClipsPayload,
  EmotionArcPayload,
  FingerprintPayload,
  MarkersPayload,
  SafetyPayload,
  ThumbnailsPayload,
} from './prompts.js';
import { summariseSafety } from './pipeline.js';
import { labelVector, textVector } from './similarity.js';
import { clamp, hash32, makeId, nowIso, round, seededRandom, sleep } from './util.js';

/* ------------------------------------------------------------------ */
/* Seed                                                                */
/* ------------------------------------------------------------------ */

export interface Seed {
  catalog: ItemBundle[];
  lists: SmartList[];
  /** Optional ad creatives (`ads.json`), e.g. local spots for stitched previews. */
  ads: AdCreative[];
  /** A real `GET /v1.3/assets` listing of the demo account (`twelvelabs-assets.json`), served by the mock client. */
  assets: TwelveLabsAsset[];
  dir: string;
}

/** Read `data/seed/catalog.json` (ItemBundle[]), `lists.json`, `ads.json` and `twelvelabs-assets.json`; missing files → empty. */
export async function loadSeed(dir: string): Promise<Seed> {
  const read = async <T>(name: string, fallback: T): Promise<T> => {
    try {
      const text = await readFile(join(dir, name), 'utf8');
      return JSON.parse(text) as T;
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return fallback;
      throw new Error(`Seed file ${name} is unreadable: ${(err as Error).message}`);
    }
  };
  const catalog = await read<ItemBundle[]>('catalog.json', []);
  const lists = await read<SmartList[]>('lists.json', []);
  const ads = await read<AdCreative[]>('ads.json', []);
  const assetsRaw = await read<TwelveLabsAsset[] | { data?: TwelveLabsAsset[] }>('twelvelabs-assets.json', []);
  const assets = Array.isArray(assetsRaw) ? assetsRaw : Array.isArray(assetsRaw?.data) ? assetsRaw.data : [];
  if (!Array.isArray(catalog)) throw new Error('catalog.json must be an ItemBundle[]');
  return { catalog, lists: Array.isArray(lists) ? lists : [], ads: Array.isArray(ads) ? ads : [], assets, dir };
}

/** Stable mock ids so seeds and freshly ingested items agree. */
export function mockAssetId(sourceUrl: string): string {
  return `mock-asset-${hash32(sourceUrl).toString(16).padStart(8, '0')}`;
}
export function mockVideoId(sourceUrl: string): string {
  return `mock-video-${hash32(sourceUrl).toString(16).padStart(8, '0')}`;
}

/* ------------------------------------------------------------------ */
/* Deterministic synthesis for unseen titles                           */
/* ------------------------------------------------------------------ */

const POOLS = {
  genres: ['drama', 'thriller', 'documentary', 'comedy', 'adventure', 'science fiction', 'fantasy', 'romance', 'mystery', 'animation', 'action', 'family'],
  keywords: ['city at night', 'road trip', 'rainstorm', 'workshop', 'coastline', 'crowd', 'rooftop', 'forest', 'old photographs', 'campfire', 'train station', 'kitchen', 'stadium', 'desert', 'laboratory', 'market'],
  moods: ['hopeful', 'tense', 'melancholic', 'playful', 'dark', 'uplifting', 'nostalgic', 'suspenseful', 'warm', 'eerie'],
  moodTags: ['second chances', 'quiet rebellion', 'found family', 'ticking clock', 'reluctant hero', 'coming home', 'secrets kept', 'small victories', 'against the odds', 'letting go'],
  themes: ['identity', 'belonging', 'loss', 'ambition', 'trust', 'freedom', 'legacy', 'resilience', 'truth', 'sacrifice'],
  characters: ['Maya', 'Elias', 'Nadia', 'Tomas', 'June', 'Rafael', 'Ines', 'Kwame', 'Sora', 'Bram'],
  emotions: ['curiosity', 'anticipation', 'tension', 'relief', 'joy', 'sadness', 'wonder', 'fear', 'amusement', 'tenderness'],
  iab: [
    { id: 'IAB1', name: 'Arts & Entertainment', tier: 1 as const },
    { id: 'IAB1-5', name: 'Movies', tier: 2 as const },
    { id: 'IAB1-7', name: 'Television', tier: 2 as const },
    { id: 'IAB20', name: 'Travel', tier: 1 as const },
    { id: 'IAB9', name: 'Hobbies & Interests', tier: 1 as const },
  ],
};

function pickLabels(rnd: () => number, pool: string[], n: number, floor = 0.35): Record<string, number> {
  const chosen = [...pool].sort(() => rnd() - 0.5).slice(0, n);
  const out: Record<string, number> = {};
  chosen.forEach((label, i) => {
    out[label] = round(clamp(0.96 - i * 0.07 - rnd() * 0.08, floor, 0.99), 2);
  });
  return out;
}

function pickSome<T>(rnd: () => number, pool: T[], n: number): T[] {
  return [...pool].sort(() => rnd() - 0.5).slice(0, n);
}

/** Synthesise a complete, internally consistent bundle for a title we have no seed for. */
export function synthesiseBundle(input: Pick<CatalogItem, 'id' | 'title' | 'sourceUrl'> & Partial<CatalogItem>): ItemBundle {
  const seed = hash32(`${input.title}|${input.sourceUrl}`);
  const rnd = seededRandom(seed);
  const durationSec = input.durationSec ?? Math.round(540 + rnd() * 960); // 9–25 min
  const fps = input.fps ?? [24, 25, 29.97][Math.floor(rnd() * 3)]!;
  const characters = pickSome(rnd, POOLS.characters, 3 + Math.floor(rnd() * 3));
  const genres = pickLabels(rnd, POOLS.genres, 5);
  const keywords = pickLabels(rnd, POOLS.keywords, 8);
  const moods = pickLabels(rnd, POOLS.moods, 5);
  const moodTags = pickLabels(rnd, POOLS.moodTags, 5);
  const themes = pickLabels(rnd, POOLS.themes, 5);
  const topGenre = Object.keys(genres)[0] ?? 'drama';
  const topMood = Object.keys(moods)[0] ?? 'hopeful';
  const lead = characters[0] ?? 'the lead';
  const now = nowIso();
  const model = `${MODELS.analyze} (mock)`;

  const short = `(mock) ${lead} faces a ${topMood} ${topGenre} that changes everything.`;
  const long = `(mock) Synthesised placeholder synopsis for "${input.title}": ${lead} and ${characters.slice(1).join(', ') || 'a stranger'} are drawn into a ${topMood} ${topGenre} built around ${Object.keys(keywords).slice(0, 3).join(', ')}. This text is generated locally because no TwelveLabs key is configured; run the pipeline in live mode to replace it with Pegasus output.`;

  const fingerprint: Fingerprint = {
    genres,
    keywords,
    moods,
    moodTags,
    themes,
    characters: characters.map((name, i) => ({
      name,
      prominence: round(clamp(0.95 - i * 0.2, 0.15, 1), 2),
      description: `(mock) ${i === 0 ? 'protagonist' : i === 1 ? 'closest ally' : 'supporting character'} in ${input.title}`,
    })),
    pacing: { score: round(0.3 + rnd() * 0.5, 2), rationale: '(mock) Estimated from a synthetic cut-rate profile.' },
    language: { primary: 'en', others: [] },
    audienceRating: { suggested: rnd() > 0.5 ? 'PG' : 'PG-13', rationale: '(mock) Mild peril and thematic elements.' },
    synopsis: {
      short,
      long,
      translations: {
        es: { short: `(mock) ${lead} se enfrenta a una historia ${topGenre} que lo cambia todo.`, long: `(mock) Sinopsis sintética de "${input.title}".` },
        fr: { short: `(mock) ${lead} affronte une histoire ${topGenre} qui change tout.`, long: `(mock) Synopsis synthétique de « ${input.title} ».` },
      },
    },
    model,
    generatedAt: now,
  };
  fingerprint.embedding = labelVector(fingerprint);

  // Emotion arc: a three-act curve with noise, ~1 sample / 25s.
  const step = 25;
  const n = Math.min(60, Math.max(6, Math.ceil(durationSec / step)));
  const width = durationSec / n;
  const samples: EmotionArc['samples'] = [];
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1);
    const arousal = clamp(0.25 + 0.55 * Math.sin(Math.PI * Math.pow(t, 1.4)) + (rnd() - 0.5) * 0.12, 0.05, 0.98);
    const valence = clamp(0.3 - 0.9 * Math.sin(Math.PI * t) * (t > 0.5 ? 1 : 0.4) + (t > 0.85 ? 0.8 : 0) + (rnd() - 0.5) * 0.2, -0.95, 0.95);
    const dominance = clamp(0.5 + (t - 0.5) * 0.6 + (rnd() - 0.5) * 0.2, 0.05, 0.95);
    const who = characters[i % characters.length] ?? lead;
    const kw = Object.keys(keywords)[i % Object.keys(keywords).length] ?? 'scene';
    samples.push({
      start: round(i * width, 2),
      end: round(Math.min(durationSec, (i + 1) * width), 2),
      valence: round(valence, 3),
      arousal: round(arousal, 3),
      dominance: round(dominance, 3),
      emotions: pickLabels(rnd, POOLS.emotions, 4, 0.2),
      beat: `(mock) ${who} at the ${kw}${arousal > 0.7 ? ' — tension peaks' : valence > 0.5 ? ' — a lighter moment' : ''}`,
      confidence: round(0.6 + rnd() * 0.3, 2),
    });
  }
  const climaxSample = samples.reduce((best, s) => (s.arousal > best.arousal ? s : best), samples[0]!);
  const emotions: EmotionArc = {
    itemId: input.id,
    samples,
    acts: [
      { name: 'Set-up', start: 0, end: round(durationSec * 0.25, 2), summary: `(mock) ${lead} is introduced.` },
      { name: 'Complication', start: round(durationSec * 0.25, 2), end: round(durationSec * 0.7, 2), summary: '(mock) Stakes escalate.' },
      { name: 'Climax', start: round(durationSec * 0.7, 2), end: round(durationSec * 0.88, 2), summary: '(mock) The confrontation.' },
      { name: 'Resolution', start: round(durationSec * 0.88, 2), end: durationSec, summary: '(mock) Aftermath and credits.' },
    ],
    climax: { at: round((climaxSample.start + climaxSample.end) / 2, 2), description: `(mock) ${climaxSample.beat}` },
    model,
    generatedAt: now,
  };

  // Markers.
  const creditsStart = round(durationSec - 45 - rnd() * 30, 2);
  const chapterCount = 4;
  const markerSet: MarkerSet = {
    itemId: input.id,
    fps,
    markers: [
      { id: makeId('mrk', `${input.id}:intro`), kind: 'intro' as const, start: 0, end: round(12 + rnd() * 20, 2), label: 'Opening titles (mock)', confidence: 0.82 },
      ...Array.from({ length: chapterCount }, (_, i) => ({
        id: makeId('mrk', `${input.id}:ch${i}`),
        kind: 'chapter' as const,
        start: round((creditsStart / chapterCount) * i, 2),
        end: round((creditsStart / chapterCount) * (i + 1), 2),
        label: `Ch. ${i + 1} — ${Object.keys(keywords)[i] ?? 'scene'} (mock)`,
        confidence: round(0.6 + rnd() * 0.3, 2),
      })),
      { id: makeId('mrk', `${input.id}:credits`), kind: 'credits' as const, start: creditsStart, end: durationSec, label: 'End credits (mock)', confidence: 0.9 },
    ].map((m) => ({ ...m, startFrame: Math.round(m.start * fps), endFrame: Math.round(m.end * fps) })),
    model,
    generatedAt: now,
  };

  // Safety: 1–2 mild segments.
  const safetySegments: SafetyReport['segments'] = pickSome(rnd, ['weapons', 'violence', 'alcohol', 'profanity'] as const, 1 + Math.floor(rnd() * 2)).map((category, i) => {
    const start = round(durationSec * (0.35 + i * 0.3) + rnd() * 20, 2);
    return {
      id: makeId('saf', `${input.id}:${category}`),
      category,
      severity: (rnd() > 0.7 ? 'medium' : 'low') as 'low' | 'medium',
      start,
      end: round(start + 6 + rnd() * 14, 2),
      description: `(mock) Brief ${category} reference.`,
      confidence: round(0.6 + rnd() * 0.3, 2),
    };
  });
  const safety: SafetyReport = { itemId: input.id, segments: safetySegments, summary: summariseSafety(safetySegments), model, generatedAt: now };

  // Ad-break candidates at ~every 110–150s, skewed to sample edges.
  const candidates: AdBreakCandidate[] = [];
  for (let t = 90; t < creditsStart - 60; t += 110 + rnd() * 40) {
    const nearest = samples.reduce((b, s) => (Math.abs(s.start - t) < Math.abs(b.start - t) ? s : b), samples[0]!);
    const at = round(clamp(nearest.start, 60, creditsStart - 60), 2);
    if (candidates.some((c) => Math.abs(c.at - at) < 30)) continue;
    const rt = pickSome(rnd, ['scene_change', 'scene_change', 'dialogue_gap', 'fade', 'music_end', 'location_change'] as const, 1)[0]!;
    candidates.push({
      at,
      confidence: round(0.55 + rnd() * 0.4, 2),
      reason: `(mock) ${rt.replace('_', ' ')} at ${Math.floor(at / 60)}m${Math.round(at % 60)}s`,
      reasonType: rt,
      sceneBefore: `(mock) ${nearest.beat}`,
      sceneAfter: `(mock) ${samples[samples.indexOf(nearest) + 1]?.beat ?? 'next scene'}`,
      mood: pickLabels(rnd, POOLS.moods, 4, 0.2),
      keywords: pickLabels(rnd, POOLS.keywords, 5, 0.2),
      iab: pickSome(rnd, POOLS.iab, 2).map((x) => ({ ...x, confidence: round(0.5 + rnd() * 0.4, 2) })),
    });
  }

  const thumbnails: ThumbnailsPayload['thumbnails'] = Array.from({ length: 12 }, (_, i) => {
    const s = samples[Math.floor((i / 12) * samples.length)]!;
    const at = round(s.start + (s.end - s.start) * 0.5, 2);
    return {
      at,
      factors: {
        relevance: round(0.5 + rnd() * 0.45, 2),
        aesthetics: round(0.5 + rnd() * 0.45, 2),
        faceProminence: round(rnd() * 0.9, 2),
        stillness: round(0.4 + rnd() * 0.55, 2),
        brightness: round(0.3 + rnd() * 0.45, 2),
        safeArea: round(0.3 + rnd() * 0.6, 2),
      },
      characters: [characters[i % characters.length]!],
      mood: pickLabels(rnd, POOLS.moods, 3, 0.2),
      crops: {
        '16:9': { x: 0, y: 0, w: 1, h: 1 },
        '2:3': { x: round(0.15 + rnd() * 0.3, 3), y: 0, w: 0.375, h: 1 },
        '1:1': { x: round(0.1 + rnd() * 0.3, 3), y: 0, w: 0.5625, h: 1 },
        '9:16': { x: round(0.2 + rnd() * 0.4, 3), y: 0, w: 0.3164, h: 1 },
      },
      logoSafeZone: pickSome(rnd, ['top-left', 'top-right', 'bottom-left', 'bottom-right'] as const, 1)[0]!,
      safe: !safetySegments.some((seg) => at >= seg.start - 5 && at <= seg.end + 5),
      caption: `(mock) ${s.beat.replace('(mock) ', '')}`,
    };
  });

  const clips: ClipsPayload['clips'] = Array.from({ length: 6 }, (_, i) => {
    const s = samples[Math.floor(((i + 0.5) / 6) * samples.length)]!;
    const start = round(s.start + 2, 2);
    const end = round(Math.min(durationSec, start + 12 + rnd() * 14), 2);
    return {
      start,
      end,
      clipType: pickSome(rnd, ['action beat', 'emotional turn', 'comic relief', 'world reveal', 'character intro', 'cliffhanger'], 1)[0]!,
      relevance: round(0.5 + rnd() * 0.45, 2),
      characters: [characters[i % characters.length]!],
      mood: pickLabels(rnd, POOLS.moods, 3, 0.2),
      keywords: pickLabels(rnd, POOLS.keywords, 4, 0.2),
      safe: !safetySegments.some((seg) => start <= seg.end && end >= seg.start),
      reframe916: [
        { at: start, cx: round(0.35 + rnd() * 0.3, 3) },
        { at: round((start + end) / 2, 2), cx: round(0.35 + rnd() * 0.3, 3) },
        { at: end, cx: round(0.35 + rnd() * 0.3, 3) },
      ],
      caption: `(mock) ${s.beat.replace('(mock) ', '')}`,
      posterAt: round((start + end) / 2, 2),
    };
  });

  const item: CatalogItem = {
    id: input.id,
    title: input.title,
    sourceUrl: input.sourceUrl,
    type: input.type ?? 'other',
    year: input.year,
    posterUrl: input.posterUrl,
    series: input.series,
    externalIds: input.externalIds,
    metadata: input.metadata,
    createdAt: input.createdAt ?? now,
    updatedAt: now,
    durationSec,
    fps,
    width: 1920,
    height: 1080,
    status: 'ready',
    upstream: { assetId: mockAssetId(input.sourceUrl), indexedAssetId: mockVideoId(input.sourceUrl), indexId: 'mock-index' },
    jobs: {},
    fingerprint,
  };

  // Plan from candidates so the synthetic bundle carries a real AdBreakPlan shape too.
  const adBreaks: AdBreakPlan & { candidates: AdBreakCandidate[] } = {
    itemId: input.id,
    breaks: [],
    policy: { targetBreaks: 2, minSpacingSec: 240, avoidFirstSec: 120, avoidLastSec: 120 },
    model,
    generatedAt: now,
    candidates,
  };

  return {
    item,
    fingerprint,
    emotions,
    markers: markerSet,
    adBreaks,
    safety,
    thumbnails: thumbnails.map((t, i) => ({ ...t, id: makeId('thm', `${input.id}:${i}`), score: 0 }) as ThumbnailCandidate),
    clips: clips.map((c, i) => ({ ...c, id: makeId('clp', `${input.id}:${i}`) }) as PreviewClip),
    jobs: [],
  };
}

/* ------------------------------------------------------------------ */
/* The client                                                          */
/* ------------------------------------------------------------------ */

export interface MockClientOptions {
  /** Live view of the store so newly ingested items are searchable and embeddable. */
  bundles?: () => ItemBundle[];
  /** Simulated latency per call in ms, [min, max]. Default [120, 480]; use [0, 0] in tests. */
  latencyMs?: [number, number];
  /** Fixed index id reported by list/create. */
  indexId?: string;
}

export class MockTwelveLabsClient implements TwelveLabsClientLike {
  readonly mode = 'mock' as const;
  private readonly seed: Seed;
  private readonly opts: MockClientOptions;
  private readonly assets = new Map<string, { url: string; createdAt: number }>();
  private readonly synthesised = new Map<string, ItemBundle>();
  private readonly tasks = new Map<string, { kind: 'analyze' | 'embed'; result: unknown; readyAt: number }>();
  private readonly searchPages = new Map<string, TLSearchPage>();

  constructor(seed: Seed, opts: MockClientOptions = {}) {
    this.seed = seed;
    this.opts = opts;
  }

  private async delay(): Promise<void> {
    const [min, max] = this.opts.latencyMs ?? [120, 480];
    const ms = min + Math.random() * Math.max(0, max - min);
    if (ms > 0) await sleep(ms);
  }

  private get indexId(): string {
    return this.opts.indexId ?? 'mock-index';
  }

  /** All bundles the mock knows about: live store first, then seed. */
  private knownBundles(): ItemBundle[] {
    const live = this.opts.bundles?.() ?? [];
    const seen = new Set(live.map((b) => b.item.id));
    return [...live, ...this.seed.catalog.filter((b) => !seen.has(b.item.id))];
  }

  /** Resolve the bundle a call refers to (by asset id, video id, url, item id or title). */
  private resolve(ref: { assetId?: string; videoId?: string; sourceUrl?: string; itemId?: string; title?: string }): ItemBundle | undefined {
    const url = ref.sourceUrl ?? (ref.assetId ? this.assets.get(ref.assetId)?.url : undefined);
    const norm = (s: string | undefined) => s?.trim().toLowerCase();
    for (const b of this.knownBundles()) {
      const u = b.item.upstream ?? {};
      if (ref.itemId && b.item.id === ref.itemId) return b;
      if (ref.assetId && (u.assetId === ref.assetId || mockAssetId(b.item.sourceUrl) === ref.assetId)) return b;
      if (ref.videoId && (u.indexedAssetId === ref.videoId || mockVideoId(b.item.sourceUrl) === ref.videoId)) return b;
      if (url && norm(b.item.sourceUrl) === norm(url)) return b;
    }
    if (ref.title) {
      const t = norm(ref.title);
      const byTitle = this.knownBundles().find((b) => norm(b.item.title) === t);
      if (byTitle) return byTitle;
    }
    return undefined;
  }

  /** A bundle with every section present — seeded, or synthesised and cached. */
  private bundleFor(ref: Parameters<MockTwelveLabsClient['resolve']>[0]): ItemBundle {
    const found = this.resolve(ref);
    const key = found?.item.id ?? ref.itemId ?? ref.sourceUrl ?? ref.assetId ?? ref.title ?? 'unknown';
    const cached = this.synthesised.get(key);
    if (cached) return this.merge(found, cached);
    const url = ref.sourceUrl ?? found?.item.sourceUrl ?? (ref.assetId ? this.assets.get(ref.assetId)?.url : undefined) ?? `mock://${key}`;
    const synthetic = synthesiseBundle({
      ...(found?.item ?? {}),
      id: found?.item.id ?? ref.itemId ?? makeId('itm', key),
      title: found?.item.title ?? ref.title ?? 'Untitled (mock)',
      sourceUrl: url,
    });
    this.synthesised.set(key, synthetic);
    return this.merge(found, synthetic);
  }

  /** Seeded sections win over synthetic ones. */
  private merge(found: ItemBundle | undefined, synthetic: ItemBundle): ItemBundle {
    if (!found) return synthetic;
    // Store sections may themselves be mock output from earlier runs; reusing them keeps re-runs stable.
    return {
      item: { ...synthetic.item, ...found.item, durationSec: found.item.durationSec ?? synthetic.item.durationSec, fps: found.item.fps ?? synthetic.item.fps },
      fingerprint: found.fingerprint ?? synthetic.fingerprint,
      emotions: found.emotions ?? synthetic.emotions,
      markers: found.markers ?? synthetic.markers,
      adBreaks: found.adBreaks ?? synthetic.adBreaks,
      safety: found.safety ?? synthetic.safety,
      thumbnails: found.thumbnails ?? synthetic.thumbnails,
      clips: found.clips ?? synthetic.clips,
      jobs: found.jobs,
    };
  }

  /* ---- assets / index -------------------------------------------- */

  /** (mock) POST /assets */
  async createAsset(params: { url: string }): Promise<TLAsset> {
    await this.delay();
    const id = mockAssetId(params.url);
    this.assets.set(id, { url: params.url, createdAt: Date.now() });
    return { _id: id, status: 'processing', url: params.url, created_at: nowIso() };
  }

  /** (mock) POST /assets (method=direct) — same as a URL upload keyed by the file:// URL. */
  async createAssetFromFile(params: { path: string; filename?: string }): Promise<TLAsset> {
    return this.createAsset({ url: pathToFileURL(params.path).href });
  }

  /** (mock) GET /assets/:id — ready after the first poll. */
  async getAsset(assetId: string): Promise<TLAsset> {
    await this.delay();
    const a = this.assets.get(assetId);
    return { _id: assetId, status: 'ready', url: a?.url };
  }

  /**
   * (mock) GET /assets — the seeded account listing (`twelvelabs-assets.json`,
   * a real capture) plus whatever this process uploaded through `createAsset`,
   * newest first, paged like the live endpoint.
   */
  async listAssets(params: { page?: number; pageLimit?: number } = {}): Promise<TwelveLabsAssetPage> {
    await this.delay();
    const seeded = new Set(this.seed.assets.map((a) => a._id));
    const runtime: TwelveLabsAsset[] = [...this.assets.entries()]
      .filter(([id]) => !seeded.has(id))
      .map(([id, a]) => {
        const item = this.resolve({ assetId: id, sourceUrl: a.url })?.item;
        const filename = (() => {
          try {
            return decodeURIComponent(new URL(a.url).pathname.split('/').filter(Boolean).at(-1) ?? id);
          } catch {
            return id;
          }
        })();
        return {
          _id: id,
          method: a.url.startsWith('file:') ? 'direct' : 'url',
          status: 'ready',
          filename: filename || `${id}.mp4`,
          file_type: 'video/mp4',
          size: undefined,
          duration: item?.durationSec ?? null,
          width: item?.width ?? null,
          height: item?.height ?? null,
          fps: item?.fps ?? null,
          hls: item?.playback?.hlsUrl ? { manifest_url: item.playback.hlsUrl, status: 'ready' } : null,
          thumbnail: item?.playback?.thumbnailUrls?.[0] ? { representative_url: item.playback.thumbnailUrls[0], status: 'ready' } : null,
          created_at: new Date(a.createdAt).toISOString(),
        };
      });
    const all = [...runtime, ...this.seed.assets].sort((x, y) => Date.parse(y.created_at) - Date.parse(x.created_at));
    const page = Math.max(1, Math.floor(params.page ?? 1));
    const limit = Math.min(100, Math.max(1, Math.floor(params.pageLimit ?? 50)));
    const data = all.slice((page - 1) * limit, page * limit);
    return { data, pageInfo: toPageInfo({ page, limit_per_page: limit, total_page: Math.max(1, Math.ceil(all.length / limit)), total_results: all.length }, page, limit, data.length) };
  }

  async createIndex(params: { name: string }): Promise<TLIndex> {
    await this.delay();
    return { _id: this.indexId, index_name: params.name, models: [{ model_name: MODELS.index, model_options: ['visual', 'audio'] }] };
  }

  async listIndexes(params: { name?: string } = {}): Promise<TLIndex[]> {
    await this.delay();
    return [{ _id: this.indexId, index_name: params.name ?? 'twelve-studio' }];
  }

  async createIndexedAsset(_indexId: string, params: { assetId: string }): Promise<TLIndexedAsset> {
    await this.delay();
    const url = this.assets.get(params.assetId)?.url ?? params.assetId;
    return { _id: mockVideoId(url), asset_id: params.assetId, status: 'indexing' };
  }

  /** (mock) GET /indexes/:id/indexed-assets/:iid — returns duration/fps from the seed or synthesis. */
  async getIndexedAsset(_indexId: string, indexedAssetId: string): Promise<TLIndexedAsset> {
    await this.delay();
    const bundle = this.bundleFor({ videoId: indexedAssetId });
    const item = bundle.item;
    return {
      _id: indexedAssetId,
      asset_id: item.upstream?.assetId ?? mockAssetId(item.sourceUrl),
      status: 'ready',
      system_metadata: { duration: item.durationSec, fps: item.fps, width: item.width ?? 1920, height: item.height ?? 1080, filename: item.title },
      hls: item.playback?.hlsUrl ? { video_url: item.playback.hlsUrl, thumbnail_urls: item.playback.thumbnailUrls, status: 'COMPLETE' } : undefined,
    };
  }

  /* ---- search ---------------------------------------------------- */

  /** (mock) POST /search — keyword matching over synopses, keywords and emotion beats. */
  async search(params: SearchParams): Promise<TLSearchPage> {
    await this.delay();
    const tokens = params.queryText
      .toLowerCase()
      .split(/[^a-z0-9À-ɏ]+/)
      .filter((t) => t.length > 2);
    const hits: Array<TLSearchHit & { _score: number }> = [];
    if (tokens.length > 0) {
      for (const b of this.knownBundles()) {
        const full = this.bundleFor({ itemId: b.item.id });
        const fp = full.fingerprint;
        const videoId = full.item.upstream?.indexedAssetId ?? mockVideoId(full.item.sourceUrl);
        const bag = [
          ...Object.keys(fp?.keywords ?? {}),
          ...Object.keys(fp?.genres ?? {}),
          ...Object.keys(fp?.moods ?? {}),
          ...Object.keys(fp?.themes ?? {}),
          fp?.synopsis.short ?? '',
          fp?.synopsis.long ?? '',
          full.item.title,
        ]
          .join(' ')
          .toLowerCase();
        const titleScore = tokens.filter((t) => bag.includes(t)).length / tokens.length;
        // Moment-level hits from emotion beats / clips.
        const moments: Array<{ start: number; end: number; text: string; weight: number }> = [
          ...(full.emotions?.samples ?? []).map((s) => ({ start: s.start, end: s.end, text: `${s.beat} ${Object.keys(s.emotions).join(' ')}`, weight: 1 })),
          ...(full.clips ?? []).map((c) => ({ start: c.start, end: c.end, text: `${c.caption} ${Object.keys(c.keywords).join(' ')} ${c.clipType}`, weight: 1.1 })),
        ];
        for (const m of moments) {
          const text = m.text.toLowerCase();
          const matched = tokens.filter((t) => text.includes(t)).length;
          if (matched === 0) continue;
          hits.push({
            video_id: videoId,
            start: m.start,
            end: m.end,
            _score: (matched / tokens.length) * m.weight + titleScore * 0.3,
            confidence: matched === tokens.length ? 'high' : 'medium',
            transcription: m.text.replace(/\(mock\)\s*/g, ''),
            modality: 'visual',
            thumbnail_url: full.item.playback?.thumbnailUrls?.[0],
          });
        }
        if (titleScore > 0 && !hits.some((h) => h.video_id === videoId)) {
          const climaxAt = full.emotions?.climax?.at ?? (full.item.durationSec ?? 60) / 2;
          hits.push({
            video_id: videoId,
            start: round(Math.max(0, climaxAt - 10), 2),
            end: round(climaxAt + 10, 2),
            _score: titleScore * 0.6,
            confidence: 'low',
            transcription: fp?.synopsis.short.replace(/\(mock\)\s*/g, ''),
            modality: 'visual',
          });
        }
      }
    }
    hits.sort((a, b) => b._score - a._score || a.start - b.start);
    const ranked = hits.map(({ _score, ...h }, i) => ({ ...h, rank: i + 1, score: round(Math.min(1, _score) * 100, 1) }));
    const limit = params.pageLimit ?? 20;
    const pages: TLSearchPage[] = [];
    for (let i = 0; i < ranked.length; i += limit) pages.push({ data: ranked.slice(i, i + limit) });
    if (pages.length === 0) pages.push({ data: [] });
    const pool = this.knownBundles();
    const totalDuration = pool.reduce((acc, b) => acc + (b.item.durationSec ?? 0), 0);
    pages.forEach((p, i) => {
      const token = `mock-page-${hash32(params.queryText).toString(16)}-${i + 1}`;
      const next = pages[i + 1];
      if (next) this.searchPages.set(token, next);
      p.page_info = { total_results: ranked.length, limit_per_page: limit, next_page_token: next ? token : undefined };
      p.search_pool = { total_count: pool.length, total_duration: totalDuration, index_id: this.indexId };
    });
    return pages[0]!;
  }

  async searchPage(pageToken: string): Promise<TLSearchPage> {
    await this.delay();
    const page = this.searchPages.get(pageToken);
    if (!page) throw new TwelveLabsError('Unknown page token', 'page_token_not_found', 404);
    return page;
  }

  /* ---- analyze --------------------------------------------------- */

  /** (mock) POST /analyze — answers from the seed / synthesis according to `hint.job`. */
  async analyze<T = unknown>(params: AnalyzeParams): Promise<AnalyzeResult<T>> {
    await this.delay();
    const payload = this.payloadFor(params);
    return { data: payload as T, raw: JSON.stringify(payload), model: `${MODELS.analyze} (mock)` };
  }

  async createAnalyzeTask(params: AnalyzeTaskParams): Promise<TLAnalyzeTask> {
    await this.delay();
    const id = makeId('mock-task');
    this.tasks.set(id, { kind: 'analyze', result: this.payloadFor(params), readyAt: Date.now() + 200 });
    return { _id: id, status: 'processing' };
  }

  async getAnalyzeTask(taskId: string): Promise<TLAnalyzeTask> {
    await this.delay();
    const t = this.tasks.get(taskId);
    if (!t || t.kind !== 'analyze') throw new TwelveLabsError('Task not found', 'task_not_found', 404);
    if (Date.now() < t.readyAt) return { _id: taskId, status: 'processing' };
    return { _id: taskId, status: 'ready', data: JSON.stringify(t.result) };
  }

  private payloadFor(params: AnalyzeParams): unknown {
    const job = params.hint?.job ?? 'fingerprint';
    const ref = {
      assetId: params.video.type === 'asset_id' ? params.video.asset_id : undefined,
      sourceUrl: params.video.type === 'url' ? params.video.url : params.hint?.sourceUrl,
      itemId: params.hint?.itemId,
      title: params.hint?.title,
    };
    if (job === 'adFingerprint') return this.adFingerprintFor(ref);
    const b = this.bundleFor(ref);
    const brief = (params.hint?.extra ?? {}) as { brief?: string; count?: number; query?: string; clipLengthSec?: [number, number] };
    switch (job) {
      case 'fingerprint': {
        const { embedding: _e, model: _m, generatedAt: _g, ...rest } = b.fingerprint!;
        const languages = ((params.hint?.extra as { languages?: string[] } | undefined)?.languages ?? []).filter((l) => l !== 'en');
        const translations = { ...(rest.synopsis.translations ?? {}) };
        for (const lang of languages) {
          if (!translations[lang]) {
            translations[lang] = { short: `(mock ${lang}) ${rest.synopsis.short}`, long: `(mock ${lang}) ${rest.synopsis.long}` };
          }
        }
        const payload: FingerprintPayload = { ...rest, synopsis: { ...rest.synopsis, translations } };
        return payload;
      }
      case 'emotions': {
        const e = b.emotions!;
        const payload: EmotionArcPayload = { samples: e.samples, acts: e.acts, climax: e.climax };
        return payload;
      }
      case 'markers': {
        const payload: MarkersPayload = { markers: b.markers!.markers.map((m) => ({ kind: m.kind, start: m.start, end: m.end, label: m.label, confidence: m.confidence })) };
        return payload;
      }
      case 'safety': {
        const payload: SafetyPayload = { segments: b.safety!.segments.map(({ id: _id, ...s }) => s) };
        return payload;
      }
      case 'adbreaks': {
        const plan = b.adBreaks as (AdBreakPlan & { candidates?: AdBreakCandidate[] }) | undefined;
        const candidates: AdBreakCandidate[] =
          plan?.candidates ??
          (plan?.breaks ?? []).map((br) => ({
            at: br.at,
            confidence: br.confidence,
            reason: br.reason,
            reasonType: /scene/i.test(br.reason) ? 'scene_change' : /act/i.test(br.reason) ? 'act_break' : /fade/i.test(br.reason) ? 'fade' : 'dialogue_gap',
            sceneBefore: br.sceneBefore,
            sceneAfter: br.sceneAfter,
            mood: br.mood,
            keywords: br.keywords,
            iab: br.iab,
          }));
        const payload: AdBreakCandidatesPayload = { candidates };
        return payload;
      }
      case 'thumbnails': {
        const base = (b.thumbnails ?? []).map(({ id: _id, frame: _f, score: _s, imageUrl: _u, ...t }) => t);
        const payload: ThumbnailsPayload = { thumbnails: this.applyBrief(base, brief, brief.count ?? 12) };
        return payload;
      }
      case 'clips': {
        const base = (b.clips ?? []).map(({ id: _id, ...c }) => c);
        const withLen = brief.clipLengthSec
          ? base.map((c) => {
              const [min, max] = brief.clipLengthSec!;
              const len = clamp(c.end - c.start, min, max);
              return { ...c, end: round(c.start + len, 2), posterAt: round(Math.min(c.posterAt, c.start + len), 2) };
            })
          : base;
        const clips = this.applyBrief(withLen, brief, brief.count ?? 6).map((c) =>
          brief.query ? { ...c, query: brief.query, queryRelevance: round(clamp(c.relevance * 0.9, 0, 1), 3) } : c,
        );
        const payload: ClipsPayload = { clips };
        return payload;
      }
      default:
        throw new TwelveLabsError(`Mock client has no data for job "${job}"`, 'mock_unknown_job', 400);
    }
  }

  /** (mock) Creative fingerprint: seeded creatives carry real Pegasus output; unknown creatives get a plausible synthesis from their name. */
  private adFingerprintFor(ref: { assetId?: string; itemId?: string; title?: string }): AdFingerprintPayload {
    const seeded = this.seed.ads.find((a) => (ref.assetId && a.upstream?.assetId === ref.assetId) || (ref.itemId && a.id === ref.itemId));
    if (seeded?.fingerprint) {
      const { model: _m, generatedAt: _g, ...rest } = seeded.fingerprint;
      return rest;
    }
    const name = ref.title ?? ref.itemId ?? 'creative';
    return {
      brand: name.split(/\s+/)[0] ?? name,
      product: name,
      tagline: '',
      callToAction: '',
      synopsis: `(mock) A ${name} spot.`,
      mood: { upbeat: 0.7, warm: 0.6, playful: 0.5 },
      keywords: Object.fromEntries(name.toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 2).slice(0, 6).map((t) => [t, 0.8])),
      tone: { humorous: 0.4, emotional: 0.4, energetic: 0.6, premium: 0.4, family: 0.6 },
      iab: [{ id: 'IAB22', name: 'Shopping', tier: 1, confidence: 0.5 }],
      sensitivities: [],
      familySafe: 0.85,
      pacing: { score: 0.6, rationale: '(mock) typical 30s cut rate' },
      moments: [{ at: 1, label: 'open' }, { at: 12, label: 'product' }, { at: 26, label: 'end card' }],
      language: { primary: 'en', others: [] },
    };
  }

  /** Re-score creative candidates against a brief (keyword overlap) so recipes visibly change output. */
  private applyBrief<T extends { mood: Record<string, number>; caption: string; characters: string[]; relevance?: number; factors?: { relevance: number } }>(
    items: T[],
    brief: { brief?: string },
    count: number,
  ): T[] {
    if (!brief.brief) return items.slice(0, count);
    const tokens = brief.brief.toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 3);
    const rnd = seededRandom(hash32(brief.brief));
    return items
      .map((it) => {
        const text = `${it.caption} ${Object.keys(it.mood).join(' ')} ${it.characters.join(' ')}`.toLowerCase();
        const overlap = tokens.length ? tokens.filter((t) => text.includes(t)).length / tokens.length : 0;
        const rel = round(clamp(0.45 + overlap * 0.5 + rnd() * 0.1, 0, 1), 3);
        const next: T = { ...it, caption: `${it.caption} — ${brief.brief!.slice(0, 40)}` };
        if (next.factors) next.factors = { ...next.factors, relevance: rel };
        if (typeof next.relevance === 'number') next.relevance = rel;
        return next;
      })
      .sort((a, b) => (b.factors?.relevance ?? b.relevance ?? 0) - (a.factors?.relevance ?? a.relevance ?? 0))
      .slice(0, count);
  }

  /* ---- embed ----------------------------------------------------- */

  /** (mock) POST /embed-v2 video — hashed bag-of-labels vector from the fingerprint. */
  async embedVideo(params: { assetId: string; title?: string }): Promise<number[]> {
    await this.delay();
    const b = this.bundleFor({ assetId: params.assetId, title: params.title });
    return labelVector(b.fingerprint!);
  }

  /** (mock) POST /embed-v2 text — same hashed space, so cosine ranking is meaningful. */
  async embedText(params: { text: string }): Promise<number[]> {
    await this.delay();
    return textVector(params.text);
  }

  async createEmbedTask(params: { assetId: string; title?: string }): Promise<TLEmbedTask> {
    await this.delay();
    const id = makeId('mock-embed');
    const b = this.bundleFor({ assetId: params.assetId, title: params.title });
    this.tasks.set(id, { kind: 'embed', result: labelVector(b.fingerprint!), readyAt: Date.now() + 200 });
    return { _id: id, status: 'processing' };
  }

  async getEmbedTask(taskId: string): Promise<TLEmbedTask> {
    await this.delay();
    const t = this.tasks.get(taskId);
    if (!t || t.kind !== 'embed') throw new TwelveLabsError('Task not found', 'task_not_found', 404);
    if (Date.now() < t.readyAt) return { _id: taskId, status: 'processing' };
    return { _id: taskId, status: 'ready', data: [{ embedding: t.result as number[], embedding_scope: 'video' }] };
  }
}
