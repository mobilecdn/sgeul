/**
 * Deterministic ad-pod planner.
 *
 * Pegasus proposes candidate pauses (`AdBreakCandidate`); this module turns
 * them into a ranked `AdBreakPlan` by applying an operations policy. It is a
 * pure function — no model calls — so re-planning with a different policy is
 * instant and reproducible, and it can be unit-tested exhaustively.
 *
 * Rules, in order:
 *   1. Policy fences: drop candidates inside `avoidFirstSec` / `avoidLastSec`.
 *   2. Brand safety: any high-severity safety segment within ±45s marks the
 *      candidate unsuitable (GARM-style flags within ±60s are attached either
 *      way). Unsuitable candidates are only used when nothing else remains.
 *   3. Emotion: cutting while arousal is rising steeply feels intrusive, so the
 *      slope of arousal across the point is penalised; falling/flat is rewarded.
 *   4. Reason: scene changes / act breaks / fades make the cleanest pods.
 *   5. Greedy selection by score honouring `minSpacingSec`, then ranks 1..n.
 *   6. `window` = ±min(8s, half the distance to the nearest neighbouring
 *      scene boundary), clamped to the policy fences.
 */

import type { AdBreak, AdBreakPlan, EmotionArc, EmotionSample, SafetyReport, ScoredLabels } from './types.js';
import type { AdBreakCandidate } from './prompts.js';
import { clamp, makeId, nowIso, round } from './util.js';

export type AdBreakPolicy = AdBreakPlan['policy'];

export interface PlanOptions {
  durationSec: number;
  policy?: Partial<AdBreakPolicy>;
  emotions?: Pick<EmotionArc, 'samples'> | EmotionSample[];
  safety?: Pick<SafetyReport, 'segments'>;
  /** Known scene boundaries (seconds). Defaults to the candidate positions. */
  sceneChanges?: number[];
  fps?: number;
  itemId?: string;
  model?: string;
  /** Preserve review state from a previous plan, matched by proximity (±2s). */
  previous?: AdBreak[];
}

export const SAFETY_RADIUS_SEC = 45;
export const FLAG_RADIUS_SEC = 60;
export const MAX_WINDOW_SEC = 8;

/** Policy defaults scaled to runtime: ~1 pod per 8 minutes, min 4 min apart, 2 min fences. */
export function defaultPolicy(durationSec: number, overrides: Partial<AdBreakPolicy> = {}): AdBreakPolicy {
  const base: AdBreakPolicy = {
    targetBreaks: clamp(Math.round(durationSec / 480), 1, 8),
    minSpacingSec: 240,
    avoidFirstSec: 120,
    avoidLastSec: 120,
  };
  const merged = { ...base, ...stripUndefined(overrides) };
  // A short film cannot honour 2-minute fences and 4-minute spacing at once; relax proportionally.
  const usable = durationSec - merged.avoidFirstSec - merged.avoidLastSec;
  if (usable < merged.minSpacingSec) {
    merged.minSpacingSec = Math.max(30, Math.floor(usable / 2));
  }
  return merged;
}

function stripUndefined<T extends object>(o: T): Partial<T> {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined)) as Partial<T>;
}

const REASON_BONUS: Record<AdBreakCandidate['reasonType'], number> = {
  scene_change: 0.15,
  act_break: 0.15,
  fade: 0.12,
  music_end: 0.06,
  location_change: 0.08,
  dialogue_gap: 0,
  other: -0.05,
};

/** Mean arousal over [from, to] using overlap-weighted samples; undefined when no coverage. */
export function meanArousal(samples: EmotionSample[], from: number, to: number): number | undefined {
  let weight = 0;
  let sum = 0;
  for (const s of samples) {
    const overlap = Math.min(s.end, to) - Math.max(s.start, from);
    if (overlap <= 0) continue;
    weight += overlap;
    sum += overlap * s.arousal;
  }
  return weight > 0 ? sum / weight : undefined;
}

/** Arousal slope across a point: mean(after 20s) − mean(before 20s). Positive = rising. */
export function arousalSlope(samples: EmotionSample[], at: number, radius = 20): number {
  const before = meanArousal(samples, at - radius, at);
  const after = meanArousal(samples, at, at + radius);
  if (before === undefined || after === undefined) return 0;
  return after - before;
}

function emotionAdjustment(slope: number): number {
  // Rising steeply (>0.15) is heavily penalised; mildly rising a bit; falling/flat rewarded.
  if (slope > 0.15) return -0.35;
  if (slope > 0.05) return -0.12;
  if (slope < -0.05) return 0.08;
  return 0.04;
}

interface Scored {
  cand: AdBreakCandidate;
  score: number;
  suitable: boolean;
  flags: ScoredLabels;
  slope: number;
}

export function planAdBreaks(candidates: AdBreakCandidate[], opts: PlanOptions): AdBreakPlan {
  const policy = defaultPolicy(opts.durationSec, opts.policy);
  const samples = Array.isArray(opts.emotions) ? opts.emotions : (opts.emotions?.samples ?? []);
  const safetySegments = opts.safety?.segments ?? [];
  const itemId = opts.itemId ?? '';

  const lo = policy.avoidFirstSec;
  const hi = opts.durationSec - policy.avoidLastSec;

  // 1. Fences + dedupe (two candidates within 3s are the same cut; keep the more confident).
  const fenced = [...candidates]
    .filter((c) => Number.isFinite(c.at) && c.at >= lo && c.at <= hi)
    .sort((a, b) => a.at - b.at)
    .filter((c, i, arr) => {
      const prev = arr[i - 1];
      return !(prev && c.at - prev.at < 3 && prev.confidence >= c.confidence);
    });

  // 2–4. Score.
  const scored: Scored[] = fenced.map((cand) => {
    const flags: ScoredLabels = {};
    let suitable = true;
    for (const seg of safetySegments) {
      const dist = Math.max(0, Math.max(seg.start - cand.at, cand.at - seg.end));
      if (dist <= FLAG_RADIUS_SEC) {
        const weight = seg.severity === 'high' ? 1 : seg.severity === 'medium' ? 0.7 : 0.4;
        const prior = flags[seg.category] ?? 0;
        flags[seg.category] = round(Math.max(prior, clamp(seg.confidence * weight, 0, 1)), 3);
      }
      if (seg.severity === 'high' && dist <= SAFETY_RADIUS_SEC) suitable = false;
    }
    const slope = arousalSlope(samples, cand.at);
    const score =
      clamp(cand.confidence, 0, 1) +
      (REASON_BONUS[cand.reasonType] ?? 0) +
      emotionAdjustment(slope) -
      Object.values(flags).reduce((acc, v) => acc + v * 0.1, 0);
    return { cand, score, suitable, flags, slope };
  });

  // 5. Greedy selection with spacing; suitable candidates first, unsuitable only to reach the target.
  const pick = (pool: Scored[], chosen: Scored[]): Scored[] => {
    const out = [...chosen];
    for (const s of [...pool].sort((a, b) => b.score - a.score || a.cand.at - b.cand.at)) {
      if (out.length >= policy.targetBreaks) break;
      if (out.every((o) => Math.abs(o.cand.at - s.cand.at) >= policy.minSpacingSec)) out.push(s);
    }
    return out;
  };
  let chosen = pick(
    scored.filter((s) => s.suitable),
    [],
  );
  if (chosen.length < policy.targetBreaks) {
    chosen = pick(
      scored.filter((s) => !s.suitable),
      chosen,
    );
  }

  // Rank by score, then order by time for output.
  const ranked = [...chosen].sort((a, b) => b.score - a.score || a.cand.at - b.cand.at);
  const rankOf = new Map(ranked.map((s, i) => [s, i + 1] as const));

  // 6. Windows from neighbouring scene boundaries.
  const scenes = Array.from(new Set([...(opts.sceneChanges ?? []), ...candidates.map((c) => c.at)])).sort((a, b) => a - b);

  const breaks: AdBreak[] = chosen
    .sort((a, b) => a.cand.at - b.cand.at)
    .map((s) => {
      const at = round(s.cand.at, 3);
      const neighbours = scenes.filter((x) => Math.abs(x - at) > 0.5);
      const prev = neighbours.filter((x) => x < at).at(-1);
      const next = neighbours.find((x) => x > at);
      const halfPrev = prev !== undefined ? (at - prev) / 2 : MAX_WINDOW_SEC;
      const halfNext = next !== undefined ? (next - at) / 2 : MAX_WINDOW_SEC;
      const radius = Math.max(1, Math.min(MAX_WINDOW_SEC, halfPrev, halfNext));
      const previous = opts.previous?.find((p) => Math.abs(p.at - at) <= 2);
      const brk: AdBreak = {
        id: previous?.id ?? makeId('brk', `${itemId}:${at}`),
        at,
        window: {
          start: round(clamp(at - radius, lo, at), 3),
          end: round(clamp(at + radius, at, hi), 3),
        },
        rank: rankOf.get(s) ?? chosen.length,
        // Calibrated view: the model's confidence nudged half-weight by the planner's adjustments.
        confidence: round(clamp(s.cand.confidence + 0.5 * (s.score - s.cand.confidence), 0.05, 0.98), 3),
        reason: s.cand.reason,
        sceneBefore: s.cand.sceneBefore,
        sceneAfter: s.cand.sceneAfter,
        mood: s.cand.mood ?? {},
        keywords: s.cand.keywords ?? {},
        iab: s.cand.iab ?? [],
        brandSafety: { suitable: s.suitable, flags: s.flags },
      };
      if (opts.fps) brk.frame = Math.round(at * opts.fps);
      if (previous?.review) brk.review = previous.review;
      return brk;
    });

  return {
    itemId,
    breaks,
    policy,
    model: opts.model ?? 'planner',
    generatedAt: nowIso(),
  };
}
