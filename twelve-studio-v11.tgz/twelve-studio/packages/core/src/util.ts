/**
 * Small, dependency-free helpers shared by the core modules.
 */

/** FNV-1a 32-bit hash — deterministic across runs and platforms. */
export function hash32(input: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

/** mulberry32 — a tiny seeded PRNG returning floats in [0, 1). */
export function seededRandom(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function round(value: number, decimals = 2): number {
  const f = 10 ** decimals;
  return Math.round(value * f) / f;
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Short, URL-safe id with a readable prefix (e.g. `brk_3f9a2c`). */
export function makeId(prefix: string, seed?: string): string {
  const body = seed !== undefined ? hash32(seed).toString(36).padStart(7, '0') : Math.random().toString(36).slice(2, 9);
  return `${prefix}_${body}`;
}

export function nowIso(): string {
  return new Date().toISOString();
}

/** Seconds → `HH:MM:SS.mmm` (VMAP / SMPTE-style time offsets). */
export function toTimeOffset(sec: number): string {
  const s = Math.max(0, sec);
  const hh = Math.floor(s / 3600);
  const mm = Math.floor((s % 3600) / 60);
  const ss = Math.floor(s % 60);
  const ms = Math.round((s - Math.floor(s)) * 1000);
  const pad = (n: number, w = 2) => String(n).padStart(w, '0');
  return `${pad(hh)}:${pad(mm)}:${pad(ss)}.${pad(ms, 3)}`;
}

/** Seconds → broadcast timecode `HH:MM:SS:FF` for a given fps. */
export function toTimecode(sec: number, fps = 24): string {
  const s = Math.max(0, sec);
  const totalFrames = Math.round(s * fps);
  const fpsInt = Math.round(fps);
  const frames = totalFrames % fpsInt;
  const totalSec = Math.floor(totalFrames / fpsInt);
  const hh = Math.floor(totalSec / 3600);
  const mm = Math.floor((totalSec % 3600) / 60);
  const ss = totalSec % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(hh)}:${pad(mm)}:${pad(ss)}:${pad(frames)}`;
}

/** Top-N entries of a `{label: score}` map, highest first. */
export function topLabels(labels: Record<string, number> | undefined, n: number): Array<[string, number]> {
  if (!labels) return [];
  return Object.entries(labels)
    .sort((a, b) => b[1] - a[1])
    .slice(0, n);
}

/** Strip Markdown code fences and parse JSON; throws with a helpful message on failure. */
export function parseJsonRobust<T = unknown>(text: string): T {
  let s = text.trim();
  // ```json ... ``` or ``` ... ```
  const fence = s.match(/^```[a-zA-Z]*\s*([\s\S]*?)\s*```$/);
  if (fence && fence[1] !== undefined) s = fence[1].trim();
  try {
    return JSON.parse(s) as T;
  } catch {
    // Fall back to the outermost JSON object/array in the string.
    const firstObj = s.indexOf('{');
    const firstArr = s.indexOf('[');
    const starts = [firstObj, firstArr].filter((i) => i >= 0);
    if (starts.length === 0) throw new Error(`Model output is not JSON: ${s.slice(0, 120)}`);
    const start = Math.min(...starts);
    const closer = s[start] === '{' ? '}' : ']';
    const end = s.lastIndexOf(closer);
    if (end <= start) throw new Error(`Model output is not JSON: ${s.slice(0, 120)}`);
    return JSON.parse(s.slice(start, end + 1)) as T;
  }
}

/** True for a publicly fetchable http(s) URL (as opposed to a local path or file:// URL). */
export function isHttpUrl(value: string | undefined): boolean {
  return typeof value === 'string' && /^https?:\/\//i.test(value.trim());
}

/** Direct-upload ceiling for `POST /assets` with `method=direct` (bytes). */
export const DIRECT_UPLOAD_MAX_BYTES = 200 * 1024 * 1024;
