/**
 * Twelve Studio — shared domain contract.
 *
 * Every product surface (REST API, web app, MCP server) speaks these types.
 * The shape deliberately mirrors what media buyers already know from
 * Vionlabs-style products, then goes further where TwelveLabs makes it possible
 * (continuous emotion arcs, calibrated confidences, break windows not points,
 * open vocabularies, natural-language search at the API layer).
 */

/** A `{label: confidence}` map — the probabilistic tag chip seen across the UI. */
export type ScoredLabels = Record<string, number>;

export type ItemType = 'movie' | 'episode' | 'short' | 'clip' | 'promo' | 'other';

export type JobKind =
  | 'ingest'
  | 'fingerprint'
  | 'emotions'
  | 'markers'
  | 'adbreaks'
  | 'safety'
  | 'thumbnails'
  | 'clips'
  | 'embedding';

export type JobStatus = 'queued' | 'running' | 'ready' | 'failed' | 'skipped';

export interface Job {
  id: string;
  itemId: string;
  kind: JobKind;
  status: JobStatus;
  startedAt?: string;
  finishedAt?: string;
  error?: string;
  /** Upstream TwelveLabs identifiers used by this job (for audit + billing). */
  upstream?: { assetId?: string; indexedAssetId?: string; taskId?: string; model?: string };
}

/* ------------------------------------------------------------------ */
/* Catalog                                                             */
/* ------------------------------------------------------------------ */

export interface CatalogItemInput {
  title: string;
  type?: ItemType;
  year?: number;
  /** Publicly reachable video URL (mp4/mov/HLS) or a YouTube link. */
  sourceUrl: string;
  posterUrl?: string;
  series?: { title: string; season?: number; episode?: number };
  externalIds?: Record<string, string>;
  /** Editorial metadata the customer already holds (genres, cast, etc). */
  metadata?: Record<string, unknown>;
}

export interface CatalogItem extends CatalogItemInput {
  id: string;
  type: ItemType;
  createdAt: string;
  updatedAt: string;
  durationSec?: number;
  fps?: number;
  width?: number;
  height?: number;
  /** Absolute path on the API host when the item was ingested from disk. */
  localPath?: string;
  /** Absolute path of a poster image on the API host (served at `/api/catalog/:id/poster`). */
  posterPath?: string;
  /** HLS playback + thumbnail sprites when TwelveLabs produced them; `fileUrl` when served from a local file. */
  playback?: { hlsUrl?: string; fileUrl?: string; thumbnailUrls?: string[] };
  status: 'ingesting' | 'indexing' | 'enriching' | 'ready' | 'failed';
  upstream?: { assetId?: string; indexedAssetId?: string; indexId?: string };
  jobs: Partial<Record<JobKind, JobStatus>>;
  /** Present once the fingerprint job has run. */
  fingerprint?: Fingerprint;
}

/* ------------------------------------------------------------------ */
/* Fingerprint+ (title-level understanding)                            */
/* ------------------------------------------------------------------ */

export interface Synopsis {
  short: string;
  long: string;
  /** ISO-639-1 → synopsis. Open-ended: any language Pegasus can write. */
  translations?: Record<string, { short: string; long: string }>;
}

export interface Fingerprint {
  genres: ScoredLabels;
  keywords: ScoredLabels;
  /** Coarse mood categories (e.g. dark, hopeful, tense). */
  moods: ScoredLabels;
  /** Fine-grained narrative/mood tags (e.g. "found family", "betrayal"). */
  moodTags: ScoredLabels;
  themes: ScoredLabels;
  /** Named characters with prominence 0..1 and a one-line description. */
  characters: Array<{ name: string; prominence: number; description: string }>;
  /** Pacing 0..1 (slow → frenetic) and its rationale. */
  pacing: { score: number; rationale: string };
  language: { primary: string; others?: string[] };
  audienceRating: { suggested: 'G' | 'PG' | 'PG-13' | 'R' | 'TV-Y' | 'TV-PG' | 'TV-14' | 'TV-MA'; rationale: string };
  synopsis: Synopsis;
  /** Marengo embedding (video scope) for similarity. Omitted from list responses. */
  embedding?: number[];
  model: string;
  generatedAt: string;
}

/* ------------------------------------------------------------------ */
/* Emotions (continuous, scene-aligned)                                */
/* ------------------------------------------------------------------ */

export interface EmotionSample {
  start: number;
  end: number;
  /** -1..1 unpleasant → pleasant */
  valence: number;
  /** 0..1 calm → intense */
  arousal: number;
  /** 0..1 submissive/vulnerable → dominant/in-control */
  dominance: number;
  /** Discrete emotions with probability. */
  emotions: ScoredLabels;
  /** One-line description of what is happening on screen. */
  beat: string;
  confidence: number;
}

export interface EmotionArc {
  itemId: string;
  samples: EmotionSample[];
  /** Named narrative acts derived from the arc. */
  acts: Array<{ name: string; start: number; end: number; summary: string }>;
  /** The single most intense moment. */
  climax?: { at: number; description: string };
  model: string;
  generatedAt: string;
}

/* ------------------------------------------------------------------ */
/* Markers (intro / recap / credits / chapters)                        */
/* ------------------------------------------------------------------ */

export type MarkerKind =
  | 'cold_open'
  | 'recap'
  | 'intro'
  | 'title_card'
  | 'chapter'
  | 'credits'
  | 'post_credits'
  | 'next_episode_hook'
  | 'preview';

export interface Marker {
  id: string;
  kind: MarkerKind;
  start: number;
  end: number;
  /** Frame-accurate start/end when fps is known. */
  startFrame?: number;
  endFrame?: number;
  label?: string;
  confidence: number;
  /** Human review state. */
  review?: ReviewState;
}

export interface MarkerSet {
  itemId: string;
  fps?: number;
  markers: Marker[];
  model: string;
  generatedAt: string;
}

/* ------------------------------------------------------------------ */
/* Ad breaks (windows, ranked, contextual, SCTE-35 ready)              */
/* ------------------------------------------------------------------ */

export interface AdBreak {
  id: string;
  /** Preferred insertion point (seconds). */
  at: number;
  /** Acceptable window around `at` in which a break is still natural. */
  window: { start: number; end: number };
  frame?: number;
  rank: number;
  confidence: number;
  /** Why this is a natural pause (scene change, dialogue gap, act break…). */
  reason: string;
  sceneBefore: string;
  sceneAfter: string;
  /** Emotional state entering the break — for tone-matched creative. */
  mood: ScoredLabels;
  keywords: ScoredLabels;
  iab: Array<{ id: string; name: string; tier: 1 | 2 | 3; confidence: number }>;
  brandSafety: {
    suitable: boolean;
    /** GARM-style categories flagged within ±60s. */
    flags: ScoredLabels;
  };
  /** Ad creative assigned to this break (see AdCreative). */
  creativeId?: string;
  /** Keyframe-aligned insertion point chosen by the stitcher, inside `window`. */
  snappedAt?: number;
  review?: ReviewState;
}

/* ------------------------------------------------------------------ */
/* Ad creatives and stitched previews                                  */
/* ------------------------------------------------------------------ */

export interface AdCreative {
  id: string;
  name: string;
  advertiser?: string;
  durationSec: number;
  /** Absolute file path on the API host when the creative was added from disk. */
  localPath?: string;
  /** Public URL when added from the web. */
  sourceUrl?: string;
  /** Where a player can fetch it: `/api/ads/:id/media` for local files, else `sourceUrl`. */
  mediaUrl: string;
  width?: number;
  height?: number;
  /** TwelveLabs asset this creative was imported from (or uploaded as). */
  upstream?: { assetId?: string };
  /** Pegasus creative intelligence (brand, mood, keywords, IAB, safety) used for break fit. */
  fingerprint?: AdFingerprint;
  createdAt: string;
}

/** What Pegasus sees in an ad creative; the same vocabularies as an AdBreak so fit can be scored. */
export interface AdFingerprint {
  brand: string;
  product: string;
  tagline?: string;
  callToAction?: string;
  synopsis: string;
  mood: ScoredLabels;
  keywords: ScoredLabels;
  /** Tone dimensions (humorous, emotional, energetic, premium, family) as probabilities. */
  tone: ScoredLabels;
  iab: Array<{ id: string; name: string; tier: 1 | 2 | 3; confidence: number }>;
  /** Content the creative itself contains that may clash with surrounding content (e.g. alcohol next to a kids' show). */
  sensitivities: Array<{ category: SafetyCategory; severity: SafetySegment['severity']; description: string; confidence: number }>;
  /** Probability the creative is suitable for family / all-audience placements. */
  familySafe: number;
  pacing: { score: number; rationale: string };
  /** Key beats (product reveal, logo, end card) as absolute seconds. */
  moments: Array<{ at: number; label: string }>;
  language: { primary: string; others: string[] };
  model: string;
  generatedAt: string;
}

/** How well a creative fits one break, with the overlaps that produced the score. */
export interface CreativeFit {
  creativeId: string;
  breakId: string;
  /** 0..1 weighted blend of mood, keyword, IAB and safety agreement. */
  score: number;
  mood: number;
  keywords: number;
  iab: number;
  /** 1 when neither side carries a clashing sensitivity, lower when they do. */
  safety: number;
  because: string[];
}

export interface StitchJob {
  id: string;
  itemId: string;
  creativeId: string;
  status: JobStatus;
  /** Breaks included, in time order, with the exact insertion point used. */
  insertions: Array<{ breakId: string; requestedAt: number; snappedAt: number }>;
  /** `/api/renders/:file` once ready. */
  outputUrl?: string;
  outputPath?: string;
  durationSec?: number;
  /** Tail of ffmpeg stderr on failure. */
  log?: string;
  error?: string;
  createdAt: string;
  finishedAt?: string;
}

export interface AdBreakPlan {
  itemId: string;
  breaks: AdBreak[];
  /** Pod plan honouring min spacing and target count. */
  policy: { targetBreaks: number; minSpacingSec: number; avoidFirstSec: number; avoidLastSec: number };
  model: string;
  generatedAt: string;
}

/* ------------------------------------------------------------------ */
/* Content safety                                                      */
/* ------------------------------------------------------------------ */

export type SafetyCategory =
  | 'nudity'
  | 'sexual_content'
  | 'violence'
  | 'gore'
  | 'profanity'
  | 'drugs'
  | 'alcohol'
  | 'tobacco'
  | 'weapons'
  | 'hate'
  | 'self_harm'
  | 'flashing_lights';

export interface SafetySegment {
  id: string;
  category: SafetyCategory;
  severity: 'low' | 'medium' | 'high';
  start: number;
  end: number;
  description: string;
  confidence: number;
}

export interface SafetyReport {
  itemId: string;
  segments: SafetySegment[];
  /** Rollup used for brand-safety and ratings. */
  summary: Partial<Record<SafetyCategory, { maxSeverity: 'low' | 'medium' | 'high'; totalSec: number }>>;
  model: string;
  generatedAt: string;
}

/* ------------------------------------------------------------------ */
/* Creative: thumbnails and preview clips                              */
/* ------------------------------------------------------------------ */

export interface ThumbnailCandidate {
  id: string;
  /** Seconds into the asset. */
  at: number;
  frame?: number;
  /** Composite score 0..1 and the parts that made it. */
  score: number;
  factors: {
    relevance: number;
    aesthetics: number;
    faceProminence: number;
    stillness: number;
    brightness: number;
    safeArea: number;
  };
  characters: string[];
  mood: ScoredLabels;
  /** Suggested crop for 2:3 / 1:1 / 9:16 as fractional {x,y,w,h}. */
  crops: Record<'16:9' | '2:3' | '1:1' | '9:16', { x: number; y: number; w: number; h: number }>;
  /** Where a logo/title-treatment could sit without covering faces. */
  logoSafeZone: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'center';
  safe: boolean;
  caption: string;
  imageUrl?: string;
}

export interface PreviewClip {
  id: string;
  start: number;
  end: number;
  clipType: string;
  relevance: number;
  /** Populated when produced against a natural-language query. */
  queryRelevance?: number;
  query?: string;
  characters: string[];
  mood: ScoredLabels;
  keywords: ScoredLabels;
  safe: boolean;
  /** Suggested reframe path for 9:16 as keyframes of fractional x-centre. */
  reframe916?: Array<{ at: number; cx: number }>;
  caption: string;
  posterAt: number;
}

export interface Recipe {
  id: string;
  name: string;
  target: 'thumbnails' | 'clips';
  /** Natural-language creative brief (open vocabulary — not an enum). */
  brief: string;
  count: number;
  clipLengthSec?: [number, number];
  formats: Array<'16:9' | '2:3' | '1:1' | '9:16'>;
  requireCharacters?: string[];
  excludeSafetyCategories?: SafetyCategory[];
  createdAt: string;
}

export interface CreativeRun {
  id: string;
  recipeId: string;
  itemId: string;
  status: JobStatus;
  thumbnails?: ThumbnailCandidate[];
  clips?: PreviewClip[];
  createdAt: string;
}

/* ------------------------------------------------------------------ */
/* Discovery: search, similar, smart lists                             */
/* ------------------------------------------------------------------ */

export interface SearchHit {
  itemId: string;
  title: string;
  start: number;
  end: number;
  rank: number;
  score?: number;
  thumbnailUrl?: string;
  transcript?: string;
  modality?: 'visual' | 'audio' | 'transcription';
}

export interface SearchResponse {
  query: string;
  hits: SearchHit[];
  nextPageToken?: string;
  pool: { items: number; totalDurationSec: number };
}

export interface SimilarTitle {
  itemId: string;
  title: string;
  score: number;
  /** Which fingerprint facets drove the match. */
  because: string[];
}

export interface SmartListRule {
  facet: 'genres' | 'keywords' | 'moods' | 'moodTags' | 'themes';
  label: string;
  min: number;
  max: number;
}

export interface SmartList {
  id: string;
  name: string;
  description?: string;
  /** Either rule-based, NL query, or AI-curated cluster. */
  source: 'rules' | 'query' | 'ai';
  rules?: SmartListRule[];
  query?: string;
  itemIds: string[];
  coverage?: number;
  createdAt: string;
  updatedAt: string;
}

/* ------------------------------------------------------------------ */
/* Review workflow                                                     */
/* ------------------------------------------------------------------ */

export interface Comment {
  id: string;
  author: string;
  text: string;
  at: string;
}

export interface ReviewState {
  status: 'open' | 'approved' | 'declined';
  rating?: 0 | 1 | 2 | 3 | 4 | 5;
  comments: Comment[];
  reviewedBy?: string;
  reviewedAt?: string;
}

/* ------------------------------------------------------------------ */
/* Full enrichment bundle for one item                                 */
/* ------------------------------------------------------------------ */

export interface ItemBundle {
  item: CatalogItem;
  fingerprint?: Fingerprint;
  emotions?: EmotionArc;
  markers?: MarkerSet;
  adBreaks?: AdBreakPlan;
  safety?: SafetyReport;
  thumbnails?: ThumbnailCandidate[];
  clips?: PreviewClip[];
  jobs: Job[];
}

export interface CatalogStats {
  items: number;
  ready: number;
  totalDurationSec: number;
  lists: number;
  coverage: number;
  pendingReviews: number;
}
