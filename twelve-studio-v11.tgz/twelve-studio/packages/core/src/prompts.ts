/**
 * Pegasus prompts + JSON schemas, one per enrichment job.
 *
 * Every function returns `{prompt, schema}`; the schema is sent as
 * `response_format:{type:'json_schema', json_schema}` on POST /v1.3/analyze and
 * shapes the reply so it parses straight into the types in `types.ts`.
 *
 * Design rules baked into every prompt:
 *   - the model is told the title, duration and fps so timestamps are absolute
 *     seconds and frame maths is possible downstream;
 *   - every judgement is a calibrated probability 0..1, never a boolean, so the
 *     UI can render "label 0.93" chips and reviewers can set thresholds;
 *   - vocabularies are open (free text) but bounded in count (5–12 per facet)
 *     so results stay legible and comparable across a catalog;
 *   - the creative brief (thumbnails/clips) and the synopsis languages are
 *     parameters, not hard-coded.
 */

import type {
  AdBreak,
  AdFingerprint,
  EmotionArc,
  Fingerprint,
  Marker,
  PreviewClip,
  SafetySegment,
  ThumbnailCandidate,
} from './types.js';
import type { JsonSchema } from './twelvelabs.js';
import { toTimeOffset } from './util.js';

/* ------------------------------------------------------------------ */
/* Payload types (what each schema produces)                           */
/* ------------------------------------------------------------------ */

/** Fingerprint as Pegasus writes it — the pipeline adds `embedding`, `model`, `generatedAt`. */
export type FingerprintPayload = Omit<Fingerprint, 'embedding' | 'model' | 'generatedAt'>;

export type EmotionArcPayload = Pick<EmotionArc, 'samples' | 'acts' | 'climax'>;

export type MarkerPayload = Pick<Marker, 'kind' | 'start' | 'end' | 'label' | 'confidence'>;
export interface MarkersPayload {
  markers: MarkerPayload[];
}

export type SafetySegmentPayload = Omit<SafetySegment, 'id'>;
export interface SafetyPayload {
  segments: SafetySegmentPayload[];
}

/** A candidate natural pause as Pegasus reports it; `adbreaks.ts` turns these into ranked `AdBreak`s. */
export interface AdBreakCandidate {
  at: number;
  confidence: number;
  reason: string;
  /** Coarse reason class — scene changes make the best pods. */
  reasonType: 'scene_change' | 'act_break' | 'dialogue_gap' | 'fade' | 'music_end' | 'location_change' | 'other';
  sceneBefore: string;
  sceneAfter: string;
  mood: AdBreak['mood'];
  keywords: AdBreak['keywords'];
  iab: AdBreak['iab'];
}
export interface AdBreakCandidatesPayload {
  candidates: AdBreakCandidate[];
}

export type ThumbnailPayload = Omit<ThumbnailCandidate, 'id' | 'frame' | 'score' | 'imageUrl'>;
export interface ThumbnailsPayload {
  thumbnails: ThumbnailPayload[];
}

export type PreviewClipPayload = Omit<PreviewClip, 'id'>;
export interface ClipsPayload {
  clips: PreviewClipPayload[];
}

/* ------------------------------------------------------------------ */
/* Context every prompt receives                                       */
/* ------------------------------------------------------------------ */

export interface PromptContext {
  title: string;
  durationSec: number;
  fps: number;
  year?: number;
  type?: string;
  series?: { title: string; season?: number; episode?: number };
  /** Customer-supplied editorial metadata; mentioned as hints, never trusted over the video. */
  metadata?: Record<string, unknown>;
}

export interface PromptBundle {
  prompt: string;
  schema: JsonSchema;
  /** Sensible `max_tokens` for the job. */
  maxTokens: number;
}

/* ------------------------------------------------------------------ */
/* Schema helpers                                                      */
/* ------------------------------------------------------------------ */

const num = (min?: number, max?: number, description?: string): JsonSchema => {
  const s: JsonSchema = { type: 'number' };
  if (min !== undefined) s.minimum = min;
  if (max !== undefined) s.maximum = max;
  if (description) s.description = description;
  return s;
};
const p01 = (description: string): JsonSchema => num(0, 1, description);
const str = (description?: string): JsonSchema => (description ? { type: 'string', description } : { type: 'string' });
const enumOf = (values: readonly string[], description?: string): JsonSchema => ({
  type: 'string',
  enum: [...values],
  ...(description ? { description } : {}),
});
const arr = (items: JsonSchema, opts: { min?: number; max?: number; description?: string } = {}): JsonSchema => {
  const s: JsonSchema = { type: 'array', items };
  if (opts.min !== undefined) s.minItems = opts.min;
  if (opts.max !== undefined) s.maxItems = opts.max;
  if (opts.description) s.description = opts.description;
  return s;
};
const obj = (properties: Record<string, JsonSchema>, required: string[] = Object.keys(properties)): JsonSchema => ({
  type: 'object',
  properties,
  required,
  additionalProperties: false,
});
/** `{label: probability}` map with an open vocabulary. */
const scoredLabels = (description: string, min = 5, max = 12): JsonSchema => ({
  type: 'object',
  description: `${description} Free-text labels (lower-case, 1–3 words) → calibrated probability 0..1. Give ${min}–${max} entries.`,
  additionalProperties: num(0, 1),
  minProperties: min,
  maxProperties: max,
});

const RATINGS = ['G', 'PG', 'PG-13', 'R', 'TV-Y', 'TV-PG', 'TV-14', 'TV-MA'] as const;
const MARKER_KINDS = [
  'cold_open',
  'recap',
  'intro',
  'title_card',
  'chapter',
  'credits',
  'post_credits',
  'next_episode_hook',
  'preview',
] as const;
const SAFETY_CATEGORIES = [
  'nudity',
  'sexual_content',
  'violence',
  'gore',
  'profanity',
  'drugs',
  'alcohol',
  'tobacco',
  'weapons',
  'hate',
  'self_harm',
  'flashing_lights',
] as const;
const SEVERITIES = ['low', 'medium', 'high'] as const;
const LOGO_ZONES = ['top-left', 'top-right', 'bottom-left', 'bottom-right', 'center'] as const;
const REASON_TYPES = ['scene_change', 'act_break', 'dialogue_gap', 'fade', 'music_end', 'location_change', 'other'] as const;

const crop = (): JsonSchema =>
  obj({
    x: p01('left edge as a fraction of frame width'),
    y: p01('top edge as a fraction of frame height'),
    w: p01('width as a fraction of frame width'),
    h: p01('height as a fraction of frame height'),
  });

/* ------------------------------------------------------------------ */
/* Shared preamble                                                     */
/* ------------------------------------------------------------------ */

function preamble(ctx: PromptContext, role: string): string {
  const mins = Math.floor(ctx.durationSec / 60);
  const secs = Math.round(ctx.durationSec % 60);
  const lines = [
    `You are ${role} working on the video "${ctx.title}"${ctx.year ? ` (${ctx.year})` : ''}${
      ctx.series ? `, ${ctx.series.title}${ctx.series.season ? ` S${ctx.series.season}` : ''}${ctx.series.episode ? `E${ctx.series.episode}` : ''}` : ''
    }.`,
    `Facts about the file: duration ${ctx.durationSec.toFixed(1)} seconds (${mins}m${secs}s, ends at ${toTimeOffset(ctx.durationSec)}), ${ctx.fps} frames per second${ctx.type ? `, content type "${ctx.type}"` : ''}.`,
    `All timestamps you output are ABSOLUTE seconds from the start of the video (decimals allowed, e.g. 312.5), never relative offsets, never mm:ss strings, and never beyond ${ctx.durationSec.toFixed(1)}.`,
    `Express every judgement as a calibrated probability between 0 and 1 (0.93 = very sure, 0.55 = coin-flip). Do not output booleans where a probability is asked for. Only claim what you actually see or hear; when unsure, lower the probability rather than omitting the label.`,
  ];
  if (ctx.metadata && Object.keys(ctx.metadata).length > 0) {
    lines.push(
      `The customer supplied this metadata as a hint only — verify against the video and do not copy it blindly: ${JSON.stringify(ctx.metadata).slice(0, 800)}`,
    );
  }
  lines.push('Answer with a single JSON object that matches the provided schema exactly. No prose, no code fences.');
  return lines.join('\n');
}

/* ------------------------------------------------------------------ */
/* 1. Fingerprint                                                      */
/* ------------------------------------------------------------------ */

export function fingerprintPrompt(ctx: PromptContext, opts: { languages?: string[] } = {}): PromptBundle {
  const languages = (opts.languages ?? []).filter((l) => l && l !== 'en');
  const prompt = [
    preamble(ctx, 'a senior editorial metadata analyst for a streaming service'),
    '',
    'Watch the whole video (picture, dialogue, music, on-screen text) and produce a title-level fingerprint used for discovery, recommendations and merchandising.',
    '',
    'Fill these facets. Use an OPEN vocabulary — pick the labels that best describe THIS title, not a fixed list — but keep labels short (1–3 lower-case words) and give 5–12 labels per facet with a probability for each:',
    '- genres: film/TV genres and sub-genres (e.g. "fantasy", "coming of age", "sci-fi action").',
    '- keywords: concrete, searchable nouns and situations (e.g. "dragon", "snowstorm", "rooftop", "robot uprising").',
    '- moods: coarse tonal categories (e.g. "melancholic", "hopeful", "tense", "whimsical").',
    '- moodTags: fine-grained narrative or emotional tags (e.g. "found family", "betrayal", "grief", "quest").',
    '- themes: what the story is about at a deeper level (e.g. "loss", "loyalty", "identity", "man vs machine").',
    '- characters: the named or clearly identifiable characters, each with prominence 0..1 (screen time and narrative importance) and a one-line description. List 1–8, most prominent first. Use names from dialogue or credits; otherwise describe them ("the shaman").',
    '- pacing: a single score 0..1 where 0 is contemplative and slow, 1 is frenetic; plus a one-sentence rationale citing cut rate, action density and dialogue tempo.',
    '- language: primary spoken language as ISO-639-1 (e.g. "en"), plus any others heard. Use "none" if there is no dialogue.',
    '- audienceRating: the most appropriate rating from the allowed list with a one-sentence rationale grounded in what is shown (violence, language, themes).',
    '- synopsis.short: one sentence, max 160 characters, spoiler-free, written like a streaming tile.',
    '- synopsis.long: 3–5 sentences, 400–800 characters, covering set-up, escalation and tone without spoiling the ending.',
    languages.length
      ? `- synopsis.translations: translate BOTH synopses into each of these languages, keyed by ISO-639-1 code: ${languages.join(', ')}. Translate naturally for a native reader; keep character names unchanged. Include every requested language.`
      : '- synopsis.translations: leave as an empty object.',
  ].join('\n');

  const synopsisPair = obj({ short: str('max 160 characters'), long: str('400–800 characters') });
  const schema = obj({
    genres: scoredLabels('Genres and sub-genres.'),
    keywords: scoredLabels('Searchable concrete keywords.', 8, 12),
    moods: scoredLabels('Coarse mood categories.'),
    moodTags: scoredLabels('Fine-grained narrative/mood tags.'),
    themes: scoredLabels('Themes.'),
    characters: arr(
      obj({
        name: str(),
        prominence: p01('screen time × narrative importance'),
        description: str('one line'),
      }),
      { min: 1, max: 8 },
    ),
    pacing: obj({ score: p01('0 slow → 1 frenetic'), rationale: str() }),
    language: obj({ primary: str('ISO-639-1 or "none"'), others: arr(str(), { max: 5 }) }),
    audienceRating: obj({ suggested: enumOf(RATINGS), rationale: str() }),
    synopsis: obj({
      short: str('max 160 characters, spoiler-free'),
      long: str('400–800 characters'),
      translations: {
        type: 'object',
        description: 'ISO-639-1 code → {short, long}',
        additionalProperties: synopsisPair,
      },
    }),
  });

  return { prompt, schema, maxTokens: languages.length ? 7000 : 3500 };
}

/* ------------------------------------------------------------------ */
/* 2. Emotion arc                                                      */
/* ------------------------------------------------------------------ */

export function emotionsPrompt(ctx: PromptContext): PromptBundle {
  const target = Math.min(60, Math.max(6, Math.round(ctx.durationSec / 25)));
  const step = Math.max(20, Math.min(30, Math.round(ctx.durationSec / target)));
  const prompt = [
    preamble(ctx, 'an affective-computing annotator who maps the emotional arc of films for editors and ad planners'),
    '',
    `Divide the video into consecutive, non-overlapping windows of roughly ${step} seconds (about ${target} windows in total, never more than 60, covering 0 to ${ctx.durationSec.toFixed(1)} with no gaps). Snap window edges to scene or shot boundaries where you can so that each sample describes one coherent beat.`,
    '',
    'For each window report:',
    '- start / end in absolute seconds.',
    '- valence from -1 (unpleasant, sad, frightening) to +1 (pleasant, joyful, triumphant). Neutral is 0.',
    '- arousal from 0 (calm, still, quiet) to 1 (intense, fast, loud). Base this on motion, cut rate, music energy, volume and stakes.',
    '- dominance from 0 (protagonist is vulnerable, overpowered, lost) to 1 (protagonist is in control, powerful).',
    '- emotions: 3–6 discrete emotions the audience is meant to feel, open vocabulary (e.g. "wonder", "dread", "tenderness", "amusement"), each with probability 0..1.',
    '- beat: one line (max 120 characters) saying what is literally happening on screen.',
    '- confidence: how sure you are about this window overall.',
    '',
    'Then derive:',
    '- acts: 3–5 named narrative acts (e.g. "Set-up", "The journey", "Confrontation", "Aftermath") with start/end seconds and a one-sentence summary; acts must tile the runtime in order.',
    '- climax: the single most intense moment (highest arousal × stakes) with its timestamp and a one-line description.',
    '',
    'Be consistent: neighbouring windows should change smoothly unless a cut or reveal justifies a jump. Values must be numbers, not strings.',
  ].join('\n');

  const schema = obj({
    samples: arr(
      obj({
        start: num(0, ctx.durationSec),
        end: num(0, ctx.durationSec),
        valence: num(-1, 1),
        arousal: num(0, 1),
        dominance: num(0, 1),
        emotions: scoredLabels('Discrete audience emotions.', 3, 6),
        beat: str('max 120 characters'),
        confidence: p01('overall confidence for this window'),
      }),
      { min: 3, max: 60 },
    ),
    acts: arr(
      obj({ name: str(), start: num(0, ctx.durationSec), end: num(0, ctx.durationSec), summary: str() }),
      { min: 2, max: 6 },
    ),
    climax: obj({ at: num(0, ctx.durationSec), description: str() }),
  });

  return { prompt, schema, maxTokens: 9000 };
}

/* ------------------------------------------------------------------ */
/* 3. Markers                                                          */
/* ------------------------------------------------------------------ */

export function markersPrompt(ctx: PromptContext): PromptBundle {
  const prompt = [
    preamble(ctx, 'a broadcast QC operator marking structural segments for a player (skip intro, skip recap, next-episode prompt)'),
    '',
    'Identify every structural segment present in the video. Kinds:',
    '- cold_open: story before the opening titles.',
    '- recap: "previously on" montage.',
    '- intro: opening title sequence / theme (the thing "Skip intro" skips).',
    '- title_card: a short card showing the title (use when there is no full intro sequence).',
    '- chapter: a clear narrative chapter boundary — give 3–8 chapters for long-form, with a short label describing the chapter.',
    '- credits: end credits; start at the first credit frame, end at the last.',
    '- post_credits: story content after the credits started.',
    '- next_episode_hook: a teaser for the next episode.',
    '- preview: trailer-like preview of the show.',
    '',
    'Rules: only output kinds you actually observe (do not invent a recap if there is none). Start/end are absolute seconds, accurate to within one second — look for the exact frame where titles appear or a fade completes. Segments of different kinds may touch but must not overlap, except chapters which may span other segments. Provide a short human label for each (e.g. "Opening titles", "Ch. 3 — The cave"). Give a calibrated confidence 0..1 per marker; be honest about ambiguous boundaries.',
  ].join('\n');

  const schema = obj({
    markers: arr(
      obj({
        kind: enumOf(MARKER_KINDS),
        start: num(0, ctx.durationSec),
        end: num(0, ctx.durationSec),
        label: str('short human label'),
        confidence: p01('confidence in both the kind and the boundaries'),
      }),
      { min: 1, max: 30 },
    ),
  });

  return { prompt, schema, maxTokens: 2500 };
}

/* ------------------------------------------------------------------ */
/* 4. Safety                                                           */
/* ------------------------------------------------------------------ */

export function safetyPrompt(ctx: PromptContext): PromptBundle {
  const prompt = [
    preamble(ctx, 'a content-compliance reviewer producing a brand-safety and ratings report'),
    '',
    `Scan the whole video for content in these categories: ${SAFETY_CATEGORIES.join(', ')}.`,
    '',
    'For each occurrence output one segment with: category, severity (low = mild/implied/brief, medium = explicit but not graphic or sustained, high = graphic, sustained or central), absolute start/end seconds, a factual one-line description of what is shown or said (no euphemisms, no moralising) and a calibrated confidence 0..1.',
    '',
    'Guidance: stylised or animated violence still counts (grade severity by intent and impact, e.g. a fatal stabbing is high even if bloodless). Include flashing_lights for strobe-like sequences (>3 flashes per second). Weapons means weapons on screen even when not used. Merge back-to-back occurrences of the same category into one segment. If a category has no occurrence, simply omit it. If the whole video is clean, return an empty segments array.',
  ].join('\n');

  const schema = obj({
    segments: arr(
      obj({
        category: enumOf(SAFETY_CATEGORIES),
        severity: enumOf(SEVERITIES),
        start: num(0, ctx.durationSec),
        end: num(0, ctx.durationSec),
        description: str('factual one-liner'),
        confidence: p01('confidence in the category and severity'),
      }),
      { min: 0, max: 60 },
    ),
  });

  return { prompt, schema, maxTokens: 3500 };
}

/* ------------------------------------------------------------------ */
/* 5. Ad-break candidates                                              */
/* ------------------------------------------------------------------ */

export function adBreakCandidatesPrompt(ctx: PromptContext, opts: { maxCandidates?: number } = {}): PromptBundle {
  const maxCandidates = opts.maxCandidates ?? Math.min(24, Math.max(6, Math.round(ctx.durationSec / 90)));
  const prompt = [
    preamble(ctx, 'an ad-operations editor finding natural pauses where a mid-roll ad pod would feel least intrusive'),
    '',
    `Propose up to ${maxCandidates} candidate insertion points across the runtime. A good candidate sits on a hard scene change, an act break, a fade to black, the end of a music cue or a clear dialogue gap — never mid-sentence, mid-action, or inside a rising tension build. Prefer points where the story "exhales". Spread candidates across the whole runtime (avoid the first and last 60 seconds) so a planner can choose spacing.`,
    '',
    'For each candidate output:',
    '- at: the exact absolute second of the cut (the first frame of the new scene).',
    '- confidence: probability that a human ad-ops editor would accept this point as natural.',
    '- reason: one line explaining why (e.g. "hard cut from night exterior to morning interior, music resolves").',
    '- reasonType: one of scene_change, act_break, dialogue_gap, fade, music_end, location_change, other.',
    '- sceneBefore / sceneAfter: one line each describing the scenes on either side (for contextual creative).',
    '- mood: 3–6 open-vocabulary mood labels describing the emotional state ENTERING the break, with probabilities.',
    '- keywords: 4–8 concrete keywords for the ±60s around the point (objects, settings, activities).',
    '- iab: 1–4 IAB Content Taxonomy 3.0 categories relevant to the surrounding content; give id (e.g. "IAB1-2"), name, tier (1–3) and confidence.',
    '',
    'Order candidates by time. Do not include the very start or the credits.',
  ].join('\n');

  const schema = obj({
    candidates: arr(
      obj({
        at: num(0, ctx.durationSec),
        confidence: p01('probability an editor accepts this cut point'),
        reason: str(),
        reasonType: enumOf(REASON_TYPES),
        sceneBefore: str(),
        sceneAfter: str(),
        mood: scoredLabels('Mood entering the break.', 3, 6),
        keywords: scoredLabels('Contextual keywords ±60s.', 4, 8),
        iab: arr(
          obj({
            id: str('IAB taxonomy id, e.g. IAB1-2'),
            name: str(),
            tier: { type: 'integer', minimum: 1, maximum: 3 },
            confidence: p01('relevance'),
          }),
          { min: 1, max: 4 },
        ),
      }),
      { min: 1, max: maxCandidates },
    ),
  });

  return { prompt, schema, maxTokens: 5000 };
}

/* ------------------------------------------------------------------ */
/* 6. Thumbnails                                                       */
/* ------------------------------------------------------------------ */

export interface ThumbnailBrief {
  /** Free-text creative brief, e.g. "dramatic close-ups of the hero, warm light, no weapons". */
  brief?: string;
  count?: number;
  requireCharacters?: string[];
  excludeSafetyCategories?: string[];
  formats?: Array<'16:9' | '2:3' | '1:1' | '9:16'>;
}

export function thumbnailsPrompt(ctx: PromptContext, brief: ThumbnailBrief = {}): PromptBundle {
  const count = Math.min(24, Math.max(1, brief.count ?? 12));
  const prompt = [
    preamble(ctx, 'a key-art producer choosing frames that will become artwork tiles for a streaming service'),
    '',
    `Select ${count} distinct still frames that would make excellent thumbnails / key art. Cover different characters, moments and moods rather than variations of one shot. Skip frames with motion blur, closed eyes, mid-word mouths, black/white frames, subtitles or burned-in text.`,
    '',
    brief.brief
      ? `CREATIVE BRIEF from the marketing team — treat it as the primary selection criterion and score relevance against it: "${brief.brief}"`
      : 'No specific creative brief: optimise for the frames that best sell the title to a new viewer.',
    brief.requireCharacters?.length
      ? `Every frame MUST clearly feature: ${brief.requireCharacters.join(', ')}.`
      : '',
    brief.excludeSafetyCategories?.length
      ? `Never pick frames containing: ${brief.excludeSafetyCategories.join(', ')}. Mark safe=false if anything borderline is visible.`
      : 'Mark safe=false for frames showing violence, weapons, nudity, drugs or anything a brand would not sit beside.',
    brief.formats?.length ? `Target formats: ${brief.formats.join(', ')}.` : '',
    '',
    'For each frame output:',
    '- at: the absolute second of the frame (be precise — the frame will be extracted at exactly this time; prefer the still centre of a shot).',
    '- factors, each 0..1: relevance (to the brief / the title\'s appeal), aesthetics (composition, light, colour), faceProminence (size and clarity of a face, 0 if none), stillness (how static the frame is), brightness (0 dark → 1 bright; ideal is 0.4–0.7), safeArea (how much of the frame is free of clutter for a title treatment).',
    '- characters: names of characters visible.',
    '- mood: 2–5 open-vocabulary mood labels with probabilities.',
    '- crops: fractional {x,y,w,h} crop rectangles (0..1 of the frame) for 16:9, 2:3, 1:1 and 9:16 that keep the subject\'s face/action inside the crop and respect the target aspect ratio exactly.',
    '- logoSafeZone: where a logo/title could sit without covering faces: top-left, top-right, bottom-left, bottom-right or center.',
    '- safe: true only if the frame is brand-safe.',
    '- caption: an evocative one-line caption (max 80 characters) an editor could use as alt text.',
  ]
    .filter((l) => l !== '')
    .join('\n');

  const schema = obj({
    thumbnails: arr(
      obj({
        at: num(0, ctx.durationSec),
        factors: obj({
          relevance: p01('fit to brief / title appeal'),
          aesthetics: p01('composition, light, colour'),
          faceProminence: p01('0 = no face'),
          stillness: p01('0 = blurry motion → 1 static'),
          brightness: p01('0 dark → 1 bright'),
          safeArea: p01('free area for title treatment'),
        }),
        characters: arr(str(), { max: 6 }),
        mood: scoredLabels('Mood of the frame.', 2, 5),
        crops: obj({ '16:9': crop(), '2:3': crop(), '1:1': crop(), '9:16': crop() }),
        logoSafeZone: enumOf(LOGO_ZONES),
        safe: { type: 'boolean', description: 'true only when brand-safe' },
        caption: str('max 80 characters'),
      }),
      { min: 1, max: count },
    ),
  });

  return { prompt, schema, maxTokens: 6000 };
}

/* ------------------------------------------------------------------ */
/* 7. Preview clips                                                    */
/* ------------------------------------------------------------------ */

export interface ClipBrief {
  brief?: string;
  count?: number;
  /** [min, max] seconds. */
  clipLengthSec?: [number, number];
  requireCharacters?: string[];
  excludeSafetyCategories?: string[];
  /** Natural-language query when clips are cut for a search/discovery use case. */
  query?: string;
}

export function clipsPrompt(ctx: PromptContext, brief: ClipBrief = {}): PromptBundle {
  const count = Math.min(12, Math.max(1, brief.count ?? 6));
  const [minLen, maxLen] = brief.clipLengthSec ?? [8, 30];
  const prompt = [
    preamble(ctx, 'a promo editor cutting short preview clips for social, autoplay hovers and vertical feeds'),
    '',
    `Find ${count} self-contained moments that work as standalone clips of ${minLen}–${maxLen} seconds. Each must start and end on a cut or a natural pause (never mid-word), read clearly without context, and not spoil the ending. Diversify: mix action, emotion, humour, spectacle and character moments.`,
    '',
    brief.brief
      ? `CREATIVE BRIEF — the primary selection criterion, score relevance against it: "${brief.brief}"`
      : 'No specific creative brief: optimise for the moments most likely to make a viewer press play.',
    brief.query
      ? `The clips are for the search query "${brief.query}". Report queryRelevance (0..1) per clip and echo the query in the query field.`
      : 'Leave queryRelevance and query empty (omit or null) — there is no search query.',
    brief.requireCharacters?.length ? `Every clip MUST feature: ${brief.requireCharacters.join(', ')}.` : '',
    brief.excludeSafetyCategories?.length
      ? `Exclude clips containing: ${brief.excludeSafetyCategories.join(', ')}. Mark safe=false if anything borderline is visible.`
      : 'Mark safe=false for clips containing violence, weapons, nudity, drugs or anything a brand would not sit beside.',
    '',
    'For each clip output:',
    '- start / end: absolute seconds, on cuts.',
    '- clipType: a short open-vocabulary type such as "action beat", "emotional turn", "comic relief", "world reveal", "character intro", "cliffhanger".',
    '- relevance: probability this clip is a strong promo moment (against the brief if given).',
    '- characters, mood (2–5 labels), keywords (3–8 labels) with probabilities.',
    '- reframe916: a 9:16 reframe path for vertical video as keyframes — 2–6 entries of {at: absolute second, cx: horizontal centre of the subject as a fraction 0..1 of frame width}; follow the main subject so a vertical crop keeps them in frame.',
    '- caption: one-line social caption (max 100 characters, no hashtags).',
    '- posterAt: the absolute second of the best poster frame inside the clip.',
  ]
    .filter((l) => l !== '')
    .join('\n');

  const schema = obj(
    {
      clips: arr(
        obj(
          {
            start: num(0, ctx.durationSec),
            end: num(0, ctx.durationSec),
            clipType: str('open vocabulary'),
            relevance: p01('strength as a promo moment'),
            queryRelevance: p01('relevance to the search query, when given'),
            query: str('echo of the query, when given'),
            characters: arr(str(), { max: 6 }),
            mood: scoredLabels('Mood of the clip.', 2, 5),
            keywords: scoredLabels('Keywords in the clip.', 3, 8),
            safe: { type: 'boolean' },
            reframe916: arr(obj({ at: num(0, ctx.durationSec), cx: p01('subject x-centre') }), { min: 2, max: 6 }),
            caption: str('max 100 characters'),
            posterAt: num(0, ctx.durationSec),
          },
          ['start', 'end', 'clipType', 'relevance', 'characters', 'mood', 'keywords', 'safe', 'reframe916', 'caption', 'posterAt'],
        ),
        { min: 1, max: count },
      ),
    },
  );

  return { prompt, schema, maxTokens: 5000 };
}

/* ------------------------------------------------------------------ */
/* 8. Ad creative fingerprint                                          */
/* ------------------------------------------------------------------ */

export type AdFingerprintPayload = Omit<AdFingerprint, 'model' | 'generatedAt'>;

/**
 * Creative intelligence for an ad spot. Uses the SAME open vocabularies as the
 * ad-break candidates (mood, keywords, IAB) so `scoreCreativeFit` can compare
 * a creative against the content on either side of a break.
 */
export function adFingerprintPrompt(ctx: PromptContext): PromptBundle {
  const prompt = [
    preamble(ctx, 'an ad-operations analyst profiling a commercial so it can be matched to the right break in long-form content'),
    '',
    'Describe the commercial as an ad buyer and a brand-safety reviewer would:',
    '- brand and product being advertised (read logos, packaging, end cards and voice-over); tagline and call to action verbatim if shown or spoken.',
    '- synopsis: two sentences on what happens.',
    '- mood: 3–6 mood labels for the feeling the spot creates (same style as content moods, e.g. "playful", "tender", "energetic").',
    '- keywords: 5–10 concrete keywords (objects, settings, activities, people) that a contextual planner could match against surrounding scenes.',
    '- tone: probabilities for exactly these five dimensions: humorous, emotional, energetic, premium, family.',
    '- iab: 1–4 IAB Content Taxonomy 3.0 categories for the product AND the setting (id such as "IAB8-5", name, tier 1–3, confidence).',
    '- sensitivities: anything IN the spot that could clash with adjacent content (alcohol, weapons, sexual_content, violence, gore, profanity, drugs, tobacco, hate, self_harm, flashing_lights, nudity) with severity and a factual description; empty if none.',
    '- familySafe: probability the spot is suitable next to family / all-audience programming.',
    '- pacing: 0 (slow, lingering) to 1 (rapid cuts) with a one-line rationale.',
    '- moments: 3–6 key beats with absolute seconds and a short label (product reveal, hero shot, logo, end card).',
    '- language: primary spoken/written language code and any others.',
  ].join('\n');

  const schema = obj({
    brand: str(),
    product: str(),
    tagline: str('verbatim tagline, empty string if none'),
    callToAction: str('verbatim CTA, empty string if none'),
    synopsis: str(),
    mood: scoredLabels('Feeling the spot creates.', 3, 6),
    keywords: scoredLabels('Concrete matchable keywords.', 5, 10),
    tone: obj({
      humorous: p01('is it funny'),
      emotional: p01('does it aim for feeling'),
      energetic: p01('high energy'),
      premium: p01('luxury / premium positioning'),
      family: p01('aimed at families or children'),
    }),
    iab: arr(
      obj({
        id: str('IAB taxonomy id'),
        name: str(),
        tier: { type: 'integer', minimum: 1, maximum: 3 },
        confidence: p01('relevance'),
      }),
      { min: 1, max: 4 },
    ),
    sensitivities: arr(
      obj({
        category: enumOf(SAFETY_CATEGORIES),
        severity: enumOf(SEVERITIES),
        description: str(),
        confidence: p01('confidence'),
      }),
      { min: 0, max: 8 },
    ),
    familySafe: p01('suitable next to family programming'),
    pacing: obj({ score: p01('0 slow → 1 rapid'), rationale: str() }),
    moments: arr(obj({ at: num(0, ctx.durationSec), label: str() }), { min: 1, max: 8 }),
    language: obj({ primary: str('ISO 639-1'), others: arr(str(), { min: 0, max: 5 }) }),
  });

  return { prompt, schema, maxTokens: 2500 };
}

/** All prompt builders keyed by job, for callers that iterate. */
export const PROMPTS = {
  fingerprint: fingerprintPrompt,
  emotions: emotionsPrompt,
  markers: markersPrompt,
  safety: safetyPrompt,
  adbreaks: adBreakCandidatesPrompt,
  thumbnails: thumbnailsPrompt,
  clips: clipsPrompt,
  adFingerprint: adFingerprintPrompt,
} as const;
