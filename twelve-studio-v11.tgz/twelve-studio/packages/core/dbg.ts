import { buildTasteProfile, recommend, recommendRails, DEFAULT_RECO_WEIGHTS, type WatchEvent } from './src/recommend.js';
import type { CatalogItem, Fingerprint } from './src/types.js';
const fp = (genres: any, extra: any = {}): Fingerprint => ({ genres, keywords:{}, moods:{}, moodTags:{}, themes:{}, characters:[], pacing:{score:0.5,rationale:''}, language:{primary:'en'}, audienceRating:{suggested:'PG-13',rationale:''}, synopsis:{short:'',long:''}, model:'t', generatedAt:'t', ...extra });
const item = (id:string,title:string,f:Fingerprint):CatalogItem => ({id,title,type:'movie',sourceUrl:'x',createdAt:'t',updatedAt:'t',status:'ready',jobs:{},durationSec:100,fingerprint:f});
const CATALOG = [
  item('romhorror1','Crimson Vow', fp({horror:.9,romance:.8},{moodTags:{'doomed love':.7},themes:{obsession:.6}})),
  item('romhorror2','The Bride Waits', fp({horror:.85,romantic:.75},{moodTags:{'doomed love':.6}})),
  item('romhorror3','Widow Hill', fp({horror:.8,romance:.7},{moodTags:{'doomed love':.5}})),
  item('horror1','Cellar Door', fp({horror:.95},{moodTags:{dread:.8}})),
  item('horror2','Night Shift', fp({horror:.9},{moodTags:{dread:.7}})),
  item('romance1','Two Summers', fp({romance:.95},{moodTags:{longing:.8}})),
  item('romance2','Letters Home', fp({romance:.9},{moodTags:{longing:.7}})),
  item('comedy1','Office Party', fp({comedy:.95},{moodTags:{silly:.8}})),
  item('doc1','Deep Field', fp({documentary:.9},{themes:{science:.8}})),
];
const NOW = Date.parse('2026-02-01T00:00:00.000Z');
const ev = (itemId:string,o:any={}):WatchEvent => ({id:'e'+itemId+(o.action??''),profileId:'v1',itemId,action:'watch',completion:.95,at:'2026-01-30T00:00:00.000Z',...o});
const profile = buildTasteProfile('v1',[ev('romhorror1'),ev('romhorror2')],CATALOG,DEFAULT_RECO_WEIGHTS,NOW);
console.log('topCombos', profile.topCombos);
console.log('top', profile.top.slice(0,6));
console.log('interacted', profile.interacted);
const out = recommend({profile,pool:CATALOG,weights:{...DEFAULT_RECO_WEIGHTS,diversity:0,repeatPenalty:0},limit:10,includeWatched:true});
console.log('ranked', out.map(r=>[r.itemId,r.score,r.parts.combo]));
const rails = recommendRails({profile,pool:CATALOG,weights:DEFAULT_RECO_WEIGHTS,limit:5});
console.log('rails', rails.map(r=>[r.kind,r.title,r.labels,r.items.map(i=>i.itemId)]));
const seed = CATALOG.find(i=>i.id==='horror1')!;
const p2 = buildTasteProfile('v1',[ev('romance1')],CATALOG,DEFAULT_RECO_WEIGHTS,NOW);
console.log('steered', recommend({profile:p2,pool:CATALOG,weights:{...DEFAULT_RECO_WEIGHTS,seed:3,diversity:0},seed,limit:5}).map(r=>[r.itemId,r.score,r.parts.seed]));
