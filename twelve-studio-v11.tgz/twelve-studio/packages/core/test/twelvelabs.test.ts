/**
 * Live-client request shapes, checked against what the TwelveLabs v1.3 API
 * accepted on 12 Sep 2026 (no network: a fake fetch records the request).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { TwelveLabsClient, listAllAssets, sanitizeJsonSchema, UNSUPPORTED_SCHEMA_KEYWORDS, type TwelveLabsAsset } from '../src/twelvelabs.js';
import { PROMPTS } from '../src/prompts.js';

function walk(node: unknown, visit: (key: string, parentIsPropertyMap: boolean) => void, parentIsPropertyMap = false): void {
  if (Array.isArray(node)) return node.forEach((n) => walk(n, visit, false));
  if (!node || typeof node !== 'object') return;
  for (const [k, v] of Object.entries(node as Record<string, unknown>)) {
    visit(k, parentIsPropertyMap);
    walk(v, visit, k === 'properties' || k === 'patternProperties' || k === 'definitions' || k === '$defs');
  }
}

test('sanitizeJsonSchema drops numeric/string constraints recursively and keeps everything else', () => {
  const input = {
    type: 'object',
    description: 'root',
    additionalProperties: false,
    required: ['score', 'tags', 'items'],
    properties: {
      score: { type: 'number', minimum: 0, maximum: 1, description: '0..1' },
      name: { type: 'string', minLength: 1, maxLength: 80, pattern: '^[a-z]+$', format: 'email' },
      tags: { type: 'array', minItems: 1, maxItems: 5, items: { type: 'string', enum: ['a', 'b'] } },
      items: {
        type: 'array',
        items: { type: 'object', minProperties: 1, maxProperties: 3, properties: { at: { type: 'integer', exclusiveMinimum: 0, exclusiveMaximum: 10 } } },
      },
      // A property that happens to be named like a constraint keyword must survive.
      format: { type: 'string', description: 'aspect ratio', minLength: 3 },
      nested: { anyOf: [{ type: 'number', minimum: 1 }, { type: 'null' }] },
    },
  };
  const before = JSON.stringify(input);
  const out = sanitizeJsonSchema(input);
  assert.equal(JSON.stringify(input), before, 'input is not mutated');

  walk(out, (k, inPropertyMap) => {
    if (!inPropertyMap) assert.equal(UNSUPPORTED_SCHEMA_KEYWORDS.has(k), false, `keyword ${k} should have been dropped`);
  });
  assert.deepEqual(out.properties.score, { type: 'number', description: '0..1' });
  assert.deepEqual(out.properties.name, { type: 'string' });
  assert.deepEqual(out.properties.tags, { type: 'array', items: { type: 'string', enum: ['a', 'b'] } });
  assert.deepEqual(out.properties.items.items, { type: 'object', properties: { at: { type: 'integer' } } });
  assert.deepEqual(out.properties.format, { type: 'string', description: 'aspect ratio' });
  assert.deepEqual(out.properties.nested, { anyOf: [{ type: 'number' }, { type: 'null' }] });
  assert.deepEqual(out.required, ['score', 'tags', 'items']);
  assert.equal(out.additionalProperties, false);
  assert.equal(out.description, 'root');
});

test('every production prompt schema is clean after sanitising', () => {
  const ctx = { title: 'T', durationSec: 600, fps: 24 };
  for (const [name, build] of Object.entries(PROMPTS)) {
    const out = sanitizeJsonSchema(build(ctx).schema);
    walk(out, (k, inPropertyMap) => {
      if (!inPropertyMap) assert.equal(UNSUPPORTED_SCHEMA_KEYWORDS.has(k), false, `${name}: keyword ${k} leaked`);
    });
    assert.equal((out as { type?: string }).type, 'object', name);
  }
});

test('analyze() sends a sanitised json_schema and the exact asset_id video shape', async () => {
  const calls: Array<{ url: string; init: RequestInit }> = [];
  const fetchImpl = (async (url: string | URL | Request, init?: RequestInit) => {
    calls.push({ url: String(url), init: init ?? {} });
    return new Response(JSON.stringify({ data: '{"ok":true}', usage: { output_tokens: 3 } }), { status: 200, headers: { 'content-type': 'application/json' } });
  }) as unknown as typeof fetch;
  const client = new TwelveLabsClient({ apiKey: 'k', fetchImpl, maxRetries: 0 });
  const res = await client.analyze<{ ok: boolean }>({
    video: { type: 'asset_id', asset_id: 'abc123' },
    prompt: 'p',
    schema: { type: 'object', properties: { n: { type: 'number', minimum: 0 } } },
    hint: { job: 'fingerprint' },
  });
  assert.deepEqual(res.data, { ok: true });
  assert.equal(calls.length, 1);
  assert.equal(calls[0]!.url, 'https://api.twelvelabs.io/v1.3/analyze');
  const body = JSON.parse(String(calls[0]!.init.body)) as Record<string, any>;
  assert.deepEqual(body.video, { type: 'asset_id', asset_id: 'abc123' });
  assert.equal(body.model_name, 'pegasus1.5');
  assert.equal(body.stream, false);
  assert.deepEqual(body.response_format, { type: 'json_schema', json_schema: { type: 'object', properties: { n: { type: 'number' } } } });
  assert.equal('hint' in body, false);
  assert.equal((calls[0]!.init.headers as Record<string, string>)['x-api-key'], 'k');
});

test('createAnalyzeTask() sanitises too, drops stream and adds analysis_mode', async () => {
  const calls: Array<{ url: string; init: RequestInit }> = [];
  const fetchImpl = (async (url: string | URL | Request, init?: RequestInit) => {
    calls.push({ url: String(url), init: init ?? {} });
    return new Response(JSON.stringify({ task_id: 't1', status: 'queued' }), { status: 202 });
  }) as unknown as typeof fetch;
  const client = new TwelveLabsClient({ apiKey: 'k', fetchImpl, maxRetries: 0 });
  await client.createAnalyzeTask({ video: { type: 'asset_id', asset_id: 'abc123' }, prompt: 'p', schema: { type: 'array', minItems: 1, items: { type: 'string', maxLength: 4 } }, analysisMode: 'time_based_metadata' });
  assert.equal(calls[0]!.url, 'https://api.twelvelabs.io/v1.3/analyze/tasks');
  const body = JSON.parse(String(calls[0]!.init.body)) as Record<string, any>;
  assert.equal('stream' in body, false);
  assert.equal(body.analysis_mode, 'time_based_metadata');
  assert.deepEqual(body.response_format.json_schema, { type: 'array', items: { type: 'string' } });
});

test('listAssets() maps GET /assets paging; listAllAssets walks every page', async () => {
  const row = (id: string): TwelveLabsAsset => ({ _id: id, method: 'url', status: 'ready', filename: `${id}.mp4`, duration: 10, width: 1, height: 1, fps: 24, hls: null, thumbnail: null, created_at: '2026-09-12T00:00:00.000Z' });
  const pages: Record<string, TwelveLabsAsset[]> = { '1': [row('a'), row('b')], '2': [row('c')] };
  const urls: string[] = [];
  const fetchImpl = (async (url: string | URL | Request) => {
    const u = new URL(String(url));
    urls.push(u.pathname + u.search);
    const page = u.searchParams.get('page') ?? '1';
    return new Response(JSON.stringify({ data: pages[page] ?? [], page_info: { page: Number(page), limit_per_page: 2, total_page: 2, total_results: 3 } }), { status: 200 });
  }) as unknown as typeof fetch;
  const client = new TwelveLabsClient({ apiKey: 'k', fetchImpl, maxRetries: 0 });
  const first = await client.listAssets({ page: 1, pageLimit: 2 });
  assert.equal(urls[0], '/v1.3/assets?page=1&page_limit=2');
  assert.deepEqual(first.pageInfo, { page: 1, limitPerPage: 2, totalPage: 2, totalResults: 3 });
  const all = await listAllAssets(client, { pageLimit: 2 });
  assert.deepEqual(
    all.map((a) => a._id),
    ['a', 'b', 'c'],
  );
});
