import { test } from 'node:test';
import assert from 'node:assert/strict';
import { autoAssign, iabOverlap, labelOverlap, labelSimilarity, rankCreatives, scoreCreativeFit } from '../src/creativefit.js';
import type { AdBreak, AdCreative, AdFingerprint } from '../src/types.js';

const brk = (over: Partial<AdBreak> = {}): AdBreak => ({
  id: 'brk_1',
  at: 600,
  window: { start: 595, end: 605 },
  rank: 1,
  confidence: 0.9,
  reason: 'scene change',
  sceneBefore: 'a',
  sceneAfter: 'b',
  mood: { playful: 0.8, warm: 0.6 },
  keywords: { kitchen: 0.9, chocolate: 0.7, family: 0.6 },
  iab: [{ id: 'IAB8-5', name: 'Food & Drink', tier: 2, confidence: 0.9 }],
  brandSafety: { suitable: true, flags: {} },
  ...over,
});

const fp = (over: Partial<AdFingerprint> = {}): AdFingerprint => ({
  brand: 'Ferrero',
  product: 'Kinder Bueno',
  synopsis: 'A chocolate bar spot.',
  mood: { playful: 0.9, lighthearted: 0.8 },
  keywords: { chocolate: 0.95, snack: 0.8, kitchen: 0.5 },
  tone: { humorous: 0.8, emotional: 0.2, energetic: 0.7, premium: 0.3, family: 0.8 },
  iab: [{ id: 'IAB8-5', name: 'Food & Drink', tier: 2, confidence: 0.9 }],
  sensitivities: [],
  familySafe: 0.9,
  pacing: { score: 0.7, rationale: 'quick' },
  moments: [{ at: 3, label: 'product reveal' }],
  language: { primary: 'en', others: [] },
  model: 'pegasus1.5',
  generatedAt: '2026-09-12T00:00:00.000Z',
  ...over,
});

const creative = (id: string, fingerprint?: AdFingerprint): AdCreative => ({ id, name: id, durationSec: 30, mediaUrl: `/api/ads/${id}/media`, createdAt: '2026-09-12T00:00:00.000Z', fingerprint });

test('label similarity: exact, token overlap, affect proximity for moods', () => {
  assert.equal(labelSimilarity('chocolate', 'Chocolate'), 1);
  assert.ok(labelSimilarity('control room', 'mission control') > 0.3);
  assert.equal(labelSimilarity('tense', 'playful', 'keyword'), 0);
  assert.ok(labelSimilarity('playful', 'lighthearted', 'mood') > 0.6, 'same affect quadrant');
  assert.ok(labelSimilarity('tense', 'playful', 'mood') < 0.2, 'opposite valence');
});

test('label overlap is symmetric, 0..1, and 1 for identical maps', () => {
  const a = { playful: 0.8, warm: 0.6 };
  assert.equal(labelOverlap(a, a, 'mood').score, 1);
  const x = labelOverlap(a, { tense: 0.9 }, 'mood').score;
  const y = labelOverlap({ tense: 0.9 }, a, 'mood').score;
  assert.equal(x, y);
  assert.ok(x < 0.2);
  assert.equal(labelOverlap({}, a).score, 0);
});

test('iab overlap: exact id, name overlap, unrelated', () => {
  assert.equal(iabOverlap([{ id: 'IAB8-5', name: 'Food & Drink', tier: 2, confidence: 1 }], [{ id: 'IAB8-5', name: 'Food & Drink', tier: 2, confidence: 1 }]).score, 1);
  const partial = iabOverlap([{ id: 'IAB19', name: 'Technology & Computing', tier: 1, confidence: 1 }], [{ id: 'IAB19-1', name: 'Science & Technology', tier: 1, confidence: 1 }]);
  assert.ok(partial.score > 0.2 && partial.score < 1);
  // Same id family but unrelated names (inconsistent taxonomy from the model) must not match.
  assert.equal(iabOverlap([{ id: 'IAB1-5', name: 'Movies', tier: 2, confidence: 1 }], [{ id: 'IAB1-1', name: 'Food & Beverages', tier: 1, confidence: 1 }]).score, 0);
});

test('fit: matching creative scores high, clashing creative low, explanations present', () => {
  const good = scoreCreativeFit(brk(), creative('good', fp()));
  assert.ok(good.score > 0.75, `good=${good.score}`);
  assert.equal(good.safety, 1);
  assert.ok(good.because.some((b) => b.includes('chocolate')));

  const clash = scoreCreativeFit(brk({ mood: { tense: 0.9, grief: 0.7 }, keywords: { battlefield: 0.9, sword: 0.8 }, iab: [{ id: 'IAB11', name: 'Law, Government & Politics', tier: 1, confidence: 0.8 }] }), creative('good', fp()));
  assert.ok(clash.score < 0.35, `clash=${clash.score}`);

  const unsafe = scoreCreativeFit(brk({ brandSafety: { suitable: false, flags: { violence: 0.9 } } }), creative('good', fp()));
  assert.ok(unsafe.safety < 0.5);
  assert.ok(unsafe.because.some((b) => /not brand-safe/.test(b)));

  const boozy = scoreCreativeFit(brk(), creative('beer', fp({ sensitivities: [{ category: 'alcohol', severity: 'medium', description: 'beer poured', confidence: 0.9 }] })));
  assert.ok(boozy.safety < 1);
  assert.ok(boozy.because.some((b) => /alcohol/.test(b)));
});

test('creatives without a fingerprint score 0 and say why; ranking and auto-assign skip them', () => {
  const none = scoreCreativeFit(brk(), creative('raw'));
  assert.equal(none.score, 0);
  assert.match(none.because[0]!, /no fingerprint/);

  const ranked = rankCreatives(brk(), [creative('raw'), creative('good', fp()), creative('dull', fp({ mood: { somber: 0.9 }, keywords: { office: 0.9 }, iab: [] }))]);
  assert.deepEqual(
    ranked.map((r) => r.creativeId),
    ['good', 'dull', 'raw'],
  );

  const picks = autoAssign([brk(), brk({ id: 'brk_2', at: 1200, mood: { tense: 0.9 }, keywords: { sword: 0.9 }, iab: [] })], [creative('raw'), creative('good', fp())], 0.5);
  assert.equal(picks[0]!.creativeId, 'good');
  assert.equal(picks[1]!.creativeId, undefined, 'below minScore stays unassigned');
});
