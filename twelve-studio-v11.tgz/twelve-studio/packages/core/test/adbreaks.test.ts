import { test } from 'node:test';
import assert from 'node:assert/strict';
import { planAdBreaks, defaultPolicy, arousalSlope, meanArousal } from '../src/adbreaks.js';
import type { AdBreakCandidate } from '../src/prompts.js';
import type { EmotionSample, SafetyReport } from '../src/types.js';

const DURATION = 1800; // 30 min

function cand(at: number, overrides: Partial<AdBreakCandidate> = {}): AdBreakCandidate {
  return {
    at,
    confidence: 0.8,
    reason: `cut at ${at}`,
    reasonType: 'dialogue_gap',
    sceneBefore: 'before',
    sceneAfter: 'after',
    mood: { calm: 0.7 },
    keywords: { street: 0.6 },
    iab: [{ id: 'IAB1', name: 'Arts & Entertainment', tier: 1, confidence: 0.7 }],
    ...overrides,
  };
}

/** Flat arousal everywhere except a steep rise around `riseAt`. */
function samples(riseAt?: number): EmotionSample[] {
  const out: EmotionSample[] = [];
  for (let t = 0; t < DURATION; t += 20) {
    let arousal = 0.4;
    if (riseAt !== undefined) {
      if (t >= riseAt - 20 && t < riseAt) arousal = 0.3;
      if (t >= riseAt && t < riseAt + 20) arousal = 0.8;
    }
    out.push({ start: t, end: t + 20, valence: 0, arousal, dominance: 0.5, emotions: {}, beat: '', confidence: 0.8 });
  }
  return out;
}

test('defaultPolicy scales to runtime and relaxes spacing for short films', () => {
  const p = defaultPolicy(DURATION);
  assert.equal(p.targetBreaks, 4);
  assert.equal(p.minSpacingSec, 240);
  const short = defaultPolicy(300);
  assert.equal(short.targetBreaks, 1);
  assert.ok(short.minSpacingSec < 240);
});

test('meanArousal / arousalSlope', () => {
  const s = samples(600);
  assert.equal(meanArousal(s, 0, 100), 0.4);
  assert.ok(arousalSlope(s, 600) > 0.4, 'steep rise across 600');
  assert.equal(arousalSlope(s, 1200), 0);
});

test('enforces avoidFirst/avoidLast fences and min spacing, ranks 1..n, sorted by time', () => {
  const cands = [cand(30), cand(200), cand(300), cand(700), cand(1100), cand(1750)];
  const plan = planAdBreaks(cands, { durationSec: DURATION, policy: { targetBreaks: 3, minSpacingSec: 240, avoidFirstSec: 120, avoidLastSec: 120 }, itemId: 'x' });
  const ats = plan.breaks.map((b) => b.at);
  assert.ok(!ats.includes(30) && !ats.includes(1750), 'fenced candidates dropped');
  assert.equal(plan.breaks.length, 3);
  for (let i = 1; i < ats.length; i++) assert.ok(ats[i]! - ats[i - 1]! >= 240, 'spacing respected');
  assert.deepEqual([...plan.breaks.map((b) => b.rank)].sort(), [1, 2, 3]);
  assert.deepEqual(ats, [...ats].sort((a, b) => a - b));
});

test('prefers scene changes over dialogue gaps at equal confidence', () => {
  const cands = [cand(500, { reasonType: 'dialogue_gap' }), cand(900, { reasonType: 'scene_change' })];
  const plan = planAdBreaks(cands, { durationSec: DURATION, policy: { targetBreaks: 1 }, itemId: 'x' });
  assert.equal(plan.breaks[0]?.at, 900);
});

test('penalises cutting on a steeply rising arousal run', () => {
  const cands = [cand(600, { reasonType: 'scene_change', confidence: 0.85 }), cand(1000, { reasonType: 'scene_change', confidence: 0.8 })];
  const plan = planAdBreaks(cands, { durationSec: DURATION, policy: { targetBreaks: 1 }, emotions: samples(600), itemId: 'x' });
  assert.equal(plan.breaks[0]?.at, 1000, 'the candidate on flat arousal wins despite lower confidence');
});

test('drops candidates within 45s of high-severity safety unless they are the only option', () => {
  const safety: Pick<SafetyReport, 'segments'> = {
    segments: [{ id: 's1', category: 'violence', severity: 'high', start: 610, end: 630, description: 'fight', confidence: 0.9 }],
  };
  const withAlternative = planAdBreaks([cand(600), cand(1000)], { durationSec: DURATION, policy: { targetBreaks: 1 }, safety, itemId: 'x' });
  assert.equal(withAlternative.breaks[0]?.at, 1000);
  assert.equal(withAlternative.breaks[0]?.brandSafety.suitable, true);

  const onlyOption = planAdBreaks([cand(600)], { durationSec: DURATION, policy: { targetBreaks: 1 }, safety, itemId: 'x' });
  assert.equal(onlyOption.breaks.length, 1);
  assert.equal(onlyOption.breaks[0]?.brandSafety.suitable, false);
  assert.ok((onlyOption.breaks[0]?.brandSafety.flags.violence ?? 0) > 0.5, 'violence flagged');
});

test('flags GARM categories within ±60s even when suitable', () => {
  const safety: Pick<SafetyReport, 'segments'> = {
    segments: [{ id: 's1', category: 'alcohol', severity: 'low', start: 640, end: 650, description: 'bar', confidence: 0.8 }],
  };
  const plan = planAdBreaks([cand(600)], { durationSec: DURATION, policy: { targetBreaks: 1 }, safety, itemId: 'x' });
  assert.equal(plan.breaks[0]?.brandSafety.suitable, true);
  assert.ok((plan.breaks[0]?.brandSafety.flags.alcohol ?? 0) > 0);
});

test('window is ±min(8, half distance to neighbouring scene) and clamped to fences', () => {
  const plan = planAdBreaks([cand(600), cand(1000)], {
    durationSec: DURATION,
    policy: { targetBreaks: 2, minSpacingSec: 100 },
    sceneChanges: [590, 600, 1000, 1100],
    itemId: 'x',
  });
  const b600 = plan.breaks.find((b) => b.at === 600)!;
  assert.deepEqual(b600.window, { start: 595, end: 605 }); // half of 10s to 590
  const b1000 = plan.breaks.find((b) => b.at === 1000)!;
  assert.deepEqual(b1000.window, { start: 992, end: 1008 }); // capped at 8

  const nearEnd = planAdBreaks([cand(1675)], { durationSec: DURATION, policy: { targetBreaks: 1, avoidLastSec: 120 }, itemId: 'x' });
  assert.equal(nearEnd.breaks[0]?.window.end, 1680);
});

test('is deterministic and preserves review state from a previous plan', () => {
  const cands = [cand(400), cand(800), cand(1300)];
  const a = planAdBreaks(cands, { durationSec: DURATION, itemId: 'item' });
  const b = planAdBreaks(cands, { durationSec: DURATION, itemId: 'item' });
  assert.deepEqual(a.breaks.map((x) => [x.id, x.at, x.rank]), b.breaks.map((x) => [x.id, x.at, x.rank]));
  const reviewed = a.breaks.map((x) => ({ ...x, review: { status: 'approved' as const, comments: [] } }));
  const c = planAdBreaks(cands, { durationSec: DURATION, itemId: 'item', previous: reviewed });
  assert.equal(c.breaks[0]?.review?.status, 'approved');
  assert.equal(c.breaks[0]?.id, a.breaks[0]?.id);
});

test('frames are computed when fps is known', () => {
  const plan = planAdBreaks([cand(600.5)], { durationSec: DURATION, fps: 24, itemId: 'x' });
  assert.equal(plan.breaks[0]?.frame, 14412);
});
