import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cosine, kmeans, labelCluster, labelVector, textVector, curationK } from '../src/similarity.js';
import { parseJsonRobust, toTimeOffset, toTimecode, hash32 } from '../src/util.js';
import type { Fingerprint } from '../src/types.js';

function fp(labels: Partial<Pick<Fingerprint, 'genres' | 'keywords' | 'moods' | 'moodTags' | 'themes'>>): Fingerprint {
  return {
    genres: {},
    keywords: {},
    moods: {},
    moodTags: {},
    themes: {},
    ...labels,
    characters: [],
    pacing: { score: 0.5, rationale: '' },
    language: { primary: 'en' },
    audienceRating: { suggested: 'PG', rationale: '' },
    synopsis: { short: '', long: '' },
    model: 't',
    generatedAt: 't',
  };
}

test('cosine basics', () => {
  assert.equal(cosine([1, 0], [1, 0]), 1);
  assert.equal(cosine([1, 0], [0, 1]), 0);
  assert.equal(cosine([], []), 0);
});

test('label vectors: shared labels → higher cosine; NL query lands in the same space', () => {
  const a = labelVector(fp({ genres: { fantasy: 0.9 }, keywords: { dragon: 0.9, snow: 0.8 } }));
  const b = labelVector(fp({ genres: { fantasy: 0.8 }, keywords: { dragon: 0.7, quest: 0.6 } }));
  const c = labelVector(fp({ genres: { documentary: 0.9 }, keywords: { office: 0.7 } }));
  assert.ok(cosine(a, b) > cosine(a, c));
  const q = textVector('a fantasy film with a dragon');
  assert.ok(cosine(q, a) > cosine(q, c));
});

test('kmeans is deterministic and groups similar vectors', () => {
  const vecs = [
    labelVector(fp({ genres: { fantasy: 0.9 }, keywords: { dragon: 0.9 } })),
    labelVector(fp({ genres: { fantasy: 0.8 }, keywords: { dragon: 0.8 } })),
    labelVector(fp({ genres: { documentary: 0.9 }, keywords: { office: 0.7 } })),
    labelVector(fp({ genres: { documentary: 0.8 }, keywords: { office: 0.9 } })),
  ];
  const r1 = kmeans(vecs, 2, { seed: 7 });
  const r2 = kmeans(vecs, 2, { seed: 7 });
  assert.deepEqual(r1.assignments, r2.assignments);
  assert.equal(r1.assignments[0], r1.assignments[1]);
  assert.equal(r1.assignments[2], r1.assignments[3]);
  assert.notEqual(r1.assignments[0], r1.assignments[2]);
});

test('curationK clamps', () => {
  assert.equal(curationK(3), 3);
  assert.equal(curationK(2), 2);
  assert.equal(curationK(60), 10);
  assert.equal(curationK(200), 12);
});

test('labelCluster names by shared mood + genre', () => {
  const label = labelCluster([
    { title: 'A', fingerprint: fp({ genres: { fantasy: 0.9 }, moods: { hopeful: 0.8 }, keywords: { dragon: 0.9 } }) },
    { title: 'B', fingerprint: fp({ genres: { fantasy: 0.7 }, moods: { hopeful: 0.9 }, keywords: { quest: 0.6 } }) },
  ]);
  assert.equal(label.name, 'Hopeful Fantasy');
  assert.ok(label.sharedLabels.includes('hopeful'));
});

test('parseJsonRobust strips fences and recovers embedded JSON', () => {
  assert.deepEqual(parseJsonRobust('```json\n{"a":1}\n```'), { a: 1 });
  assert.deepEqual(parseJsonRobust('Sure! {"a":[1,2]} hope this helps'), { a: [1, 2] });
  assert.throws(() => parseJsonRobust('no json here'));
});

test('time formatting', () => {
  assert.equal(toTimeOffset(3725.5), '01:02:05.500');
  assert.equal(toTimecode(1.5, 24), '00:00:01:12');
  assert.equal(hash32('abc'), hash32('abc'));
});
