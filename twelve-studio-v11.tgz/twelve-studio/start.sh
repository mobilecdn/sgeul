#!/bin/bash
# SGEUL · Story AI — run the prebuilt API + web app: ./start.sh
cd "$(dirname "$0")" && NODE_ENV=production node apps/api/dist/server.js
