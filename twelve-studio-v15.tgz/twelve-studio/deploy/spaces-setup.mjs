#!/usr/bin/env node
/**
 * One-shot object storage setup for SGEUL browser uploads. Run on the server after putting the
 * S3_* values in .env:
 *
 *   cd /opt/sgeul/twelve-studio && sudo -u sgeul node deploy/spaces-setup.mjs --origin https://sgeul.com
 *
 * It reads credentials from .env (never prints them) and, against DigitalOcean Spaces or any
 * S3-compatible endpoint:
 *   1. creates the bucket if it does not exist (private; needs a key with bucket-create rights,
 *      otherwise create it in the DigitalOcean control panel first)
 *   2. sets CORS: PUT/GET/HEAD from the SGEUL origin(s), all headers, ExposeHeaders ETag
 *   3. sets a lifecycle rule aborting incomplete multipart uploads after 7 days
 *   4. verifies: reads CORS and lifecycle back, checks the bucket is not publicly listable, and runs a
 *      real multipart round trip (create → PUT a part with an Origin header → ETag visible → abort)
 *
 * Options: --origin <url> (repeatable; default https://sgeul.com and https://www.sgeul.com)
 *          --days <n> (default 7)   --no-create   --dry-run
 */

import { createHash } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const { presignUrl, objectStoreConfigFromEnv } = await import(resolve(root, 'apps/api/dist/objectstore.js'));

/* ---- args + env -------------------------------------------------------------------------- */

const argv = process.argv.slice(2);
const flag = (name) => argv.includes(name);
const values = (name) => argv.flatMap((a, i) => (a === name && argv[i + 1] ? [argv[i + 1]] : []));
const origins = values('--origin').length ? values('--origin') : ['https://sgeul.com', 'https://www.sgeul.com'];
const days = Math.max(1, Number(values('--days')[0] ?? 7) || 7);
const dryRun = flag('--dry-run');

function loadDotenv(path) {
  const env = {};
  if (!existsSync(path)) return env;
  for (const line of readFileSync(path, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
  return env;
}
const env = { ...loadDotenv(resolve(root, '.env')), ...process.env };
const cfg = objectStoreConfigFromEnv(env);
if (!cfg) {
  const missing = ['S3_ENDPOINT', 'S3_BUCKET', 'S3_ACCESS_KEY_ID', 'S3_SECRET_ACCESS_KEY'].filter((k) => !env[k]?.trim());
  console.error(`✗ Missing in ${resolve(root, '.env')}: ${missing.join(', ')}`);
  process.exit(1);
}

const ok = (msg) => console.log(`✓ ${msg}`);
const warn = (msg) => console.log(`! ${msg}`);
const fail = (msg) => {
  console.error(`✗ ${msg}`);
  process.exitCode = 1;
};

console.log(`Bucket ${cfg.bucket} at ${cfg.endpoint} (region ${cfg.region}, key ${cfg.accessKeyId.slice(0, 4)}…)`);
console.log(`Origins: ${origins.join(', ')} · abort incomplete uploads after ${days} days${dryRun ? ' · DRY RUN' : ''}\n`);

/* ---- signed requests --------------------------------------------------------------------- */

const xmlValue = (xml, tag) => xml.match(new RegExp(`<${tag}>([^<]*)</${tag}>`))?.[1];

async function s3(method, { key = '', query = {}, body, headers = {} } = {}) {
  const url = presignUrl(cfg, { method, key, query, expiresSec: 300 });
  const h = { ...headers };
  if (body !== undefined) {
    h['content-md5'] = createHash('md5').update(body).digest('base64');
    h['content-type'] ??= 'application/xml';
  }
  const res = await fetch(url, { method, body, headers: h });
  const text = method === 'HEAD' ? '' : await res.text();
  return { status: res.status, ok: res.ok, text, headers: res.headers };
}
const describe = (r) => `HTTP ${r.status}${xmlValue(r.text, 'Code') ? ` ${xmlValue(r.text, 'Code')}` : ''}${xmlValue(r.text, 'Message') ? `: ${xmlValue(r.text, 'Message')}` : ''}`;

/* ---- 1. bucket --------------------------------------------------------------------------- */

const head = await s3('HEAD');
if (head.ok) {
  ok('Bucket exists and the key can reach it');
} else if (head.status === 404) {
  if (flag('--no-create') || dryRun) {
    fail(`Bucket not found${dryRun ? ' (dry run: would create)' : ''}`);
    if (!dryRun) process.exit(1);
  } else {
    const region = cfg.region && cfg.region !== 'us-east-1' ? `<CreateBucketConfiguration><LocationConstraint>${cfg.region}</LocationConstraint></CreateBucketConfiguration>` : undefined;
    const created = await s3('PUT', { body: region, headers: { 'x-amz-acl': 'private' } });
    if (created.ok) ok(`Created private bucket ${cfg.bucket}`);
    else {
      fail(`Could not create bucket (${describe(created)}). Create "${cfg.bucket}" in the DigitalOcean control panel (Spaces Object Storage → Create) in region ${cfg.region}, then run this again.`);
      process.exit(1);
    }
  }
} else {
  fail(`Cannot reach bucket (${describe(head)}). Check S3_ENDPOINT/S3_REGION and that the key has access to ${cfg.bucket}.`);
  process.exit(1);
}

/* ---- 2. CORS ----------------------------------------------------------------------------- */

const corsXml =
  '<CORSConfiguration><CORSRule>' +
  origins.map((o) => `<AllowedOrigin>${o}</AllowedOrigin>`).join('') +
  '<AllowedMethod>PUT</AllowedMethod><AllowedMethod>GET</AllowedMethod><AllowedMethod>HEAD</AllowedMethod>' +
  '<AllowedHeader>*</AllowedHeader><ExposeHeader>ETag</ExposeHeader><MaxAgeSeconds>3600</MaxAgeSeconds>' +
  '</CORSRule></CORSConfiguration>';

if (dryRun) console.log(`\nWould PUT ?cors:\n${corsXml}\n`);
else {
  const put = await s3('PUT', { query: { cors: '' }, body: corsXml });
  if (put.ok) ok(`CORS set: PUT/GET/HEAD from ${origins.join(', ')}, exposes ETag`);
  else fail(`Setting CORS failed (${describe(put)})`);
}

/* ---- 3. lifecycle ------------------------------------------------------------------------ */

const lifecycleXml =
  '<LifecycleConfiguration><Rule><ID>abort-incomplete-uploads</ID><Filter><Prefix></Prefix></Filter><Status>Enabled</Status>' +
  `<AbortIncompleteMultipartUpload><DaysAfterInitiation>${days}</DaysAfterInitiation></AbortIncompleteMultipartUpload>` +
  '</Rule></LifecycleConfiguration>';
// Older S3-compatible stores (including some Spaces regions) want <Prefix> directly on the rule instead of <Filter>.
const lifecycleLegacyXml = lifecycleXml.replace('<Filter><Prefix></Prefix></Filter>', '<Prefix></Prefix>');

if (dryRun) console.log(`Would PUT ?lifecycle:\n${lifecycleXml}\n`);
else {
  let put = await s3('PUT', { query: { lifecycle: '' }, body: lifecycleXml });
  if (!put.ok && [400, 501].includes(put.status)) put = await s3('PUT', { query: { lifecycle: '' }, body: lifecycleLegacyXml });
  if (put.ok) ok(`Lifecycle set: abort incomplete multipart uploads after ${days} days`);
  else fail(`Setting lifecycle failed (${describe(put)})`);
}

if (dryRun) process.exit(0);

/* ---- 4. verify --------------------------------------------------------------------------- */

console.log('\nVerifying…');

const cors = await s3('GET', { query: { cors: '' } });
if (cors.ok && /<ExposeHeader>ETag<\/ExposeHeader>/i.test(cors.text) && origins.every((o) => cors.text.includes(o))) ok('CORS reads back correctly');
else fail(`CORS read-back does not match (${describe(cors)})`);

const life = await s3('GET', { query: { lifecycle: '' } });
if (life.ok && new RegExp(`<DaysAfterInitiation>${days}</DaysAfterInitiation>`).test(life.text)) ok('Lifecycle reads back correctly');
else fail(`Lifecycle read-back does not match (${describe(life)})`);

// Private: an anonymous listing must be refused.
const endpoint = new URL(cfg.endpoint);
const publicUrl = cfg.addressing === 'virtual' ? `${endpoint.protocol}//${cfg.bucket}.${endpoint.host}/` : `${endpoint.protocol}//${endpoint.host}/${cfg.bucket}/`;
const anon = await fetch(publicUrl).catch(() => undefined);
if (anon && anon.status === 200) fail(`Bucket is publicly listable at ${publicUrl}. Set it to private (File Listing: Restricted) in the control panel.`);
else ok('Bucket is private (anonymous listing refused)');

// Real multipart round trip, as the browser would do it.
const key = `${cfg.prefix}_setup-check/${Date.now()}.bin`;
const init = await s3('POST', { key, query: { uploads: '' } });
const uploadId = init.ok ? xmlValue(init.text, 'UploadId') : undefined;
if (!uploadId) fail(`CreateMultipartUpload failed (${describe(init)})`);
else {
  const origin = origins[0];
  const partUrl = presignUrl(cfg, { method: 'PUT', key, query: { partNumber: '1', uploadId }, expiresSec: 300 });
  const preflight = await fetch(partUrl, { method: 'OPTIONS', headers: { origin, 'access-control-request-method': 'PUT', 'access-control-request-headers': 'content-type' } }).catch(() => undefined);
  const allowOrigin = preflight?.headers.get('access-control-allow-origin');
  if (preflight && (allowOrigin === origin || allowOrigin === '*')) ok(`Browser preflight from ${origin} allowed`);
  else warn(`Preflight did not return Access-Control-Allow-Origin for ${origin} (got ${preflight?.status ?? 'no response'}). CORS can take a minute to apply; re-run if uploads fail.`);

  const put = await fetch(partUrl, { method: 'PUT', body: Buffer.alloc(1024, 7), headers: { origin } });
  const etag = put.headers.get('etag');
  const exposed = (put.headers.get('access-control-expose-headers') ?? '').toLowerCase().includes('etag');
  if (put.ok && etag) ok(`Part upload works (ETag ${etag})${exposed ? ', ETag exposed to browsers' : ''}`);
  else fail(`Part upload failed (HTTP ${put.status})`);
  if (put.ok && !exposed) warn('Response did not list ETag in Access-Control-Expose-Headers. Browsers need it; confirm the CORS rule above applied.');

  const abort = await s3('DELETE', { key, query: { uploadId } });
  if (abort.ok || abort.status === 204) ok('Test upload aborted, nothing left behind');
  else warn(`Could not abort test upload (${describe(abort)}); the ${days}-day rule will clean it up`);
}

console.log(process.exitCode ? '\nSetup finished with errors (see ✗ above).' : '\nAll set. Restart SGEUL (systemctl restart sgeul) and the Editorial "From file" tab appears.');
