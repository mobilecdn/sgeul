#!/usr/bin/env bash
# One-shot install on Ubuntu 22.04/24.04. Run as root from the folder that holds twelve-studio-v15.tgz.
#   sudo bash install.sh
set -euo pipefail
ARCHIVE="${1:-twelve-studio-v15.tgz}"

apt-get update -y
apt-get install -y ca-certificates curl gnupg nginx ffmpeg
if ! command -v node >/dev/null || [ "$(node -v | cut -c2-3)" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi

id -u sgeul >/dev/null 2>&1 || useradd --system --home /opt/sgeul --shell /usr/sbin/nologin sgeul
mkdir -p /opt/sgeul /var/lib/sgeul/{renders,media}
tar -xzf "$ARCHIVE" -C /opt/sgeul
cd /opt/sgeul/twelve-studio
npm ci --omit=dev --ignore-scripts          # runtime deps only: express, cors, dotenv, MCP sdk, zod

[ -f .env ] || cp deploy/.env.production.example .env
chown -R sgeul:sgeul /opt/sgeul /var/lib/sgeul

install -m 644 deploy/sgeul.service /etc/systemd/system/sgeul.service
install -m 644 deploy/nginx-sgeul.conf /etc/nginx/sites-available/sgeul.com
ln -sf /etc/nginx/sites-available/sgeul.com /etc/nginx/sites-enabled/sgeul.com
rm -f /etc/nginx/sites-enabled/default

systemctl daemon-reload
systemctl enable --now sgeul
nginx -t && systemctl reload nginx

echo
echo "SGEUL is running on 127.0.0.1:8787 behind nginx."
echo "Next: edit /opt/sgeul/twelve-studio/.env (key, BASIC_AUTH), then: systemctl restart sgeul"
echo "TLS:  apt-get install -y certbot python3-certbot-nginx && certbot --nginx -d sgeul.com -d www.sgeul.com"
echo "Media: copy DavidandGoliath1960.mp4 and the Kinder Bueno spots into /var/lib/sgeul/media for stitched previews."
