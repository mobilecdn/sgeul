/**
 * Runtime configuration. `.env` is read from the repo root so one file serves
 * every workspace; process env always wins.
 */

import { existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { objectStoreConfigFromEnv, type ObjectStoreConfig } from './objectstore.js';

const here = dirname(fileURLToPath(import.meta.url));
/** Repo root: apps/api/src → ../../.. (also correct from apps/api/dist). */
export const REPO_ROOT = resolve(here, '..', '..', '..');

const envPath = resolve(REPO_ROOT, '.env');
if (existsSync(envPath)) dotenv.config({ path: envPath, quiet: true });

export interface ApiConfig {
  port: number;
  mode: 'live' | 'mock';
  apiKey?: string;
  indexId?: string;
  indexName: string;
  synopsisLanguages: string[];
  seedDir: string;
  storePath: string;
  /** Where stitched previews (and the ad transcode cache) are written. */
  rendersDir: string;
  /** Job runner concurrency. */
  concurrency: number;
  corsOrigin: string | true;
  /** Simulated latency for the mock client, [min, max] ms. */
  mockLatencyMs: [number, number];
  /** Optional `user:password` that gates every route with HTTP basic auth (set it on any public host). */
  basicAuth?: { user: string; password: string };
  /** Bind address (default all interfaces; use 127.0.0.1 behind a reverse proxy). */
  host?: string;
  /** S3-compatible bucket for browser uploads (S3_* env); undefined disables the "From file" tab. */
  objectStore?: ObjectStoreConfig;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): ApiConfig {
  const apiKey = env.TWELVELABS_API_KEY?.trim() || undefined;
  return {
    port: Number(env.PORT ?? 8787),
    mode: apiKey ? 'live' : 'mock',
    apiKey,
    indexId: env.TWELVELABS_INDEX_ID?.trim() || undefined,
    indexName: env.TWELVELABS_INDEX_NAME?.trim() || 'twelve-studio',
    synopsisLanguages: (env.SYNOPSIS_LANGS ?? 'es,fr,de,ja,pt,ar,hi,ko')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    seedDir: resolve(REPO_ROOT, env.SEED_DIR ?? 'data/seed'),
    storePath: resolve(REPO_ROOT, env.STORE_PATH ?? 'data/store.json'),
    rendersDir: resolve(REPO_ROOT, env.RENDERS_DIR ?? 'data/renders'),
    concurrency: Math.max(1, Number(env.JOB_CONCURRENCY ?? 2)),
    corsOrigin: env.CORS_ORIGIN ?? true,
    mockLatencyMs: parseLatency(env.MOCK_LATENCY_MS),
    basicAuth: parseBasicAuth(env.BASIC_AUTH),
    host: env.HOST?.trim() || undefined,
    objectStore: objectStoreConfigFromEnv(env),
  };
}

function parseBasicAuth(raw: string | undefined): ApiConfig['basicAuth'] {
  const v = raw?.trim();
  if (!v) return undefined;
  const i = v.indexOf(':');
  if (i <= 0 || i === v.length - 1) throw new Error('BASIC_AUTH must be "user:password"');
  return { user: v.slice(0, i), password: v.slice(i + 1) };
}

function parseLatency(raw: string | undefined): [number, number] {
  if (!raw) return [120, 480];
  const [a, b] = raw.split(/[,-]/).map((x) => Number(x.trim()));
  const min = Number.isFinite(a) ? Math.max(0, a!) : 0;
  const max = Number.isFinite(b) ? Math.max(min, b!) : min;
  return [min, max];
}
