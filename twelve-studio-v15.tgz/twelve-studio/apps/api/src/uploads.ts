/**
 * Browser uploads straight to object storage (S3 multipart), then into the catalog.
 *
 *   GET  /api/uploads/config        { enabled, maxBytes, partSizeBytes }
 *   POST /api/uploads               { filename, sizeBytes, contentType? }         → { key, uploadId, partSizeBytes, partCount }
 *   POST /api/uploads/parts         { key, uploadId, partNumbers: number[] }     → { urls: [{ partNumber, url }] }
 *   GET  /api/uploads/parts         ?key=&uploadId=                              → { parts: [{ partNumber, etag }] }  (resume)
 *   POST /api/uploads/complete      { key, uploadId, parts, title?, type?, sizeBytes } → CatalogItem (201)
 *   POST /api/uploads/abort         { key, uploadId }                            → 204
 *
 * Bytes never pass through Node or nginx, so there is no 2 GB body limit and a dropped
 * connection only costs the part in flight. The bucket needs CORS allowing PUT from the
 * SGEUL origin and exposing the ETag header (see deploy/README.md).
 */

import type { NextFunction, Request, Response, Router } from 'express';
import type { CatalogItem, CatalogItemInput } from '@twelve-studio/core';
import { ObjectStoreError, partSizeFor, type MultipartPart, type ObjectStore } from './objectstore.js';
import { hasFfmpeg } from './stitch.js';
import { publicItem } from './views.js';

type Wrap = (fn: (req: Request, res: Response) => unknown) => (req: Request, res: Response, next: NextFunction) => void;
type HttpErrorCtor = new (status: number, code: string, message: string) => Error;

export interface UploadRouteDeps {
  objectStore?: ObjectStore;
  addCatalogItem: (input: CatalogItemInput, i: number, ffmpeg: boolean) => Promise<CatalogItem>;
  wrap: Wrap;
  HttpError: HttpErrorCtor;
}

const VIDEO_EXT = /\.(mp4|m4v|mov|mkv|webm|avi|mxf|ts|mpg|mpeg|wmv|flv|3gp)$/i;
const MAX_SIGN_BATCH = 100;

export function registerUploadRoutes(router: Router, { objectStore, addCatalogItem, wrap, HttpError }: UploadRouteDeps): void {
  const store = (): ObjectStore => {
    if (!objectStore) throw new HttpError(409, 'uploads_disabled', 'File uploads need object storage: set S3_ENDPOINT, S3_BUCKET, S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY');
    return objectStore;
  };
  const bad = (msg: string) => new HttpError(400, 'bad_request', msg);
  const asHttp = (err: unknown): never => {
    if (err instanceof ObjectStoreError) throw new HttpError(err.status, err.code, err.message);
    throw err;
  };
  const target = (body: Record<string, unknown>) => {
    const os = store();
    if (!os.isUploadKey(body.key)) throw bad('key must be a key issued by POST /uploads');
    if (typeof body.uploadId !== 'string' || !body.uploadId || body.uploadId.length > 1024) throw bad('uploadId is required');
    return { os, key: body.key, uploadId: body.uploadId };
  };

  router.get(
    '/uploads/config',
    wrap(() => ({
      enabled: !!objectStore,
      maxBytes: objectStore?.config.maxBytes ?? 0,
      partSizeBytes: objectStore ? partSizeFor(0) : 0,
    })),
  );

  router.post(
    '/uploads',
    wrap(async (req, res) => {
      const os = store();
      const body = (req.body ?? {}) as { filename?: unknown; sizeBytes?: unknown; contentType?: unknown };
      const filename = typeof body.filename === 'string' ? body.filename.trim() : '';
      const size = Number(body.sizeBytes);
      if (!filename) throw bad('filename is required');
      if (!VIDEO_EXT.test(filename)) throw bad('filename must be a video file (mp4, mov, mkv, webm, mxf, …)');
      if (!Number.isFinite(size) || size <= 0) throw bad('sizeBytes must be a positive number');
      if (size > os.config.maxBytes) {
        throw new HttpError(413, 'file_too_large', `${filename} is ${(size / 1024 ** 3).toFixed(2)} GB; the limit is ${(os.config.maxBytes / 1024 ** 3).toFixed(0)} GB (TwelveLabs URL ingest caps assets at 4 GB)`);
      }
      const contentType = typeof body.contentType === 'string' && /^video\/[\w.+-]+$/.test(body.contentType) ? body.contentType : undefined;
      const key = os.newKey(filename);
      const uploadId = await os.createMultipart(key, contentType).catch(asHttp);
      const partSizeBytes = partSizeFor(size);
      res.status(201);
      return { key, uploadId, partSizeBytes, partCount: Math.ceil(size / partSizeBytes) };
    }),
  );

  router.post(
    '/uploads/parts',
    wrap((req) => {
      const body = (req.body ?? {}) as Record<string, unknown>;
      const { os, key, uploadId } = target(body);
      const nums = body.partNumbers;
      if (!Array.isArray(nums) || nums.length === 0 || nums.length > MAX_SIGN_BATCH) throw bad(`partNumbers must be an array of 1 to ${MAX_SIGN_BATCH} part numbers`);
      const urls = nums.map((n) => {
        if (!Number.isInteger(n) || (n as number) < 1 || (n as number) > 10_000) throw bad('part numbers must be integers from 1 to 10000');
        return { partNumber: n as number, url: os.partUrl(key, uploadId, n as number) };
      });
      return { urls };
    }),
  );

  router.get(
    '/uploads/parts',
    wrap(async (req) => {
      const { os, key, uploadId } = target(req.query as Record<string, unknown>);
      return { parts: await os.listParts(key, uploadId).catch(asHttp) };
    }),
  );

  router.post(
    '/uploads/complete',
    wrap(async (req, res) => {
      const body = (req.body ?? {}) as Record<string, unknown>;
      const { os, key, uploadId } = target(body);
      const raw = body.parts;
      if (!Array.isArray(raw) || raw.length === 0 || raw.length > 10_000) throw bad('parts must list every uploaded part');
      const parts: MultipartPart[] = raw.map((p) => {
        const { partNumber, etag } = (p ?? {}) as { partNumber?: unknown; etag?: unknown };
        if (!Number.isInteger(partNumber) || typeof etag !== 'string' || !etag) throw bad('each part needs partNumber and etag');
        return { partNumber: partNumber as number, etag };
      });
      const seen = new Set(parts.map((p) => p.partNumber));
      if (seen.size !== parts.length) throw bad('duplicate part numbers');
      for (let n = 1; n <= parts.length; n++) if (!seen.has(n)) throw bad(`part ${n} is missing`);

      await os.completeMultipart(key, uploadId, parts).catch(asHttp);
      const head = await os.head(key).catch(asHttp);
      const expected = Number(body.sizeBytes);
      if (Number.isFinite(expected) && expected > 0 && head.sizeBytes !== expected) {
        throw new HttpError(422, 'size_mismatch', `Stored object is ${head.sizeBytes} bytes but the browser sent ${expected}; upload again`);
      }

      const filename = key.split('/').pop() ?? 'video';
      const input: CatalogItemInput = {
        title: typeof body.title === 'string' && body.title.trim() ? body.title.trim() : undefined,
        type: body.type as CatalogItemInput['type'],
        sourceUrl: os.sourceUrlFor(key),
        metadata: { filename, sizeBytes: head.sizeBytes, uploadMethod: 'browser-multipart', storageKey: key },
      } as CatalogItemInput;
      if (input.title === undefined) delete (input as Partial<CatalogItemInput>).title;
      if (input.type === undefined) delete (input as Partial<CatalogItemInput>).type;
      const item = await addCatalogItem(input, 0, await hasFfmpeg());
      res.status(201);
      return publicItem(item);
    }),
  );

  router.post(
    '/uploads/abort',
    wrap(async (req) => {
      const { os, key, uploadId } = target((req.body ?? {}) as Record<string, unknown>);
      await os.abortMultipart(key, uploadId).catch((err) => {
        // Already gone is fine.
        if (err instanceof ObjectStoreError && err.code === 'storage_not_found') return;
        asHttp(err);
      });
      return undefined;
    }),
  );
}
