/**
 * S3-compatible object storage for browser uploads (DigitalOcean Spaces, Backblaze B2,
 * Cloudflare R2, MinIO, AWS S3). No SDK: AWS Signature V4 query presigning plus the five
 * multipart calls SGEUL needs.
 *
 * Flow: the browser never sends bytes through Node or nginx. The API creates a multipart
 * upload, hands the browser presigned PUT URLs per part, the browser uploads parts straight
 * to the bucket, then the API completes the upload and stores `s3://bucket/key` as the
 * catalog `sourceUrl`. The ingest job signs a fresh GET URL for TwelveLabs each time, so a
 * stuck asset can be resubmitted from storage without the user re-uploading.
 */

import { createHash, createHmac, randomUUID } from 'node:crypto';

export interface ObjectStoreConfig {
  /** e.g. https://nyc3.digitaloceanspaces.com, https://s3.us-west-004.backblazeb2.com */
  endpoint: string;
  region: string;
  bucket: string;
  accessKeyId: string;
  secretAccessKey: string;
  /** Key prefix for uploads (default `uploads/`). */
  prefix: string;
  /** `path` (default, works everywhere) or `virtual` (bucket.host). */
  addressing: 'path' | 'virtual';
  /** Largest accepted upload. TwelveLabs URL ingest is capped at 4 GB. */
  maxBytes: number;
  /** Lifetime of the GET URL handed to TwelveLabs. */
  sourceUrlTtlSec: number;
}

export interface MultipartPart {
  partNumber: number;
  etag: string;
}

type FetchLike = typeof fetch;

const UNSIGNED = 'UNSIGNED-PAYLOAD';
export const MIN_PART_BYTES = 8 * 1024 * 1024;
export const DEFAULT_PART_BYTES = 64 * 1024 * 1024;
const MAX_PARTS = 10_000;

/** RFC 3986 encoding as SigV4 requires (everything except unreserved). */
export function rfc3986(value: string): string {
  return encodeURIComponent(value).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}

const sha256Hex = (s: string) => createHash('sha256').update(s, 'utf8').digest('hex');
const hmac = (key: Buffer | string, s: string) => createHmac('sha256', key).update(s, 'utf8').digest();

function amzDate(d: Date): { date: string; stamp: string } {
  const stamp = d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  return { date: stamp.slice(0, 8), stamp };
}

export interface PresignParams {
  method: 'GET' | 'PUT' | 'POST' | 'DELETE' | 'HEAD';
  key: string;
  query?: Record<string, string>;
  expiresSec: number;
  now?: Date;
}

/** AWS SigV4 presigned URL (query-string auth, host is the only signed header). */
export function presignUrl(cfg: Pick<ObjectStoreConfig, 'endpoint' | 'region' | 'bucket' | 'accessKeyId' | 'secretAccessKey' | 'addressing'>, p: PresignParams): string {
  const endpoint = new URL(cfg.endpoint);
  const host = cfg.addressing === 'virtual' ? `${cfg.bucket}.${endpoint.host}` : endpoint.host;
  const encodedKey = p.key.split('/').map(rfc3986).join('/');
  const path = cfg.addressing === 'virtual' ? `/${encodedKey}` : `/${rfc3986(cfg.bucket)}/${encodedKey}`;
  const { date, stamp } = amzDate(p.now ?? new Date());
  const scope = `${date}/${cfg.region}/s3/aws4_request`;
  const expires = Math.max(1, Math.min(604_800, Math.round(p.expiresSec)));

  const query: Record<string, string> = {
    ...(p.query ?? {}),
    'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
    'X-Amz-Credential': `${cfg.accessKeyId}/${scope}`,
    'X-Amz-Date': stamp,
    'X-Amz-Expires': String(expires),
    'X-Amz-SignedHeaders': 'host',
  };
  const canonicalQuery = Object.keys(query)
    .sort()
    .map((k) => `${rfc3986(k)}=${rfc3986(query[k]!)}`)
    .join('&');
  const canonicalRequest = [p.method, path, canonicalQuery, `host:${host}`, '', 'host', UNSIGNED].join('\n');
  const stringToSign = ['AWS4-HMAC-SHA256', stamp, scope, sha256Hex(canonicalRequest)].join('\n');
  const kDate = hmac(`AWS4${cfg.secretAccessKey}`, date);
  const kSigning = hmac(hmac(hmac(kDate, cfg.region), 's3'), 'aws4_request');
  const signature = createHmac('sha256', kSigning).update(stringToSign, 'utf8').digest('hex');
  return `${endpoint.protocol}//${host}${path}?${canonicalQuery}&X-Amz-Signature=${signature}`;
}

/** Choose a part size: at least 8 MiB, default 64 MiB, and never more than 10,000 parts. */
export function partSizeFor(sizeBytes: number, preferred = DEFAULT_PART_BYTES): number {
  const mib = 1024 * 1024;
  const floor = Math.ceil(sizeBytes / MAX_PARTS / mib) * mib;
  return Math.max(MIN_PART_BYTES, preferred, floor);
}

export class ObjectStoreError extends Error {
  constructor(
    message: string,
    readonly code: string,
    readonly status = 502,
  ) {
    super(message);
  }
}

const xmlValue = (xml: string, tag: string) => xml.match(new RegExp(`<${tag}>([^<]*)</${tag}>`))?.[1];
const xmlEscape = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const xmlUnescape = (s: string) => s.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');

export class ObjectStore {
  constructor(
    readonly config: ObjectStoreConfig,
    private readonly fetchImpl: FetchLike = fetch,
  ) {}

  /** `s3://bucket/key`: the stable, unsigned form stored on catalog items. */
  sourceUrlFor(key: string): string {
    return `s3://${this.config.bucket}/${key}`;
  }

  /** Key for an `s3://` URL in this bucket, or undefined for anything else. */
  keyFromSourceUrl(sourceUrl: string | undefined): string | undefined {
    if (typeof sourceUrl !== 'string') return undefined;
    const m = sourceUrl.trim().match(/^s3:\/\/([^/]+)\/(.+)$/);
    if (!m || m[1] !== this.config.bucket) return undefined;
    return this.isUploadKey(m[2]!) ? m[2] : undefined;
  }

  /** Keys the API issued: under the prefix, no traversal, no empty segments. */
  isUploadKey(key: unknown): key is string {
    if (typeof key !== 'string' || !key.startsWith(this.config.prefix) || key.length > 1024) return false;
    return key.split('/').every((seg) => seg !== '' && seg !== '.' && seg !== '..');
  }

  /** `uploads/2026/09/<uuid>/<safe-filename>` */
  newKey(filename: string, now = new Date()): string {
    const safe =
      filename
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^A-Za-z0-9._-]+/g, '_')
        .replace(/^[._]+/, '')
        .slice(-120) || 'video';
    const yyyy = now.getUTCFullYear();
    const mm = String(now.getUTCMonth() + 1).padStart(2, '0');
    return `${this.config.prefix}${yyyy}/${mm}/${randomUUID()}/${safe}`;
  }

  presign(method: PresignParams['method'], key: string, expiresSec: number, query?: Record<string, string>): string {
    return presignUrl(this.config, { method, key, expiresSec, query });
  }

  /** Fresh GET URL for TwelveLabs to fetch the object. */
  signedSourceUrl(key: string): string {
    return this.presign('GET', key, this.config.sourceUrlTtlSec);
  }

  private async call(method: PresignParams['method'], key: string, query: Record<string, string>, init: RequestInit = {}): Promise<Response> {
    const url = this.presign(method, key, 900, query);
    let res: Response;
    try {
      res = await this.fetchImpl(url, { method, ...init });
    } catch (err) {
      throw new ObjectStoreError(`Object storage unreachable: ${(err as Error).message}`, 'storage_unreachable');
    }
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      const code = xmlValue(body, 'Code') ?? `http_${res.status}`;
      const msg = xmlValue(body, 'Message') ?? res.statusText;
      throw new ObjectStoreError(`${method} ${key}: ${code} ${msg}`.trim(), res.status === 404 ? 'storage_not_found' : 'storage_error', res.status === 404 ? 404 : 502);
    }
    return res;
  }

  async createMultipart(key: string, contentType?: string): Promise<string> {
    const res = await this.call('POST', key, { uploads: '' }, contentType ? { headers: { 'content-type': contentType } } : {});
    const uploadId = xmlValue(await res.text(), 'UploadId');
    if (!uploadId) throw new ObjectStoreError('CreateMultipartUpload returned no UploadId', 'storage_error');
    return xmlUnescape(uploadId);
  }

  partUrl(key: string, uploadId: string, partNumber: number, expiresSec = 3600): string {
    return this.presign('PUT', key, expiresSec, { partNumber: String(partNumber), uploadId });
  }

  async listParts(key: string, uploadId: string): Promise<MultipartPart[]> {
    const parts: MultipartPart[] = [];
    let marker = '';
    for (let guard = 0; guard < 20; guard++) {
      const res = await this.call('GET', key, { uploadId, ...(marker ? { 'part-number-marker': marker } : {}) });
      const xml = await res.text();
      for (const m of xml.matchAll(/<Part>([\s\S]*?)<\/Part>/g)) {
        const n = Number(xmlValue(m[1]!, 'PartNumber'));
        const etag = xmlValue(m[1]!, 'ETag');
        if (n && etag) parts.push({ partNumber: n, etag: xmlUnescape(etag) });
      }
      if (xmlValue(xml, 'IsTruncated') !== 'true') break;
      marker = xmlValue(xml, 'NextPartNumberMarker') ?? '';
      if (!marker) break;
    }
    return parts;
  }

  async completeMultipart(key: string, uploadId: string, parts: MultipartPart[]): Promise<void> {
    const sorted = [...parts].sort((a, b) => a.partNumber - b.partNumber);
    const body =
      '<CompleteMultipartUpload>' +
      sorted.map((p) => `<Part><PartNumber>${p.partNumber}</PartNumber><ETag>${xmlEscape(p.etag.startsWith('"') ? p.etag : `"${p.etag}"`)}</ETag></Part>`).join('') +
      '</CompleteMultipartUpload>';
    const res = await this.call('POST', key, { uploadId }, { body, headers: { 'content-type': 'application/xml' } });
    // S3 can return 200 with an <Error> body.
    const text = await res.text();
    if (/<Error>/.test(text)) throw new ObjectStoreError(`CompleteMultipartUpload failed: ${xmlValue(text, 'Code')} ${xmlValue(text, 'Message') ?? ''}`.trim(), 'storage_error');
  }

  async abortMultipart(key: string, uploadId: string): Promise<void> {
    await this.call('DELETE', key, { uploadId });
  }

  async head(key: string): Promise<{ sizeBytes: number; contentType?: string }> {
    const res = await this.call('HEAD', key, {});
    return { sizeBytes: Number(res.headers.get('content-length') ?? 0), contentType: res.headers.get('content-type') ?? undefined };
  }
}

/** Build from env; undefined (uploads disabled) unless bucket, endpoint and both keys are set. */
export function objectStoreConfigFromEnv(env: NodeJS.ProcessEnv): ObjectStoreConfig | undefined {
  const endpoint = env.S3_ENDPOINT?.trim();
  const bucket = env.S3_BUCKET?.trim();
  const accessKeyId = env.S3_ACCESS_KEY_ID?.trim();
  const secretAccessKey = env.S3_SECRET_ACCESS_KEY?.trim();
  if (!endpoint || !bucket || !accessKeyId || !secretAccessKey) return undefined;
  let prefix = env.S3_PREFIX?.trim() || 'uploads/';
  if (!prefix.endsWith('/')) prefix += '/';
  prefix = prefix.replace(/^\/+/, '');
  const maxGb = Number(env.UPLOAD_MAX_GB ?? 4);
  return {
    endpoint: endpoint.replace(/\/+$/, ''),
    region: env.S3_REGION?.trim() || 'us-east-1',
    bucket,
    accessKeyId,
    secretAccessKey,
    prefix,
    addressing: env.S3_ADDRESSING?.trim() === 'virtual' ? 'virtual' : 'path',
    maxBytes: Math.round((Number.isFinite(maxGb) && maxGb > 0 ? maxGb : 4) * 1024 ** 3),
    sourceUrlTtlSec: Math.max(3600, Number(env.S3_SOURCE_URL_TTL_SEC ?? 86_400) || 86_400),
  };
}
