/**
 * Fetching page URLs (YouTube, Vimeo, …) to disk with yt-dlp.
 *
 * TwelveLabs' asset API ingests *direct* media URLs only; "https://www.youtube.com/watch?v=…" is a web page and
 * the upload fails. So the ingest job hands such URLs to `fetchRemote`, which downloads the media into
 * `uploadsDir` and turns the title into a local item (playback from this host, direct upload to TwelveLabs).
 *
 * yt-dlp is a single static binary (https://github.com/yt-dlp/yt-dlp/releases); deploy/install.sh installs it.
 * Where ffmpeg exists, video and audio streams are merged into one mp4; otherwise the best single-file mp4 is used.
 */

import { execFile, spawn } from 'node:child_process';
import { mkdir, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { promisify } from 'node:util';
import type { CatalogItem } from '@twelve-studio/core';
import type { Store } from './store.js';
import { hasFfmpeg, probeMedia } from './stitch.js';

const exec = promisify(execFile);

export class DownloadError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly log?: string,
  ) {
    super(message);
    this.name = 'DownloadError';
  }
}

const checked = new Map<string, Promise<string | undefined>>();

/** yt-dlp version when the binary runs, undefined otherwise (cached per path). */
export function ytDlpVersion(bin: string): Promise<string | undefined> {
  let p = checked.get(bin);
  if (!p) {
    p = exec(bin, ['--version'], { timeout: 15_000 })
      .then(({ stdout }) => stdout.trim() || 'unknown')
      .catch(() => undefined);
    checked.set(bin, p);
  }
  return p;
}

export interface DownloadResult {
  path: string;
  title?: string;
  durationSec?: number;
  bytes: number;
}

/** Percentage lines yt-dlp prints with --newline: `[download]  42.3% of  120.00MiB at 5.00MiB/s ETA 00:14`. */
const PROGRESS = /\[download\]\s+([\d.]+)%\s+of\s+~?\s*([\d.]+\w+)/;

/**
 * Download `url` into `destDir` as mp4. Progress notes are throttled to whole 10 % steps so the activity ledger
 * stays readable. Resolves with the file path, the page title and duration yt-dlp reported.
 */
export async function downloadWithYtDlp(
  bin: string,
  url: string,
  destDir: string,
  opts: { slug: string; onNote?: (note: string) => void; timeoutMs?: number; maxHeight?: number; cookies?: string },
): Promise<DownloadResult> {
  await mkdir(destDir, { recursive: true });
  const merge = await hasFfmpeg();
  const h = opts.maxHeight ?? 1080;
  const format = merge
    ? `bv*[ext=mp4][height<=${h}]+ba[ext=m4a]/b[ext=mp4][height<=${h}]/bv*+ba/b`
    : `b[ext=mp4][height<=${h}]/b[ext=mp4]/b`;
  const template = join(destDir, `${opts.slug}-%(id)s.%(ext)s`);
  const args = [
    '--no-playlist',
    '--no-warnings',
    // YouTube extraction needs a JS runtime; every SGEUL host has Node (deno stays the default if present).
    '--js-runtimes', 'node',
    // --print implies --quiet, which would hide the progress lines the ledger shows; --progress restores them.
    '--progress',
    '--newline',
    '--no-part',
    '-f', format,
    ...(merge ? ['--merge-output-format', 'mp4'] : []),
    ...(opts.cookies ? ['--cookies', opts.cookies] : []),
    '-o', template,
    // Printed once the file is in place: path, title and duration as one JSON object (yt-dlp's `j` conversion).
    '--print', 'after_move:__SGEUL__{"path":%(filepath)j,"title":%(title|)j,"duration":%(duration|0)j}',
    '--no-simulate',
    url,
  ];

  return new Promise<DownloadResult>((resolve, reject) => {
    const child = spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    const log: string[] = [];
    let result: DownloadResult | undefined;
    let lastStep = -1;
    let buf = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new DownloadError('download_timeout', `yt-dlp took longer than ${Math.round((opts.timeoutMs ?? 0) / 60000)} min`, log.slice(-20).join('\n')));
    }, opts.timeoutMs ?? 45 * 60_000);

    const onLine = (line: string) => {
      if (!line) return;
      log.push(line);
      if (log.length > 400) log.splice(0, log.length - 400);
      if (line.startsWith('__SGEUL__{')) {
        try {
          const j = JSON.parse(line.slice('__SGEUL__'.length)) as { path: string; title?: string; duration?: number | string };
          const dur = Number(j.duration);
          result = { path: j.path, title: typeof j.title === 'string' && j.title.trim() ? j.title.trim() : undefined, durationSec: Number.isFinite(dur) && dur > 0 ? dur : undefined, bytes: 0 };
        } catch {
          /* malformed print line: fall through to the "no file" error below */
        }
        return;
      }
      const m = PROGRESS.exec(line);
      if (m) {
        const step = Math.floor(Number(m[1]) / 10);
        if (step !== lastStep) {
          lastStep = step;
          opts.onNote?.(`→ yt-dlp ${Math.round(Number(m[1]))}% of ${m[2]}`);
        }
      } else if (/^\[Merger\]/.test(line)) opts.onNote?.('→ yt-dlp merging video and audio (ffmpeg)');
    };
    const onChunk = (chunk: Buffer) => {
      buf += chunk.toString('utf8');
      const lines = buf.split(/\r?\n/);
      buf = lines.pop() ?? '';
      lines.forEach(onLine);
    };
    child.stdout.on('data', onChunk);
    child.stderr.on('data', onChunk);
    child.on('error', (err) => {
      clearTimeout(timer);
      reject(new DownloadError('yt_dlp_missing', `Cannot run ${bin}: ${err.message}. Install yt-dlp (deploy/install.sh does) or set YT_DLP to its path.`));
    });
    child.on('close', async (code) => {
      clearTimeout(timer);
      if (buf) onLine(buf);
      if (code !== 0 || !result) {
        const joined = log.join('\n');
        if (/Sign in to confirm you.re not a bot/i.test(joined)) {
          reject(
            new DownloadError(
              'youtube_bot_check',
              `YouTube refused this server ("Sign in to confirm you're not a bot" — it treats datacenter IPs that way). Fix: export a cookies.txt from a browser signed in to YouTube, put it on the server and set YT_DLP_COOKIES to its path; or run SGEUL on your laptop for YouTube links; or download the file yourself and use Upload a video on the Overview page.`,
              log.slice(-40).join('\n'),
            ),
          );
          return;
        }
        const tail = log.filter((l) => /ERROR|error/i.test(l)).slice(-3).join(' · ') || log.slice(-3).join(' · ');
        reject(new DownloadError('download_failed', `yt-dlp could not fetch ${url}${tail ? `: ${tail}` : ''}`, log.slice(-40).join('\n')));
        return;
      }
      try {
        result.bytes = (await stat(result.path)).size;
        if (result.bytes === 0) throw new Error('empty file');
        resolve(result);
      } catch (err) {
        reject(new DownloadError('download_failed', `yt-dlp finished but ${result.path} is unusable: ${(err as Error).message}`));
      }
    });
  });
}

export interface FetchRemoteDeps {
  store: Store;
  ytDlpPath: string;
  uploadsDir: string;
  cookies?: string;
  /** Titles derived from the URL (e.g. "watch") are replaced with the page title yt-dlp reports. */
  titleFromUrl: (url: string) => string;
}

/**
 * `PipelineConfig.fetchRemote` for the API: download the page URL, probe the file, and save the item as a local
 * title (localPath + playback from this host). Returns the updated item.
 */
export function makeFetchRemote(deps: FetchRemoteDeps) {
  return async (item: CatalogItem, onNote?: (note: string) => void): Promise<CatalogItem | undefined> => {
    if (!(await ytDlpVersion(deps.ytDlpPath))) {
      throw new DownloadError(
        'yt_dlp_missing',
        `${new URL(item.sourceUrl).hostname} is a web page, not a media file, and yt-dlp is not installed on this host to fetch it. Install yt-dlp (deploy/install.sh does), or ingest a direct .mp4/.m3u8 URL, or upload the file from the Overview page.`,
      );
    }
    const slug = item.id.replace(/[^a-z0-9-]/gi, '').slice(0, 40) || 'remote';
    const dl = await downloadWithYtDlp(deps.ytDlpPath, item.sourceUrl, deps.uploadsDir, { slug, onNote, cookies: deps.cookies });
    onNote?.(`→ fetched ${Math.round(dl.bytes / 1e6)} MB to this host${dl.title ? ` (“${dl.title}”)` : ''}`);

    const latest = deps.store.getBundle(item.id)?.item ?? item;
    const next: CatalogItem = { ...latest, localPath: dl.path, playback: { ...(latest.playback ?? {}), fileUrl: `/api/catalog/${item.id}/media` }, updatedAt: new Date().toISOString() };
    if (dl.title && (!latest.title.trim() || latest.title === deps.titleFromUrl(latest.sourceUrl))) next.title = dl.title;
    if (dl.durationSec && !next.durationSec) next.durationSec = dl.durationSec;
    if (await hasFfmpeg()) {
      const info = await probeMedia(dl.path).catch(() => undefined);
      if (info) {
        if (info.durationSec > 0) next.durationSec = Math.round(info.durationSec * 1000) / 1000;
        if (info.video) {
          next.fps = info.video.fps || next.fps;
          next.width = info.video.width || next.width;
          next.height = info.video.height || next.height;
        }
      }
    }
    return deps.store.saveItem(next);
  };
}
