/**
 * yt-dlp downloader: runs only when yt-dlp is on PATH (CI without it skips). Uses yt-dlp's generic extractor
 * against a tiny mp4 served from this process, so no network beyond loopback is needed.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, rm } from 'node:fs/promises';
import { basename } from 'node:path';
import type { AddressInfo } from 'node:net';
import { downloadWithYtDlp, ytDlpVersion } from '../src/download.js';
import { makeSyntheticMedia } from './synthetic.js';

test('downloadWithYtDlp fetches a URL to disk and reports path, title and progress', async (t) => {
  if (!(await ytDlpVersion('yt-dlp'))) return t.skip('yt-dlp not installed');
  const media = await makeSyntheticMedia('twelve-dl-');
  if (!media) return t.skip('ffmpeg not installed');
  const bytes = await readFile(media.movie);
  const srv = createServer((req, res) => {
    if (req.url !== '/clip.mp4') return void res.writeHead(404).end();
    res.writeHead(200, { 'content-type': 'video/mp4', 'content-length': bytes.length });
    res.end(bytes);
  });
  await new Promise<void>((r) => srv.listen(0, '127.0.0.1', r));
  const port = (srv.address() as AddressInfo).port;
  const notes: string[] = [];
  try {
    const out = await downloadWithYtDlp('yt-dlp', `http://127.0.0.1:${port}/clip.mp4`, `${media.dir}/dl`, { slug: 'test-item', onNote: (n) => notes.push(n) });
    assert.match(basename(out.path), /^test-item-clip\.mp4$/);
    assert.equal(out.bytes, bytes.length);
    assert.equal(out.title, 'clip');
    assert.ok(notes.some((n) => /yt-dlp 100%/.test(n)), `progress notes: ${notes.join(' | ')}`);
    await assert.rejects(downloadWithYtDlp('yt-dlp', `http://127.0.0.1:${port}/missing.mp4`, `${media.dir}/dl`, { slug: 'x' }), /could not fetch/);
    await assert.rejects(downloadWithYtDlp('/no/such/yt-dlp', `http://127.0.0.1:${port}/clip.mp4`, `${media.dir}/dl`, { slug: 'x' }), /Cannot run/);
  } finally {
    srv.closeAllConnections();
    srv.close();
    await rm(media.dir, { recursive: true, force: true });
  }
});
