/**
 * Browser uploads: SigV4 presigning, S3 multipart against a fake bucket, catalog creation
 * with an s3:// source, and ingest handing TwelveLabs a freshly signed URL.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { createServer, type Server } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import { createApp, type App } from '../src/server.js';
import { loadConfig } from '../src/config.js';
import { ObjectStore, objectStoreConfigFromEnv, partSizeFor, presignUrl } from '../src/objectstore.js';

/* ---- a minimal S3 multipart server --------------------------------------------------- */

interface Upload {
  key: string;
  parts: Map<number, Buffer>;
}
const objects = new Map<string, Buffer>();
const uploads = new Map<string, Upload>();
const seenSignatures: string[] = [];

function startFakeS3(): Promise<Server> {
  const srv = createServer(async (req, res) => {
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    const body = Buffer.concat(chunks);
    const url = new URL(req.url!, 'http://x');
    // Path style: /bucket/key...
    const [, bucket, ...rest] = url.pathname.split('/');
    const key = rest.map(decodeURIComponent).join('/');
    const q = url.searchParams;
    res.setHeader('access-control-expose-headers', 'ETag');
    if (bucket !== 'sgeul-media' || !q.get('X-Amz-Signature')) {
      res.writeHead(403).end('<Error><Code>AccessDenied</Code><Message>bad bucket or unsigned</Message></Error>');
      return;
    }
    seenSignatures.push(`${req.method} ${[...q.keys()].filter((k) => !k.startsWith('X-Amz')).join(',')}`);
    const uploadId = q.get('uploadId');
    if (req.method === 'POST' && q.has('uploads')) {
      const id = `up-${uploads.size + 1}`;
      uploads.set(id, { key, parts: new Map() });
      res.writeHead(200).end(`<InitiateMultipartUploadResult><Bucket>sgeul-media</Bucket><Key>${key}</Key><UploadId>${id}</UploadId></InitiateMultipartUploadResult>`);
    } else if (req.method === 'PUT' && uploadId && q.get('partNumber')) {
      const u = uploads.get(uploadId);
      if (!u) return void res.writeHead(404).end('<Error><Code>NoSuchUpload</Code></Error>');
      u.parts.set(Number(q.get('partNumber')), body);
      res.writeHead(200, { etag: `"etag-${q.get('partNumber')}-${body.length}"` }).end();
    } else if (req.method === 'GET' && uploadId) {
      const u = uploads.get(uploadId);
      if (!u) return void res.writeHead(404).end('<Error><Code>NoSuchUpload</Code></Error>');
      const xml = [...u.parts.entries()].map(([n, b]) => `<Part><PartNumber>${n}</PartNumber><ETag>&quot;etag-${n}-${b.length}&quot;</ETag></Part>`).join('');
      res.writeHead(200).end(`<ListPartsResult><IsTruncated>false</IsTruncated>${xml}</ListPartsResult>`);
    } else if (req.method === 'POST' && uploadId) {
      const u = uploads.get(uploadId);
      if (!u) return void res.writeHead(404).end('<Error><Code>NoSuchUpload</Code></Error>');
      const nums = [...body.toString().matchAll(/<PartNumber>(\d+)<\/PartNumber>/g)].map((m) => Number(m[1]));
      objects.set(u.key, Buffer.concat(nums.map((n) => u.parts.get(n)!)));
      uploads.delete(uploadId);
      res.writeHead(200).end(`<CompleteMultipartUploadResult><Key>${u.key}</Key></CompleteMultipartUploadResult>`);
    } else if (req.method === 'DELETE' && uploadId) {
      if (!uploads.delete(uploadId)) return void res.writeHead(404).end('<Error><Code>NoSuchUpload</Code></Error>');
      res.writeHead(204).end();
    } else if (req.method === 'HEAD') {
      const o = objects.get(key);
      if (!o) return void res.writeHead(404).end();
      res.writeHead(200, { 'content-length': String(o.length), 'content-type': 'video/mp4' }).end();
    } else {
      res.writeHead(400).end('<Error><Code>Unsupported</Code></Error>');
    }
  });
  return new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv)));
}

/* ---- app under test ---------------------------------------------------------------------- */

let s3: Server;
let s3Base: string;
let app: App;
let server: Server;
let base: string;
let dir: string;

const json = async (path: string, init: RequestInit = {}) => {
  const res = await fetch(`${base}${path}`, { ...init, headers: { 'content-type': 'application/json', ...(init.headers ?? {}) } });
  const text = await res.text();
  return { status: res.status, body: text ? (JSON.parse(text) as any) : undefined };
};

before(async () => {
  s3 = await startFakeS3();
  s3Base = `http://127.0.0.1:${(s3.address() as AddressInfo).port}`;
  dir = await mkdtemp(join(tmpdir(), 'twelve-uploads-'));
  const config = loadConfig({
    ...process.env,
    TWELVELABS_API_KEY: '',
    STORE_PATH: join(dir, 'store.json'),
    MOCK_LATENCY_MS: '0',
    PORT: '0',
    S3_ENDPOINT: s3Base,
    S3_REGION: 'nyc3',
    S3_BUCKET: 'sgeul-media',
    S3_ACCESS_KEY_ID: 'AKIDTEST',
    S3_SECRET_ACCESS_KEY: 'secret',
  });
  app = await createApp(config);
  server = app.app.listen(0);
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
  await app.runner.idle();
});

after(async () => {
  server.close();
  s3.close();
  await app.close();
  await rm(dir, { recursive: true, force: true });
});

/* ---- signing ----------------------------------------------------------------------------- */

test('SigV4 presign matches the AWS documentation test vector', () => {
  // https://docs.aws.amazon.com/AmazonS3/latest/API/sigv4-query-string-auth.html
  const url = presignUrl(
    { endpoint: 'https://s3.amazonaws.com', region: 'us-east-1', bucket: 'examplebucket', accessKeyId: 'AKIAIOSFODNN7EXAMPLE', secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY', addressing: 'virtual' },
    { method: 'GET', key: 'test.txt', expiresSec: 86400, now: new Date('2013-05-24T00:00:00Z') },
  );
  assert.ok(url.startsWith('https://examplebucket.s3.amazonaws.com/test.txt?'));
  assert.ok(url.endsWith('X-Amz-Signature=aeeed9bbccd4d02ee5c0109b86d86835f995330da4c265957d157751f604d404'));
});

test('env config: disabled without credentials, sane defaults with them', () => {
  assert.equal(objectStoreConfigFromEnv({}), undefined);
  const cfg = objectStoreConfigFromEnv({ S3_ENDPOINT: 'https://nyc3.digitaloceanspaces.com/', S3_BUCKET: 'b', S3_ACCESS_KEY_ID: 'k', S3_SECRET_ACCESS_KEY: 's', S3_PREFIX: '/incoming' })!;
  assert.equal(cfg.endpoint, 'https://nyc3.digitaloceanspaces.com');
  assert.equal(cfg.prefix, 'incoming/');
  assert.equal(cfg.addressing, 'path');
  assert.equal(cfg.maxBytes, 4 * 1024 ** 3);
  assert.equal(cfg.sourceUrlTtlSec, 86_400);
});

test('part size: 64 MiB default, grows to stay under 10,000 parts', () => {
  assert.equal(partSizeFor(1.4e9), 64 * 1024 * 1024);
  const huge = 5 * 1024 ** 4;
  assert.ok(Math.ceil(huge / partSizeFor(huge)) <= 10_000);
});

test('keys: only issued keys under the prefix are accepted', () => {
  const os = app.objectStore!;
  const key = os.newKey('Trainspotting (1996) 1080p.mp4', new Date('2026-09-16T00:00:00Z'));
  assert.match(key, /^uploads\/2026\/09\/[0-9a-f-]{36}\/Trainspotting_1996_1080p\.mp4$/);
  assert.equal(os.isUploadKey(key), true);
  assert.equal(os.isUploadKey('uploads/../secrets.env'), false);
  assert.equal(os.isUploadKey('other/x.mp4'), false);
  assert.equal(os.keyFromSourceUrl(`s3://sgeul-media/${key}`), key);
  assert.equal(os.keyFromSourceUrl(`s3://someone-else/${key}`), undefined);
});

/* ---- routes ------------------------------------------------------------------------------ */

test('GET /uploads/config reports enabled', async () => {
  const { status, body } = await json('/uploads/config');
  assert.equal(status, 200);
  assert.equal(body.enabled, true);
  assert.equal(body.maxBytes, 4 * 1024 ** 3);
});

test('POST /uploads validates filename and size', async () => {
  assert.equal((await json('/uploads', { method: 'POST', body: JSON.stringify({ filename: 'notes.txt', sizeBytes: 10 }) })).status, 400);
  assert.equal((await json('/uploads', { method: 'POST', body: JSON.stringify({ filename: 'a.mp4', sizeBytes: 0 }) })).status, 400);
  const big = await json('/uploads', { method: 'POST', body: JSON.stringify({ filename: 'a.mp4', sizeBytes: 5 * 1024 ** 3 }) });
  assert.equal(big.status, 413);
  assert.equal(big.body.error.code, 'file_too_large');
});

test('parts signing rejects keys the API did not issue', async () => {
  const r = await json('/uploads/parts', { method: 'POST', body: JSON.stringify({ key: 'elsewhere/x.mp4', uploadId: 'u', partNumbers: [1] }) });
  assert.equal(r.status, 400);
});

test('full browser flow: create → PUT parts direct to bucket → resume listing → complete → catalog title → ingest via signed URL', async () => {
  // Spy on what the pipeline hands TwelveLabs.
  const submittedUrls: string[] = [];
  const client = app.client as any;
  const realCreate = client.createAsset.bind(client);
  client.createAsset = async (p: { url: string }) => {
    submittedUrls.push(p.url);
    return realCreate(p);
  };
  // First asset "fails" upstream, so ingest must resubmit from storage with a fresh signed URL.
  const realGet = client.getAsset.bind(client);
  const failedOnce = new Set<string>();
  client.getAsset = async (id: string) => {
    const a = await realGet(id);
    if (submittedUrls.length === 1 && !failedOnce.has(id)) {
      failedOnce.add(id);
      return { ...a, status: 'failed' };
    }
    return a;
  };

  // Pretend part size is tiny by uploading 3 small parts (S3 min-size rules are not enforced by the fake).
  const bytes = [Buffer.alloc(1000, 1), Buffer.alloc(1000, 2), Buffer.alloc(500, 3)];
  const total = bytes.reduce((a, b) => a + b.length, 0);
  const created = await json('/uploads', { method: 'POST', body: JSON.stringify({ filename: 'Trainspotting_1996_1080p.mp4', sizeBytes: total, contentType: 'video/mp4' }) });
  assert.equal(created.status, 201);
  const { key, uploadId } = created.body;
  assert.match(key, /^uploads\/\d{4}\/\d{2}\/.+\/Trainspotting_1996_1080p\.mp4$/);

  const signed = await json('/uploads/parts', { method: 'POST', body: JSON.stringify({ key, uploadId, partNumbers: [1, 2, 3] }) });
  assert.equal(signed.status, 200);
  const etags: Array<{ partNumber: number; etag: string }> = [];
  // Upload parts 1 and 2, "lose the connection", then resume.
  for (const { partNumber, url } of signed.body.urls.slice(0, 2)) {
    assert.ok(url.startsWith(s3Base), 'part URL points at the bucket, not the API');
    const put = await fetch(url, { method: 'PUT', body: bytes[partNumber - 1] });
    assert.equal(put.status, 200);
    etags.push({ partNumber, etag: put.headers.get('etag')! });
  }
  const listed = await json(`/uploads/parts?key=${encodeURIComponent(key)}&uploadId=${uploadId}`);
  assert.deepEqual(listed.body.parts.map((p: any) => p.partNumber), [1, 2]);
  assert.equal(listed.body.parts[0].etag, etags[0]!.etag);
  const put3 = await fetch(signed.body.urls[2].url, { method: 'PUT', body: bytes[2] });
  etags.push({ partNumber: 3, etag: put3.headers.get('etag')! });

  // Missing part → 400 before touching storage.
  const incomplete = await json('/uploads/complete', { method: 'POST', body: JSON.stringify({ key, uploadId, parts: etags.slice(1), sizeBytes: total }) });
  assert.equal(incomplete.status, 400);

  const done = await json('/uploads/complete', { method: 'POST', body: JSON.stringify({ key, uploadId, parts: etags, sizeBytes: total, type: 'movie' }) });
  assert.equal(done.status, 201, JSON.stringify(done.body));
  assert.equal(done.body.sourceUrl, `s3://sgeul-media/${key}`);
  assert.equal(done.body.title, 'Trainspotting 1996 1080p');
  assert.equal(done.body.type, 'movie');
  assert.equal(done.body.metadata.sizeBytes, total);
  assert.equal(objects.get(key)!.length, total);

  // Ingest resolves s3:// to a signed GET URL on the bucket and hands that to TwelveLabs.
  await app.runner.idle();
  const bundle = await json(`/catalog/${done.body.id}`);
  const assetId = bundle.body.item.upstream?.assetId;
  assert.ok(assetId, `ingest created an asset: ${JSON.stringify(bundle.body.item.jobs)}`);
  client.createAsset = realCreate;
  client.getAsset = realGet;
  const objectPath = `${s3Base}/sgeul-media/${key.split('/').map(encodeURIComponent).join('/')}?`;
  assert.equal(submittedUrls.length, 2, `one submission plus one resubmission: ${submittedUrls.join(' | ')}`);
  for (const u of submittedUrls) {
    assert.ok(u.startsWith(objectPath), u);
    assert.match(u, /X-Amz-Expires=86400/);
    assert.match(u, /X-Amz-Signature=[0-9a-f]{64}$/);
  }
  assert.equal(bundle.body.item.jobs.ingest, 'ready');

  // Playback before TwelveLabs HLS exists: /media redirects to a short-lived signed GET on the bucket.
  assert.equal(bundle.body.item.playback.fileUrl, `/api/catalog/${done.body.id}/media`);
  const media = await fetch(`${base}/catalog/${done.body.id}/media`, { redirect: 'manual' });
  assert.equal(media.status, 302);
  assert.ok(media.headers.get('location')!.startsWith(objectPath));
  assert.match(media.headers.get('location')!, /X-Amz-Expires=3600/);

  // Re-posting the same s3:// source is idempotent.
  const again = await json('/catalog', { method: 'POST', body: JSON.stringify({ sourceUrl: `s3://sgeul-media/${key}` }) });
  assert.equal(again.body[0].id, done.body.id);
});

test('POST /catalog rejects s3:// URLs outside the configured bucket or prefix', async () => {
  const r1 = await json('/catalog', { method: 'POST', body: JSON.stringify({ sourceUrl: 's3://other-bucket/uploads/2026/09/x/a.mp4' }) });
  assert.equal(r1.status, 400);
  const r2 = await json('/catalog', { method: 'POST', body: JSON.stringify({ sourceUrl: 's3://sgeul-media/private/a.mp4' }) });
  assert.equal(r2.status, 400);
});

test('abort is idempotent', async () => {
  const created = await json('/uploads', { method: 'POST', body: JSON.stringify({ filename: 'x.mov', sizeBytes: 100 }) });
  const { key, uploadId } = created.body;
  assert.equal((await json('/uploads/abort', { method: 'POST', body: JSON.stringify({ key, uploadId }) })).status, 204);
  assert.equal((await json('/uploads/abort', { method: 'POST', body: JSON.stringify({ key, uploadId }) })).status, 204);
});

test('ObjectStore surfaces S3 XML errors with codes', async () => {
  const os = new ObjectStore({ ...app.objectStore!.config, bucket: 'wrong-bucket' });
  await assert.rejects(() => os.createMultipart('uploads/x/a.mp4'), (e: any) => e.code === 'storage_error' && /AccessDenied/.test(e.message));
});
