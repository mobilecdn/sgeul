import { useState } from 'react';
import { Button, Card } from '../components/ui';
import { Icon } from '../components/Icon';
import { useToast } from '../lib/hooks';
import { useTopbar } from '../App';

type Method = 'GET' | 'POST' | 'PATCH' | 'DELETE';
interface Endpoint {
  method: Method;
  path: string;
  desc: string;
  body?: string;
  sample: string;
  behind: string;
}
interface Group {
  id: string;
  name: string;
  blurb: string;
  endpoints: Endpoint[];
}

const BASE = 'http://localhost:8787';

const SPEC: Group[] = [
  {
    id: 'system',
    name: 'System',
    blurb: 'Health, stats and the live job stream.',
    endpoints: [
      { method: 'GET', path: '/api/health', desc: 'Mode, index and model versions', sample: `{ "ok": true, "mode": "live", "index": "idx_…", "models": { "index": "marengo3.0", "embed": "marengo3.5", "analyze": "pegasus1.5" } }`, behind: 'GET /indexes/:id (verifies the index exists in live mode)' },
      { method: 'GET', path: '/api/stats', desc: 'Catalog roll-up', sample: `{ "items": 24, "ready": 22, "totalDurationSec": 71820, "lists": 6, "coverage": 0.93, "pendingReviews": 41 }`, behind: 'none — computed from the store' },
      { method: 'GET', path: '/api/jobs?status=running', desc: 'Pipeline jobs', sample: `[{ "id": "job_…", "itemId": "item_…", "kind": "emotions", "status": "running", "upstream": { "model": "pegasus1.5" } }]`, behind: 'none' },
      { method: 'GET', path: '/api/events', desc: 'Server-Sent Events', sample: `event: job\ndata: {"type":"job","job":{…}}\n\nevent: item\ndata: {"type":"item","item":{…}}`, behind: 'none' },
    ],
  },
  {
    id: 'catalog',
    name: 'Catalog',
    blurb: 'Ingest assets and read every enrichment product.',
    endpoints: [
      { method: 'GET', path: '/api/catalog', desc: 'All items (embeddings omitted)', sample: `[{ "id": "item_…", "title": "…", "status": "ready", "durationSec": 2760, "fps": 24, "jobs": { "fingerprint": "ready", … }, "fingerprint": { … } }]`, behind: 'none' },
      { method: 'POST', path: '/api/catalog', desc: 'Add one or many items; starts the pipeline', body: `{ "title": "Pilot", "type": "episode", "sourceUrl": "https://cdn.example.com/pilot.mp4" }`, sample: `[{ "id": "item_…", "status": "ingesting", "jobs": { "ingest": "queued" } }]`, behind: 'POST /assets (url) → GET /assets/:id until ready → POST /indexes/:id/indexed-assets → poll' },
      { method: 'GET', path: '/api/twelvelabs/assets?page=1&pageLimit=50', desc: 'Assets already in the TwelveLabs account, with what each is linked to here', sample: `{ "assets": [{ "_id": "6aa5…", "filename": "grok4.mp4", "status": "ready", "duration": 65.8, "width": 1280, "height": 720, "size": 12623666, "hls": { "manifest_url": "…/playlist.m3u8" }, "thumbnail": { "representative_url": "…/5.jpeg" }, "linked": { "kind": "title", "id": "grok4-…", "title": "grok4" } }], "pageInfo": { "page": 1, "totalPage": 1, "totalResults": 8 } }`, behind: 'GET /assets?page=&page_limit=' },
      { method: 'POST', path: '/api/catalog/import', desc: 'Link account assets as titles (enrich without re-uploading) or ad creatives', body: `{ "items": [{ "assetId": "6aa5…", "as": "title", "type": "promo" }, { "assetId": "6aa5…", "as": "ad", "advertiser": "Ferrero" }] }`, sample: `{ "items": [{ "id": "grok4-…", "status": "ingesting", "playback": { "hlsUrl": "…" }, "upstream": { "assetId": "6aa5…" } }], "ads": [...], "skipped": [{ "assetId": "…", "linked": {…} }], "errors": [{ "assetId": "…", "error": { "code": "asset_not_ready", "message": "…" } }] }`, behind: 'GET /assets (all pages) → POST /indexes/:id/indexed-assets {asset_id} → poll (no POST /assets)' },
      { method: 'POST', path: '/api/uploads', desc: 'Start a browser upload to object storage (S3 multipart)', body: `{ "filename": "pilot.mp4", "sizeBytes": 1398520522, "contentType": "video/mp4" }`, sample: `{ "key": "uploads/2026/09/…/pilot.mp4", "uploadId": "…", "partSizeBytes": 67108864, "partCount": 21 }`, behind: 'S3 CreateMultipartUpload (no TwelveLabs call)' },
      { method: 'POST', path: '/api/uploads/parts', desc: 'Presigned PUT URLs for parts; the browser uploads straight to the bucket', body: `{ "key": "uploads/…/pilot.mp4", "uploadId": "…", "partNumbers": [1, 2, 3, 4] }`, sample: `{ "urls": [{ "partNumber": 1, "url": "https://sgeul-media.nyc3.digitaloceanspaces.com/…?X-Amz-Signature=…" }] }`, behind: 'SigV4 presign, 1h (no TwelveLabs call)' },
      { method: 'POST', path: '/api/uploads/complete', desc: 'Finish the upload and create the title; ingest hands TwelveLabs a signed URL', body: `{ "key": "uploads/…/pilot.mp4", "uploadId": "…", "parts": [{ "partNumber": 1, "etag": "\\"…\\"" }], "sizeBytes": 1398520522, "type": "episode" }`, sample: `{ "id": "pilot-…", "sourceUrl": "s3://sgeul-media/uploads/…/pilot.mp4", "status": "ingesting" }`, behind: 'S3 CompleteMultipartUpload → POST /assets (method=url, signed GET) → poll → POST /indexes/:id/indexed-assets' },
      { method: 'GET', path: '/api/catalog/:id', desc: 'Full ItemBundle', sample: `{ "item": {…}, "fingerprint": {…}, "emotions": {…}, "markers": {…}, "adBreaks": {…}, "safety": {…}, "thumbnails": [...], "clips": [...], "jobs": [...] }`, behind: 'none' },
      { method: 'DELETE', path: '/api/catalog/:id', desc: 'Remove an item', sample: `204 No Content`, behind: 'none (upstream asset retained)' },
      { method: 'POST', path: '/api/catalog/:id/jobs/:kind', desc: 'Re-run one job', sample: `{ "id": "job_…", "kind": "markers", "status": "queued" }`, behind: 'POST /analyze with the job’s JSON schema (or embed-v2 / indexed-assets for embedding/ingest)' },
      { method: 'GET', path: '/api/catalog/:id/fingerprint', desc: 'Fingerprint+', sample: `{ "genres": { "thriller": 0.93 }, "moods": { "tense": 0.88 }, "characters": [...], "pacing": { "score": 0.71 }, "synopsis": { "short": "…", "translations": { "es": {…} } } }`, behind: 'POST /analyze · pegasus1.5 · response_format json_schema' },
      { method: 'GET', path: '/api/catalog/:id/emotions', desc: 'Continuous emotion arc', sample: `{ "samples": [{ "start": 0, "end": 24, "valence": -0.2, "arousal": 0.4, "beat": "…" }], "acts": [...], "climax": { "at": 2210 } }`, behind: 'POST /analyze (time_based_metadata style prompt)' },
      { method: 'GET', path: '/api/catalog/:id/markers', desc: 'Intro / recap / credits / chapters', sample: `{ "fps": 24, "markers": [{ "kind": "intro", "start": 61.2, "end": 118.9, "startFrame": 1469, "confidence": 0.95 }] }`, behind: 'POST /analyze' },
      { method: 'GET', path: '/api/catalog/:id/adbreaks', desc: 'Ranked ad-break plan', sample: `{ "breaks": [{ "at": 612.5, "window": { "start": 604, "end": 618 }, "rank": 1, "confidence": 0.91, "iab": [...], "brandSafety": { "suitable": true } }], "policy": {…} }`, behind: 'POST /analyze (candidates) → deterministic pod planner' },
      { method: 'GET', path: '/api/catalog/:id/safety', desc: 'Safety segments + rollup', sample: `{ "segments": [{ "category": "violence", "severity": "medium", "start": 1330, "end": 1362 }], "summary": { "violence": { "maxSeverity": "medium", "totalSec": 32 } } }`, behind: 'POST /analyze' },
      { method: 'GET', path: '/api/catalog/:id/thumbnails', desc: '12 scored thumbnail candidates', sample: `[{ "at": 843.1, "score": 0.88, "factors": {…}, "crops": { "2:3": {…} }, "logoSafeZone": "top-left", "safe": true }]`, behind: 'POST /analyze' },
      { method: 'GET', path: '/api/catalog/:id/clips', desc: '6 preview clips with reframe path', sample: `[{ "start": 1201, "end": 1224, "clipType": "hook", "relevance": 0.86, "reframe916": [{ "at": 1201, "cx": 0.5 }] }]`, behind: 'POST /analyze' },
      { method: 'GET', path: '/api/catalog/:id/similar?limit=8', desc: 'Nearest titles', sample: `[{ "itemId": "item_…", "title": "…", "score": 0.81, "because": ["thriller", "betrayal"] }]`, behind: 'none — cosine over stored marengo3.5 embeddings' },
    ],
  },
  {
    id: 'review',
    name: 'Review & export',
    blurb: 'Human-in-the-loop state and broadcast deliverables.',
    endpoints: [
      { method: 'PATCH', path: '/api/catalog/:id/markers/:mid', desc: 'Review a marker', body: `{ "status": "approved", "rating": 4 }`, sample: `{ "id": "mk_…", "kind": "intro", "review": { "status": "approved", "rating": 4, "comments": [] } }`, behind: 'none' },
      { method: 'PATCH', path: '/api/catalog/:id/adbreaks/:bid', desc: 'Review an ad break', body: `{ "status": "declined", "comments": [{ "author": "qc", "text": "mid-line" }] }`, sample: `{ "id": "br_…", "rank": 2, "review": { "status": "declined", … } }`, behind: 'none' },
      { method: 'POST', path: '/api/catalog/:id/adbreaks/plan', desc: 'Re-plan pods deterministically', body: `{ "targetBreaks": 4, "minSpacingSec": 480 }`, sample: `{ "breaks": [...], "policy": { "targetBreaks": 4, "minSpacingSec": 480, "avoidFirstSec": 120, "avoidLastSec": 180 } }`, behind: 'none — planner over stored candidates' },
      { method: 'POST', path: '/api/ads/:id/fingerprint', desc: 'Creative intelligence for an ad spot', sample: `{ "id": "ad_…", "name": "Kinder Bueno 30s", "fingerprint": { "brand": "Ferrero", "product": "Kinder Bueno", "mood": { "playful": 0.95, "humorous": 0.95 }, "keywords": { "space": 0.95, "chocolate": 0.95 }, "tone": { "humorous": 0.95, "family": 0.75 }, "iab": [{ "id": "IAB8-5", "name": "Food & Drink" }], "sensitivities": [], "familySafe": 0.9, "moments": [{ "at": 4, "label": "product reveal" }] } }`, behind: 'POST /assets (only if the creative is not an asset yet) → POST /analyze (pegasus1.5, json_schema: adFingerprint)' },
      { method: 'GET', path: '/api/catalog/:id/adbreaks/fit', desc: 'Creative-to-break fit for every planned break', sample: `{ "breaks": [{ "breakId": "brk_…", "at": 1130, "fits": [{ "creativeId": "ad_…", "score": 0.30, "mood": 0.44, "keywords": 0, "iab": 0, "safety": 1, "because": ["mood \"tender\" ~ \"lighthearted\""] }] }] }`, behind: 'none — 0.35·mood + 0.30·keywords + 0.20·IAB + 0.15·safety over stored labels' },
      { method: 'POST', path: '/api/catalog/:id/adbreaks/autoassign', desc: 'Assign the best-fitting creative per break', body: `{ "minScore": 0.25 }`, sample: `{ "plan": { "breaks": [...] }, "assignments": [{ "breakId": "brk_…", "creativeId": "ad_…", "fit": { "score": 0.32, "because": [...] } }] }`, behind: 'none' },
      { method: 'GET', path: '/api/catalog/:id/export/vmap', desc: 'VMAP 1.0 of approved breaks', sample: `<vmap:VMAP version="1.0">\n  <vmap:AdBreak timeOffset="00:10:12.500" breakType="linear" breakId="br_…">…</vmap:AdBreak>\n</vmap:VMAP>`, behind: 'none' },
      { method: 'GET', path: '/api/catalog/:id/export/scte35', desc: 'Splice points', sample: `{ "splicePoints": [{ "id": 1, "pts": 55125000, "duration": 2700000, "spliceEventId": 1000 }] }`, behind: 'none' },
      { method: 'GET', path: '/api/catalog/:id/export/markers', desc: 'Player-ready markers', sample: `{ "skipIntro": { "start": 61.2, "end": 118.9 }, "skipRecap": null, "creditsStart": 2690.0, "nextEpisodeAt": 2695.5 }`, behind: 'none' },
    ],
  },
  {
    id: 'discovery',
    name: 'Search & lists',
    blurb: 'Any-to-video search, smart lists and AI curation.',
    endpoints: [
      { method: 'POST', path: '/api/search', desc: 'Moments across the catalog', body: `{ "query": "a tense standoff at night", "modalities": ["visual","audio"], "limit": 12 }`, sample: `{ "hits": [{ "itemId": "item_…", "start": 1330.5, "end": 1347.2, "rank": 1, "thumbnailUrl": "…", "transcript": "…" }], "nextPageToken": "…", "pool": { "items": 24, "totalDurationSec": 71820 } }`, behind: 'POST /search (multipart: index_id, query_text, search_options[], group_by=clip) · GET /search/:page_token' },
      { method: 'GET', path: '/api/lists', desc: 'Smart lists', sample: `[{ "id": "list_…", "name": "Dark thrillers", "source": "rules", "itemIds": [...], "coverage": 0.25 }]`, behind: 'none' },
      { method: 'POST', path: '/api/lists', desc: 'Create rules or NL list', body: `{ "name": "Late-night", "source": "query", "query": "slow-burn dramas about grief" }`, sample: `{ "id": "list_…", "source": "query", "itemIds": ["item_…"], "coverage": 0.17 }`, behind: 'rules: none · query: POST /embed-v2 (text, marengo3.5) → cosine vs item embeddings' },
      { method: 'POST', path: '/api/lists/curate', desc: 'AI curation over the catalog', sample: `[{ "id": "list_…", "name": "Tense · betrayal & heist", "source": "ai", "itemIds": [...], "coverage": 0.29 }]`, behind: 'none — k-means over stored embeddings (k = clamp(items/6, 3, 12))' },
      { method: 'DELETE', path: '/api/lists/:id', desc: 'Delete a list', sample: `204 No Content`, behind: 'none' },
    ],
  },
  {
    id: 'reco',
    name: 'Recommendations',
    blurb: 'Watch events in, ranked titles and rows out. A viewer who watches romantic horror gets romantic horror first, then horror and romance, at the weights the app sets.',
    endpoints: [
      { method: 'POST', path: '/api/reco/events?profileId=viewer-1', desc: 'Record a play, like, dislike or skip', body: `{ "itemId": "item_\u2026", "action": "watch", "completion": 0.92 }`, sample: `[{ "id": "wev_\u2026", "profileId": "viewer-1", "itemId": "item_\u2026", "action": "watch", "completion": 0.92, "at": "2026-09-15T09:12:03.221Z" }]`, behind: 'none \u2014 the only input the engine needs' },
      { method: 'GET', path: '/api/reco/profile/viewer-1', desc: 'The taste profile derived from those events', sample: `{ "events": 7, "facets": { "genres": { "horror": 1, "romance": 0.89 } }, "combos": { "horror + romance": 1 }, "top": [{ "label": "horror", "facet": "genres", "weight": 1 }], "topCombos": [{ "label": "horror + romance", "weight": 1 }], "pacing": 0.54, "rating": 0.71 }`, behind: 'none \u2014 recency-decayed, completion-weighted label affinities over the stored fingerprints' },
      { method: 'GET', path: '/api/catalog/:id/recommendations?profileId=viewer-1&limit=12', desc: 'What to play after this title', sample: `{ "seedId": "item_\u2026", "items": [{ "itemId": "item_\u2026", "title": "\u2026", "score": 0.78, "because": ["horror + romance", "doomed love", "close to Crimson Vow"], "parts": { "combo": 0.91, "genres": 0.86, "embedding": 0.62, "seed": 0.71, "penalty": 0 } }] }`, behind: 'none \u2014 cosine over marengo3.5 embeddings plus facet and combination affinities' },
      { method: 'GET', path: '/api/reco/home?profileId=viewer-1&seedId=item_\u2026', desc: 'The rows a player would render, each with its reason', sample: `{ "rails": [{ "id": "rail_continue", "title": "Continue watching", "kind": "continue", "items": [\u2026] }, { "title": "More Horror + Romance", "kind": "combo", "labels": ["horror","romance"], "reason": "This viewer watches horror and romance together\u2026" }, { "title": "More Horror", "kind": "facet" }] }`, behind: 'none' },
      { method: 'GET', path: '/api/reco/weights', desc: 'The weighting in force, next to the engine defaults', sample: `{ "custom": true, "weights": { "facets": { "genres": 1, "moodTags": 0.8, "moods": 0.6, "themes": 0.6, "keywords": 0.4 }, "combo": 1.2, "embedding": 0.9, "seed": 1, "diversity": 0.25, "recencyHalfLifeDays": 30 } }`, behind: 'none' },
      { method: 'POST', path: '/api/reco/weights', desc: 'Change the weighting (PUT; partial and clamped)', body: `{ "combo": 2.2, "facets": { "genres": 1.4 }, "diversity": 0.4 }`, sample: `{ "custom": true, "weights": { \u2026 } }`, behind: 'none' },
      { method: 'POST', path: '/api/reco/simulate', desc: 'Score a hypothetical viewer and hypothetical weights, storing nothing', body: `{ "events": [{ "itemId": "item_\u2026", "action": "watch", "completion": 1 }], "weights": { "combo": 3 }, "seedId": "item_\u2026" }`, sample: `{ "profile": { \u2026 }, "rails": [\u2026], "next": [\u2026] }`, behind: 'none \u2014 what the Recommendations lab calls on every dial change' },
      { method: 'DELETE', path: '/api/reco/events?profileId=viewer-1', desc: 'Forget a viewer', sample: `{ "deleted": 7 }`, behind: 'none' },
    ],
  },
  {
    id: 'creative',
    name: 'Creative recipes',
    blurb: 'Brief-driven thumbnails and clips.',
    endpoints: [
      { method: 'GET', path: '/api/recipes', desc: 'List recipes', sample: `[{ "id": "recipe_…", "name": "Key art — action", "target": "thumbnails", "brief": "epic battle scenes", "count": 6, "formats": ["16:9","2:3"] }]`, behind: 'none' },
      { method: 'POST', path: '/api/recipes', desc: 'Create a recipe', body: `{ "name": "Social hooks", "target": "clips", "brief": "quiet emotional beats", "count": 4, "clipLengthSec": [8, 20], "formats": ["9:16"], "excludeSafetyCategories": ["gore"] }`, sample: `{ "id": "recipe_…", "createdAt": "…" }`, behind: 'none' },
      { method: 'POST', path: '/api/recipes/:id/run', desc: 'Run against items', body: `{ "itemIds": ["item_…"] }`, sample: `[{ "id": "run_…", "recipeId": "recipe_…", "itemId": "item_…", "status": "running" }]`, behind: 'POST /analyze with the brief injected into the thumbnails/clips prompt' },
      { method: 'GET', path: '/api/runs/:id', desc: 'Poll a run', sample: `{ "id": "run_…", "status": "ready", "clips": [{ "start": 1201, "end": 1216, "queryRelevance": 0.9, "query": "quiet emotional beats" }] }`, behind: 'none' },
      { method: 'DELETE', path: '/api/recipes/:id', desc: 'Delete a recipe', sample: `204 No Content`, behind: 'none' },
    ],
  },
];

const MCP_TOOLS: Array<[string, string]> = [
  ['catalog_list', 'List titles with status and duration'],
  ['catalog_ingest', 'Add a video URL and start the pipeline'],
  ['catalog_get', 'Full bundle for one title'],
  ['search_moments', 'Marengo search across the catalog'],
  ['similar_titles', 'Embedding neighbours with reasons'],
  ['fingerprint_get', 'Genres, moods, keywords, synopsis'],
  ['emotion_arc_get', 'Valence/arousal samples, acts, climax'],
  ['markers_get', 'Intro/recap/credits/chapters'],
  ['adbreaks_plan', 'Re-plan pods with a policy'],
  ['safety_report', 'Safety segments and rollup'],
  ['thumbnails_generate', 'Brief-driven thumbnail candidates'],
  ['clips_generate', 'Brief-driven preview clips'],
  ['smartlist_create', 'Rules or NL smart list'],
  ['curate_catalog', 'AI-curated lists'],
  ['ads_fingerprint', 'Creative intelligence for one ad spot'],
  ['adbreaks_fit', 'Rank creatives per break with reasons'],
  ['adbreaks_autoassign', 'Best-fit creative on every break'],
  ['export_vmap', 'VMAP for approved breaks'],
  ['export_markers', 'Player-ready markers JSON'],
];

const CLAUDE_CONFIG = `{
  "mcpServers": {
    "twelve-studio": {
      "command": "npm",
      "args": ["run", "mcp", "--prefix", "/path/to/twelve-studio"],
      "env": { "TWELVE_API_URL": "http://localhost:8787" }
    }
  }
}`;

function curlFor(e: Endpoint): string {
  const lines = [`curl -s ${e.method !== 'GET' ? `-X ${e.method} ` : ''}${BASE}${e.path.replace(':id', 'item_123').replace(':mid', 'mk_1').replace(':bid', 'br_1').replace(':kind', 'markers')}`];
  if (e.body) lines.push(`  -H 'content-type: application/json' \\\n  -d '${e.body.replace(/\n\s*/g, ' ')}'`);
  return lines.join(' \\\n');
}

export function ApiDocs() {
  const toast = useToast();
  const [open, setOpen] = useState<string | null>('GET /api/health');
  useTopbar(
    <a href={`${BASE}/api/health`} target="_blank" rel="noreferrer">
      <Button variant="ghost" size="sm" icon="external">
        {BASE}
      </Button>
    </a>,
    [],
  );
  const copy = (text: string) => {
    void navigator.clipboard?.writeText(text).then(() => toast.push('Copied to clipboard', 'success'));
  };
  return (
    <div className="content">
      <div className="docs" style={{ maxWidth: 1400 }}>
        <nav className="docs__nav">
          <span className="eyebrow" style={{ padding: '6px 10px' }}>
            REST
          </span>
          {SPEC.map((g) => (
            <a key={g.id} href={`#${g.id}`}>
              {g.name} <span className="muted small">· {g.endpoints.length}</span>
            </a>
          ))}
          <span className="eyebrow" style={{ padding: '14px 10px 6px' }}>
            Reference
          </span>
          <a href="#behind">TwelveLabs calls</a>
          <a href="#mcp">MCP server</a>
          <a href="#claude">Claude Desktop</a>
        </nav>

        <div className="stack stack--lg" style={{ minWidth: 0 }}>
          <Card soft>
            <div className="row" style={{ gap: 16 }}>
              <div style={{ flex: 1 }}>
                <h2>One JSON API, three TwelveLabs primitives</h2>
                <p className="small muted" style={{ marginTop: 4 }}>
                  Every endpoint below is served by <code>@twelve-studio/api</code> on port 8787. Errors are <code>{'{ error: { code, message } }'}</code>. List responses never include embeddings. Set <code>TWELVELABS_API_KEY</code> for live mode; without it the API serves seeded data in mock mode.
                </p>
              </div>
              <div className="row">
                <span className="pill pill--green">GET</span>
                <span className="pill pill--blue">POST</span>
                <span className="pill pill--orange">PATCH</span>
                <span className="pill pill--red">DELETE</span>
              </div>
            </div>
          </Card>

          {SPEC.map((g) => (
            <section key={g.id} id={g.id} className="stack">
              <div>
                <h2>{g.name}</h2>
                <div className="small muted">{g.blurb}</div>
              </div>
              {g.endpoints.map((e) => {
                const key = `${e.method} ${e.path}`;
                const isOpen = open === e.path || open === key;
                return (
                  <div key={key} className="endpoint">
                    <div className="endpoint__head" onClick={() => setOpen(isOpen ? null : key)}>
                      <span className={`method method--${e.method.toLowerCase()}`}>{e.method}</span>
                      <span className="endpoint__path">{e.path}</span>
                      <span className="endpoint__desc">{e.desc}</span>
                      <Icon name="chevronDown" size={14} style={{ color: 'var(--muted)', transform: isOpen ? 'rotate(180deg)' : undefined, transition: 'transform .15s' }} />
                    </div>
                    {isOpen && (
                      <div className="endpoint__body">
                        <div className="stack" style={{ gap: 6 }}>
                          <div className="row row--between">
                            <span className="eyebrow">curl</span>
                            <Button size="sm" variant="ghost" icon="copy" onClick={() => copy(curlFor(e))}>
                              Copy
                            </Button>
                          </div>
                          <pre className="code">{curlFor(e)}</pre>
                          <div className="small muted" style={{ marginTop: 6 }}>
                            <b style={{ color: 'var(--heading)' }}>Behind it:</b> {e.behind}
                          </div>
                        </div>
                        <div className="stack" style={{ gap: 6 }}>
                          <span className="eyebrow">sample response (abbreviated)</span>
                          <pre className="code code--wrap">{e.sample}</pre>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </section>
          ))}

          <Card title="Endpoint → TwelveLabs calls behind it" icon="layers" sub="What is billed and where, per call">
            <div id="behind" />
            <div style={{ overflowX: 'auto' }}>
              <table className="table">
                <thead>
                  <tr>
                    <th>Endpoint</th>
                    <th>TwelveLabs</th>
                    <th>Model</th>
                    <th>Billing</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>POST /api/catalog</td>
                    <td>POST /assets → GET /assets/:id → POST /indexes/:id/indexed-assets → poll</td>
                    <td>marengo3.0</td>
                    <td>$2.50 / hour indexed</td>
                  </tr>
                  <tr>
                    <td>jobs: fingerprint, emotions, markers, safety, adbreaks, thumbnails, clips</td>
                    <td>POST /analyze with response_format json_schema, temperature 0.2 (async /analyze/tasks &gt; 1 h)</td>
                    <td>pegasus1.5</td>
                    <td>$1.75 / hour in + $7.50 / M tokens out</td>
                  </tr>
                  <tr>
                    <td>job: embedding</td>
                    <td>POST /embed-v2 (video, embedding_scope video) or /embed-v2/tasks</td>
                    <td>marengo3.5</td>
                    <td>$0.26 / M tokens</td>
                  </tr>
                  <tr>
                    <td>POST /api/search</td>
                    <td>POST /search (group_by clip) · GET /search/:page_token</td>
                    <td>marengo3.0</td>
                    <td>$4 / 1 000 queries</td>
                  </tr>
                  <tr>
                    <td>POST /api/lists (source query)</td>
                    <td>POST /embed-v2 (text) → local cosine</td>
                    <td>marengo3.5</td>
                    <td>negligible</td>
                  </tr>
                  <tr>
                    <td>POST /api/recipes/:id/run</td>
                    <td>POST /analyze with the brief injected</td>
                    <td>pegasus1.5</td>
                    <td>as analyze</td>
                  </tr>
                  <tr>
                    <td>similar, curate, plan, exports, review</td>
                    <td>none — computed from the store</td>
                    <td>—</td>
                    <td>free</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>

          <Card title="MCP server" icon="bolt" sub="@twelve-studio/mcp · stdio · the same primitives for agents">
            <div id="mcp" />
            <div className="grid" style={{ gridTemplateColumns: 'repeat(2, 1fr)', gap: 6 }}>
              {MCP_TOOLS.map(([name, d]) => (
                <div key={name} className="row" style={{ gap: 10, padding: '6px 10px', borderRadius: 8, background: 'var(--surface-2)' }}>
                  <code style={{ color: 'var(--heading)' }}>{name}</code>
                  <span className="small muted truncate">{d}</span>
                </div>
              ))}
            </div>
            <div className="row row--wrap small muted" style={{ marginTop: 12, gap: 14 }}>
              <span>
                Resources: <code>twelve://catalog</code> · <code>twelve://item/{'{id}'}</code>
              </span>
              <span>
                Prompts: <code>editorial_brief</code> · <code>ad_ops_review</code>
              </span>
            </div>
          </Card>

          <Card title="Claude Desktop config" icon="key" sub="~/Library/Application Support/Claude/claude_desktop_config.json" actions={<Button size="sm" variant="ghost" icon="copy" onClick={() => copy(CLAUDE_CONFIG)}>Copy</Button>}>
            <div id="claude" />
            <pre className="code">{CLAUDE_CONFIG}</pre>
            <p className="small muted" style={{ marginTop: 10 }}>
              The MCP server talks to the REST API, so one store serves the UI, the API and agents. Ask Claude: “Plan four ad breaks for the pilot, avoid the first two minutes, and export VMAP.”
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
