/**
 * "Upload a video" — a drop zone that streams a file from the user's computer to `POST /api/catalog/upload`,
 * then hands the new title to the nine-stage pipeline. Progress comes from XHR upload events; the static demo
 * (no server) explains that it cannot store files.
 */
import { useRef, useState, type DragEvent } from 'react';
import { Link } from 'react-router-dom';
import type { CatalogItem, ItemType } from '@twelve-studio/core';
import { Button, Card, Meter } from './ui';
import { Icon } from './Icon';
import { useApi, useToast } from '../lib/hooks';
import { ApiError } from '../lib/api';

const TYPES: ItemType[] = ['movie', 'episode', 'short', 'clip', 'promo', 'other'];
const ACCEPT = '.mp4,.mov,.m4v,.mkv,.webm,.mpg,.mpeg,.ts,.avi,video/*';

function titleFromFile(name: string): string {
  const base = name.replace(/\.[a-z0-9]{2,4}$/i, '').replace(/[-_.]+/g, ' ').trim();
  return base.replace(/\b\w/g, (c) => c.toUpperCase()) || 'Untitled';
}

function fmtBytes(n: number): string {
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)} GB`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)} MB`;
  return `${Math.round(n / 1e3)} KB`;
}

export function UploadCard({ onUploaded }: { onUploaded?: (item: CatalogItem) => void }) {
  const api = useApi();
  const toast = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [type, setType] = useState<ItemType>('movie');
  const [over, setOver] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<CatalogItem | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const pick = (f: File | null | undefined) => {
    if (!f) return;
    setFile(f);
    setTitle(titleFromFile(f.name));
    setDone(null);
    setErr(null);
    setProgress(null);
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setOver(false);
    const f = [...e.dataTransfer.files].find((x) => /^video\//.test(x.type) || /\.(mp4|mov|m4v|mkv|webm|mpg|mpeg|ts|avi)$/i.test(x.name));
    if (!f) {
      setErr('Drop a video file (mp4, mov, mkv, webm…)');
      return;
    }
    pick(f);
  };

  const start = async () => {
    if (!file || busy) return;
    setErr(null);
    setProgress(0);
    setBusy(true);
    try {
      const { item } = await api.uploadFile(file, { title: title.trim() || undefined, type }, (f) => setProgress(f));
      setProgress(1);
      setDone(item);
      onUploaded?.(item);
      toast.push(`${item.title} uploaded (${fmtBytes(file.size)}) — pipeline started`, 'success');
      setFile(null);
      if (inputRef.current) inputRef.current.value = '';
    } catch (e) {
      const msg = e instanceof ApiError && e.code === 'needs_api' ? e.message : `Upload failed: ${(e as Error).message}`;
      setErr(msg);
      setProgress(null);
      toast.push(msg, 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card title="Upload a video" icon="upload" sub="From your computer straight into the pipeline">
      <div
        className={`dropzone${over ? ' dropzone--over' : ''}${file ? ' dropzone--has' : ''}`}
        onDragOver={(e) => {
          e.preventDefault();
          if (!busy) setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={busy ? (e) => e.preventDefault() : onDrop}
        onClick={() => !busy && !file && inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if ((e.key === 'Enter' || e.key === ' ') && !busy && !file) inputRef.current?.click();
        }}
      >
        <input ref={inputRef} type="file" accept={ACCEPT} hidden onChange={(e) => pick(e.target.files?.[0])} />
        {!file ? (
          <div className="dropzone__empty">
            <Icon name="upload" size={22} />
            <div>
              <b style={{ color: 'var(--heading)' }}>Drop a video here</b> or click to choose one
            </div>
            <div className="muted small">mp4 · mov · mkv · webm · up to 4 GB · it never leaves your server except to TwelveLabs</div>
          </div>
        ) : (
          <div className="stack" style={{ gap: 12 }} onClick={(e) => e.stopPropagation()}>
            <div className="row" style={{ gap: 10 }}>
              <Icon name="film" size={16} style={{ color: '#8cbaff' }} />
              <span className="truncate" style={{ color: 'var(--heading)', fontWeight: 600, flex: 1 }} title={file.name}>
                {file.name}
              </span>
              <span className="muted small">{fmtBytes(file.size)}</span>
              {!busy && (
                <Button
                  variant="ghost"
                  size="sm"
                  icon="x"
                  onClick={() => {
                    setFile(null);
                    setErr(null);
                    if (inputRef.current) inputRef.current.value = '';
                  }}
                  aria-label="Remove file"
                />
              )}
            </div>
            <div className="grid" style={{ gridTemplateColumns: '1fr 140px', gap: 10 }}>
              <div className="field">
                <label>Title</label>
                <input className="input input--sm" value={title} onChange={(e) => setTitle(e.target.value)} disabled={busy} placeholder="Title shown in the catalog" />
              </div>
              <div className="field">
                <label>Type</label>
                <select className="select select--sm" value={type} onChange={(e) => setType(e.target.value as ItemType)} disabled={busy}>
                  {TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            {progress !== null && (
              <div className="row" style={{ gap: 10 }}>
                <Meter value={progress} color="#0068e0" thin />
                <span className="num muted small" style={{ minWidth: 42, textAlign: 'right' }}>
                  {Math.round(progress * 100)}%
                </span>
              </div>
            )}
            <div className="row" style={{ gap: 8 }}>
              <Button variant="primary" size="sm" icon="upload" onClick={() => void start()} disabled={busy}>
                {busy ? (progress !== null && progress >= 1 ? 'Registering…' : `Uploading ${Math.round((progress ?? 0) * 100)}%`) : 'Upload and enrich'}
              </Button>
              <span className="muted small">Ingest → fingerprint → arcs, markers, safety, breaks, thumbnails, clips</span>
            </div>
          </div>
        )}
      </div>
      {err && (
        <div className="small" style={{ color: '#ff8a80', marginTop: 10 }}>
          {err}
        </div>
      )}
      {done && (
        <div className="row row--wrap small" style={{ gap: 10, marginTop: 10 }}>
          <span className="pill pill--green">
            <span className="pill__dot" />
            {done.title} is in the pipeline
          </span>
          <Link to={`/editorial?item=${encodeURIComponent(done.id)}`}>Open in Editorial →</Link>
          <Link to={`/operations?item=${encodeURIComponent(done.id)}`}>Operations →</Link>
        </div>
      )}
    </Card>
  );
}
