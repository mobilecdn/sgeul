/**
 * Resumable browser upload straight to object storage (S3 multipart via presigned URLs).
 *
 * The API only signs and completes; bytes go browser → bucket. Parts upload 4 at a time with
 * per-part retries and backoff. Progress is saved in localStorage, so re-selecting the same
 * file after a closed tab or dropped connection skips parts the bucket already has.
 */

import type { CatalogItem, CatalogItemInput } from '@twelve-studio/core';

export interface UploadConfig {
  enabled: boolean;
  maxBytes: number;
  partSizeBytes: number;
}

export interface UploadProgress {
  phase: 'preparing' | 'uploading' | 'completing' | 'done';
  sentBytes: number;
  totalBytes: number;
  partsDone: number;
  partCount: number;
  /** Bytes per second over the last few seconds. */
  rateBps: number;
  resumed: boolean;
}

export interface UploadOptions {
  title?: string;
  type?: CatalogItemInput['type'];
  onProgress?: (p: UploadProgress) => void;
  signal?: AbortSignal;
  concurrency?: number;
}

interface Session {
  key: string;
  uploadId: string;
  partSizeBytes: number;
  partCount: number;
}

type Fetch = <T>(path: string, init?: RequestInit) => Promise<T>;

const STORAGE_PREFIX = 'sgeul.upload.';
const RETRIES = 5;
const SIGN_BATCH = 50;

const fileId = (f: File) => `${STORAGE_PREFIX}${f.name}:${f.size}:${f.lastModified}`;

function loadSession(f: File): Session | undefined {
  try {
    const raw = localStorage.getItem(fileId(f));
    return raw ? (JSON.parse(raw) as Session) : undefined;
  } catch {
    return undefined;
  }
}
function saveSession(f: File, s: Session | undefined) {
  try {
    if (s) localStorage.setItem(fileId(f), JSON.stringify(s));
    else localStorage.removeItem(fileId(f));
  } catch {
    /* private mode: resume just won't survive a reload */
  }
}

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(t);
        reject(new DOMException('Upload cancelled', 'AbortError'));
      },
      { once: true },
    );
  });

/** PUT one part with XHR (fetch has no upload progress). Resolves with the ETag. */
function putPart(url: string, blob: Blob, onBytes: (loaded: number) => void, signal?: AbortSignal): Promise<string> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', url);
    xhr.upload.onprogress = (e) => onBytes(e.loaded);
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        const etag = xhr.getResponseHeader('ETag');
        if (!etag) reject(new Error('Bucket did not expose the ETag header. Add ETag to the bucket CORS ExposeHeaders.'));
        else resolve(etag);
      } else {
        reject(Object.assign(new Error(`Part upload failed: HTTP ${xhr.status}`), { status: xhr.status }));
      }
    };
    xhr.onerror = () => reject(Object.assign(new Error('Network error while uploading (check bucket CORS allows PUT from this site)'), { status: 0 }));
    const onAbort = () => {
      xhr.abort();
      reject(new DOMException('Upload cancelled', 'AbortError'));
    };
    signal?.addEventListener('abort', onAbort, { once: true });
    xhr.send(blob);
  });
}

export async function uploadFile(api: Fetch, file: File, opts: UploadOptions = {}): Promise<CatalogItem> {
  const { signal, onProgress } = opts;
  const concurrency = Math.max(1, Math.min(8, opts.concurrency ?? 4));
  const total = file.size;
  const report = (p: Omit<UploadProgress, 'totalBytes'>) => onProgress?.({ ...p, totalBytes: total });
  report({ phase: 'preparing', sentBytes: 0, partsDone: 0, partCount: 0, rateBps: 0, resumed: false });

  // Resume if we have a session for this exact file and the bucket still knows the upload.
  let session = loadSession(file);
  const done = new Map<number, string>();
  let resumed = false;
  if (session) {
    try {
      const { parts } = await api<{ parts: Array<{ partNumber: number; etag: string }> }>(`/uploads/parts?key=${encodeURIComponent(session.key)}&uploadId=${encodeURIComponent(session.uploadId)}`, { signal });
      for (const p of parts) done.set(p.partNumber, p.etag);
      resumed = true;
    } catch {
      saveSession(file, undefined);
      session = undefined;
    }
  }
  if (!session) {
    session = await api<Session>('/uploads', {
      method: 'POST',
      body: JSON.stringify({ filename: file.name, sizeBytes: total, contentType: file.type || undefined }),
      signal,
    });
    saveSession(file, session);
  }
  const s = session;

  const partBytes = (n: number) => Math.min(s.partSizeBytes, total - (n - 1) * s.partSizeBytes);
  const inFlight = new Map<number, number>();
  let confirmedBytes = [...done.keys()].reduce((acc, n) => acc + partBytes(n), 0);
  const samples: Array<[number, number]> = [];
  const tick = () => {
    const sent = confirmedBytes + [...inFlight.values()].reduce((a, b) => a + b, 0);
    const now = performance.now();
    samples.push([now, sent]);
    while (samples.length > 2 && now - samples[0]![0] > 5000) samples.shift();
    const [t0, b0] = samples[0]!;
    const rate = now > t0 ? ((sent - b0) * 1000) / (now - t0) : 0;
    report({ phase: 'uploading', sentBytes: Math.min(sent, total), partsDone: done.size, partCount: s.partCount, rateBps: Math.max(0, rate), resumed });
  };
  tick();

  const pending = Array.from({ length: s.partCount }, (_, i) => i + 1).filter((n) => !done.has(n));
  const urls = new Map<number, string>();
  const signFor = async (n: number) => {
    const batch = pending.filter((p) => !urls.has(p) && p >= n).slice(0, SIGN_BATCH);
    if (!batch.includes(n)) batch.unshift(n);
    const { urls: signed } = await api<{ urls: Array<{ partNumber: number; url: string }> }>('/uploads/parts', {
      method: 'POST',
      body: JSON.stringify({ key: s.key, uploadId: s.uploadId, partNumbers: batch }),
      signal,
    });
    for (const u of signed) urls.set(u.partNumber, u.url);
  };

  let cursor = 0;
  const worker = async () => {
    while (cursor < pending.length) {
      const n = pending[cursor++]!;
      const start = (n - 1) * s.partSizeBytes;
      const blob = file.slice(start, start + partBytes(n));
      for (let attempt = 1; ; attempt++) {
        signal?.throwIfAborted();
        try {
          if (!urls.has(n)) await signFor(n);
          inFlight.set(n, 0);
          const etag = await putPart(urls.get(n)!, blob, (loaded) => {
            inFlight.set(n, loaded);
            tick();
          }, signal);
          inFlight.delete(n);
          done.set(n, etag);
          confirmedBytes += blob.size;
          tick();
          break;
        } catch (err) {
          inFlight.delete(n);
          if ((err as Error).name === 'AbortError' || attempt >= RETRIES) throw err;
          // Expired or rejected signature: re-sign. Network blip: back off and retry.
          if ((err as { status?: number }).status === 403) urls.delete(n);
          await sleep(Math.min(30_000, 1000 * 2 ** (attempt - 1)) + Math.random() * 500, signal);
        }
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, pending.length || 1) }, worker));

  report({ phase: 'completing', sentBytes: total, partsDone: s.partCount, partCount: s.partCount, rateBps: 0, resumed });
  const parts = [...done.entries()].sort((a, b) => a[0] - b[0]).map(([partNumber, etag]) => ({ partNumber, etag }));
  const item = await api<CatalogItem>('/uploads/complete', {
    method: 'POST',
    body: JSON.stringify({ key: s.key, uploadId: s.uploadId, parts, sizeBytes: total, title: opts.title, type: opts.type }),
    signal,
  });
  saveSession(file, undefined);
  report({ phase: 'done', sentBytes: total, partsDone: s.partCount, partCount: s.partCount, rateBps: 0, resumed });
  return item;
}

/** Cancel and discard the stored parts for this file. */
export async function abortUpload(api: Fetch, file: File): Promise<void> {
  const s = loadSession(file);
  if (!s) return;
  saveSession(file, undefined);
  await api('/uploads/abort', { method: 'POST', body: JSON.stringify({ key: s.key, uploadId: s.uploadId }) }).catch(() => undefined);
}
