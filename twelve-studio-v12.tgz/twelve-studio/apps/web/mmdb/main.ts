/**
 * MMDB (McLeod Movie DB) — a one-file player for the MMDB hundred.
 *
 * The catalog is fictional and carries no media, so the stage plays a title the
 * only honest way it can: the poster, a clock running at sixty times real speed,
 * and a progress bar. That is enough to close the loop the product is actually
 * about — playing something emits a watch event, the event rewrites the taste
 * profile, and every row under the stage re-ranks before the credits would roll.
 *
 * The engine is the real one (`@twelve-studio/core/recommend`), running in the
 * browser against data inlined at build time. No API, no network, no storage.
 */
import {
  DEFAULT_RECO_WEIGHTS,
  buildTasteProfile,
  popularityIndex,
  recommend,
  recommendRails,
  type RecoRail,
  type Recommendation,
  type WatchEvent,
} from '../../../packages/core/src/recommend.js';
import type { CatalogItem } from '../../../packages/core/src/types.js';
import CATALOG from './data.generated.json';

const items = CATALOG as unknown as CatalogItem[];
const byId = new Map(items.map((i) => [i.id, i]));
const W = DEFAULT_RECO_WEIGHTS;
const VIEWER = 'mmdb-guest';
/** Simulated playback: one second of wall clock is one minute of film. */
const SPEED = 60;

let events: WatchEvent[] = [];
let current: CatalogItem = items[0]!;
let elapsed = 0;
let playing = false;
let timer: number | undefined;
let seq = 0;

const $ = <T extends HTMLElement>(sel: string): T => document.querySelector(sel) as T;
const el = (tag: string, cls?: string, text?: string): HTMLElement => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text) n.textContent = text;
  return n;
};
const clock = (sec: number) => {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
};
const runtime = (i: CatalogItem) => i.durationSec ?? 5400;
const poster = (i: CatalogItem) => i.posterUrl ?? '';

/* ---- events -------------------------------------------------------- */

function record(itemId: string, action: WatchEvent['action'], completion?: number): void {
  events = [...events, { id: `e${++seq}`, profileId: VIEWER, itemId, action, completion, at: new Date().toISOString() }];
  render();
}

function profile() {
  return buildTasteProfile(VIEWER, events, items, W);
}

/* ---- playback ------------------------------------------------------ */

function play(item: CatalogItem, autostart = true): void {
  if (playing && current.id !== item.id) commitProgress();
  current = item;
  elapsed = 0;
  renderStage();
  render();
  if (autostart) start();
  else stop();
  $('.stage').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function start(): void {
  playing = true;
  $('#play').textContent = '❙❙';
  if (timer) window.clearInterval(timer);
  timer = window.setInterval(() => {
    elapsed = Math.min(runtime(current), elapsed + SPEED / 4);
    paintProgress();
    if (elapsed >= runtime(current)) finish();
  }, 250);
}

function stop(): void {
  playing = false;
  $('#play').textContent = '▶';
  if (timer) window.clearInterval(timer);
  timer = undefined;
}

/** Leaving a title part-watched is a watch event too — that is what Continue watching is built from. */
function commitProgress(): void {
  const done = elapsed / runtime(current);
  if (done > 0.02) record(current.id, 'watch', Number(done.toFixed(3)));
}

function finish(): void {
  stop();
  record(current.id, 'watch', 1);
  const next = upNext()[0];
  if (next) {
    const item = byId.get(next.itemId);
    if (item) window.setTimeout(() => play(item), 900);
  }
}

/* ---- ranking ------------------------------------------------------- */

const popularity = () => popularityIndex(events, W);

function upNext(): Recommendation[] {
  return recommend({ profile: profile(), pool: items, weights: W, popularity: popularity(), seed: current, limit: 12 });
}

function rails(): RecoRail[] {
  return recommendRails({ profile: profile(), pool: items, weights: W, popularity: popularity(), limit: 12, maxRails: 7 }).filter((r) => r.kind !== 'next');
}

/* ---- rendering ----------------------------------------------------- */

function renderStage(): void {
  const fp = current.fingerprint;
  $('#art').setAttribute('src', poster(current));
  $('#backdrop').setAttribute('src', poster(current));
  $('#title').textContent = current.title;
  $('#meta').textContent = [current.year, fp?.audienceRating?.suggested, `${Math.round(runtime(current) / 60)} min`, Object.keys(fp?.genres ?? {}).slice(0, 3).join(' · ')]
    .filter(Boolean)
    .join('  ·  ');
  $('#synopsis').textContent = fp?.synopsis?.short ?? '';
  paintProgress();
}

function paintProgress(): void {
  const pct = Math.min(1, elapsed / runtime(current));
  ($('#bar') as HTMLElement).style.width = `${pct * 100}%`;
  $('#time').textContent = `${clock(elapsed)} / ${clock(runtime(current))}`;
}

function card(rec: Recommendation): HTMLElement {
  const item = byId.get(rec.itemId);
  const node = el('button', 'card');
  const art = el('span', 'card__art');
  if (item?.posterUrl) {
    const img = document.createElement('img');
    img.src = item.posterUrl;
    img.alt = rec.title;
    img.loading = 'lazy';
    art.append(img);
  }
  const match = el('span', 'card__match', `${Math.round(Math.max(0, rec.score) * 100)}`);
  match.title = `engine score ${rec.score.toFixed(3)}`;
  art.append(match);
  const body = el('span', 'card__body');
  body.append(el('span', 'card__title', rec.title));
  const why = el('span', 'card__why');
  for (const b of rec.because.slice(0, 2)) why.append(el('span', b.includes('+') ? 'why why--combo' : 'why', b));
  body.append(why);
  node.append(art, body);
  node.onclick = () => { if (item) play(item); };
  return node;
}

function renderRow(title: string, reason: string, recs: Recommendation[]): HTMLElement {
  const row = el('section', 'row');
  const head = el('div', 'row__head');
  head.append(el('h3', undefined, title), el('span', 'row__reason', reason));
  const strip = el('div', 'strip');
  for (const r of recs) strip.append(card(r));
  row.append(head, strip);
  return row;
}

function renderTaste(): void {
  const p = profile();
  const box = $('#taste');
  box.innerHTML = '';
  if (p.events === 0) {
    box.append(el('p', 'muted', 'Nothing watched yet. Every row below is ranked by catalog popularity until you play something.'));
    return;
  }
  const combos = p.topCombos.filter((c) => c.weight > 0.2).slice(0, 3);
  if (combos.length) {
    box.append(el('div', 'taste__label', 'Combinations'));
    const line = el('div', 'taste__chips');
    for (const c of combos) line.append(el('span', 'chip chip--combo', `${c.label} ${c.weight.toFixed(2)}`));
    box.append(line);
  }
  box.append(el('div', 'taste__label', 'Labels'));
  const line = el('div', 'taste__chips');
  for (const t of p.top.slice(0, 8)) line.append(el('span', 'chip', `${t.label} ${t.weight.toFixed(2)}`));
  box.append(line);
  box.append(el('p', 'muted', `${p.events} event${p.events === 1 ? '' : 's'} · ${p.interacted.length} title${p.interacted.length === 1 ? '' : 's'} rated or played`));
}

function render(): void {
  const rowsBox = $('#rows');
  rowsBox.innerHTML = '';
  const next = upNext();
  // Before any history, up next is carried entirely by the seed term, and most of the
  // catalog scores under the engine's minimum — so a cold viewer gets popularity instead
  // of a row with one title in it.
  let coldFallback = false;
  if (next.length >= 6) {
    rowsBox.append(renderRow(`Because you are watching ${current.title}`, 'Closest titles to what is on, steered by this viewer.', next.slice(0, 12)));
  } else {
    coldFallback = true;
    const cold = recommend({ profile: profile(), pool: items, weights: W, popularity: popularity(), limit: 12, exclude: new Set([current.id]) });
    rowsBox.append(renderRow('Popular on MMDB', 'No history yet, so the catalog is ranked by popularity and variety.', cold));
  }
  // The catch-all row is the same ranking as the cold fallback, so it is dropped rather than repeated.
  for (const rail of rails()) {
    if (coldFallback && rail.kind === 'foryou') continue;
    rowsBox.append(renderRow(rail.title, rail.reason, rail.items));
  }
  renderTaste();
}

/* ---- wiring -------------------------------------------------------- */

function boot(): void {
  document.body.innerHTML = `
  <header class="top">
    <div class="brand"><b>MMDB</b><span>McLeod Movie DB</span></div>
    <div class="top__right">
      <span class="tag">simulated playback · 60×</span>
      <span class="tag tag--muted">${items.length} titles · engine in the browser</span>
    </div>
  </header>

  <section class="stage">
    <img id="backdrop" class="stage__backdrop" alt="" />
    <div class="stage__inner">
      <div class="stage__art"><img id="art" alt="" /></div>
      <div class="stage__body">
        <h1 id="title"></h1>
        <div id="meta" class="stage__meta"></div>
        <p id="synopsis" class="stage__synopsis"></p>
        <div class="transport">
          <button id="play" class="btn btn--play">▶</button>
          <div class="track" id="track"><div class="track__bar" id="bar"></div></div>
          <span id="time" class="time"></span>
        </div>
        <div class="actions">
          <button id="like" class="btn">♥ Like</button>
          <button id="skip" class="btn">✕ Not for me</button>
          <button id="next" class="btn">Next up ▸</button>
        </div>
      </div>
    </div>
  </section>

  <section class="panel">
    <h2>What it has learned</h2>
    <div id="taste"></div>
  </section>

  <div id="rows"></div>

  <footer class="foot">MMDB · fictional catalog, generated posters, no media. The ranking is the real engine: watch events in, rows out.</footer>`;

  $('#play').onclick = () => (playing ? (commitProgress(), stop()) : start());
  $('#like').onclick = () => record(current.id, 'like');
  $('#skip').onclick = () => { record(current.id, 'skip'); const n = upNext()[0]; const item = n && byId.get(n.itemId); if (item) play(item); };
  $('#next').onclick = () => { commitProgress(); const n = upNext()[0]; const item = n && byId.get(n.itemId); if (item) play(item); };
  $('#track').onclick = (e) => {
    const t = $('#track').getBoundingClientRect();
    elapsed = Math.max(0, Math.min(1, ((e as MouseEvent).clientX - t.left) / t.width)) * runtime(current);
    paintProgress();
  };
  window.addEventListener('keydown', (e) => {
    if (e.key === ' ') { e.preventDefault(); playing ? (commitProgress(), stop()) : start(); }
  });

  // Open on the most popular title in the catalog so the first screen is not arbitrary.
  const seed = [...items].sort((a, b) => ((b.metadata as { seedPopularity?: number })?.seedPopularity ?? 0) - ((a.metadata as { seedPopularity?: number })?.seedPopularity ?? 0))[0]!;
  play(seed, false);
}

boot();
