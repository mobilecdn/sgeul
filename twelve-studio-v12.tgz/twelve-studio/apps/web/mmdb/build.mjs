/**
 * Builds apps/web/public/mmdb.html: one file, no network, no API.
 *
 * The catalog is inlined with its embeddings stripped — the engine rebuilds the
 * hashed label vector from the fingerprint, which is byte-for-byte what was
 * stored, so the ranking is identical and the file stays about a megabyte.
 */
import { readFileSync, writeFileSync, rmSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '../../..');

const bundles = JSON.parse(readFileSync(resolve(ROOT, 'data/seed/mmdb100.json'), 'utf8'));
const items = bundles.map((b) => {
  const item = { ...b.item };
  if (item.fingerprint) {
    const { embedding: _drop, ...fp } = item.fingerprint;
    item.fingerprint = fp;
  }
  return item;
});
const dataPath = resolve(HERE, 'data.generated.json');
writeFileSync(dataPath, JSON.stringify(items));

const out = await build({
  entryPoints: [resolve(HERE, 'main.ts')],
  bundle: true,
  minify: true,
  format: 'iife',
  target: 'es2020',
  write: false,
  loader: { '.json': 'json' },
});
const js = out.outputFiles[0].text;
const css = readFileSync(resolve(HERE, 'mmdb.css'), 'utf8');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>MMDB · Movie Metadata Database</title>
<style>${css}</style>
</head>
<body></body>
<script>${js}</script>
</html>`;

const target = resolve(ROOT, 'apps/web/public/mmdb.html');
writeFileSync(target, html);
rmSync(dataPath, { force: true });
console.log(`mmdb.html ${(html.length / 1024).toFixed(0)} KB (${items.length} titles, js ${(js.length / 1024).toFixed(0)} KB) → ${target}`);
