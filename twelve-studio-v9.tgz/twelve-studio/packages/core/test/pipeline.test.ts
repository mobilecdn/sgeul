import { test } from 'node:test';
import assert from 'node:assert/strict';
import { enrichItem, runJob, JOB_ORDER, type PipelineStore, type PipelineDeps, type JobProgress } from '../src/pipeline.js';
import { MockTwelveLabsClient } from '../src/mock.js';
import type { CatalogItem, ItemBundle } from '../src/types.js';
import type { AnalyzeParams } from '../src/twelvelabs.js';

class MemoryStore implements PipelineStore {
  bundles = new Map<string, ItemBundle>();
  meta = new Map<string, string>();
  getBundle(id: string) {
    return this.bundles.get(id);
  }
  saveItem(item: CatalogItem) {
    const b = this.bundles.get(item.id) ?? { item, jobs: [] };
    b.item = item;
    if (item.fingerprint) b.fingerprint = item.fingerprint;
    this.bundles.set(item.id, b);
    return item;
  }
  saveSection(id: string, key: string, value: unknown) {
    const b = this.bundles.get(id)!;
    (b as unknown as Record<string, unknown>)[key] = value;
    if (key === 'fingerprint') b.item = { ...b.item, fingerprint: value as ItemBundle['fingerprint'] };
  }
  getMeta(k: string) {
    return this.meta.get(k);
  }
  setMeta(k: string, v: string) {
    this.meta.set(k, v);
  }
}

function item(): CatalogItem {
  return {
    id: 'demo',
    title: 'Demo Title',
    sourceUrl: 'https://example.com/demo.mp4',
    type: 'short',
    createdAt: 't',
    updatedAt: 't',
    status: 'ingesting',
    jobs: {},
  };
}

function deps(client: MockTwelveLabsClient, store: MemoryStore): PipelineDeps {
  return { client, store, config: { indexName: 'test', synopsisLanguages: ['es', 'fr'], pollIntervalMs: 1 } };
}

test('enrichItem runs all nine jobs in order against the mock client', async () => {
  const store = new MemoryStore();
  const client = new MockTwelveLabsClient({ catalog: [], lists: [], ads: [], assets: [], dir: '' }, { latencyMs: [0, 0] });
  const events: JobProgress[] = [];
  const it = item();
  store.saveItem(it);
  const done = await enrichItem(it, deps(client, store), (p) => events.push(p));
  assert.equal(done.status, 'ready');
  for (const k of JOB_ORDER) assert.equal(done.jobs[k], 'ready', `${k} ready`);
  const started = events.filter((e) => e.status === 'running').map((e) => e.kind);
  assert.deepEqual([...new Set(started)], [...JOB_ORDER]);
  const b = store.getBundle('demo')!;
  assert.ok(b.fingerprint?.embedding?.length);
  assert.ok(b.fingerprint?.synopsis.translations?.es);
  assert.ok(b.emotions!.samples.length <= 60);
  assert.ok(b.markers!.markers.every((m) => typeof m.startFrame === 'number'));
  assert.ok(b.adBreaks!.breaks.length >= 1);
  assert.equal(b.thumbnails!.length, 12);
  assert.equal(b.clips!.length, 6);
  assert.match(b.fingerprint!.synopsis.short, /\(mock\)/);
  assert.equal(store.getMeta('twelvelabs.indexId'), 'mock-index');
});

test('a failing job is recorded and the rest continue; re-running skips ready jobs', async () => {
  const store = new MemoryStore();
  const client = new MockTwelveLabsClient({ catalog: [], lists: [], ads: [], assets: [], dir: '' }, { latencyMs: [0, 0] });
  const original = client.analyze.bind(client);
  let safetyCalls = 0;
  client.analyze = (async (params: AnalyzeParams) => {
    if (params.hint?.job === 'safety') {
      safetyCalls += 1;
      if (safetyCalls === 1) throw new Error('simulated 500 from /analyze');
    }
    return original(params);
  }) as typeof client.analyze;
  const events: JobProgress[] = [];
  const it = item();
  store.saveItem(it);
  const first = await enrichItem(it, deps(client, store), (p) => events.push(p));
  assert.equal(first.jobs.safety, 'failed');
  assert.equal(first.jobs.adbreaks, 'ready', 'later jobs still ran');
  assert.equal(first.status, 'ready');
  assert.ok(events.find((e) => e.kind === 'safety' && e.status === 'failed')?.error?.includes('simulated'));

  const again = await enrichItem(first, deps(client, store), (p) => events.push(p));
  assert.equal(again.jobs.safety, 'ready');
  const skipped = events.filter((e) => e.status === 'skipped').map((e) => e.kind);
  assert.ok(skipped.includes('fingerprint') && skipped.includes('clips'));
  assert.equal(safetyCalls, 2);
});

test('runJob(embedding) runs fingerprint first when it is missing', async () => {
  const store = new MemoryStore();
  const client = new MockTwelveLabsClient({ catalog: [], lists: [], ads: [], assets: [], dir: '' }, { latencyMs: [0, 0] });
  const it = item();
  store.saveItem(it);
  const r = await runJob('embedding', it, deps(client, store));
  assert.equal(r.kind, 'embedding');
  assert.ok(store.getBundle('demo')!.fingerprint?.embedding?.length);
  assert.ok(store.getBundle('demo')!.item.durationSec, 'ingest happened implicitly');
});

test('creative runs with a brief do not overwrite the default thumbnails', async () => {
  const store = new MemoryStore();
  const client = new MockTwelveLabsClient({ catalog: [], lists: [], ads: [], assets: [], dir: '' }, { latencyMs: [0, 0] });
  const it = item();
  store.saveItem(it);
  await enrichItem(it, deps(client, store));
  const before = store.getBundle('demo')!.thumbnails!;
  const r = await runJob('thumbnails', store.getBundle('demo')!.item, deps(client, store), { creative: { thumbnails: { brief: 'moody night shots', count: 3 } } });
  const out = r.output as Array<{ caption: string }>;
  assert.equal(out.length, 3);
  assert.match(out[0]!.caption, /moody night shots/);
  assert.equal(store.getBundle('demo')!.thumbnails, before);
});

test('ingest: a YouTube watch URL is fetched to this host first (fetchRemote), then uploaded as a file', async () => {
  const store = new MemoryStore();
  const client = new MockTwelveLabsClient({ catalog: [], lists: [], ads: [], assets: [], dir: '' }, { latencyMs: [0, 0] });
  const it: CatalogItem = { ...item(), id: 'yt', sourceUrl: 'https://www.youtube.com/watch?v=eDiw5FLpxn8', title: 'YouTube eDiw5FLpxn8' };
  store.saveItem(it);
  const calls: string[] = [];
  const orig = client.createAssetFromFile.bind(client);
  client.createAssetFromFile = async (p) => {
    calls.push(`file:${p.path}`);
    return orig(p);
  };
  const origUrl = client.createAsset.bind(client);
  client.createAsset = async (p) => {
    calls.push(`url:${p.url}`);
    return origUrl(p);
  };
  const notes: string[] = [];
  const d = deps(client, store);
  d.config.fetchRemote = async (i, onNote) => {
    onNote?.('→ yt-dlp 50% of 10MiB');
    return store.saveItem({ ...i, localPath: '/tmp/fake/yt-eDiw5FLpxn8.mp4', title: 'The real page title', durationSec: 42 });
  };
  const done = await runJob('ingest', it, d, { onProgress: (p) => void (p.note && notes.push(p.note)) });
  assert.equal(done.item.title, 'The real page title');
  assert.equal(done.item.localPath, '/tmp/fake/yt-eDiw5FLpxn8.mp4');
  // (the mock's createAssetFromFile delegates to createAsset with a file:// URL; only http URLs count here)
  assert.deepEqual(calls.filter((c) => !c.startsWith('url:file:')), ['file:/tmp/fake/yt-eDiw5FLpxn8.mp4'], 'the page URL is never sent to TwelveLabs');
  assert.ok(notes.some((n) => /page URL to this host/.test(n)));
  assert.ok(notes.some((n) => /yt-dlp 50%/.test(n)));
  assert.ok(notes.some((n) => /direct upload/.test(n)));
});

test('ingest: without fetchRemote a page URL goes to TwelveLabs as-is (mock accepts it); a direct mp4 URL never triggers the fetch', async () => {
  const store = new MemoryStore();
  const client = new MockTwelveLabsClient({ catalog: [], lists: [], ads: [], assets: [], dir: '' }, { latencyMs: [0, 0] });
  const calls: string[] = [];
  const origUrl = client.createAsset.bind(client);
  client.createAsset = async (p) => {
    calls.push(`url:${p.url}`);
    return origUrl(p);
  };
  const yt: CatalogItem = { ...item(), id: 'yt2', sourceUrl: 'https://youtu.be/abc' };
  store.saveItem(yt);
  await runJob('ingest', yt, deps(client, store));
  const mp4 = item();
  store.saveItem(mp4);
  const d = deps(client, store);
  let fetched = 0;
  d.config.fetchRemote = async () => {
    fetched++;
    return undefined;
  };
  await runJob('ingest', mp4, d);
  assert.deepEqual(calls, ['url:https://youtu.be/abc', 'url:https://example.com/demo.mp4']);
  assert.equal(fetched, 0);
});

test('ingest: a local file over the direct-upload limit is handed to TwelveLabs as the signed public URL', async () => {
  const { writeFile, mkdtemp, rm } = await import('node:fs/promises');
  const { tmpdir } = await import('node:os');
  const { join } = await import('node:path');
  const { DIRECT_UPLOAD_MAX_BYTES } = await import('../src/util.js');
  const dir = await mkdtemp(join(tmpdir(), 'sgeul-big-'));
  try {
    const small = join(dir, 'small.mp4');
    await writeFile(small, Buffer.alloc(16, 1));
    const store = new MemoryStore();
    const client = new MockTwelveLabsClient({ catalog: [], lists: [], ads: [], assets: [], dir: '' }, { latencyMs: [0, 0] });
    const calls: string[] = [];
    const origFile = client.createAssetFromFile.bind(client);
    client.createAssetFromFile = async (p) => {
      calls.push(`file:${p.path}`);
      return origFile(p);
    };
    const origUrl = client.createAsset.bind(client);
    client.createAsset = async (p) => {
      calls.push(`url:${p.url}`);
      return origUrl(p);
    };
    const d = deps(client, store);
    d.config.publicUrlFor = (i) => `https://sgeul.example/api/public/media/title.${i.id}.mac`;
    // Small file: direct upload even though a public URL exists.
    const a: CatalogItem = { ...item(), id: 'small', sourceUrl: `file://${small}`, localPath: small };
    store.saveItem(a);
    await runJob('ingest', a, d);
    // "Big" file: fake the size check by pointing at a sparse file just over the limit.
    const big = join(dir, 'big.mp4');
    const fh = await (await import('node:fs/promises')).open(big, 'w');
    await fh.truncate(DIRECT_UPLOAD_MAX_BYTES + 1);
    await fh.close();
    const b: CatalogItem = { ...item(), id: 'big', sourceUrl: `file://${big}`, localPath: big };
    store.saveItem(b);
    const notes: string[] = [];
    await runJob('ingest', b, d, { onProgress: (p) => void (p.note && notes.push(p.note)) });
    assert.deepEqual(calls.filter((c) => !c.startsWith('url:file:')), [`file:${small}`, 'url:https://sgeul.example/api/public/media/title.big.mac']);
    assert.ok(notes.some((n) => /url on this host, 2\d\d MB/.test(n)));
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});
