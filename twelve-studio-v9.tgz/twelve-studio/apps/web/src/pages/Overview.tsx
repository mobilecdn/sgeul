import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import type { CatalogItem, Job, StitchJob } from '@twelve-studio/core';
import { Button, Card, StatTile, StatusPill, EmptyState, Meter, Skeleton } from '../components/ui';
import { Icon } from '../components/Icon';
import { useApi, useEvents, useQuery } from '../lib/hooks';
import { duration, hours, money, pct, relTime } from '../lib/format';
import { estimateCost, PRICING } from '../lib/pricing';
import { useTopbar } from '../App';
import { UploadCard } from '../components/UploadCard';

const MODEL_FOR: Record<string, string> = {
  ingest: 'Marengo 3.0 · index',
  embedding: 'Marengo 3.5 · embed',
  fingerprint: 'Pegasus 1.5 · analyze',
  emotions: 'Pegasus 1.5 · analyze',
  markers: 'Pegasus 1.5 · analyze',
  safety: 'Pegasus 1.5 · analyze',
  adbreaks: 'Pegasus 1.5 · analyze + planner',
  thumbnails: 'Pegasus 1.5 · analyze',
  clips: 'Pegasus 1.5 · analyze',
  stitch: 'ffmpeg · local stitch',
};

/** A pipeline row: an enrichment job or a stitched-preview render (kind "stitch"). */
type PipeRow = Omit<Job, 'kind'> & { kind: Job['kind'] | 'stitch' };

const stitchRow = (j: StitchJob): PipeRow => ({ id: j.id, itemId: j.itemId, kind: 'stitch', status: j.status, startedAt: j.createdAt, finishedAt: j.finishedAt, error: j.error });

export function Overview() {
  const api = useApi();
  const stats = useQuery(() => api.stats(), []);
  const catalog = useQuery(() => api.catalog(), []);
  const jobsQ = useQuery(async () => {
    const [jobs, stitches] = await Promise.all([api.jobs(), api.listStitches().catch(() => [] as StitchJob[])]);
    return [...jobs, ...stitches.map(stitchRow)] as PipeRow[];
  }, []);
  const [live, setLive] = useState<PipeRow[]>([]);

  useTopbar(
    <>
      <Button variant="ghost" size="sm" icon="refresh" onClick={() => void Promise.all([stats.refetch(), catalog.refetch(), jobsQ.refetch()])}>
        Refresh
      </Button>
      <Link to="/editorial?upload=1">
        <Button variant="primary" size="sm" icon="upload">
          Upload assets
        </Button>
      </Link>
    </>,
    [],
  );

  useEvents((e) => {
    if (e.type === 'job' || e.type === 'stitch') {
      const row: PipeRow = e.type === 'stitch' ? stitchRow(e.job) : e.job;
      setLive((prev) => [row, ...prev.filter((j) => j.id !== row.id)].slice(0, 40));
      if (e.type === 'job' && (e.job.status === 'ready' || e.job.status === 'failed')) void stats.refetch();
    }
    if (e.type === 'item') {
      catalog.setData((prev) => (prev ? prev.map((i) => (i.id === e.item.id ? e.item : i)).concat(prev.some((i) => i.id === e.item.id) ? [] : [e.item]) : prev));
    }
  });

  const titleOf = useMemo(() => {
    const m = new Map<string, CatalogItem>();
    for (const i of catalog.data ?? []) m.set(i.id, i);
    return (id: string) => m.get(id)?.title ?? id;
  }, [catalog.data]);

  const pipeline = useMemo(() => {
    const merged = new Map<string, PipeRow>();
    for (const j of jobsQ.data ?? []) merged.set(j.id, j);
    for (const j of live) merged.set(j.id, j);
    return [...merged.values()]
      .sort((a, b) => {
        const rank = (j: PipeRow) => (j.status === 'running' ? 0 : j.status === 'queued' ? 1 : 2);
        const d = rank(a) - rank(b);
        if (d) return d;
        return (b.finishedAt ?? b.startedAt ?? '').localeCompare(a.finishedAt ?? a.startedAt ?? '');
      })
      .slice(0, 10);
  }, [jobsQ.data, live]);

  const totalHours = hours(stats.data?.totalDurationSec ?? 0);
  const cost = estimateCost(totalHours, stats.data?.items ?? 0, 250);
  const running = pipeline.filter((j) => j.status === 'running' || j.status === 'queued').length;

  return (
    <div className="content">
      <div className="stack stack--lg" style={{ maxWidth: 1400 }}>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(6, 1fr)' }}>
          <StatTile label="Assets" value={stats.data?.items} loading={stats.loading} hint="Titles in the catalog" accent="#0068e0" />
          <StatTile label="Ready" value={stats.data?.ready} loading={stats.loading} hint={stats.data ? `${stats.data.items - stats.data.ready} still enriching` : undefined} accent="#5ec16a" />
          <StatTile label="Hours indexed" value={totalHours.toFixed(1)} unit="h" loading={stats.loading} hint={duration(stats.data?.totalDurationSec)} accent="#8cbaff" />
          <StatTile label="Smart lists" value={stats.data?.lists} loading={stats.loading} hint="Rules · NL · AI-curated" accent="#6d3fd4" />
          <StatTile label="Coverage" value={stats.data ? Math.round(stats.data.coverage * 100) : undefined} unit="%" loading={stats.loading} hint="Enrichment jobs complete" accent="#2fbfa6" />
          <StatTile label="Pending reviews" value={stats.data?.pendingReviews} loading={stats.loading} hint={<Link to="/operations">Open Operations Lab →</Link>} accent="#f56300" />
        </div>

        <div className="grid" style={{ gridTemplateColumns: '1.4fr 1fr' }}>
          <UploadCard
            onUploaded={(item) => {
              catalog.setData((prev) => (prev ? (prev.some((i) => i.id === item.id) ? prev : [item, ...prev]) : [item]));
              void Promise.all([stats.refetch(), jobsQ.refetch()]);
            }}
          />
          <Card title="Add from a URL" icon="external" sub="Direct media URLs, or a YouTube / Vimeo page">
            <p className="small" style={{ color: 'var(--heading)', lineHeight: 1.6, margin: 0 }}>
              Paste an <b>.mp4 / .m3u8 URL</b> and TwelveLabs fetches it directly. Paste a <b>YouTube or Vimeo page</b> and the SGEUL server fetches the media first (yt-dlp), because the TwelveLabs asset
              API only accepts direct media URLs. Either way the title goes through the same nine stages.
            </p>
            <div className="row row--wrap" style={{ gap: 8, marginTop: 14 }}>
              <Link to="/editorial?upload=1">
                <Button variant="primary" size="sm" icon="plus">
                  Add URLs
                </Button>
              </Link>
              <Link to="/editorial?upload=twelvelabs">
                <Button variant="ghost" size="sm" icon="layers">
                  From TwelveLabs account
                </Button>
              </Link>
            </div>
            <div className="muted small" style={{ marginTop: 14, lineHeight: 1.6 }}>
              Files over 200 MB (TwelveLabs' direct-upload limit) are handed to TwelveLabs as a signed URL on this server when <code className="mono">PUBLIC_BASE_URL</code> is set.
            </div>
          </Card>
        </div>

        <div className="grid" style={{ gridTemplateColumns: '1.4fr 1fr' }}>
          <Card title="Provenance" icon="sparkle" sub="Where every number on these screens came from">
            <p style={{ color: 'var(--heading)', fontSize: 14, lineHeight: 1.6, margin: 0, maxWidth: 720 }}>
              Every fingerprint, arc, marker, break and thumbnail in this demo was produced by <b>TwelveLabs Pegasus 1.5</b> from the video itself (structured JSON via <code className="mono">json_schema</code>), 12 Sep 2026,
              either through <code className="mono">POST /analyze</code> directly or through the <b>Jockey</b> MCP agent's grounded queries. Three Blender Foundation open movies (CC-BY), a public-domain 1960 feature and a
              launch promo uploaded to the account. Nothing hand-written.
            </p>
            <div className="row row--wrap" style={{ gap: 8, marginTop: 14 }}>
              {(catalog.data ?? []).map((i) => (
                <span key={i.id} className="pill pill--neutral" title={i.sourceUrl}>
                  {i.title}
                  {i.year ? ` · ${i.year}` : ''}
                </span>
              ))}
              <span className="pill pill--violet">CC-BY · Blender Foundation</span>
            </div>
            <div className="row row--wrap small muted" style={{ gap: 14, marginTop: 14 }}>
              <span>
                <b style={{ color: 'var(--heading)' }}>Ingest</b> POST /assets → POST /indexes/:id/indexed-assets (Marengo 3.0, HLS + thumbnails returned)
              </span>
              <span>
                <b style={{ color: 'var(--heading)' }}>Analyze</b> POST /analyze · temperature 0.2 · response_format json_schema
              </span>
              <span>
                <b style={{ color: 'var(--heading)' }}>Embed</b> POST /embed-v2 · video scope
              </span>
            </div>
          </Card>
          <Card title="Model calls per title" icon="bolt" sub="Nine pipeline stages, three model families, plus the Jockey agent">
            <table className="table" style={{ width: '100%' }}>
              <thead>
                <tr>
                  <th style={{ textAlign: 'left' }}>Model</th>
                  <th style={{ textAlign: 'left' }}>Endpoint</th>
                  <th style={{ textAlign: 'right' }}>Calls</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Marengo 3.0', 'index', 1, '#0068e0', 'ingest'],
                  ['Marengo 3.5', 'embed', 1, '#2fbfa6', 'embedding'],
                  ['Pegasus 1.5', 'analyze', 7, '#6d3fd4', 'fingerprint · emotions · markers · safety · ad breaks · thumbnails · clips'],
                  ['Jockey', 'jockey_query · jockey_search', '4 + n', '#f5c518', 'MCP agent on the same stack: one knowledge-store item per title, grounded json_schema queries for emotions · markers · safety · ad breaks, clip search to verify timestamps'],
                ].map(([model, ep, n, color, jobs]) => (
                  <tr key={String(model)}>
                    <td style={{ whiteSpace: 'normal', fontFamily: 'inherit', fontSize: 13 }}>
                      <span className="row" style={{ gap: 8 }}>
                        <i style={{ width: 8, height: 8, borderRadius: 2, background: String(color), display: 'inline-block', flex: '0 0 8px' }} />
                        <span style={{ color: 'var(--heading)', fontWeight: 600 }}>{model}</span>
                      </span>
                      <div className="muted" style={{ fontSize: 11, marginTop: 2 }}>
                        {jobs}
                      </div>
                    </td>
                    <td className="mono muted small" style={{ whiteSpace: 'normal' }}>{ep}</td>
                    <td className="num" style={{ textAlign: 'right', color: 'var(--heading)', fontWeight: 700, fontSize: typeof n === 'number' ? 18 : 14, whiteSpace: 'nowrap' }}>
                      {n}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={2} className="muted small" style={{ whiteSpace: 'normal', fontFamily: 'inherit', borderBottom: 0 }}>
                    per title · {stats.data?.items ?? '—'} titles → {stats.data ? stats.data.items * 9 : '—'} model calls total, plus Jockey agent turns where the MCP was used instead of raw /analyze
                  </td>
                  <td className="num" style={{ textAlign: 'right', color: 'var(--heading)', fontWeight: 700, borderBottom: 0 }}>
                    9 + Jockey
                  </td>
                </tr>
              </tfoot>
            </table>
          </Card>
        </div>

        <div className="grid" style={{ gridTemplateColumns: '1.4fr 1fr' }}>
          <Card
            title="Pipeline"
            icon="bolt"
            sub="Live job activity from the enrichment runner"
            actions={
              <span className={`pill ${running ? 'pill--blue' : 'pill--neutral'}`}>
                <span className="pill__dot" />
                {running ? `${running} running` : 'idle'}
              </span>
            }
          >
            {jobsQ.loading ? (
              <div className="stack">
                <Skeleton h={34} />
                <Skeleton h={34} />
                <Skeleton h={34} />
              </div>
            ) : pipeline.length === 0 ? (
              <EmptyState icon="bolt" title="No jobs yet" text="Upload an asset and the nine-stage pipeline will appear here as it runs." action={<Link to="/editorial?upload=1"><Button variant="primary" size="sm">Upload assets</Button></Link>} />
            ) : (
              <div>
                {pipeline.map((j) => (
                  <div key={j.id} className="pipe">
                    <StatusPill status={j.status} />
                    <span className="pipe__kind" style={j.kind === 'stitch' ? { color: '#c8b0ff' } : undefined}>
                      {j.kind}
                    </span>
                    <span className="pipe__title">{titleOf(j.itemId)}</span>
                    <span className="muted small" style={{ minWidth: 150 }} title={j.error}>
                      {j.upstream?.model ? j.upstream.model : MODEL_FOR[j.kind]}
                    </span>
                    <span className="pipe__time">{relTime(j.finishedAt ?? j.startedAt)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card title="Cost to date" icon="dollar" sub="Estimated from list pricing × catalog hours">
            <div className="stat__value" style={{ fontSize: 48, marginBottom: 6 }}>
              {stats.loading ? <Skeleton h={48} w={160} /> : money(cost.total)}
            </div>
            <div className="stack" style={{ gap: 10 }}>
              <CostRow label="Index (Marengo 3.0)" value={cost.index} total={cost.total} note={`${PRICING.indexPerHour.toFixed(2)}/h × ${totalHours.toFixed(1)}h`} color="#0068e0" />
              <CostRow label="Analyze (Pegasus 1.5) input" value={cost.analyze} total={cost.total} note={`$${PRICING.analyzePerHourIn}/h × ${PRICING.analyzeCallsPerItem} calls`} color="#6d3fd4" />
              <CostRow label="Analyze output tokens" value={cost.analyzeTokens} total={cost.total} note={`$${PRICING.analyzePerMTokensOut}/M tokens`} color="#c8b0ff" />
              <CostRow label="Embed (Marengo 3.5)" value={cost.embed} total={cost.total} note={`$${PRICING.embedPerMTokens}/M tokens`} color="#2fbfa6" />
              <CostRow label="Search (250 queries)" value={cost.search} total={cost.total} note={`$${PRICING.searchPer1kQueries}/1k queries`} color="#8cbaff" />
            </div>
            <div className="divider" style={{ margin: '14px 0 10px' }} />
            <div className="row row--between small muted">
              <span>Per hour of content ≈ {money(totalHours ? cost.total / totalHours : cost.index + PRICING.analyzePerHourIn * PRICING.analyzeCallsPerItem)}</span>
              <Link to="/settings">Pricing calculator →</Link>
            </div>
          </Card>
        </div>

        <Card title="What TwelveLabs does behind each Lab" icon="layers" sub="Every intelligence primitive in this product is one of three calls">
          <div className="lab">
            <div className="lab__col">
              <h3>
                <Icon name="search" size={15} style={{ color: '#8cbaff' }} /> Marengo — search & embed
              </h3>
              <span className="lab__model">POST /indexes · /search · /embed-v2 · marengo3.0 / marengo3.5</span>
              <ul>
                <li>Indexes every asset with visual + audio options; HLS playback and thumbnails come back for free.</li>
                <li>Discovery: any-to-video text search grouped by clip with rank and transcript.</li>
                <li>Video-scope embeddings power similar titles, NL smart lists and AI curation clusters.</li>
              </ul>
            </div>
            <div className="lab__col">
              <h3>
                <Icon name="sparkle" size={15} style={{ color: '#c8b0ff' }} /> Pegasus — analyze
              </h3>
              <span className="lab__model">POST /analyze · pegasus1.5 · temperature 0.2</span>
              <ul>
                <li>Fingerprint+: genres, keywords, moods, themes, characters, pacing, rating, multilingual synopsis.</li>
                <li>Emotion arcs every 20–30 s, chapter and credit markers, safety segments, ad-break candidates.</li>
                <li>Creative: thumbnail candidates with factor scores and crops; preview clips with 9:16 reframe paths.</li>
              </ul>
            </div>
            <div className="lab__col">
              <h3>
                <Icon name="api" size={15} style={{ color: '#5ec16a' }} /> Structured JSON
              </h3>
              <span className="lab__model">response_format: json_schema · deterministic planners</span>
              <ul>
                <li>Every prompt carries a strict schema so answers land as typed objects, never prose.</li>
                <li>Confidence on every label — chips show probability, sliders filter by it.</li>
                <li>Ad pods are planned deterministically from candidates: spacing, edges, brand safety, rising-arousal guard.</li>
              </ul>
            </div>
          </div>
        </Card>

        {catalog.data && catalog.data.length > 0 && (
          <Card title="Catalog status" icon="film" sub={`${catalog.data.length} titles`} actions={<Link to="/editorial"><Button variant="ghost" size="sm">Open Editorial Lab</Button></Link>}>
            <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 10 }}>
              {catalog.data.slice(0, 12).map((i) => (
                <div key={i.id} className="row" style={{ padding: '8px 10px', borderRadius: 10, background: 'var(--surface-2)', gap: 10 }}>
                  <span className="truncate" style={{ color: 'var(--heading)', fontWeight: 500, flex: 1 }}>
                    {i.title}
                  </span>
                  <span className="muted small">{duration(i.durationSec)}</span>
                  <StatusPill status={i.status} />
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

function CostRow({ label, value, total, note, color }: { label: string; value: number; total: number; note: string; color: string }) {
  return (
    <div className="stack" style={{ gap: 4 }}>
      <div className="row row--between small">
        <span style={{ color: 'var(--heading)' }}>{label}</span>
        <span className="num" style={{ color: 'var(--heading)' }}>
          {money(value)}
        </span>
      </div>
      <div className="row" style={{ gap: 10 }}>
        <Meter value={total ? value / total : 0} color={color} thin />
        <span className="muted" style={{ fontSize: 11, minWidth: 130, textAlign: 'right' }}>
          {note} · {total ? pct(value / total) : '0%'}
        </span>
      </div>
    </div>
  );
}
