import { useCallback, useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import type { CatalogItem, CatalogItemInput, Fingerprint, JobKind, SmartList, SmartListRule } from '@twelve-studio/core';
import { Button, Card, EmptyState, ErrorNote, Meter, Modal, Skeleton, StatusPill, Tabs } from '../components/ui';
import { TagRow, TagChip } from '../components/TagChip';
import { RangeSlider } from '../components/RangeSlider';
import { PosterArt, PosterCard } from '../components/Poster';
import { Icon } from '../components/Icon';
import { useApi, useEvents, useQuery, useToast } from '../lib/hooks';
import type { ImportResult, LinkedAsset } from '../lib/api';
import { duration, mmss, pct, titleCase } from '../lib/format';
import { useTopbar } from '../App';

type Tab = 'library' | 'lists' | 'curation';
const FACETS: SmartListRule['facet'][] = ['genres', 'keywords', 'moods', 'moodTags', 'themes'];
const FACET_LABEL: Record<SmartListRule['facet'], string> = { genres: 'Genre', keywords: 'Keyword', moods: 'Mood', moodTags: 'Mood tag', themes: 'Theme' };
const JOB_ORDER: JobKind[] = ['ingest', 'fingerprint', 'embedding', 'emotions', 'markers', 'safety', 'adbreaks', 'thumbnails', 'clips'];

/** Native-script names for the synopsis language switch (SYNOPSIS_LANGS default order first). */
const LANG_NAMES: Record<string, string> = { en: 'English', es: 'Español', fr: 'Français', de: 'Deutsch', ja: '日本語', pt: 'Português', ar: 'العربية', hi: 'हिन्दी', ko: '한국어', it: 'Italiano', zh: '中文' };
const LANG_ORDER = ['es', 'fr', 'de', 'ja', 'pt', 'ar', 'hi', 'ko'];
const RTL_LANGS = new Set(['ar', 'he', 'fa', 'ur']);
const langName = (code: string) => LANG_NAMES[code] ?? code.toUpperCase();

export function Editorial() {
  const loc = useLocation();
  const nav = useNavigate();
  const [params, setParams] = useSearchParams();
  const tab: Tab = loc.pathname.includes('/lists') ? 'lists' : loc.pathname.includes('/curation') ? 'curation' : 'library';
  const setTab = (t: Tab) => nav(t === 'library' ? '/editorial' : `/editorial/${t}`);
  const api = useApi();
  const catalog = useQuery(() => api.catalog(), []);
  const lists = useQuery(() => api.lists(), []);
  // `?upload=1` opens the URL tab, `?upload=twelvelabs` the account tab (Settings → "Sync assets").
  const [upload, setUpload] = useState<AddTab | null>(addTabFromParam(params.get('upload')));
  const toast = useToast();

  useEffect(() => {
    const t = addTabFromParam(params.get('upload'));
    if (t) {
      setUpload(t);
      params.delete('upload');
      setParams(params, { replace: true });
    }
  }, [params, setParams]);

  useEvents((e) => {
    if (e.type === 'item') catalog.setData((prev) => (prev ? (prev.some((i) => i.id === e.item.id) ? prev.map((i) => (i.id === e.item.id ? { ...i, ...e.item } : i)) : [...prev, e.item]) : prev));
  });

  useTopbar(
    <>
      <Tabs<Tab>
        tabs={[
          { id: 'library', label: 'Asset library', count: catalog.data?.length },
          { id: 'lists', label: 'Smart lists', count: lists.data?.length },
          { id: 'curation', label: 'AI curation', icon: 'sparkle' },
        ]}
        value={tab}
        onChange={setTab}
      />
      <Button variant="primary" size="sm" icon="upload" onClick={() => setUpload('urls')}>
        Add assets
      </Button>
    </>,
    [tab, catalog.data?.length, lists.data?.length],
  );

  const items = catalog.data ?? [];

  return (
    <>
      {tab === 'library' && <Library items={items} loading={catalog.loading} error={catalog.error} onChanged={() => void catalog.refetch()} />}
      {tab === 'lists' && <SmartLists items={items} lists={lists.data ?? []} loading={lists.loading} onChanged={() => void lists.refetch()} />}
      {tab === 'curation' && <Curation items={items} lists={lists.data ?? []} onChanged={() => void lists.refetch()} />}
      <AddAssetsModal
        open={upload !== null}
        initialTab={upload ?? 'urls'}
        onClose={() => setUpload(null)}
        onSubmit={async (inputs) => {
          const created = await api.addItems(inputs);
          toast.push(`${created.length} asset${created.length === 1 ? '' : 's'} queued — pipeline started`, 'success');
          setUpload(null);
          void catalog.refetch();
          nav('/editorial');
        }}
        onImported={(r) => {
          const n = r.items.length + r.ads.length;
          if (n > 0) {
            const parts = [r.items.length ? `${r.items.length} title${r.items.length === 1 ? '' : 's'} (enriching)` : '', r.ads.length ? `${r.ads.length} ad creative${r.ads.length === 1 ? '' : 's'}` : ''].filter(Boolean);
            toast.push(`Imported ${parts.join(' and ')} from TwelveLabs — no re-upload needed`, 'success');
          } else if (r.errors.length === 0) toast.push('Nothing to import — those assets are already linked', 'info');
          if (r.errors.length) toast.push(`${r.errors.length} asset${r.errors.length === 1 ? '' : 's'} could not be imported`, 'error');
          void catalog.refetch();
          if (r.items.length) nav('/editorial');
        }}
      />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Library                                                             */
/* ------------------------------------------------------------------ */
function Library({ items, loading, error, onChanged }: { items: CatalogItem[]; loading: boolean; error: Error | null; onChanged: () => void }) {
  const [q, setQ] = useState('');
  const [type, setType] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [genre, setGenre] = useState<string | null>(null);
  const [params, setParams] = useSearchParams();
  const selectedId = params.get('item');
  const select = (id: string | null) => {
    if (id) params.set('item', id);
    else params.delete('item');
    setParams(params, { replace: true });
  };

  const genres = useMemo(() => {
    const m = new Map<string, number>();
    for (const i of items) for (const [g, s] of Object.entries(i.fingerprint?.genres ?? {})) m.set(g, (m.get(g) ?? 0) + s);
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([g]) => g);
  }, [items]);
  const types = useMemo(() => [...new Set(items.map((i) => i.type))], [items]);

  const filtered = items.filter((i) => {
    if (type && i.type !== type) return false;
    if (status && i.status !== status) return false;
    if (genre && !(genre in (i.fingerprint?.genres ?? {}))) return false;
    if (q) {
      const hay = `${i.title} ${i.year ?? ''} ${i.series?.title ?? ''} ${Object.keys(i.fingerprint?.keywords ?? {}).join(' ')} ${i.fingerprint?.synopsis.short ?? ''}`.toLowerCase();
      return q
        .toLowerCase()
        .split(/\s+/)
        .every((t) => hay.includes(t));
    }
    return true;
  });

  return (
    <div className="content content--flush">
      <div style={{ flex: 1, minWidth: 0, overflow: 'auto', padding: 24 }}>
        <div className="stack stack--lg">
          <div className="row" style={{ gap: 10 }}>
            <div className="searchbox" style={{ width: 360 }}>
              <Icon name="search" size={15} />
              <input className="input" placeholder="Search titles, keywords, synopsis…" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <span className="muted small" style={{ marginLeft: 'auto' }}>
              {filtered.length} of {items.length} titles
            </span>
          </div>
          <div className="chiprow">
            <TagChip label="All types" tone={!type ? 'active' : 'default'} onClick={() => setType(null)} />
            {types.map((t) => (
              <TagChip key={t} label={titleCase(t)} tone={type === t ? 'active' : 'default'} onClick={() => setType(type === t ? null : t)} />
            ))}
            <span style={{ width: 8 }} />
            {['ready', 'enriching', 'failed'].map((s) => (
              <TagChip key={s} label={titleCase(s)} tone={status === s ? 'active' : 'default'} onClick={() => setStatus(status === s ? null : s)} />
            ))}
            <span style={{ width: 8 }} />
            {genres.map((g) => (
              <TagChip key={g} label={g} tone={genre === g ? 'active' : 'default'} onClick={() => setGenre(genre === g ? null : g)} />
            ))}
          </div>
          <ErrorNote error={error} />
          {loading ? (
            <div className="posters">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="skeleton" style={{ aspectRatio: '2/3.6', borderRadius: 16 }} />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <EmptyState icon="film" title={items.length ? 'No titles match' : 'Your catalog is empty'} text={items.length ? 'Try clearing a filter or searching for something broader.' : 'Upload a few video URLs to start the enrichment pipeline.'} />
          ) : (
            <div className="posters">
              {filtered.map((i) => (
                <PosterCard key={i.id} item={i} selected={selectedId === i.id} onClick={() => select(selectedId === i.id ? null : i.id)} />
              ))}
            </div>
          )}
        </div>
      </div>
      {selectedId && <Inspector id={selectedId} onClose={() => select(null)} onDeleted={onChanged} />}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Inspector                                                           */
/* ------------------------------------------------------------------ */
export function Inspector({ id, onClose, onDeleted }: { id: string; onClose: () => void; onDeleted?: () => void }) {
  const api = useApi();
  const toast = useToast();
  const b = useQuery(() => api.item(id), [id]);
  const [synLen, setSynLen] = useState<'short' | 'long'>('short');
  const [lang, setLang] = useState('primary');
  const [rerunning, setRerunning] = useState<JobKind | null>(null);

  useEvents((e) => {
    if (e.type === 'job' && e.job.itemId === id) {
      b.setData((prev) => (prev ? { ...prev, item: { ...prev.item, jobs: { ...prev.item.jobs, [e.job.kind]: e.job.status } }, jobs: [...prev.jobs.filter((j) => j.id !== e.job.id), e.job] } : prev));
      if (e.job.status === 'ready' && rerunning === e.job.kind) {
        setRerunning(null);
        void b.refetch();
      }
    }
  }, [rerunning]);

  const fp: Fingerprint | undefined = b.data?.fingerprint ?? b.data?.item.fingerprint;
  const item = b.data?.item;
  const translated = Object.keys(fp?.synopsis.translations ?? {}).sort((a, b) => {
    const ia = LANG_ORDER.indexOf(a);
    const ib = LANG_ORDER.indexOf(b);
    return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib) || a.localeCompare(b);
  });
  const langs = ['primary', ...translated];
  const synopsis = lang === 'primary' ? fp?.synopsis[synLen] : fp?.synopsis.translations?.[lang]?.[synLen];
  const rtl = lang !== 'primary' ? RTL_LANGS.has(lang) : RTL_LANGS.has(fp?.language.primary ?? '');

  const rerun = async (kind: JobKind) => {
    setRerunning(kind);
    try {
      await api.rerunJob(id, kind);
      toast.push(`Re-running ${kind} on ${item?.title ?? 'item'}`, 'ai');
    } catch (e) {
      setRerunning(null);
      toast.push((e as Error).message, 'error');
    }
  };

  return (
    <aside className="inspector">
      <div className="inspector__head">
        <div className="row" style={{ alignItems: 'flex-start' }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            {b.loading && !item ? (
              <Skeleton h={20} w="70%" />
            ) : (
              <>
                <h2 style={{ fontSize: 17, lineHeight: 1.3 }}>{item?.title}</h2>
                <div className="row small muted" style={{ marginTop: 4, gap: 6, flexWrap: 'wrap' }}>
                  {item?.year && <span>{item.year}</span>}
                  <span>{item ? titleCase(item.type) : ''}</span>
                  {item?.series && (
                    <span>
                      · {item.series.title} S{item.series.season ?? '?'}E{item.series.episode ?? '?'}
                    </span>
                  )}
                  <span>· {duration(item?.durationSec)}</span>
                  {item?.fps && <span>· {item.fps} fps</span>}
                  {item?.width && (
                    <span>
                      · {item.width}×{item.height}
                    </span>
                  )}
                </div>
              </>
            )}
          </div>
          <Button icon="x" variant="ghost" size="sm" onClick={onClose} aria-label="Close inspector" />
        </div>
      </div>
      <div className="inspector__body">
        {item && (
          <div style={{ borderRadius: 12, overflow: 'hidden', aspectRatio: '16/9', position: 'relative', border: '1px solid var(--hairline)' }}>
            <PosterArt item={item} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            <div style={{ position: 'absolute', top: 8, left: 8 }}>
              <StatusPill status={item.status} />
            </div>
          </div>
        )}
        <ErrorNote error={b.error} />
        {b.loading && !fp && (
          <div className="stack">
            <Skeleton h={60} />
            <Skeleton h={28} />
            <Skeleton h={28} />
          </div>
        )}
        {!b.loading && !fp && item && <EmptyState icon="sparkle" title="Fingerprint pending" text="Pegasus has not finished analysing this title yet. Genres, moods and synopsis appear when the fingerprint job completes." style={{ minHeight: 120 }} />}
        {fp && (
          <>
            <div className="section">
              <div className="section__title">
                <span>Synopsis</span>
                <span className="row" style={{ gap: 6, minWidth: 0 }}>
                  <Tabs<'short' | 'long'> tabs={[{ id: 'short', label: 'Short' }, { id: 'long', label: 'Long' }]} value={synLen} onChange={setSynLen} />
                  <select className="select select--sm" value={lang} onChange={(e) => setLang(e.target.value)} style={{ width: 'auto', maxWidth: 120 }} aria-label="Synopsis language" title="Synopsis language — 8 translations from the same Pegasus call">
                    {langs.map((l) => (
                      <option key={l} value={l}>
                        {l === 'primary' ? langName(fp.language.primary) : langName(l)}
                      </option>
                    ))}
                  </select>
                </span>
              </div>
              <p
                style={{ color: 'var(--heading)', fontSize: 13.5, lineHeight: 1.6, textAlign: rtl ? 'right' : undefined, unicodeBidi: 'plaintext' }}
                dir={rtl ? 'rtl' : 'ltr'}
                lang={lang === 'primary' ? fp.language.primary : lang}
              >
                {synopsis}
              </p>
              {lang !== 'primary' && (
                <span className="muted" style={{ fontSize: 11 }}>
                  Translated by Pegasus in the same analyze call · {translated.length} languages
                </span>
              )}
            </div>
            <FacetSection title="Genres" labels={fp.genres} />
            <FacetSection title="Keywords" labels={fp.keywords} max={10} />
            <FacetSection title="Moods" labels={fp.moods} />
            <FacetSection title="Mood tags" labels={fp.moodTags} />
            <FacetSection title="Themes" labels={fp.themes} />
            <div className="section">
              <div className="section__title">
                <span>Characters</span>
                <span className="muted" style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>
                  prominence
                </span>
              </div>
              {fp.characters.length === 0 && <span className="muted small">No named characters detected</span>}
              {[...fp.characters]
                .sort((a, c) => c.prominence - a.prominence)
                .map((c) => (
                  <div key={c.name} className="charbar">
                    <span className="charbar__name">{c.name}</span>
                    <Meter value={c.prominence} color="#8cbaff" />
                    <span className="num small" style={{ color: 'var(--heading)', textAlign: 'right' }}>
                      {c.prominence.toFixed(2)}
                    </span>
                    <span className="charbar__desc" title={c.description}>
                      {c.description}
                    </span>
                  </div>
                ))}
            </div>
            <div className="section">
              <div className="section__title">
                <span>Pacing</span>
                <span className="num" style={{ color: 'var(--heading)', textTransform: 'none', letterSpacing: 0 }}>
                  {fp.pacing.score.toFixed(2)}
                </span>
              </div>
              <div className="row" style={{ gap: 8 }}>
                <span className="muted" style={{ fontSize: 11 }}>
                  slow
                </span>
                <Meter value={fp.pacing.score} color="linear-gradient(90deg,#2fbfa6,#f56300)" />
                <span className="muted" style={{ fontSize: 11 }}>
                  frenetic
                </span>
              </div>
              <p className="small muted">{fp.pacing.rationale}</p>
            </div>
            <div className="section">
              <div className="section__title">
                <span>Suggested rating</span>
              </div>
              <div className="row" style={{ alignItems: 'flex-start' }}>
                <span
                  style={{
                    fontWeight: 800,
                    fontSize: 22,
                    color: '#fff',
                    border: '2px solid rgba(255,255,255,.7)',
                    borderRadius: 8,
                    padding: '0 8px',
                    lineHeight: '30px',
                    letterSpacing: '-0.02em',
                  }}
                >
                  {fp.audienceRating.suggested}
                </span>
                <p className="small muted" style={{ flex: 1 }}>
                  {fp.audienceRating.rationale}
                </p>
              </div>
            </div>
            <div className="section">
              <div className="section__title">
                <span>Language</span>
              </div>
              <div className="chiprow">
                <TagChip label={langName(fp.language.primary)} tone="active" />
                {fp.language.others?.map((l) => <TagChip key={l} label={langName(l)} />)}
              </div>
            </div>
          </>
        )}
        {item && (
          <div className="section">
            <div className="section__title">
              <span>Enrichment jobs</span>
              <span className="muted" style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>
                {fp?.model ?? ''}
              </span>
            </div>
            <div className="jobstrip">
              {JOB_ORDER.map((k) => (
                <span key={k} className={`jobstrip__item ${item.jobs[k] ?? 'none'}`} title={`${k}: ${item.jobs[k] ?? 'not run'}`}>
                  <i />
                  {k}
                </span>
              ))}
            </div>
            <div className="chiprow" style={{ marginTop: 4 }}>
              {(['fingerprint', 'emotions', 'markers', 'adbreaks', 'safety', 'thumbnails', 'clips'] as JobKind[]).map((k) => (
                <Button key={k} variant="ghost" size="sm" icon="refresh" loading={rerunning === k || item.jobs[k] === 'running'} onClick={() => void rerun(k)} title={`Re-run ${k} (one Pegasus call)`}>
                  {k}
                </Button>
              ))}
            </div>
          </div>
        )}
        {item && (
          <div className="section">
            <div className="section__title">
              <span>Source</span>
            </div>
            <div className="kv">
              <dt>URL</dt>
              <dd title={item.sourceUrl}>
                <a href={item.sourceUrl} target="_blank" rel="noreferrer">
                  {item.sourceUrl.replace(/^https?:\/\//, '').slice(0, 40)}
                  {item.sourceUrl.length > 48 ? '…' : ''}
                </a>
              </dd>
              {item.upstream?.assetId && (
                <>
                  <dt>Asset</dt>
                  <dd className="mono">{item.upstream.assetId}</dd>
                </>
              )}
              {item.upstream?.indexedAssetId && (
                <>
                  <dt>Indexed</dt>
                  <dd className="mono">{item.upstream.indexedAssetId}</dd>
                </>
              )}
              <dt>Added</dt>
              <dd>{new Date(item.createdAt).toLocaleDateString()}</dd>
            </div>
            <Button
              variant="danger"
              size="sm"
              icon="trash"
              style={{ alignSelf: 'flex-start', marginTop: 6 }}
              onClick={async () => {
                if (!confirm(`Remove "${item.title}" from the catalog?`)) return;
                await api.deleteItem(item.id);
                toast.push('Removed from catalog', 'info');
                onClose();
                onDeleted?.();
              }}
            >
              Remove
            </Button>
          </div>
        )}
      </div>
    </aside>
  );
}

function FacetSection({ title, labels, max = 8 }: { title: string; labels: Record<string, number>; max?: number }) {
  return (
    <div className="section">
      <div className="section__title">
        <span>{title}</span>
        <span className="muted" style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>
          {Object.keys(labels).length}
        </span>
      </div>
      <TagRow labels={labels} max={max} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Add assets modal: paste URLs, or pick from the TwelveLabs account    */
/* ------------------------------------------------------------------ */
type AddTab = 'urls' | 'twelvelabs';

function addTabFromParam(v: string | null): AddTab | null {
  if (v === '1' || v === 'urls') return 'urls';
  if (v === 'twelvelabs') return 'twelvelabs';
  return null;
}

function AddAssetsModal({
  open,
  initialTab,
  onClose,
  onSubmit,
  onImported,
}: {
  open: boolean;
  initialTab: AddTab;
  onClose: () => void;
  onSubmit: (inputs: CatalogItemInput[]) => Promise<void>;
  onImported: (result: ImportResult) => void;
}) {
  const api = useApi();
  const [tab, setTab] = useState<AddTab>(initialTab);
  const [text, setText] = useState('');
  const [type, setType] = useState<CatalogItemInput['type']>('movie');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  // TwelveLabs tab state.
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [importing, setImporting] = useState<'title' | 'ad' | null>(null);
  const [problems, setProblems] = useState<ImportResult['errors']>([]);
  const assets = useQuery(() => api.twelvelabsAssets({ pageLimit: 100 }), [open, tab], { enabled: open && tab === 'twelvelabs' });

  useEffect(() => {
    if (open) {
      setTab(initialTab);
      setErr(null);
      setProblems([]);
      setSelected(new Set());
    }
  }, [open, initialTab]);

  const urls = text
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => /^https?:\/\//i.test(l));
  const titleFromUrl = (u: string) => {
    try {
      const p = new URL(u);
      if (/youtu/.test(p.hostname)) return `YouTube ${p.searchParams.get('v') ?? p.pathname.slice(1)}`;
      const last = decodeURIComponent(p.pathname.split('/').filter(Boolean).pop() ?? p.hostname);
      return titleCase(last.replace(/\.[a-z0-9]+$/i, '').replace(/[-_.]+/g, ' '));
    } catch {
      return u;
    }
  };

  const rows = assets.data?.assets ?? [];
  const importable = rows.filter((a) => !a.linked && a.status === 'ready');
  const chosen = importable.filter((a) => selected.has(a._id));
  const toggle = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  const allChosen = importable.length > 0 && importable.every((a) => selected.has(a._id));

  const runImport = async (as: 'title' | 'ad') => {
    if (!chosen.length) return;
    setImporting(as);
    setProblems([]);
    try {
      const result = await api.importAssets(chosen.map((a) => ({ assetId: a._id, as, ...(as === 'title' ? { type } : {}) })));
      setProblems(result.errors);
      setSelected(new Set());
      onImported(result);
      await assets.refetch();
      if (result.errors.length === 0) onClose();
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setImporting(null);
    }
  };

  const summary = useMemo(() => {
    const total = rows.reduce((acc, a) => acc + (a.duration ?? 0), 0);
    return { count: assets.data?.pageInfo.totalResults ?? rows.length, hours: total / 3600, linked: rows.filter((a) => a.linked).length, ready: rows.filter((a) => a.status === 'ready').length };
  }, [rows, assets.data]);

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide={tab === 'twelvelabs'}
      title={
        <span className="row" style={{ gap: 14 }}>
          <span>Add assets</span>
          <Tabs<AddTab>
            tabs={[
              { id: 'urls', label: 'From URLs', icon: 'upload' },
              { id: 'twelvelabs', label: 'From TwelveLabs', icon: 'layers', count: assets.data?.pageInfo.totalResults },
            ]}
            value={tab}
            onChange={setTab}
          />
        </span>
      }
      footer={
        tab === 'urls' ? (
          <>
            <Button variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button
              variant="primary"
              icon="upload"
              disabled={!urls.length}
              loading={busy}
              onClick={async () => {
                setBusy(true);
                setErr(null);
                try {
                  await onSubmit(urls.map((u) => ({ title: titleFromUrl(u), sourceUrl: u, type })));
                  setText('');
                } catch (e) {
                  setErr((e as Error).message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              Ingest {urls.length ? `${urls.length} asset${urls.length === 1 ? '' : 's'}` : ''}
            </Button>
          </>
        ) : (
          <>
            <span className="small muted" style={{ marginRight: 'auto' }}>
              {chosen.length ? `${chosen.length} selected` : importable.length ? `${importable.length} asset${importable.length === 1 ? '' : 's'} available to import` : 'Every ready asset is already linked'}
            </span>
            <Button variant="ghost" onClick={onClose}>
              Close
            </Button>
            <Button variant="default" icon="tag" disabled={!chosen.length || importing !== null} loading={importing === 'ad'} onClick={() => void runImport('ad')} title="Create ad creatives that stream from the asset's HLS manifest">
              Import as ad creatives
            </Button>
            <Button variant="primary" icon="film" disabled={!chosen.length || importing !== null} loading={importing === 'title'} onClick={() => void runImport('title')} title="Create catalog titles and start enrichment (index only — the asset is not re-uploaded)">
              Import as titles
            </Button>
          </>
        )
      }
    >
      {tab === 'urls' && (
        <>
          <p className="small muted">
            One publicly reachable video URL per line — mp4, mov, HLS manifest, or a YouTube / Vimeo page. Direct media URLs go straight to TwelveLabs; page URLs are fetched to the SGEUL server first (yt-dlp), since the asset API only takes direct media. Then Marengo indexes it and the nine-stage Pegasus pipeline runs.
          </p>
          <div className="field">
            <label>Video URLs</label>
            <textarea className="textarea" rows={7} value={text} onChange={(e) => setText(e.target.value)} placeholder={'https://cdn.example.com/season1/ep01.mp4\nhttps://www.youtube.com/watch?v=…'} spellCheck={false} />
          </div>
          <div className="row" style={{ gap: 14 }}>
            <div className="field" style={{ width: 200 }}>
              <label>Type</label>
              <select className="select" value={type} onChange={(e) => setType(e.target.value as CatalogItemInput['type'])}>
                {(['movie', 'episode', 'short', 'clip', 'promo', 'other'] as const).map((t) => (
                  <option key={t} value={t}>
                    {titleCase(t)}
                  </option>
                ))}
              </select>
            </div>
            <div className="small muted" style={{ alignSelf: 'flex-end', paddingBottom: 8 }}>
              {urls.length ? `${urls.length} valid URL${urls.length === 1 ? '' : 's'} detected · titles inferred from the path, edit later` : 'Paste URLs to continue'}
            </div>
          </div>
        </>
      )}
      {tab === 'twelvelabs' && (
        <div className="stack">
          <div className="row" style={{ gap: 14, alignItems: 'flex-end', flexWrap: 'wrap' }}>
            <p className="small muted" style={{ flex: 1, minWidth: 320, margin: 0 }}>
              Everything already uploaded to the connected TwelveLabs account (<code className="mono">GET /v1.3/assets</code>). Importing links the asset — titles are indexed in place and enriched without re-uploading; creatives stream from the asset's HLS manifest.
            </p>
            <div className="row" style={{ gap: 8 }}>
              <div className="field" style={{ width: 150, margin: 0 }}>
                <label>Import titles as</label>
                <select className="select select--sm" value={type} onChange={(e) => setType(e.target.value as CatalogItemInput['type'])} aria-label="Type for imported titles">
                  {(['movie', 'episode', 'short', 'clip', 'promo', 'other'] as const).map((t) => (
                    <option key={t} value={t}>
                      {titleCase(t)}
                    </option>
                  ))}
                </select>
              </div>
              <Button variant="ghost" size="sm" icon="refresh" loading={assets.loading} onClick={() => void assets.refetch()} title="Re-read the account listing">
                Refresh
              </Button>
            </div>
          </div>
          {assets.data && (
            <div className="row small muted" style={{ gap: 14 }}>
              <span>
                <b style={{ color: 'var(--heading)' }}>{summary.count}</b> asset{summary.count === 1 ? '' : 's'}
              </span>
              <span>· {summary.hours.toFixed(1)} h of video</span>
              <span>· {summary.linked} linked to this workspace</span>
              <span>· {summary.ready} ready</span>
            </div>
          )}
          <ErrorNote error={assets.error} />
          {assets.loading && !assets.data && (
            <div className="stack">
              <Skeleton h={40} />
              <Skeleton h={40} />
              <Skeleton h={40} />
            </div>
          )}
          {assets.data && rows.length === 0 && <EmptyState icon="layers" title="No assets in this account" text="Upload from the URLs tab, or through the TwelveLabs console or Jockey, then refresh." style={{ minHeight: 140 }} />}
          {rows.length > 0 && (
            <div style={{ overflow: 'auto', maxHeight: '52vh', border: '1px solid var(--hairline)', borderRadius: 12 }}>
              <table className="table assets-table">
                <thead>
                  <tr>
                    <th style={{ width: 36 }}>
                      <input
                        type="checkbox"
                        className="assets-check"
                        aria-label="Select every importable asset"
                        checked={allChosen}
                        disabled={importable.length === 0}
                        onChange={() => setSelected(allChosen ? new Set() : new Set(importable.map((a) => a._id)))}
                      />
                    </th>
                    <th style={{ width: 72 }}></th>
                    <th>Filename</th>
                    <th>Duration</th>
                    <th>Frame</th>
                    <th>Size</th>
                    <th>Uploaded</th>
                    <th>Status</th>
                    <th>In workspace</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((a) => (
                    <AssetRow key={a._id} asset={a} checked={selected.has(a._id)} onToggle={() => toggle(a._id)} problem={problems.find((p) => p.assetId === a._id)?.error.message} />
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      {err && <ErrorNote error={new Error(err)} />}
    </Modal>
  );
}

function AssetRow({ asset: a, checked, onToggle, problem }: { asset: LinkedAsset; checked: boolean; onToggle: () => void; problem?: string }) {
  const [thumbOk, setThumbOk] = useState(true);
  const importable = !a.linked && a.status === 'ready';
  const mb = a.size ? a.size / 1024 / 1024 : 0;
  return (
    <tr className={importable ? 'is-importable' : undefined} onClick={importable ? onToggle : undefined} style={{ cursor: importable ? 'pointer' : 'default', opacity: a.status === 'ready' ? 1 : 0.7 }}>
      <td onClick={(e) => e.stopPropagation()}>
        {importable ? (
          <input type="checkbox" className="assets-check" checked={checked} onChange={onToggle} aria-label={`Import ${a.filename}`} />
        ) : (
          <span className="muted" style={{ display: 'inline-block', width: 15 }} />
        )}
      </td>
      <td>
        <span className="adthumb" title={a.filename}>
          <Icon name="film" size={14} />
          {a.thumbnail?.representative_url && thumbOk && <img src={a.thumbnail.representative_url} alt="" loading="lazy" onError={() => setThumbOk(false)} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />}
        </span>
      </td>
      <td style={{ fontFamily: 'inherit', whiteSpace: 'normal', minWidth: 160, maxWidth: 240 }}>
        <div style={{ color: 'var(--heading)', fontWeight: 600 }} className="truncate" title={a.filename}>
          {a.filename}
        </div>
        <div className="mono muted truncate" style={{ fontSize: 11 }} title={`${a._id} · uploaded via ${a.method}`}>
          {a._id} · {a.method}
        </div>
        {problem && (
          <div className="small" style={{ color: '#ff8a97', marginTop: 2 }}>
            {problem}
          </div>
        )}
      </td>
      <td className="num" style={{ whiteSpace: 'nowrap' }}>{a.duration != null ? mmss(a.duration) : '—'}</td>
      <td className="num" style={{ whiteSpace: 'nowrap' }} title={a.fps ? `${Math.round(a.fps * 100) / 100} fps` : undefined}>
        {a.width && a.height ? `${a.width}×${a.height}` : '—'}
      </td>
      <td className="num" style={{ whiteSpace: 'nowrap' }}>{mb ? `${mb < 10 ? mb.toFixed(1) : Math.round(mb)} MB` : '—'}</td>
      <td style={{ whiteSpace: 'nowrap' }}>{new Date(a.created_at).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}</td>
      <td>
        <StatusPill status={a.status} tone={a.status === 'ready' ? 'green' : a.status === 'failed' ? 'red' : 'orange'} />
      </td>
      <td>
        {a.linked ? (
          <StatusPill status={a.linked.kind} tone={a.linked.kind === 'ad' ? 'violet' : 'blue'} dot={false} style={{ maxWidth: 200 }}>
            <Icon name={a.linked.kind === 'ad' ? 'tag' : 'film'} size={11} />
            <span className="truncate">linked to {a.linked.title}</span>
          </StatusPill>
        ) : a.status === 'ready' ? (
          <span className="small muted">{checked ? 'selected' : 'not imported'}</span>
        ) : (
          <span className="small muted">wait for processing</span>
        )}
      </td>
    </tr>
  );
}

/* ------------------------------------------------------------------ */
/* Smart lists                                                         */
/* ------------------------------------------------------------------ */
type Source = SmartList['source'];

function useVocab(items: CatalogItem[]) {
  return useMemo(() => {
    const v: Record<SmartListRule['facet'], Map<string, { n: number; avg: number }>> = { genres: new Map(), keywords: new Map(), moods: new Map(), moodTags: new Map(), themes: new Map() };
    for (const i of items) {
      const fp = i.fingerprint;
      if (!fp) continue;
      for (const f of FACETS) {
        for (const [label, s] of Object.entries(fp[f] ?? {})) {
          const cur = v[f].get(label) ?? { n: 0, avg: 0 };
          v[f].set(label, { n: cur.n + 1, avg: (cur.avg * cur.n + s) / (cur.n + 1) });
        }
      }
    }
    return v;
  }, [items]);
}

function matchRules(fp: Fingerprint | undefined, rules: SmartListRule[]) {
  if (!fp) return false;
  return rules.every((r) => {
    const s = fp[r.facet]?.[r.label];
    return s != null && s >= r.min && s <= r.max;
  });
}

function SmartLists({ items, lists, loading, onChanged }: { items: CatalogItem[]; lists: SmartList[]; loading: boolean; onChanged: () => void }) {
  const api = useApi();
  const toast = useToast();
  const vocab = useVocab(items);
  const [selected, setSelected] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [source, setSource] = useState<Source>('rules');
  const [rules, setRules] = useState<SmartListRule[]>([{ facet: 'genres', label: '', min: 0.6, max: 1 }]);
  const [query, setQuery] = useState('');
  const [saving, setSaving] = useState(false);
  const [nlPreview, setNlPreview] = useState<CatalogItem[] | null>(null);
  const [nlBusy, setNlBusy] = useState(false);

  const active = lists.find((l) => l.id === selected) ?? null;
  const byId = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);

  const preview = useMemo(() => {
    if (source === 'rules') {
      const valid = rules.filter((r) => r.label);
      if (!valid.length) return [];
      return items.filter((i) => matchRules(i.fingerprint, valid));
    }
    return nlPreview ?? [];
  }, [source, rules, items, nlPreview]);

  const runNl = useCallback(async () => {
    if (!query.trim()) return;
    setNlBusy(true);
    try {
      // Preview through search-by-list semantics: create nothing, reuse query matcher via a throwaway list on the static provider is not possible,
      // so we rank locally with the same signal (keywords/moods/synopsis).
      const q = query.toLowerCase().split(/\s+/).filter((t) => t.length > 2);
      const ranked = items
        .map((i) => {
          const fp = i.fingerprint;
          if (!fp) return { i, s: 0 };
          const text = `${fp.synopsis.short} ${fp.synopsis.long} ${Object.keys(fp.keywords).join(' ')} ${Object.keys(fp.moods).join(' ')} ${Object.keys(fp.moodTags).join(' ')} ${Object.keys(fp.themes).join(' ')} ${Object.keys(fp.genres).join(' ')}`.toLowerCase();
          const m = q.filter((t) => text.includes(t)).length;
          return { i, s: q.length ? m / q.length : 0 };
        })
        .filter((x) => x.s > 0)
        .sort((a, b) => b.s - a.s)
        .map((x) => x.i);
      await new Promise((r) => setTimeout(r, 500));
      setNlPreview(ranked);
    } finally {
      setNlBusy(false);
    }
  }, [query, items]);

  const save = async () => {
    setSaving(true);
    try {
      const l = await api.createList({ name: name || (source === 'rules' ? rules.filter((r) => r.label).map((r) => r.label).join(' + ') : query.slice(0, 40)), source, rules: source === 'rules' ? rules.filter((r) => r.label) : undefined, query: source === 'query' ? query : undefined });
      toast.push(`Saved "${l.name}" with ${l.itemIds.length} titles`, source === 'query' ? 'ai' : 'success');
      onChanged();
      setSelected(l.id);
      setName('');
    } catch (e) {
      toast.push((e as Error).message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="content">
      <div className="grid" style={{ gridTemplateColumns: '320px 1fr', alignItems: 'start' }}>
        <div className="stack">
          <div className="row row--between">
            <span className="eyebrow">Lists</span>
            <Button size="sm" variant="ghost" icon="plus" onClick={() => setSelected(null)}>
              New
            </Button>
          </div>
          {loading && <Skeleton h={60} />}
          {!loading && lists.length === 0 && <EmptyState icon="list" title="No smart lists yet" text="Build one from rules, describe it in plain language, or let AI curate the catalog." style={{ minHeight: 120 }} />}
          {lists.map((l) => (
            <div key={l.id} className={`listrow${selected === l.id ? ' is-active' : ''}`} onClick={() => setSelected(l.id)}>
              <div className="row row--between">
                <span className="truncate" style={{ color: 'var(--heading)', fontWeight: 600 }}>
                  {l.name}
                </span>
                <StatusPill status={l.source} tone={l.source === 'ai' ? 'violet' : l.source === 'query' ? 'violet' : 'neutral'} dot={false}>
                  {l.source === 'ai' ? '✦ AI' : l.source === 'query' ? '✦ NL' : 'rules'}
                </StatusPill>
              </div>
              <div className="row small muted">
                <span>{l.itemIds.length} title{l.itemIds.length === 1 ? '' : 's'}</span>
                {l.coverage != null && <span>· {pct(l.coverage)} of catalog</span>}
              </div>
              <Meter value={l.coverage ?? 0} thin color={l.source === 'rules' ? '#0068e0' : '#6d3fd4'} />
            </div>
          ))}
        </div>

        {active ? (
          <Card
            title={active.name}
            sub={active.description ?? (active.query ? `“${active.query}”` : active.rules?.map((r) => `${FACET_LABEL[r.facet]} ${r.label} ${r.min.toFixed(2)}–${r.max.toFixed(2)}`).join(' · '))}
            actions={
              <Button
                variant="danger"
                size="sm"
                icon="trash"
                onClick={async () => {
                  await api.deleteList(active.id);
                  toast.push('List deleted');
                  setSelected(null);
                  onChanged();
                }}
              >
                Delete
              </Button>
            }
          >
            <div className="row small muted" style={{ marginBottom: 12 }}>
              <span>{active.itemIds.length} title{active.itemIds.length === 1 ? '' : 's'}</span>
              <span>· coverage {pct(active.coverage ?? 0)}</span>
              <span>· updated {new Date(active.updatedAt).toLocaleString()}</span>
            </div>
            <ItemGrid items={active.itemIds.map((id) => byId.get(id)).filter((x): x is CatalogItem => !!x)} />
          </Card>
        ) : (
          <Card title="New smart list" icon="list" sub="Membership is recomputed from fingerprints whenever the catalog changes">
            <div className="stack stack--lg">
              <div className="row" style={{ gap: 14, alignItems: 'flex-end' }}>
                <div className="field" style={{ flex: 1 }}>
                  <label>Name</label>
                  <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Dark thrillers for late-night" />
                </div>
                <div className="field">
                  <label>Source</label>
                  <Tabs<Source>
                    tabs={[
                      { id: 'rules', label: 'Rules' },
                      { id: 'query', label: 'Natural language', icon: 'sparkle' },
                      { id: 'ai', label: 'AI', icon: 'sparkle' },
                    ]}
                    value={source}
                    onChange={setSource}
                  />
                </div>
              </div>

              {source === 'rules' && (
                <div className="stack">
                  {rules.map((r, idx) => (
                    <div key={idx} className="rule">
                      <select className="select select--sm" value={r.facet} onChange={(e) => setRules(rules.map((x, i) => (i === idx ? { ...x, facet: e.target.value as SmartListRule['facet'], label: '' } : x)))}>
                        {FACETS.map((f) => (
                          <option key={f} value={f}>
                            {FACET_LABEL[f]}
                          </option>
                        ))}
                      </select>
                      <Typeahead value={r.label} options={[...vocab[r.facet].entries()].sort((a, b) => b[1].n - a[1].n)} onChange={(label) => setRules(rules.map((x, i) => (i === idx ? { ...x, label } : x)))} placeholder={`Type a ${FACET_LABEL[r.facet].toLowerCase()}…`} />
                      <RangeSlider compact value={[r.min, r.max]} onChange={([min, max]) => setRules(rules.map((x, i) => (i === idx ? { ...x, min, max } : x)))} />
                      <Button icon="x" variant="ghost" size="sm" onClick={() => setRules(rules.filter((_, i) => i !== idx))} disabled={rules.length === 1} aria-label="Remove rule" />
                    </div>
                  ))}
                  <Button variant="ghost" size="sm" icon="plus" style={{ alignSelf: 'flex-start' }} onClick={() => setRules([...rules, { facet: 'moods', label: '', min: 0.5, max: 1 }])}>
                    Add rule
                  </Button>
                </div>
              )}

              {source === 'query' && (
                <div className="stack">
                  <div className="field">
                    <label className="row" style={{ gap: 6 }}>
                      <Icon name="sparkle" size={12} style={{ color: '#c8b0ff' }} /> Describe the list
                    </label>
                    <textarea className="textarea" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Slow-burn dramas about grief with a hopeful ending, suitable for a Sunday evening slot" style={{ borderColor: 'rgba(109,63,212,.5)' }} />
                  </div>
                  <div className="row">
                    <Button variant="ai" size="sm" loading={nlBusy} onClick={() => void runNl()} disabled={!query.trim()}>
                      Preview matches
                    </Button>
                    <span className="small muted">Marengo text embedding vs. video embeddings (cosine), keyword fallback</span>
                  </div>
                </div>
              )}

              {source === 'ai' && (
                <div className="card card--soft" style={{ padding: 16 }}>
                  <div className="row" style={{ gap: 10 }}>
                    <Icon name="sparkle" size={16} style={{ color: '#c8b0ff' }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ color: 'var(--heading)', fontWeight: 600 }}>AI-curated lists are generated for the whole catalog</div>
                      <div className="small muted">k-means over Marengo embeddings, labelled by the top shared moods and keywords. Run it from the AI curation tab.</div>
                    </div>
                  </div>
                </div>
              )}

              {source !== 'ai' && (
                <div className="section">
                  <div className="section__title">
                    <span>Live preview</span>
                    <span style={{ textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>
                      {preview.length} of {items.length} titles · {items.length ? pct(preview.length / items.length) : '0%'}
                    </span>
                  </div>
                  <Meter value={items.length ? preview.length / items.length : 0} thin color={source === 'rules' ? '#0068e0' : '#6d3fd4'} />
                  {preview.length ? (
                    <ItemGrid items={preview} />
                  ) : (
                    <div className="muted small" style={{ padding: '10px 0' }}>
                      {source === 'rules' ? 'Pick a label to see matching titles.' : 'Run a preview to see matching titles.'}
                    </div>
                  )}
                </div>
              )}

              <div className="row" style={{ justifyContent: 'flex-end' }}>
                <Button variant={source === 'query' ? 'ai' : 'primary'} loading={saving} disabled={source === 'ai' || (source === 'rules' ? !rules.some((r) => r.label) : !query.trim())} onClick={() => void save()}>
                  Save list
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

function ItemGrid({ items }: { items: CatalogItem[] }) {
  const nav = useNavigate();
  if (!items.length) return <span className="muted small">No titles</span>;
  return (
    <div className="minigrid">
      {items.map((i) => (
        <div key={i.id} className="minigrid__item" title={i.title} onClick={() => nav(`/editorial?item=${i.id}`)} style={{ cursor: 'pointer' }}>
          <PosterArt item={i} style={{ width: '100%', height: '100%', objectFit: 'cover' }} showFrame={false} />
          <span>{i.title}</span>
        </div>
      ))}
    </div>
  );
}

function Typeahead({ value, options, onChange, placeholder }: { value: string; options: Array<[string, { n: number; avg: number }]>; onChange: (v: string) => void; placeholder?: string }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  const filtered = options.filter(([l]) => l.toLowerCase().includes(text.toLowerCase())).slice(0, 12);
  return (
    <div className="typeahead">
      <input
        className="input input--sm"
        value={text}
        placeholder={placeholder}
        onChange={(e) => {
          setText(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && filtered[0]) {
            onChange(filtered[0][0]);
            setOpen(false);
          }
        }}
      />
      {open && filtered.length > 0 && (
        <div className="typeahead__list">
          {filtered.map(([l, m]) => (
            <button
              key={l}
              onMouseDown={(e) => {
                e.preventDefault();
                onChange(l);
                setOpen(false);
              }}
            >
              <span>{l}</span>
              <small>
                {m.n} title{m.n === 1 ? '' : 's'} · avg {m.avg.toFixed(2)}
              </small>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* AI curation                                                         */
/* ------------------------------------------------------------------ */
function Curation({ items, lists, onChanged }: { items: CatalogItem[]; lists: SmartList[]; onChanged: () => void }) {
  const api = useApi();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [fresh, setFresh] = useState<SmartList[] | null>(null);
  const byId = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);
  const ai = fresh ?? lists.filter((l) => l.source === 'ai');

  const run = async () => {
    setBusy(true);
    try {
      const out = await api.curate();
      setFresh(out);
      toast.push(`Curated ${out.length} lists across ${items.length} titles`, 'ai');
      onChanged();
    } catch (e) {
      toast.push((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="content">
      <div className="stack stack--lg" style={{ maxWidth: 1300 }}>
        <Card soft>
          <div className="row" style={{ gap: 20 }}>
            <div style={{ flex: 1 }}>
              <h2 className="row" style={{ gap: 8 }}>
                <Icon name="sparkle" size={16} style={{ color: '#c8b0ff' }} /> Curate the whole catalog
              </h2>
              <p className="small muted" style={{ marginTop: 4, maxWidth: 720 }}>
                Clusters titles with k-means over their Marengo 3.5 video embeddings (k = clamp(items/6, 3, 12)), then names each cluster from the moods and keywords its members share. Lists are saved as AI-sourced smart lists you can edit or delete.
              </p>
            </div>
            <Button variant="ai" size="lg" loading={busy} onClick={() => void run()} disabled={items.length === 0}>
              Curate catalog
            </Button>
          </div>
        </Card>
        {busy && (
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} h={180} style={{ borderRadius: 20 }} />
            ))}
          </div>
        )}
        {!busy && ai.length === 0 && <EmptyState icon="sparkle" title="Nothing curated yet" text="Run curation to generate themed lists across the catalog." />}
        {!busy && ai.length > 0 && (
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))' }}>
            {ai.map((l) => (
              <Card key={l.id} title={l.name} sub={l.description}>
                <div className="row small muted" style={{ marginBottom: 6 }}>
                  <span>{l.itemIds.length} title{l.itemIds.length === 1 ? '' : 's'}</span>
                  <span style={{ marginLeft: 'auto', color: 'var(--heading)' }} className="num">
                    {pct(l.coverage ?? 0)} coverage
                  </span>
                </div>
                <Meter value={l.coverage ?? 0} color="#6d3fd4" />
                <div style={{ marginTop: 12 }}>
                  <ItemGrid items={l.itemIds.map((id) => byId.get(id)).filter((x): x is CatalogItem => !!x)} />
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

