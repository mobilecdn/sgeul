/**
 * End-to-end API tests in mock mode against a temporary store.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import type { Server } from 'node:http';
import { createApp, type App } from '../src/server.js';
import { loadConfig } from '../src/config.js';

let app: App;
let server: Server;
let base: string;
let dir: string;

const json = async (path: string, init: RequestInit = {}) => {
  const res = await fetch(`${base}${path}`, { ...init, headers: { 'content-type': 'application/json', ...(init.headers ?? {}) } });
  const text = await res.text();
  return { status: res.status, body: text ? (JSON.parse(text) as any) : undefined, text, headers: res.headers };
};

before(async () => {
  dir = await mkdtemp(join(tmpdir(), 'twelve-api-'));
  const config = loadConfig({ ...process.env, TWELVELABS_API_KEY: '', STORE_PATH: join(dir, 'store.json'), MOCK_LATENCY_MS: '0', PORT: '0' });
  // STORE_PATH is resolved against the repo root; an absolute path stays absolute.
  app = await createApp(config);
  server = app.app.listen(0);
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
  await app.runner.idle();
});

after(async () => {
  server.close();
  await app.close();
  await rm(dir, { recursive: true, force: true });
});

test('health reports mock mode and models', async () => {
  const { status, body } = await json('/health');
  assert.equal(status, 200);
  assert.equal(body.mode, 'mock');
  assert.equal(body.models.analyze, 'pegasus1.5');
});

test('seed is imported; list responses omit embeddings', async () => {
  const { body } = await json('/catalog');
  // Three Blender shorts + David and Goliath + the Grok 4 promo, all with real Pegasus fingerprints.
  assert.equal(body.length, 5);
  for (const item of body) {
    if (!item.fingerprint) continue;
    assert.equal(item.fingerprint.hasEmbedding, true);
    assert.equal('embedding' in item.fingerprint, false);
  }
  assert.equal(body.filter((i: any) => i.fingerprint).length, 5);
  const bundle = await json('/catalog/sintel');
  assert.equal(bundle.status, 200);
  assert.equal(bundle.body.item.title, 'Sintel');
  assert.ok(bundle.body.emotions.samples.length > 10);
  assert.equal('embedding' in bundle.body.fingerprint, false);
  assert.ok(Object.keys(bundle.body.fingerprint.synopsis.translations).length >= 8);
});

test('stats', async () => {
  const { body } = await json('/stats');
  assert.equal(body.items, 5);
  assert.equal(body.ready, 5);
  assert.ok(body.totalDurationSec > 2000);
});

test('search returns moment hits with real start/end', async () => {
  const { status, body } = await json('/search', { method: 'POST', body: JSON.stringify({ query: 'dragon' }) });
  assert.equal(status, 200);
  assert.ok(body.hits.length > 0);
  assert.equal(body.hits[0].itemId, 'sintel');
  assert.ok(body.hits[0].end > body.hits[0].start);
  assert.equal(body.pool.items, 5);
  const bad = await json('/search', { method: 'POST', body: JSON.stringify({}) });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.error.code, 'bad_request');
});

test('review + exports: only approved breaks reach VMAP/SCTE-35', async () => {
  const plan = (await json('/catalog/sintel/adbreaks')).body;
  const brk = plan.breaks[0];
  const patched = await json(`/catalog/sintel/adbreaks/${brk.id}`, { method: 'PATCH', body: JSON.stringify({ status: 'approved', rating: 5, comments: [{ text: 'ok' }] }) });
  assert.equal(patched.status, 200);
  assert.equal(patched.body.review.status, 'approved');
  assert.equal(patched.body.review.comments.length, 1);

  const vmap = await fetch(`${base}/catalog/sintel/export/vmap`);
  assert.equal(vmap.headers.get('content-type')?.includes('xml'), true);
  const xml = await vmap.text();
  assert.match(xml, /<vmap:VMAP/);
  assert.equal((xml.match(/<vmap:AdBreak /g) ?? []).length, 1);
  const mm = String(Math.floor(brk.at / 60)).padStart(2, '0');
  const ss = String(Math.floor(brk.at % 60)).padStart(2, '0');
  assert.match(xml, new RegExp(`timeOffset="00:${mm}:${ss}\\.\\d{3}"`));

  const scte = (await json('/catalog/sintel/export/scte35')).body;
  assert.equal(scte.splices.length, 1);
  assert.equal(scte.splices[0].pts_time, Math.round(brk.at * 90000));
  assert.equal(scte.splices[0].duration_sec, 30);

  const markers = (await json('/catalog/sintel/export/markers')).body;
  assert.equal(markers.creditsStart, 744);
  assert.ok(markers.skipIntro);
});

test('re-plan keeps ids and review state', async () => {
  const { status, body } = await json('/catalog/sintel/adbreaks/plan', { method: 'POST', body: JSON.stringify({ targetBreaks: 4, minSpacingSec: 100 }) });
  assert.equal(status, 200);
  assert.equal(body.policy.targetBreaks, 4);
  assert.ok(body.breaks.length >= 3);
  assert.ok(body.breaks.some((b: any) => b.review?.status === 'approved'));
});

test('markers review', async () => {
  const set = (await json('/catalog/sintel/markers')).body;
  const m = set.markers.find((x: any) => x.kind === 'credits');
  const { body } = await json(`/catalog/sintel/markers/${m.id}`, { method: 'PATCH', body: JSON.stringify({ status: 'declined' }) });
  assert.equal(body.review.status, 'declined');
  const exported = (await json('/catalog/sintel/export/markers')).body;
  assert.equal(exported.creditsStart, undefined, 'declined markers are excluded');
});

test('smart lists: rules, query, curate', async () => {
  const rules = await json('/lists', { method: 'POST', body: JSON.stringify({ name: 'Fantasy', rules: [{ facet: 'genres', label: 'fantasy', min: 0.5, max: 1 }] }) });
  assert.equal(rules.status, 201);
  assert.ok(rules.body.itemIds.includes('sintel'));
  const query = await json('/lists', { method: 'POST', body: JSON.stringify({ name: 'Robots', query: 'robots taking over a city' }) });
  assert.equal(query.status, 201);
  assert.deepEqual(query.body.itemIds, ['tears-of-steel']);
  const curated = await json('/lists/curate', { method: 'POST' });
  assert.equal(curated.status, 200);
  assert.ok(curated.body.length >= 1);
  assert.ok(curated.body.every((l: any) => l.source === 'ai'));
  const all = (await json('/lists')).body;
  // Curation replaces the seed's AI list (3 non-AI seed lists + 2 created here + curated).
  assert.equal(all.length, 3 + 2 + curated.body.length);
  const del = await fetch(`${base}/lists/${rules.body.id}`, { method: 'DELETE' });
  assert.equal(del.status, 204);
});

test('similar titles explain the match', async () => {
  const { body } = await json('/catalog/sintel/similar?limit=2');
  assert.equal(body.length, 2);
  assert.ok(body[0].because.length > 0);
});

test('ingest a new URL runs the full pipeline in mock mode', async () => {
  const created = await json('/catalog', { method: 'POST', body: JSON.stringify({ title: 'Big Buck Bunny', sourceUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ' }) });
  assert.equal(created.status, 200);
  const id = created.body[0].id;
  assert.ok(['queued', 'running'].includes(created.body[0].jobs.ingest), 'pipeline reflected on the item immediately');
  await app.runner.idle();
  const bundle = (await json(`/catalog/${id}`)).body;
  assert.equal(bundle.item.status, 'ready');
  assert.ok(bundle.item.durationSec > 0);
  assert.match(bundle.fingerprint.synopsis.short, /\(mock\)/);
  assert.ok(bundle.adBreaks.breaks.length >= 1);
  assert.equal(bundle.thumbnails.length, 12);
  assert.equal(bundle.clips.length, 6);
  const jobs = (await json(`/jobs?itemId=${id}`)).body;
  assert.equal(jobs.length, 9);
  assert.ok(jobs.every((j: any) => j.status === 'ready'));
  // Re-posting the same URL is idempotent.
  const again = await json('/catalog', { method: 'POST', body: JSON.stringify({ sourceUrl: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ' }) });
  assert.equal(again.body[0].id, id);
  await app.runner.idle();
  const rerun = await json(`/catalog/${id}/jobs/thumbnails`, { method: 'POST' });
  assert.equal(rerun.status, 202);
  assert.equal(rerun.body.kind, 'thumbnails');
  await app.runner.idle();
  const del = await fetch(`${base}/catalog/${id}`, { method: 'DELETE' });
  assert.equal(del.status, 204);
});

test('recipes run creative jobs with the brief', async () => {
  const recipe = await json('/recipes', { method: 'POST', body: JSON.stringify({ name: 'Warm', target: 'clips', brief: 'tender warm moments', count: 3, clipLengthSec: [5, 10] }) });
  assert.equal(recipe.status, 201);
  const runs = await json(`/recipes/${recipe.body.id}/run`, { method: 'POST', body: JSON.stringify({ itemIds: ['sintel'] }) });
  assert.equal(runs.status, 202);
  await app.runner.idle();
  const run = (await json(`/runs/${runs.body[0].id}`)).body;
  assert.equal(run.status, 'ready');
  assert.equal(run.clips.length, 3);
  for (const c of run.clips) assert.ok(c.end - c.start <= 10.01);
  // The item's default clips are untouched by a recipe run.
  const bundle = (await json('/catalog/sintel')).body;
  assert.equal(bundle.clips.length, 6);
});

test('errors are {error:{code,message}}', async () => {
  const { status, body } = await json('/catalog/does-not-exist');
  assert.equal(status, 404);
  assert.equal(body.error.code, 'not_found');
  const bad = await json('/catalog', { method: 'POST', body: JSON.stringify({ title: 'x' }) });
  assert.equal(bad.status, 400);
});

test('BASIC_AUTH gates every route except health', async () => {
  const dir2 = await mkdtemp(join(tmpdir(), 'twelve-auth-'));
  const cfg = loadConfig({ ...process.env, TWELVELABS_API_KEY: '', STORE_PATH: join(dir2, 'store.json'), MOCK_LATENCY_MS: '0', PORT: '0', BASIC_AUTH: 'euan:secret' });
  const inst = await createApp(cfg);
  const srv = inst.app.listen(0);
  const b = `http://127.0.0.1:${(srv.address() as AddressInfo).port}/api`;
  try {
    assert.equal((await fetch(`${b}/health`)).status, 200);
    const denied = await fetch(`${b}/catalog`);
    assert.equal(denied.status, 401);
    assert.match(denied.headers.get('www-authenticate') ?? '', /Basic/);
    assert.equal((await fetch(`${b}/catalog`, { headers: { authorization: 'Basic ' + Buffer.from('euan:wrong').toString('base64') } })).status, 401);
    assert.equal((await fetch(`${b}/catalog`, { headers: { authorization: 'Basic ' + Buffer.from('euan:secret').toString('base64') } })).status, 200);
    assert.throws(() => loadConfig({ BASIC_AUTH: 'nocolon' }), /user:password/);
  } finally {
    srv.close();
    await inst.close();
    await rm(dir2, { recursive: true, force: true });
  }
});

test('signed public media URL bypasses BASIC_AUTH; bad tokens 404; health reports yt-dlp and PUBLIC_BASE_URL', async () => {
  const dir2 = await mkdtemp(join(tmpdir(), 'twelve-public-'));
  const { readFile } = await import('node:fs/promises');
  const { mediaToken } = await import('../src/media.js');
  const { makeSyntheticMedia } = await import('./synthetic.js');
  const media = await makeSyntheticMedia('twelve-public-media-');
  if (!media) return; // no ffmpeg on this machine
  const file = media.movie;
  const bytes = await readFile(file);
  const cfg = loadConfig({
    ...process.env,
    TWELVELABS_API_KEY: '',
    STORE_PATH: join(dir2, 'store.json'),
    MOCK_LATENCY_MS: '0',
    PORT: '0',
    BASIC_AUTH: 'euan:secret',
    PUBLIC_BASE_URL: 'https://sgeul.example/',
    YT_DLP: '/definitely/not/here/yt-dlp',
  });
  assert.equal(cfg.publicBaseUrl, 'https://sgeul.example', 'trailing slash trimmed');
  const inst = await createApp(cfg);
  const srv = inst.app.listen(0);
  const b = `http://127.0.0.1:${(srv.address() as AddressInfo).port}/api`;
  const auth = { authorization: 'Basic ' + Buffer.from('euan:secret').toString('base64') };
  try {
    const health = (await (await fetch(`${b}/health`)).json()) as { ytDlp: string | null; publicBaseUrl: string | null };
    assert.equal(health.ytDlp, null);
    assert.equal(health.publicBaseUrl, 'https://sgeul.example');

    // Register a local title (mock pipeline ingests it), then fetch it through the public route with no credentials.
    const created = await fetch(`${b}/catalog`, { method: 'POST', headers: { ...auth, 'content-type': 'application/json' }, body: JSON.stringify({ sourceUrl: file, title: 'Clip' }) });
    assert.equal(created.status, 200);
    const [item] = (await created.json()) as { id: string }[];
    const secret = inst.store.getMeta('media.secret')!;
    assert.ok(secret.length >= 24);
    const url = inst.pipeline.config.publicUrlFor!({ id: item!.id } as never)!;
    assert.match(url, /^https:\/\/sgeul\.example\/api\/public\/media\/title\./);
    const token = url.split('/').at(-1)!;
    assert.equal(token, mediaToken(secret, 'title', item!.id));
    const open = await fetch(`${b}/public/media/${token}`);
    assert.equal(open.status, 200);
    assert.equal(Buffer.from(await open.arrayBuffer()).length, bytes.length);
    const ranged = await fetch(`${b}/public/media/${token}`, { headers: { range: 'bytes=0-2' } });
    assert.equal(ranged.status, 206);
    assert.deepEqual(Buffer.from(await ranged.arrayBuffer()), bytes.subarray(0, 3));
    // Tampered / unknown tokens and a title with no local file all 404, never 401 (nothing to enumerate).
    assert.equal((await fetch(`${b}/public/media/${token.slice(0, -2)}xx`)).status, 404);
    assert.equal((await fetch(`${b}/public/media/title.nope.abc`)).status, 404);
    assert.equal((await fetch(`${b}/public/media/${mediaToken(secret, 'title', 'no-such-item')}`)).status, 404);
    // Everything else still needs the credential.
    assert.equal((await fetch(`${b}/catalog`)).status, 401);
  } finally {
    srv.close();
    await inst.close();
    await rm(dir2, { recursive: true, force: true });
    await rm(media.dir, { recursive: true, force: true });
  }
});
