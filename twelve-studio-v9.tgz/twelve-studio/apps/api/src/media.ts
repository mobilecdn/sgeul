/**
 * Local media helpers: HTTP Range streaming for progressive playback of files
 * on the API host (movies ingested from disk, ad creatives, stitched renders)
 * and a small ffprobe wrapper for duration / fps / dimensions.
 */

import { createHmac, timingSafeEqual } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { basename, extname, isAbsolute, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { Request, Response } from 'express';

const MIME: Record<string, string> = {
  '.mp4': 'video/mp4',
  '.m4v': 'video/mp4',
  '.mov': 'video/quicktime',
  '.webm': 'video/webm',
  '.mkv': 'video/x-matroska',
  '.ts': 'video/mp2t',
  '.avi': 'video/x-msvideo',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
};

/** MIME type by extension (video/mp4 for unknown video-ish files). */
export function mimeFor(path: string, fallback = 'application/octet-stream'): string {
  return MIME[extname(path).toLowerCase()] ?? fallback;
}

/**
 * Accept `/abs/path`, `file:///abs/path` (or `file:/abs/path`) and return the
 * absolute path; `undefined` for anything else (http URLs, relative paths).
 */
export function localPathFrom(value: string | undefined): string | undefined {
  if (typeof value !== 'string') return undefined;
  const v = value.trim();
  if (!v) return undefined;
  if (/^file:/i.test(v)) {
    try {
      return fileURLToPath(v.startsWith('file:///') || !v.startsWith('file:/') ? v : `file://${v.slice(5)}`);
    } catch {
      return undefined;
    }
  }
  if (isAbsolute(v) && !/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) return resolve(v);
  return undefined;
}

/**
 * Resolve a stored local media path for this host. The path is used as-is when
 * it exists; otherwise, when `TWELVE_MEDIA_DIR` is set, a file with the same
 * basename under that directory is used. This lets a catalog seeded on one
 * machine (e.g. `/Users/euan/Downloads/film.mp4`) run on another where the media
 * lives elsewhere, without editing the store.
 */
export function resolveMediaPath(path: string): string {
  if (existsSync(path)) return path;
  const dir = process.env.TWELVE_MEDIA_DIR;
  if (dir) {
    const alt = resolve(dir, basename(path));
    if (existsSync(alt)) return alt;
  }
  return path;
}

/** Throws `{code:'file_not_found'}` unless `path` is a readable regular file; returns its size. */
export async function requireFile(path: string): Promise<number> {
  try {
    const st = await stat(path);
    if (!st.isFile()) throw new Error('not a regular file');
    return st.size;
  } catch (err) {
    const e = new Error(`Cannot read ${path}: ${(err as Error).message}`) as Error & { code: string; status: number };
    e.code = 'file_not_found';
    e.status = 400;
    throw e;
  }
}

/**
 * Stream a file with `Range: bytes=` support (206 + Content-Range, 416 when
 * unsatisfiable) and HEAD. Suitable for `<video src>` seeking.
 */
export async function streamFile(req: Request, res: Response, path: string, mime: string = mimeFor(path)): Promise<void> {
  let size: number;
  try {
    const st = await stat(path);
    if (!st.isFile()) throw new Error('not a file');
    size = st.size;
  } catch {
    res.status(404).json({ error: { code: 'file_not_found', message: `Media file is missing on this host: ${path}` } });
    return;
  }

  res.setHeader('accept-ranges', 'bytes');
  res.setHeader('content-type', mime);
  res.setHeader('cache-control', 'private, max-age=3600');

  const rangeHeader = req.headers.range;
  let start = 0;
  let end = size - 1;
  let partial = false;
  if (rangeHeader) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(rangeHeader.trim());
    if (!m || (m[1] === '' && m[2] === '')) {
      res.status(416).setHeader('content-range', `bytes */${size}`);
      res.end();
      return;
    }
    if (m[1] === '') {
      // Suffix range: last N bytes.
      const suffix = Number(m[2]);
      start = Math.max(0, size - suffix);
    } else {
      start = Number(m[1]);
      if (m[2] !== '') end = Math.min(size - 1, Number(m[2]));
    }
    if (!Number.isFinite(start) || !Number.isFinite(end) || start > end || start >= size) {
      res.status(416).setHeader('content-range', `bytes */${size}`);
      res.end();
      return;
    }
    partial = true;
  }

  const length = end - start + 1;
  res.setHeader('content-length', String(length));
  if (partial) {
    res.status(206);
    res.setHeader('content-range', `bytes ${start}-${end}/${size}`);
  } else {
    res.status(200);
  }
  if (req.method === 'HEAD') {
    res.end();
    return;
  }
  if (size === 0) {
    res.end();
    return;
  }
  // Headers go out now so callers that inspect `res.headersSent` after this resolves see a started response.
  res.flushHeaders();
  const stream = createReadStream(path, { start, end });
  stream.on('error', (err) => res.destroy(err));
  req.on('close', () => stream.destroy());
  stream.pipe(res);
}

/* ------------------------------------------------------------------ */
/* Signed public media URLs                                            */
/* ------------------------------------------------------------------ */

/**
 * Token for `GET /api/public/media/:token` — the one route that bypasses basic auth, so TwelveLabs can fetch a
 * local file that is over the direct-upload limit. `<kind>.<id>.<hmac>`; the secret lives in store meta.
 */
export function mediaToken(secret: string, kind: 'title' | 'ad', id: string): string {
  const mac = createHmac('sha256', secret).update(`${kind}:${id}`).digest('base64url').slice(0, 32);
  return `${kind}.${encodeURIComponent(id)}.${mac}`;
}

/** Verify a token from the public route; undefined when it does not check out. */
export function verifyMediaToken(secret: string, token: string): { kind: 'title' | 'ad'; id: string } | undefined {
  const parts = token.split('.');
  if (parts.length !== 3) return undefined;
  const [kind, rawId, mac] = parts as [string, string, string];
  if (kind !== 'title' && kind !== 'ad') return undefined;
  let id: string;
  try {
    id = decodeURIComponent(rawId);
  } catch {
    return undefined;
  }
  const expected = createHmac('sha256', secret).update(`${kind}:${id}`).digest('base64url').slice(0, 32);
  const a = Buffer.from(mac);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return undefined;
  return { kind, id };
}
