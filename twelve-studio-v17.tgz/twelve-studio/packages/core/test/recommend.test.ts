import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_RECO_WEIGHTS,
  buildTasteProfile,
  canonicalLabel,
  eventWeight,
  hasLabels,
  normaliseWeights,
  popularityIndex,
  recommend,
  recommendRails,
  scoreItem,
  signatureLabels,
  type WatchEvent,
} from '../src/recommend.js';
import type { CatalogItem, Fingerprint } from '../src/types.js';

/* ------------------------------------------------------------------ */
/* Fixtures: a small catalog with clean, separable tastes              */
/* ------------------------------------------------------------------ */

function fp(genres: Record<string, number>, extra: Partial<Fingerprint> = {}): Fingerprint {
  return {
    genres,
    keywords: {},
    moods: {},
    moodTags: {},
    themes: {},
    characters: [],
    pacing: { score: 0.5, rationale: '' },
    language: { primary: 'en' },
    audienceRating: { suggested: 'PG-13', rationale: '' },
    synopsis: { short: '', long: '' },
    model: 'test',
    generatedAt: '2026-01-01T00:00:00.000Z',
    ...extra,
  };
}

function item(id: string, title: string, fingerprint: Fingerprint): CatalogItem {
  return {
    id,
    title,
    type: 'movie',
    sourceUrl: `https://example.test/${id}.mp4`,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    status: 'ready',
    jobs: {},
    durationSec: 5400,
    fingerprint,
  };
}

const CATALOG: CatalogItem[] = [
  item('romhorror1', 'Crimson Vow', fp({ horror: 0.9, romance: 0.8 }, { moodTags: { 'doomed love': 0.7 }, themes: { obsession: 0.6 } })),
  item('romhorror2', 'The Bride Waits', fp({ horror: 0.85, romantic: 0.75 }, { moodTags: { 'doomed love': 0.6 } })),
  item('romhorror3', 'Widow Hill', fp({ horror: 0.8, romance: 0.7 }, { moodTags: { 'doomed love': 0.5 } })),
  item('horror1', 'Cellar Door', fp({ horror: 0.95 }, { moodTags: { dread: 0.8 } })),
  item('horror2', 'Night Shift', fp({ horror: 0.9 }, { moodTags: { dread: 0.7 } })),
  item('romance1', 'Two Summers', fp({ romance: 0.95 }, { moodTags: { longing: 0.8 } })),
  item('romance2', 'Letters Home', fp({ romance: 0.9 }, { moodTags: { longing: 0.7 } })),
  item('comedy1', 'Office Party', fp({ comedy: 0.95 }, { moodTags: { silly: 0.8 } })),
  item('doc1', 'Deep Field', fp({ documentary: 0.9 }, { themes: { science: 0.8 } })),
];

const NOW = Date.parse('2026-02-01T00:00:00.000Z');
const ev = (itemId: string, over: Partial<WatchEvent> = {}): WatchEvent => ({
  id: `wev_${itemId}_${over.action ?? 'watch'}`,
  profileId: 'v1',
  itemId,
  action: 'watch',
  completion: 0.95,
  at: '2026-01-30T00:00:00.000Z',
  ...over,
});

const profileFor = (events: WatchEvent[], weights = DEFAULT_RECO_WEIGHTS) => buildTasteProfile('v1', events, CATALOG, weights, NOW);

/* ------------------------------------------------------------------ */

test('canonicalLabel folds synonyms and adjective forms', () => {
  assert.equal(canonicalLabel('Romantic'), 'romance');
  assert.equal(canonicalLabel('  SCARY '), 'horror');
  assert.equal(canonicalLabel('Sci-Fi'), 'science fiction');
  assert.equal(canonicalLabel('Western'), 'western');
});

test('eventWeight rewards completion, decays with age and goes negative on dislike', () => {
  const w = DEFAULT_RECO_WEIGHTS;
  const finished = eventWeight(ev('horror1', { completion: 1 }), w, NOW);
  const halfWatched = eventWeight(ev('horror1', { completion: 0.5 }), w, NOW);
  const bounced = eventWeight(ev('horror1', { completion: 0.02 }), w, NOW);
  assert.ok(finished > halfWatched && halfWatched > bounced);
  const old = eventWeight(ev('horror1', { completion: 1, at: '2025-12-01T00:00:00.000Z' }), w, NOW);
  assert.ok(old < finished, 'older watches count for less');
  assert.ok(eventWeight(ev('horror1', { action: 'dislike' }), w, NOW) < 0);
});

test('a horror viewer gets horror back', () => {
  const profile = profileFor([ev('horror1'), ev('horror2')]);
  const out = recommend({ profile, pool: CATALOG, weights: DEFAULT_RECO_WEIGHTS, limit: 3 });
  assert.ok(out.length > 0);
  const top = out[0]!;
  const fpTop = CATALOG.find((i) => i.id === top.itemId)!.fingerprint!;
  assert.ok('horror' in fpTop.genres, `expected a horror title first, got ${top.title}`);
  assert.ok(top.because.length > 0, 'every recommendation is explained');
});

test('romantic horror ranks romantic horror first, then its ingredients, and comedy last', () => {
  const profile = profileFor([ev('romhorror1'), ev('romhorror2')]);
  const out = recommend({
    profile,
    pool: CATALOG,
    weights: { ...DEFAULT_RECO_WEIGHTS, diversity: 0, repeatPenalty: 0 },
    limit: 10,
    includeWatched: true,
  });
  const rank = new Map(out.map((r, i) => [r.itemId, i]));
  const score = new Map(out.map((r) => [r.itemId, r.score]));

  // The unwatched romantic horror leads, then the single genres, then the rest.
  assert.deepEqual(out.slice(0, 3).map((r) => r.itemId).sort(), ['romhorror1', 'romhorror2', 'romhorror3'], 'the romantic horrors take the top three');
  assert.ok(score.get('romhorror3')! > score.get('horror1')!, 'romantic horror beats plain horror');
  assert.ok(score.get('romhorror3')! > score.get('romance1')!, 'romantic horror beats plain romance');
  assert.ok(score.get('horror1')! > score.get('comedy1')!, 'horror beats comedy');
  assert.ok(score.get('romance1')! > score.get('comedy1')!, 'romance beats comedy');
  assert.ok(rank.get('doc1')! > rank.get('horror1')!, 'documentary ranks below horror');

  // The combination is scored as its own taste, not just the sum of two genres.
  const combo = out.find((r) => r.itemId === 'romhorror1')!;
  assert.ok(combo.parts.combo > 0, 'a romantic horror carries a combo contribution');
  assert.equal(out.find((r) => r.itemId === 'horror1')!.parts.combo, 0, 'plain horror carries none');
  assert.ok(
    combo.because.some((b) => b.includes('+')),
    'the combination is named in the explanation',
  );
});

test('the combo weight is the dial that moves combinations above single genres', () => {
  const profile = profileFor([ev('romhorror1'), ev('romhorror2')]);
  const pool = CATALOG.filter((i) => ['horror1', 'romance1', 'comedy1', 'romhorror3'].includes(i.id));
  const rankWith = (combo: number) =>
    recommend({ profile, pool, weights: { ...DEFAULT_RECO_WEIGHTS, combo, diversity: 0 }, limit: 5 }).map((r) => r.itemId);
  assert.equal(rankWith(2.5)[0], 'romhorror3', 'a high combo weight puts the combination first');
  const lowCombo = rankWith(0);
  assert.ok(lowCombo.indexOf('romhorror3') >= 0);
  // With the combo dial off, a pure-genre title can overtake it.
  assert.ok(
    rankWith(2.5).indexOf('romhorror3') <= lowCombo.indexOf('romhorror3'),
    'turning the dial up never hurts the combination',
  );
});

test('a dislike pushes a title down, a like pulls its taste up', () => {
  const liked = profileFor([ev('romance1', { action: 'like' })]);
  const out = recommend({ profile: liked, pool: CATALOG, weights: { ...DEFAULT_RECO_WEIGHTS, diversity: 0 }, limit: 8 });
  assert.equal(out[0]!.itemId, 'romance2', 'the other romance comes first');
  assert.ok(!out.some((r) => r.itemId === 'romance1'), 'a title the viewer already liked is not recommended back');

  const disliked = profileFor([ev('horror1'), ev('horror2'), ev('romance2', { action: 'dislike' })]);
  const withDislike = recommend({ profile: disliked, pool: CATALOG, weights: { ...DEFAULT_RECO_WEIGHTS, diversity: 0 }, limit: 8 });
  const romance2 = withDislike.find((r) => r.itemId === 'romance2');
  assert.ok(!romance2 || romance2.parts.penalty > 0, 'a disliked title is penalised');
});

test('finished titles drop out, part-watched ones come back as Continue watching', () => {
  const profile = profileFor([ev('horror1', { completion: 1 }), ev('horror2', { completion: 0.4 })]);
  const out = recommend({ profile, pool: CATALOG, weights: DEFAULT_RECO_WEIGHTS, limit: 8 });
  assert.ok(!out.some((r) => r.itemId === 'horror1'), 'a finished title is not recommended again');
  const rails = recommendRails({ profile, pool: CATALOG, weights: DEFAULT_RECO_WEIGHTS });
  const cont = rails.find((r) => r.kind === 'continue');
  assert.ok(cont, 'a Continue watching row exists');
  assert.equal(cont!.items[0]!.itemId, 'horror2');
});

test('up next blends the title playing with the profile', () => {
  const profile = profileFor([ev('romance1')]);
  const seed = CATALOG.find((i) => i.id === 'horror1')!;
  const out = recommend({ profile, pool: CATALOG, weights: { ...DEFAULT_RECO_WEIGHTS, diversity: 0 }, seed, limit: 5 });
  assert.ok(!out.some((r) => r.itemId === seed.id), 'the title playing is never recommended back');
  // With the seed dial at zero it is pure taste: the other romance leads.
  const taste = recommend({ profile, pool: CATALOG, weights: { ...DEFAULT_RECO_WEIGHTS, seed: 0, diversity: 0 }, seed, limit: 8 });
  assert.equal(taste[0]!.itemId, 'romance2');
  // Turned up, what is playing pulls horror-adjacent titles up the row.
  const steered = recommend({ profile, pool: CATALOG, weights: { ...DEFAULT_RECO_WEIGHTS, seed: 3, diversity: 0 }, seed, limit: 8 });
  const pos = (list: typeof steered, id: string) => list.findIndex((r) => r.itemId === id);
  assert.ok(pos(steered, 'horror2') < pos(taste, 'horror2'), 'the other horror climbs when the seed dial is up');
  assert.ok(steered.some((r) => r.parts.seed > 0), 'the seed contributes');
});

test('rails lead with the combination, then each ingredient', () => {
  const profile = profileFor([ev('romhorror1'), ev('romhorror2')]);
  const rails = recommendRails({ profile, pool: CATALOG, weights: DEFAULT_RECO_WEIGHTS, limit: 5 });
  const combo = rails.find((r) => r.kind === 'combo');
  assert.ok(combo, 'a combination row exists');
  assert.deepEqual([...combo!.labels].sort(), ['horror', 'romance']);
  for (const rec of combo!.items) {
    assert.ok(hasLabels(CATALOG.find((i) => i.id === rec.itemId)!, ['horror', 'romance']));
  }
  const facetRails = rails.filter((r) => r.kind === 'facet');
  assert.ok(facetRails.length >= 1, 'single-taste rows follow');
  assert.ok(rails.every((r) => r.items.length > 0), 'no empty rows are returned');
});

test('one row per taste: a label reached through two facets makes a single row', () => {
  // "romance" as a genre and "love" as a theme canonicalise to the same label, so the
  // viewer has one romance taste, not two, and must not be shown two "More Romance" rows.
  const pool: CatalogItem[] = [
    item('rom_a', { romance: 0.9, drama: 0.6 }, { themes: { love: 0.9 } }),
    item('rom_b', { romance: 0.85, drama: 0.5 }, { themes: { love: 0.85 } }),
    item('rom_c', { romance: 0.8 }, { themes: { love: 0.8 } }),
    item('rom_d', { romance: 0.75 }, { themes: { love: 0.7 } }),
    item('doc_a', { documentary: 0.9 }),
  ];
  const profile = buildTasteProfile('p', [ev('rom_a'), ev('rom_b')], pool, DEFAULT_RECO_WEIGHTS);
  const rails = recommendRails({ profile, pool, weights: DEFAULT_RECO_WEIGHTS, limit: 4 });
  const titles = rails.map((r) => r.title);
  assert.equal(new Set(titles).size, titles.length, `rows repeat a title: ${titles.join(' | ')}`);
  const ids = rails.map((r) => r.id);
  assert.equal(new Set(ids).size, ids.length, 'row ids are unique');
});

test('a viewer with no history still gets something (cold start by popularity)', () => {
  const others: WatchEvent[] = [
    { ...ev('comedy1'), profileId: 'other', id: 'a' },
    { ...ev('comedy1'), profileId: 'other2', id: 'b' },
    { ...ev('doc1'), profileId: 'other3', id: 'c' },
  ];
  const popularity = popularityIndex(others, DEFAULT_RECO_WEIGHTS, NOW);
  const profile = profileFor([]);
  const out = recommend({ profile, pool: CATALOG, weights: DEFAULT_RECO_WEIGHTS, popularity, limit: 4 });
  assert.ok(out.length > 0, 'a cold viewer still gets a row');
  assert.equal(out[0]!.itemId, 'comedy1', 'the most-watched title leads');
});

test('diversity spreads a row out', () => {
  const profile = profileFor([ev('horror1'), ev('romhorror1')]);
  const flat = recommend({ profile, pool: CATALOG, weights: { ...DEFAULT_RECO_WEIGHTS, diversity: 0 }, limit: 4 }).map((r) => r.itemId);
  const varied = recommend({ profile, pool: CATALOG, weights: { ...DEFAULT_RECO_WEIGHTS, diversity: 0.9 }, limit: 4 }).map((r) => r.itemId);
  assert.equal(flat.length, varied.length);
  assert.notDeepEqual(flat, varied, 'the diversity dial changes the row');
});

test('scoring is deterministic and bounded', () => {
  const profile = profileFor([ev('horror1')]);
  const a = scoreItem(CATALOG[2]!, { profile, weights: DEFAULT_RECO_WEIGHTS });
  const b = scoreItem(CATALOG[2]!, { profile, weights: DEFAULT_RECO_WEIGHTS });
  assert.deepEqual(a, b);
  assert.ok(a!.score <= 1 && a!.score >= -1);
});

test('weights are merged and clamped', () => {
  const w = normaliseWeights({ combo: 99, facets: { genres: -4 } as never, diversity: 0.5 });
  assert.equal(w.combo, 3);
  assert.equal(w.facets.genres, 0);
  assert.equal(w.diversity, 0.5);
  assert.equal(w.embedding, DEFAULT_RECO_WEIGHTS.embedding);
});

test('signatureLabels canonicalises and ranks', () => {
  const labels = signatureLabels(CATALOG[1]!.fingerprint!).map((l) => l.label);
  assert.ok(labels.includes('horror'));
  assert.ok(labels.includes('romance'), 'the "romantic" genre folds into romance');
});

test('items without a fingerprint are skipped, not thrown on', () => {
  const pool = CATALOG.concat({ ...item('raw', 'Just Ingested', fp({})), fingerprint: undefined });
  const profile = profileFor([ev('horror1')]);
  const out = recommend({ profile, pool, weights: DEFAULT_RECO_WEIGHTS, limit: 10 });
  assert.ok(!out.some((r) => r.itemId === 'raw'));
});
