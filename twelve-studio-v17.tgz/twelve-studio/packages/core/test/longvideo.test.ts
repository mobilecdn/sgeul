import { test } from 'node:test';
import assert from 'node:assert/strict';
import { analysisWindows, mergeWindowResults, runJob, toAssetTimeline, type PipelineDeps, type PipelineStore } from '../src/pipeline.js';
import { MockTwelveLabsClient } from '../src/mock.js';
import { normaliseAnalyzeTask, type AnalyzeParams, type AnalyzeTaskParams } from '../src/twelvelabs.js';
import type { CatalogItem, ItemBundle } from '../src/types.js';

test('analysisWindows: one window up to two hours, equal windows beyond', () => {
  assert.deepEqual(analysisWindows(5631), [{ start: 0, end: 5631 }]);
  const w = analysisWindows(10663.2);
  assert.equal(w.length, 2);
  assert.equal(w[0]!.start, 0);
  assert.equal(w[1]!.end, 10663.2);
  assert.ok(w.every((x) => x.end - x.start <= 7200));
  assert.equal(analysisWindows(21601).length, 4);
});

test('toAssetTimeline: relative times move onto the asset timeline, absolute times stay', () => {
  const win = { start: 5000, end: 10000 };
  assert.deepEqual(toAssetTimeline({ markers: [{ start: 10, end: 20, label: 'a' }] }, win), { markers: [{ start: 5010, end: 5020, label: 'a' }] });
  assert.deepEqual(toAssetTimeline({ markers: [{ start: 6000, end: 6100 }] }, win), { markers: [{ start: 6000, end: 6100 }] });
  assert.deepEqual(toAssetTimeline({ candidates: [{ at: 30 }] }, { start: 0, end: 7000 }), { candidates: [{ at: 30 }] });
});

test('mergeWindowResults: arrays concatenate, label maps keep the best score, scalars keep the first', () => {
  const merged = mergeWindowResults([
    { synopsis: 'first half', markers: [{ start: 1 }], mood: { tense: 0.4, grim: 0.9 } },
    { synopsis: 'second half', markers: [{ start: 6000 }], mood: { tense: 0.8 } },
  ]);
  assert.equal(merged.synopsis, 'first half');
  assert.deepEqual(merged.markers, [{ start: 1 }, { start: 6000 }]);
  assert.deepEqual(merged.mood, { tense: 0.8, grim: 0.9 });
});

test('normaliseAnalyzeTask reads the current task shape (task_id, result.data)', () => {
  const t = normaliseAnalyzeTask({ task_id: 'abc', status: 'ready', result: { data: '{"x":1}', usage: { output_tokens: 3 } } } as never);
  assert.equal(t._id, 'abc');
  assert.equal(t.data, '{"x":1}');
  assert.equal(t.usage?.output_tokens, 3);
});

class Store implements PipelineStore {
  bundles = new Map<string, ItemBundle>();
  getBundle(id: string) { return this.bundles.get(id); }
  saveItem(item: CatalogItem) { const b = this.bundles.get(item.id) ?? { item, jobs: [] }; b.item = item; this.bundles.set(item.id, b); return item; }
  saveSection(id: string, key: string, value: unknown) { (this.bundles.get(id) as unknown as Record<string, unknown>)[key] = value; }
  getMeta() { return undefined; }
  setMeta() {}
}

class LongClient extends MockTwelveLabsClient {
  syncCalls = 0;
  taskParams: AnalyzeTaskParams[] = [];
  override async analyze<T>(p: AnalyzeParams): Promise<never> { this.syncCalls++; void p; throw new Error('sync analyze must not be used for long videos'); }
  override async createAnalyzeTask(p: AnalyzeTaskParams) { this.taskParams.push(p); return super.createAnalyzeTask(p); }
}

test('a film over two hours runs markers as windowed async tasks and never calls sync analyze', async () => {
  const client = new LongClient({ catalog: [], lists: [], ads: [], assets: [], dir: '' }, { latencyMs: [0, 0] });
  const store = new Store();
  const it: CatalogItem = {
    id: 'brave', title: 'Braveheart', sourceUrl: 'https://example.com/b.mp4', type: 'movie', createdAt: 't', updatedAt: 't',
    status: 'enriching', jobs: { ingest: 'ready' }, durationSec: 10663.2, fps: 24,
    upstream: { assetId: 'mock-asset-brave', indexId: 'mock-index', indexedAssetId: 'mock-ia' },
  } as CatalogItem;
  store.saveItem(it);
  const deps: PipelineDeps = { client, store, config: { indexName: 'test', synopsisLanguages: [], pollIntervalMs: 1 } };
  await runJob('markers', it, deps);
  assert.equal(client.syncCalls, 0);
  assert.equal(client.taskParams.length, 2);
  assert.deepEqual(client.taskParams.map((t) => [t.startTime, t.endTime]), [[0, 5331], [5331, 10662]]);
  assert.ok(client.taskParams.every((t) => t.schema && !t.analysisMode));
  const markers = store.getBundle('brave')!.markers!.markers;
  assert.ok(markers.length > 0);
  assert.ok(markers.every((m) => m.end <= 10663.2));
  assert.ok(client.taskParams.every((t) => (t.maxTokens ?? 0) >= 32768));
});

test('parseJsonRobust recovers output cut off at max_tokens', async () => {
  const { parseJsonRobust } = await import('../src/util.js');
  const cut = '{"samples":[{"start":0,"end":10,"beat":"open"},{"start":10,"end":20,"beat":"cha';
  assert.deepEqual(parseJsonRobust(cut), { samples: [{ start: 0, end: 10, beat: 'open' }] });
  const cut2 = '{"candidates":[{"at":5,"mood":{"calm":0.5}},{"at":9,"mood":{"te';
  assert.deepEqual(parseJsonRobust(cut2), { candidates: [{ at: 5, mood: { calm: 0.5 } }] });
});
