/**
 * TwelveLabs v1.3 — a deliberately small fetch client.
 *
 * No SDK: every call here maps 1:1 to an HTTP endpoint so the reader can see
 * exactly what the product asks of Marengo (index / search / embed) and
 * Pegasus (analyze). Only the endpoints Twelve Studio uses are wrapped.
 *
 *   POST /assets                          upload by URL (method=url) or from disk (method=direct, multipart file)
 *   GET  /assets/:id                      poll until ready
 *   POST /indexes, GET /indexes           Marengo index
 *   POST /indexes/:id/indexed-assets      index an asset
 *   GET  /indexes/:id/indexed-assets/:iid poll; duration/fps/hls
 *   POST /search, GET /search/:token      multipart search
 *   POST /analyze                         Pegasus, JSON-schema output
 *   POST /analyze/tasks, GET /analyze/tasks/:id   async analyze (>1h video)
 *   POST /embed-v2, POST /embed-v2/tasks, GET /embed-v2/tasks/:id
 */

import { openAsBlob } from 'node:fs';
import { stat } from 'node:fs/promises';
import { basename, extname } from 'node:path';
import { DIRECT_UPLOAD_MAX_BYTES, parseJsonRobust, sleep } from './util.js';

export const TWELVELABS_BASE_URL = 'https://api.twelvelabs.io/v1.3';

export const MODELS = {
  /** Marengo — index / search. */
  index: 'marengo3.0',
  /** Marengo — embeddings. */
  embed: 'marengo3.5',
  /** Pegasus — analyze. */
  analyze: 'pegasus1.5',
} as const;

/* ------------------------------------------------------------------ */
/* Wire types (the subset of TwelveLabs responses we read)             */
/* ------------------------------------------------------------------ */

export type UpstreamStatus = 'waiting' | 'processing' | 'validating' | 'pending' | 'queued' | 'indexing' | 'ready' | 'failed';

export interface TLAsset {
  _id: string;
  status: UpstreamStatus;
  filename?: string;
  url?: string;
  created_at?: string;
}

/**
 * One row of `GET /v1.3/assets` (verified 12 Sep 2026). `duration`, `width`,
 * `height`, `fps`, `hls` and `thumbnail` are null while the asset is processing.
 */
export interface TwelveLabsAsset {
  _id: string;
  method: 'multipart' | 'url' | 'direct' | string;
  status: 'ready' | 'processing' | 'failed' | string;
  filename: string;
  file_type?: string;
  /** Bytes. */
  size?: number;
  /** Seconds. */
  duration: number | null;
  width: number | null;
  height: number | null;
  fps: number | null;
  hls: { manifest_url: string; status?: string } | null;
  thumbnail: { representative_url: string; status?: string } | null;
  created_at: string;
  technical_metadata?: Record<string, unknown>;
}

export interface TwelveLabsAssetPage {
  data: TwelveLabsAsset[];
  pageInfo: { page: number; limitPerPage: number; totalPage: number; totalResults: number };
}

/** Raw `page_info` of a paged TwelveLabs listing. */
interface TLPageInfo {
  page?: number;
  limit_per_page?: number;
  total_page?: number;
  total_results?: number;
}

export interface TLIndex {
  _id: string;
  index_name: string;
  models?: Array<{ model_name: string; model_options: string[] }>;
  created_at?: string;
}

export interface TLIndexedAsset {
  _id: string;
  asset_id?: string;
  status: UpstreamStatus;
  system_metadata?: { duration?: number; fps?: number; width?: number; height?: number; filename?: string };
  hls?: { video_url?: string; thumbnail_urls?: string[]; status?: string };
  error?: { code?: string; message?: string } | string;
}

export interface TLSearchHit {
  video_id: string;
  start: number;
  end: number;
  score?: number;
  confidence?: string;
  rank?: number;
  thumbnail_url?: string;
  transcription?: string;
  /** Present when the hit was found through one specific modality. */
  modality?: string;
}

export interface TLSearchPage {
  data: TLSearchHit[];
  page_info?: { next_page_token?: string; total_results?: number; limit_per_page?: number };
  search_pool?: { total_count?: number; total_duration?: number; index_id?: string };
}

export interface TLAnalyzeResponse {
  id?: string;
  data: string;
  usage?: { output_tokens?: number };
}

export interface TLAnalyzeTask {
  _id: string;
  /** The API answers POST /analyze/tasks with `task_id`; GET returns `task_id` too. */
  task_id?: string;
  status: UpstreamStatus;
  data?: string;
  /** Since Sep 2026 a finished task carries its output here: `result.data` is the model's text. */
  result?: { data?: string; usage?: { output_tokens?: number } };
  usage?: { output_tokens?: number };
  error?: { code?: string; message?: string } | string;
}

export interface TLEmbedResponse {
  data: Array<{ embedding: number[]; embedding_scope?: string; start_offset_sec?: number; end_offset_sec?: number }>;
  usage?: { total_tokens?: number };
}

export interface TLEmbedTask {
  _id: string;
  status: UpstreamStatus;
  data?: TLEmbedResponse['data'];
  error?: { code?: string; message?: string } | string;
}

/* ------------------------------------------------------------------ */
/* Request shapes                                                      */
/* ------------------------------------------------------------------ */

export type VideoRef = { type: 'url'; url: string } | { type: 'asset_id'; asset_id: string };

export type SearchModality = 'visual' | 'audio' | 'transcription';

export interface SearchParams {
  indexId: string;
  queryText: string;
  searchOptions?: SearchModality[];
  groupBy?: 'clip' | 'video';
  pageLimit?: number;
}

/** JSON Schema (draft-07 flavour) — kept loose on purpose; prompts.ts builds these. */
export type JsonSchema = Record<string, unknown>;

/**
 * Keywords `POST /analyze` rejects inside `response_format.json_schema`
 * (verified 12 Sep 2026: `response_format_invalid — numeric constraints
 * ('minimum') are not supported`). Ranges stay documented in `description`.
 */
export const UNSUPPORTED_SCHEMA_KEYWORDS: ReadonlySet<string> = new Set([
  'minimum',
  'maximum',
  'exclusiveMinimum',
  'exclusiveMaximum',
  'minProperties',
  'maxProperties',
  'minItems',
  'maxItems',
  'minLength',
  'maxLength',
  'pattern',
  'format',
]);

/** Keywords whose *values* are maps keyed by property name, not by schema keyword. */
const PROPERTY_MAPS = new Set(['properties', 'patternProperties', 'definitions', '$defs']);

/**
 * Strip the constraint keywords TwelveLabs does not accept, recursively, without
 * touching `type`, `description`, `enum`, `required`, `additionalProperties`,
 * `properties` or `items`. Property *names* that happen to equal a dropped
 * keyword (e.g. a field called `format`) are preserved. Returns a new object.
 */
export function sanitizeJsonSchema<T extends JsonSchema>(schema: T): T {
  return sanitizeNode(schema) as T;
}

function sanitizeNode(node: unknown): unknown {
  if (Array.isArray(node)) return node.map(sanitizeNode);
  if (!node || typeof node !== 'object') return node;
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(node as Record<string, unknown>)) {
    if (UNSUPPORTED_SCHEMA_KEYWORDS.has(key)) continue;
    if (PROPERTY_MAPS.has(key) && value && typeof value === 'object' && !Array.isArray(value)) {
      out[key] = Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([name, sub]) => [name, sanitizeNode(sub)]));
      continue;
    }
    out[key] = sanitizeNode(value);
  }
  return out;
}

export interface AnalyzeParams {
  video: VideoRef;
  prompt: string;
  /** When given, sent as `response_format:{type:'json_schema', json_schema}` and the reply is parsed. */
  schema?: JsonSchema;
  temperature?: number;
  maxTokens?: number;
  startTime?: number;
  endTime?: number;
  /**
   * Hint for the mock client (ignored by the live client): which job this call
   * belongs to and which title it is about, so seeded/synthesised output can
   * be picked without inspecting the prompt.
   */
  hint?: { job: string; title?: string; sourceUrl?: string; itemId?: string; extra?: Record<string, unknown> };
}

export interface AnalyzeTaskParams extends AnalyzeParams {
  /**
   * 'time_based_metadata' now requires `response_format.type: segment_definitions`.
   * Leave unset for JSON-schema output, which async tasks accept with a start/end window.
   */
  analysisMode?: 'time_based_metadata' | 'general';
}

export interface AnalyzeResult<T = unknown> {
  data: T;
  raw: string;
  model: string;
  outputTokens?: number;
  taskId?: string;
}

/* ------------------------------------------------------------------ */
/* Errors + polling                                                    */
/* ------------------------------------------------------------------ */

export class TwelveLabsError extends Error {
  readonly code: string;
  readonly status: number;
  readonly details?: unknown;
  constructor(message: string, code: string, status: number, details?: unknown) {
    super(message);
    this.name = 'TwelveLabsError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

export interface PollOptions {
  intervalMs?: number;
  timeoutMs?: number;
  /** Optional callback per tick — useful for progress logs. */
  onTick?: (attempt: number, elapsedMs: number) => void;
}

/**
 * Poll `fn` until it returns a non-undefined value. Throws `TwelveLabsError`
 * with code `timeout` when `timeoutMs` elapses.
 */
export async function pollUntil<T>(fn: () => Promise<T | undefined>, opts: PollOptions = {}): Promise<T> {
  const intervalMs = opts.intervalMs ?? 5000;
  const timeoutMs = opts.timeoutMs ?? 30 * 60 * 1000;
  const startedAt = Date.now();
  let attempt = 0;
  for (;;) {
    attempt += 1;
    const result = await fn();
    if (result !== undefined) return result;
    const elapsed = Date.now() - startedAt;
    opts.onTick?.(attempt, elapsed);
    if (elapsed + intervalMs > timeoutMs) {
      throw new TwelveLabsError(`Timed out after ${Math.round(elapsed / 1000)}s`, 'timeout', 504);
    }
    await sleep(intervalMs);
  }
}

/* ------------------------------------------------------------------ */
/* The interface both the live and the mock client implement           */
/* ------------------------------------------------------------------ */

export interface TwelveLabsClientLike {
  readonly mode: 'live' | 'mock';

  createAsset(params: { url: string; filename?: string }): Promise<TLAsset>;
  /** Upload a local file (`method=direct`, ≤ 200 MB). Throws `file_too_large` above the limit. */
  createAssetFromFile(params: { path: string; filename?: string }): Promise<TLAsset>;
  getAsset(assetId: string): Promise<TLAsset>;
  /** Page through every asset in the account (newest first). */
  listAssets(params?: { page?: number; pageLimit?: number }): Promise<TwelveLabsAssetPage>;

  createIndex(params: { name: string }): Promise<TLIndex>;
  listIndexes(params?: { name?: string }): Promise<TLIndex[]>;

  createIndexedAsset(indexId: string, params: { assetId: string }): Promise<TLIndexedAsset>;
  getIndexedAsset(indexId: string, indexedAssetId: string): Promise<TLIndexedAsset>;

  search(params: SearchParams): Promise<TLSearchPage>;
  searchPage(pageToken: string): Promise<TLSearchPage>;

  analyze<T = unknown>(params: AnalyzeParams): Promise<AnalyzeResult<T>>;
  createAnalyzeTask(params: AnalyzeTaskParams): Promise<TLAnalyzeTask>;
  getAnalyzeTask(taskId: string): Promise<TLAnalyzeTask>;

  embedVideo(params: { assetId: string; title?: string }): Promise<number[]>;
  embedText(params: { text: string }): Promise<number[]>;
  createEmbedTask(params: { assetId: string; title?: string }): Promise<TLEmbedTask>;
  getEmbedTask(taskId: string): Promise<TLEmbedTask>;
}

/** Fold the current task shape (`task_id`, `result.data`) into the fields the pipeline reads (`_id`, `data`). */
export function normaliseAnalyzeTask(t: TLAnalyzeTask): TLAnalyzeTask {
  return {
    ...t,
    _id: t._id ?? t.task_id ?? '',
    data: t.data ?? t.result?.data,
    usage: t.usage ?? t.result?.usage,
  };
}

/* ------------------------------------------------------------------ */
/* Live client                                                          */
/* ------------------------------------------------------------------ */

export interface TwelveLabsClientOptions {
  apiKey: string;
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  /** Max retries on 429 / 5xx (default 5). */
  maxRetries?: number;
  /** Logger for every request (method, path, ms). */
  onRequest?: (info: { method: string; path: string; status: number; ms: number }) => void;
}

const RETRYABLE = new Set([429, 500, 502, 503, 504]);

export class TwelveLabsClient implements TwelveLabsClientLike {
  readonly mode = 'live' as const;
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly maxRetries: number;
  private readonly onRequest?: TwelveLabsClientOptions['onRequest'];

  constructor(opts: TwelveLabsClientOptions) {
    if (!opts.apiKey) throw new TwelveLabsError('TWELVELABS_API_KEY is required for the live client', 'config', 500);
    this.apiKey = opts.apiKey;
    this.baseUrl = (opts.baseUrl ?? TWELVELABS_BASE_URL).replace(/\/$/, '');
    this.fetchImpl = opts.fetchImpl ?? fetch;
    this.maxRetries = opts.maxRetries ?? 5;
    this.onRequest = opts.onRequest;
  }

  /* ---- assets ---------------------------------------------------- */

  /** → POST /v1.3/assets (multipart, method=url) */
  createAsset(params: { url: string; filename?: string }): Promise<TLAsset> {
    const form = new FormData();
    form.set('method', 'url');
    form.set('url', params.url);
    if (params.filename) form.set('filename', params.filename);
    return this.request<TLAsset>('POST', '/assets', { form });
  }

  /**
   * → POST /v1.3/assets (multipart, method=direct, `file`)
   * Streams a local file straight into TwelveLabs. Direct uploads are capped at
   * 200 MB; larger files must be hosted at a URL and ingested with `createAsset`.
   */
  async createAssetFromFile(params: { path: string; filename?: string }): Promise<TLAsset> {
    let size: number;
    try {
      const st = await stat(params.path);
      if (!st.isFile()) throw new TwelveLabsError(`${params.path} is not a file`, 'file_not_found', 400);
      size = st.size;
    } catch (err) {
      if (err instanceof TwelveLabsError) throw err;
      throw new TwelveLabsError(`Cannot read ${params.path}: ${(err as Error).message}`, 'file_not_found', 400);
    }
    if (size > DIRECT_UPLOAD_MAX_BYTES) {
      const mb = Math.round(size / 1024 / 1024);
      throw new TwelveLabsError(
        `${basename(params.path)} is ${mb} MB; direct uploads are limited to ${DIRECT_UPLOAD_MAX_BYTES / 1024 / 1024} MB. Host the file at a public URL and ingest it by sourceUrl instead.`,
        'file_too_large',
        413,
        { size, limit: DIRECT_UPLOAD_MAX_BYTES },
      );
    }
    // Node ≥ 20: a file-backed Blob — fetch streams it as multipart without buffering the whole file.
    const blob = await openAsBlob(params.path, { type: videoMime(params.path) });
    const form = new FormData();
    form.set('method', 'direct');
    form.set('file', blob, params.filename ?? basename(params.path));
    return this.request<TLAsset>('POST', '/assets', { form });
  }

  /** → GET /v1.3/assets/:id */
  getAsset(assetId: string): Promise<TLAsset> {
    return this.request<TLAsset>('GET', `/assets/${encodeURIComponent(assetId)}`);
  }

  /** → GET /v1.3/assets?page=&page_limit= */
  async listAssets(params: { page?: number; pageLimit?: number } = {}): Promise<TwelveLabsAssetPage> {
    const page = Math.max(1, Math.floor(params.page ?? 1));
    const limit = Math.min(50, Math.max(1, Math.floor(params.pageLimit ?? 50)));
    const qs = new URLSearchParams({ page: String(page), page_limit: String(limit) });
    const res = await this.request<{ data?: TwelveLabsAsset[]; page_info?: TLPageInfo }>('GET', `/assets?${qs.toString()}`);
    return { data: res.data ?? [], pageInfo: toPageInfo(res.page_info, page, limit, res.data?.length ?? 0) };
  }

  /* ---- indexes --------------------------------------------------- */

  /** → POST /v1.3/indexes (marengo3.0, visual+audio, thumbnail addon) */
  createIndex(params: { name: string }): Promise<TLIndex> {
    return this.request<TLIndex>('POST', '/indexes', {
      json: {
        index_name: params.name,
        models: [{ model_name: MODELS.index, model_options: ['visual', 'audio'] }],
        addons: ['thumbnail'],
      },
    });
  }

  /** → GET /v1.3/indexes?index_name= */
  async listIndexes(params: { name?: string } = {}): Promise<TLIndex[]> {
    const qs = new URLSearchParams({ page_limit: '50' });
    if (params.name) qs.set('index_name', params.name);
    const res = await this.request<{ data?: TLIndex[] }>('GET', `/indexes?${qs.toString()}`);
    return res.data ?? [];
  }

  /* ---- indexed assets -------------------------------------------- */

  /** → POST /v1.3/indexes/:id/indexed-assets */
  createIndexedAsset(indexId: string, params: { assetId: string }): Promise<TLIndexedAsset> {
    return this.request<TLIndexedAsset>('POST', `/indexes/${encodeURIComponent(indexId)}/indexed-assets`, {
      json: { asset_id: params.assetId, enable_video_stream: true },
    });
  }

  /** → GET /v1.3/indexes/:id/indexed-assets/:iid */
  getIndexedAsset(indexId: string, indexedAssetId: string): Promise<TLIndexedAsset> {
    return this.request<TLIndexedAsset>(
      'GET',
      `/indexes/${encodeURIComponent(indexId)}/indexed-assets/${encodeURIComponent(indexedAssetId)}`,
    );
  }

  /* ---- search ---------------------------------------------------- */

  /** → POST /v1.3/search (multipart; marengo3.0) */
  search(params: SearchParams): Promise<TLSearchPage> {
    const form = new FormData();
    form.set('index_id', params.indexId);
    form.set('query_text', params.queryText);
    for (const opt of params.searchOptions ?? ['visual', 'audio']) form.append('search_options', opt);
    form.set('group_by', params.groupBy ?? 'clip');
    form.set('page_limit', String(params.pageLimit ?? 20));
    return this.request<TLSearchPage>('POST', '/search', { form });
  }

  /** → GET /v1.3/search/:page_token */
  searchPage(pageToken: string): Promise<TLSearchPage> {
    return this.request<TLSearchPage>('GET', `/search/${encodeURIComponent(pageToken)}`);
  }

  /* ---- analyze (Pegasus) ----------------------------------------- */

  /** → POST /v1.3/analyze (pegasus1.5, stream:false, response_format json_schema) */
  async analyze<T = unknown>(params: AnalyzeParams): Promise<AnalyzeResult<T>> {
    const body = this.analyzeBody(params);
    const res = await this.request<TLAnalyzeResponse>('POST', '/analyze', { json: body });
    return {
      data: params.schema ? parseJsonRobust<T>(res.data) : (res.data as unknown as T),
      raw: res.data,
      model: MODELS.analyze,
      outputTokens: res.usage?.output_tokens,
    };
  }

  /** → POST /v1.3/analyze/tasks (async; use for >1h assets, analysis_mode time_based_metadata) */
  async createAnalyzeTask(params: AnalyzeTaskParams): Promise<TLAnalyzeTask> {
    const body: Record<string, unknown> = { ...this.analyzeBody(params) };
    if (params.analysisMode) body.analysis_mode = params.analysisMode;
    delete body.stream;
    const res = await this.request<TLAnalyzeTask>('POST', '/analyze/tasks', { json: body });
    return normaliseAnalyzeTask(res);
  }

  /** → GET /v1.3/analyze/tasks/:id */
  async getAnalyzeTask(taskId: string): Promise<TLAnalyzeTask> {
    const res = await this.request<TLAnalyzeTask>('GET', `/analyze/tasks/${encodeURIComponent(taskId)}`);
    return normaliseAnalyzeTask(res);
  }

  private analyzeBody(params: AnalyzeParams): Record<string, unknown> {
    // Exactly the two shapes the API accepts (verified 12 Sep 2026: `{type:'asset_id', asset_id}` → 202 queued).
    const video: VideoRef = params.video.type === 'asset_id' ? { type: 'asset_id', asset_id: params.video.asset_id } : { type: 'url', url: params.video.url };
    const body: Record<string, unknown> = {
      model_name: MODELS.analyze,
      video,
      prompt: params.prompt,
      temperature: params.temperature ?? 0.2,
      stream: false,
      max_tokens: params.maxTokens ?? 4096,
    };
    // The API rejects numeric/string constraint keywords in json_schema; drop them (ranges live in descriptions).
    if (params.schema) body.response_format = { type: 'json_schema', json_schema: sanitizeJsonSchema(params.schema) };
    if (params.startTime !== undefined) body.start_time = params.startTime;
    if (params.endTime !== undefined) body.end_time = params.endTime;
    return body;
  }

  /* ---- embed (Marengo 3.5) --------------------------------------- */

  /** → POST /v1.3/embed-v2 (input_type video, embedding_scope video) */
  async embedVideo(params: { assetId: string }): Promise<number[]> {
    const res = await this.request<TLEmbedResponse>('POST', '/embed-v2', {
      json: {
        input_type: 'video',
        model_name: MODELS.embed,
        video: { media_source: { asset_id: params.assetId }, embedding_scope: ['video'] },
      },
    });
    return pickVideoEmbedding(res.data);
  }

  /** → POST /v1.3/embed-v2 (input_type text) */
  async embedText(params: { text: string }): Promise<number[]> {
    const res = await this.request<TLEmbedResponse>('POST', '/embed-v2', {
      json: { input_type: 'text', model_name: MODELS.embed, text: { input_text: params.text } },
    });
    const first = res.data?.[0]?.embedding;
    if (!first) throw new TwelveLabsError('embed-v2 returned no text embedding', 'empty_embedding', 502, res);
    return first;
  }

  /** → POST /v1.3/embed-v2/tasks (long videos) */
  createEmbedTask(params: { assetId: string }): Promise<TLEmbedTask> {
    return this.request<TLEmbedTask>('POST', '/embed-v2/tasks', {
      json: {
        input_type: 'video',
        model_name: MODELS.embed,
        video: { media_source: { asset_id: params.assetId }, embedding_scope: ['video'] },
      },
    });
  }

  /** → GET /v1.3/embed-v2/tasks/:id */
  getEmbedTask(taskId: string): Promise<TLEmbedTask> {
    return this.request<TLEmbedTask>('GET', `/embed-v2/tasks/${encodeURIComponent(taskId)}`);
  }

  /* ---- transport ------------------------------------------------- */

  private async request<T>(
    method: 'GET' | 'POST' | 'DELETE',
    path: string,
    body: { json?: unknown; form?: FormData } = {},
  ): Promise<T> {
    const url = `${this.baseUrl}${path}`;
    let attempt = 0;
    for (;;) {
      const headers: Record<string, string> = { 'x-api-key': this.apiKey, accept: 'application/json' };
      let payload: string | FormData | undefined;
      if (body.json !== undefined) {
        headers['content-type'] = 'application/json';
        payload = JSON.stringify(body.json);
      } else if (body.form) {
        payload = body.form; // fetch sets the multipart boundary
      }
      const started = Date.now();
      let res: Response;
      try {
        res = await this.fetchImpl(url, { method, headers, body: payload });
      } catch (err) {
        if (attempt < this.maxRetries) {
          attempt += 1;
          await sleep(backoffMs(attempt));
          continue;
        }
        throw new TwelveLabsError(`Network error calling ${method} ${path}: ${(err as Error).message}`, 'network', 0);
      }
      this.onRequest?.({ method, path, status: res.status, ms: Date.now() - started });

      if (res.ok) {
        if (res.status === 204) return undefined as T;
        const text = await res.text();
        return (text ? JSON.parse(text) : undefined) as T;
      }

      const text = await res.text();
      let parsed: { code?: string; message?: string } | undefined;
      try {
        parsed = JSON.parse(text) as { code?: string; message?: string };
      } catch {
        parsed = undefined;
      }

      if (RETRYABLE.has(res.status) && attempt < this.maxRetries) {
        attempt += 1;
        const retryAfter = Number(res.headers.get('retry-after'));
        const wait = Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : backoffMs(attempt);
        await sleep(wait);
        continue;
      }

      throw new TwelveLabsError(
        parsed?.message ?? `${method} ${path} failed with HTTP ${res.status}`,
        parsed?.code ?? `http_${res.status}`,
        res.status,
        parsed ?? text,
      );
    }
  }
}

/** MIME type for a video file by extension (multipart `file` part). */
export function videoMime(path: string): string {
  switch (extname(path).toLowerCase()) {
    case '.mp4':
    case '.m4v':
      return 'video/mp4';
    case '.mov':
      return 'video/quicktime';
    case '.webm':
      return 'video/webm';
    case '.mkv':
      return 'video/x-matroska';
    case '.avi':
      return 'video/x-msvideo';
    case '.ts':
      return 'video/mp2t';
    default:
      return 'application/octet-stream';
  }
}

function backoffMs(attempt: number): number {
  // 1s, 2s, 4s, 8s, 16s (+ jitter)
  return Math.min(16000, 1000 * 2 ** (attempt - 1)) + Math.floor(Math.random() * 250);
}

/** Normalise a TwelveLabs `page_info` (shared by the live and mock listings). */
export function toPageInfo(raw: TLPageInfo | undefined, page: number, limit: number, count: number): TwelveLabsAssetPage['pageInfo'] {
  const totalResults = raw?.total_results ?? count;
  return {
    page: raw?.page ?? page,
    limitPerPage: raw?.limit_per_page ?? limit,
    totalPage: raw?.total_page ?? Math.max(1, Math.ceil(totalResults / limit)),
    totalResults,
  };
}

/**
 * Fetch every asset in the account by walking the pages (capped at `maxPages`
 * × `pageLimit` rows so a runaway account cannot hang a request).
 */
export async function listAllAssets(client: Pick<TwelveLabsClientLike, 'listAssets'>, opts: { pageLimit?: number; maxPages?: number } = {}): Promise<TwelveLabsAsset[]> {
  const pageLimit = opts.pageLimit ?? 50;
  const maxPages = opts.maxPages ?? 20;
  const all: TwelveLabsAsset[] = [];
  for (let page = 1; page <= maxPages; page++) {
    const res = await client.listAssets({ page, pageLimit });
    all.push(...res.data);
    if (page >= res.pageInfo.totalPage || res.data.length === 0) break;
  }
  return all;
}

/** Pick the `video`-scope embedding from an embed-v2 reply (falls back to the first row). */
export function pickVideoEmbedding(rows: TLEmbedResponse['data'] | undefined): number[] {
  if (!rows || rows.length === 0) throw new TwelveLabsError('embed-v2 returned no embeddings', 'empty_embedding', 502);
  const video = rows.find((r) => r.embedding_scope === 'video') ?? rows[0];
  if (!video?.embedding) throw new TwelveLabsError('embed-v2 row has no embedding', 'empty_embedding', 502);
  return video.embedding;
}

/** True when an upstream status means "done, usable". */
export function isReady(status: UpstreamStatus | string | undefined): boolean {
  return status === 'ready';
}

/** True when an upstream status is terminal-failed. */
export function isFailed(status: UpstreamStatus | string | undefined): boolean {
  return status === 'failed';
}
