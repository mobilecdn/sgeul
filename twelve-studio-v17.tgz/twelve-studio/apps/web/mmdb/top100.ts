/**
 * MMDB Top 100 — top100mmdb.html.
 *
 * The wall leads: a hundred posters ranked by whatever the viewer picks, filtered
 * by genre and decade, searchable. Clicking one plays it in the stage above, and
 * the engine rows between the two re-rank as the viewer watches. Same catalog,
 * same engine and same simulated player as mmdb.html, from engine.ts.
 */
import type { CatalogItem } from '../../../packages/core/src/types.js';
import { canonicalLabel } from '../../../packages/core/src/recommend.js';
import {
  $, PANEL_HTML, STAGE_HTML, byId, el, items, meta, play, render, renderStage,
  runtimeOf, setOnChange, state, wireTransport,
} from './engine.js';

type SortKey = 'rating' | 'popularity' | 'newest' | 'oldest' | 'longest' | 'az';
const SORTS: Array<[SortKey, string]> = [
  ['rating', 'Rating'], ['popularity', 'Popularity'], ['newest', 'Newest'],
  ['oldest', 'Oldest'], ['longest', 'Longest'], ['az', 'A–Z'],
];
const BY: Record<SortKey, (a: CatalogItem, b: CatalogItem) => number> = {
  rating: (a, b) => (meta(b).seedRating ?? 0) - (meta(a).seedRating ?? 0),
  popularity: (a, b) => (meta(b).seedPopularity ?? 0) - (meta(a).seedPopularity ?? 0),
  newest: (a, b) => (b.year ?? 0) - (a.year ?? 0),
  oldest: (a, b) => (a.year ?? 0) - (b.year ?? 0),
  longest: (a, b) => runtimeOf(b) - runtimeOf(a),
  az: (a, b) => a.title.localeCompare(b.title),
};

const decadeOf = (i: CatalogItem) => (i.year ? `${Math.floor(i.year / 10) * 10}s` : '—');
const genresOf = (i: CatalogItem) => Object.keys(i.fingerprint?.genres ?? {}).map(canonicalLabel);

let sort: SortKey = 'rating';
let genre: string | null = null;
let decade: string | null = null;
let query = '';

const genreCounts = (): Array<[string, number]> => {
  const c = new Map<string, number>();
  for (const i of items) for (const g of genresOf(i)) c.set(g, (c.get(g) ?? 0) + 1);
  return [...c.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
};
const decades = () => [...new Set(items.map(decadeOf))].sort();

function shown(): CatalogItem[] {
  const needle = query.trim().toLowerCase();
  const out = items.filter((i) => {
    if (genre && !genresOf(i).includes(genre)) return false;
    if (decade && decadeOf(i) !== decade) return false;
    if (needle) {
      const hay = `${i.title} ${i.fingerprint?.synopsis?.short ?? ''} ${Object.keys(i.fingerprint?.keywords ?? {}).join(' ')}`.toLowerCase();
      if (!hay.includes(needle)) return false;
    }
    return true;
  });
  return out.sort(BY[sort]);
}

function tile(item: CatalogItem, rank: number): HTMLElement {
  const node = el('button', `walltile${item.id === state.current.id ? ' is-playing' : ''}`);
  const art = el('span', 'walltile__art');
  if (item.posterUrl) {
    const img = document.createElement('img');
    img.src = item.posterUrl;
    img.alt = item.title;
    img.loading = 'lazy';
    art.append(img);
  }
  if (item.id === state.current.id) art.append(el('span', 'walltile__now', state.playing ? 'Playing' : 'Paused'));
  const body = el('span', 'walltile__meta');
  const line = el('span', 'walltile__title');
  line.append(el('span', 'walltile__rank', String(rank)), document.createTextNode(item.title));
  const sub = el('span', 'walltile__sub');
  sub.append(el('span', undefined, String(item.year ?? '')), el('span', 'walltile__dot', '·'), el('span', undefined, `${Math.round(runtimeOf(item) / 60)}m`));
  const rating = meta(item).seedRating;
  if (rating) sub.append(el('span', 'walltile__rating', rating.toFixed(1)));
  body.append(line, sub);
  node.append(art, body);
  node.onclick = () => play(item);
  return node;
}

function renderWall(): void {
  const list = shown();
  $('#wallcount').textContent = `${list.length} of ${items.length}`;
  const wall = $('#wall');
  wall.innerHTML = '';
  if (list.length === 0) {
    wall.append(el('p', 'muted', 'Nothing matches. Clear the search or widen the filters.'));
    return;
  }
  list.forEach((item, i) => wall.append(tile(item, i + 1)));
}

function chip(label: string, active: boolean, onClick: () => void, count?: number): HTMLElement {
  const b = el('button', `chip chip--click${active ? ' is-active' : ''}`, label);
  if (count !== undefined) b.append(el('b', undefined, String(count)));
  b.onclick = () => { onClick(); renderControls(); renderWall(); };
  return b;
}

function renderControls(): void {
  const sorts = $('#sorts');
  sorts.innerHTML = '';
  for (const [id, label] of SORTS) sorts.append(chip(label, id === sort, () => { sort = id; }));

  const g = $('#genres');
  g.innerHTML = '';
  g.append(chip('All genres', genre === null, () => { genre = null; }));
  for (const [name, n] of genreCounts()) g.append(chip(name, name === genre, () => { genre = name === genre ? null : name; }, n));

  const d = $('#decades');
  d.innerHTML = '';
  d.append(chip('Any decade', decade === null, () => { decade = null; }));
  for (const name of decades()) d.append(chip(name, name === decade, () => { decade = name === decade ? null : name; }));
}

function boot(): void {
  const years = items.map((i) => i.year ?? 0).filter(Boolean);
  const hours = Math.round(items.reduce((a, i) => a + runtimeOf(i), 0) / 3600);
  const mean = (items.reduce((a, i) => a + (meta(i).seedRating ?? 0), 0) / items.length).toFixed(1);

  document.body.innerHTML = `
  <header class="top">
    <div class="brand"><b>MMDB</b><span>Top 100 · McLeod Movie DB</span></div>
    <div class="top__right">
      <span class="tag">simulated playback · 60×</span>
      <span class="tag tag--muted">${Math.min(...years)}–${Math.max(...years)} · ${hours} hours · mean ${mean}</span>
    </div>
  </header>
  ${STAGE_HTML}
  ${PANEL_HTML}
  <section class="wallsection">
    <div class="wallhead">
      <h2>The hundred</h2>
      <span class="muted" id="wallcount"></span>
    </div>
    <div class="wallbar">
      <div class="wallsearch"><input id="q" placeholder="Search titles, synopsis, keywords…" aria-label="Search" /></div>
      <div class="chiprow" id="sorts"></div>
    </div>
    <div class="chiprow" id="genres"></div>
    <div class="chiprow chiprow--sub" id="decades"></div>
    <div class="wall" id="wall"></div>
  </section>
  <footer class="foot">MMDB Top 100 · posters by Euan McLeod. No media attached, so the stage runs a clock rather than a file. Ranking, rows and reasons are the real engine.</footer>`;

  wireTransport();
  ($('#q') as HTMLInputElement).addEventListener('input', (e) => {
    query = (e.target as HTMLInputElement).value;
    renderWall();
  });
  // The wall marks what is playing, so it redraws whenever the viewer changes.
  setOnChange(renderWall);

  renderStage();
  const top = [...items].sort(BY.rating)[0]!;
  play(top, false);
  renderControls();
  render();
}

boot();
