/**
 * Shared MMDB runtime: the catalog, the recommendation engine, the simulated
 * player and the row rendering. Both pages are thin entries on top of this —
 * `main.ts` (mmdb.html, player first) and `top100.ts` (top100mmdb.html, the
 * ranked wall first).
 *
 * The engine is the real one (`@twelve-studio/core/recommend`) running in the
 * browser against data inlined at build time. No API, no network, no storage.
 */
import {
  DEFAULT_RECO_WEIGHTS,
  buildTasteProfile,
  popularityIndex,
  recommend,
  recommendRails,
  type RecoRail,
  type Recommendation,
  type WatchEvent,
} from '../../../packages/core/src/recommend.js';
import type { CatalogItem } from '../../../packages/core/src/types.js';
import CATALOG from './data.generated.json';

export const items = CATALOG as unknown as CatalogItem[];
export const byId = new Map(items.map((i) => [i.id, i]));
const W = DEFAULT_RECO_WEIGHTS;
const VIEWER = 'mmdb-guest';
/** Simulated playback: one second of wall clock is one minute of film. */
const SPEED = 60;

let events: WatchEvent[] = [];
let seq = 0;
let timer: number | undefined;

export const state = { current: items[0]!, elapsed: 0, playing: false };
/** Pages register here to redraw whatever they own when the viewer changes. */
let onChange: () => void = () => undefined;
export const setOnChange = (fn: () => void) => { onChange = fn; };

export const $ = <T extends HTMLElement>(sel: string): T => document.querySelector(sel) as T;
export const el = (tag: string, cls?: string, text?: string): HTMLElement => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text) n.textContent = text;
  return n;
};
export const runtimeOf = (i: CatalogItem) => i.durationSec ?? 5400;
export const meta = (i: CatalogItem) => (i.metadata ?? {}) as { seedRating?: number; seedPopularity?: number };
const clock = (sec: number) => `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;

/* ---- events and ranking -------------------------------------------- */

export function record(itemId: string, action: WatchEvent['action'], completion?: number): void {
  events = [...events, { id: `e${++seq}`, profileId: VIEWER, itemId, action, completion, at: new Date().toISOString() }];
  render();
}
export const profile = () => buildTasteProfile(VIEWER, events, items, W);
const popularity = () => popularityIndex(events, W);

export const upNext = (): Recommendation[] =>
  recommend({ profile: profile(), pool: items, weights: W, popularity: popularity(), seed: state.current, limit: 12 });

const rails = (): RecoRail[] =>
  recommendRails({ profile: profile(), pool: items, weights: W, popularity: popularity(), limit: 12, maxRails: 7 }).filter((r) => r.kind !== 'next');

/* ---- playback ------------------------------------------------------- */

export function play(item: CatalogItem, autostart = true): void {
  if (state.playing && state.current.id !== item.id) commitProgress();
  state.current = item;
  state.elapsed = 0;
  renderStage();
  render();
  if (autostart) start();
  else stop();
  $('.stage').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

export function start(): void {
  state.playing = true;
  $('#play').textContent = '❙❙';
  if (timer) window.clearInterval(timer);
  timer = window.setInterval(() => {
    state.elapsed = Math.min(runtimeOf(state.current), state.elapsed + SPEED / 4);
    paintProgress();
    if (state.elapsed >= runtimeOf(state.current)) finish();
  }, 250);
}

export function stop(): void {
  state.playing = false;
  $('#play').textContent = '▶';
  if (timer) window.clearInterval(timer);
  timer = undefined;
}

/** Leaving a title part-watched is a watch event too — Continue watching is built from these. */
export function commitProgress(): void {
  const done = state.elapsed / runtimeOf(state.current);
  if (done > 0.02) record(state.current.id, 'watch', Number(done.toFixed(3)));
}

function finish(): void {
  stop();
  record(state.current.id, 'watch', 1);
  const next = upNext()[0];
  const item = next && byId.get(next.itemId);
  if (item) window.setTimeout(() => play(item), 900);
}

/* ---- rendering ------------------------------------------------------ */

export const STAGE_HTML = `
  <section class="stage">
    <img id="backdrop" class="stage__backdrop" alt="" />
    <div class="stage__inner">
      <div class="stage__art"><img id="art" alt="" /></div>
      <div class="stage__body">
        <h1 id="title"></h1>
        <div id="meta" class="stage__meta"></div>
        <p id="synopsis" class="stage__synopsis"></p>
        <div class="transport">
          <button id="play" class="btn btn--play">▶</button>
          <div class="track" id="track"><div class="track__bar" id="bar"></div></div>
          <span id="time" class="time"></span>
        </div>
        <div class="actions">
          <button id="like" class="btn">♥ Like</button>
          <button id="skip" class="btn">✕ Not for me</button>
          <button id="next" class="btn">Next up ▸</button>
        </div>
      </div>
    </div>
  </section>`;

export const PANEL_HTML = `
  <section class="panel">
    <h2>What it has learned</h2>
    <div id="taste"></div>
  </section>
  <div id="rows"></div>`;

export function renderStage(): void {
  const fp = state.current.fingerprint;
  $('#art').setAttribute('src', state.current.posterUrl ?? '');
  $('#backdrop').setAttribute('src', state.current.posterUrl ?? '');
  $('#title').textContent = state.current.title;
  $('#meta').textContent = [state.current.year, fp?.audienceRating?.suggested, `${Math.round(runtimeOf(state.current) / 60)} min`, Object.keys(fp?.genres ?? {}).slice(0, 3).join(' · ')]
    .filter(Boolean)
    .join('  ·  ');
  $('#synopsis').textContent = fp?.synopsis?.short ?? '';
  paintProgress();
}

export function paintProgress(): void {
  const pct = Math.min(1, state.elapsed / runtimeOf(state.current));
  ($('#bar') as HTMLElement).style.width = `${pct * 100}%`;
  $('#time').textContent = `${clock(state.elapsed)} / ${clock(runtimeOf(state.current))}`;
}

export function card(rec: Recommendation): HTMLElement {
  const item = byId.get(rec.itemId);
  const node = el('button', 'card');
  const art = el('span', 'card__art');
  if (item?.posterUrl) {
    const img = document.createElement('img');
    img.src = item.posterUrl;
    img.alt = rec.title;
    img.loading = 'lazy';
    art.append(img);
  }
  const match = el('span', 'card__match', `${Math.round(Math.max(0, rec.score) * 100)}`);
  match.title = `engine score ${rec.score.toFixed(3)}`;
  art.append(match);
  const body = el('span', 'card__body');
  body.append(el('span', 'card__title', rec.title));
  const why = el('span', 'card__why');
  for (const b of rec.because.slice(0, 2)) why.append(el('span', b.includes('+') ? 'why why--combo' : 'why', b));
  body.append(why);
  node.append(art, body);
  node.onclick = () => { if (item) play(item); };
  return node;
}

function row(title: string, reason: string, recs: Recommendation[]): HTMLElement {
  const node = el('section', 'row');
  const head = el('div', 'row__head');
  head.append(el('h3', undefined, title), el('span', 'row__reason', reason));
  const strip = el('div', 'strip');
  for (const r of recs) strip.append(card(r));
  node.append(head, strip);
  return node;
}

function renderTaste(): void {
  const p = profile();
  const box = $('#taste');
  box.innerHTML = '';
  if (p.events === 0) {
    box.append(el('p', 'muted', 'Nothing watched yet. Every row below is ranked by catalog popularity until you play something.'));
    return;
  }
  const combos = p.topCombos.filter((c) => c.weight > 0.2).slice(0, 3);
  if (combos.length) {
    box.append(el('div', 'taste__label', 'Combinations'));
    const line = el('div', 'taste__chips');
    for (const c of combos) line.append(el('span', 'chip chip--combo', `${c.label} ${c.weight.toFixed(2)}`));
    box.append(line);
  }
  box.append(el('div', 'taste__label', 'Labels'));
  const line = el('div', 'taste__chips');
  for (const t of p.top.slice(0, 8)) line.append(el('span', 'chip', `${t.label} ${t.weight.toFixed(2)}`));
  box.append(line);
  box.append(el('p', 'muted', `${p.events} event${p.events === 1 ? '' : 's'} · ${p.interacted.length} title${p.interacted.length === 1 ? '' : 's'} rated or played`));
}

export function render(): void {
  const rowsBox = $('#rows');
  rowsBox.innerHTML = '';
  const next = upNext();
  // Before any history, up next is carried entirely by the seed term and most of the
  // catalog scores under the engine's minimum, so a cold viewer gets popularity instead
  // of a row with one title in it.
  let cold = false;
  if (next.length >= 6) {
    rowsBox.append(row(`Because you are watching ${state.current.title}`, 'Closest titles to what is on, steered by this viewer.', next.slice(0, 12)));
  } else {
    cold = true;
    const popular = recommend({ profile: profile(), pool: items, weights: W, popularity: popularity(), limit: 12, exclude: new Set([state.current.id]) });
    rowsBox.append(row('Popular on MMDB', 'No history yet, so the catalog is ranked by popularity and variety.', popular));
  }
  for (const rail of rails()) {
    if (cold && rail.kind === 'foryou') continue;
    rowsBox.append(row(rail.title, rail.reason, rail.items));
  }
  renderTaste();
  onChange();
}

export function wireTransport(): void {
  $('#play').onclick = () => (state.playing ? (commitProgress(), stop()) : start());
  $('#like').onclick = () => record(state.current.id, 'like');
  $('#skip').onclick = () => { record(state.current.id, 'skip'); const n = upNext()[0]; const item = n && byId.get(n.itemId); if (item) play(item); };
  $('#next').onclick = () => { commitProgress(); const n = upNext()[0]; const item = n && byId.get(n.itemId); if (item) play(item); };
  $('#track').onclick = (e) => {
    const t = $('#track').getBoundingClientRect();
    state.elapsed = Math.max(0, Math.min(1, ((e as MouseEvent).clientX - t.left) / t.width)) * runtimeOf(state.current);
    paintProgress();
  };
  window.addEventListener('keydown', (e) => {
    if (e.key === ' ' && (e.target as HTMLElement)?.tagName !== 'INPUT') {
      e.preventDefault();
      state.playing ? (commitProgress(), stop()) : start();
    }
  });
}
