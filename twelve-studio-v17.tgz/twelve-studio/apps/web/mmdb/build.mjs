/**
 * Builds the two standalone MMDB pages into apps/web/public/:
 *   mmdb.html        player first
 *   top100mmdb.html  the ranked wall, with the same player above it
 *
 * Both are one file each: no network, no API, no storage. The catalog is inlined
 * with its embeddings stripped — the engine rebuilds the hashed label vector from
 * the fingerprint, which is byte-for-byte what was stored, so the ranking is
 * identical and each file stays near two megabytes.
 */
import { readFileSync, writeFileSync, rmSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '../../..');

const bundles = JSON.parse(readFileSync(resolve(ROOT, 'data/seed/mmdb100.json'), 'utf8'));
const items = bundles.map((b) => {
  const item = { ...b.item };
  if (item.fingerprint) {
    const { embedding: _drop, ...fp } = item.fingerprint;
    item.fingerprint = fp;
  }
  return item;
});
const dataPath = resolve(HERE, 'data.generated.json');
writeFileSync(dataPath, JSON.stringify(items));

const css = readFileSync(resolve(HERE, 'mmdb.css'), 'utf8');

async function page(entry, out, title) {
  const built = await build({
    entryPoints: [resolve(HERE, entry)],
    bundle: true,
    minify: true,
    format: 'iife',
    target: 'es2020',
    write: false,
    loader: { '.json': 'json' },
  });
  const js = built.outputFiles[0].text;
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>${title}</title>
<style>${css}</style>
</head>
<body></body>
<script>${js}</script>
</html>`;
  const target = resolve(ROOT, 'apps/web/public', out);
  writeFileSync(target, html);
  console.log(`${out} ${(html.length / 1024).toFixed(0)} KB (js ${(js.length / 1024).toFixed(0)} KB)`);
}

await page('main.ts', 'mmdb.html', 'MMDB · McLeod Movie DB');
await page('top100.ts', 'top100mmdb.html', 'MMDB Top 100 · McLeod Movie DB');
rmSync(dataPath, { force: true });
console.log(`${items.length} titles inlined in each`);
