/**
 * MMDB (McLeod Movie DB) — the player page, mmdb.html.
 *
 * Stage first: a title is always on, and the engine rows underneath re-rank as
 * the viewer plays, likes and skips. The catalog, the engine and the simulated
 * playback all live in engine.ts, which top100.ts shares.
 */
import { PANEL_HTML, STAGE_HTML, items, meta, play, render, renderStage, wireTransport } from './engine.js';

function boot(): void {
  document.body.innerHTML = `
  <header class="top">
    <div class="brand"><b>MMDB</b><span>McLeod Movie DB</span></div>
    <div class="top__right">
      <span class="tag">simulated playback · 60×</span>
      <span class="tag tag--muted">${items.length} titles · engine in the browser</span>
    </div>
  </header>
  ${STAGE_HTML}
  ${PANEL_HTML}
  <footer class="foot">MMDB · posters by Euan McLeod. No media attached, so the stage runs a clock rather than a file. The ranking is the real engine: watch events in, rows out.</footer>`;

  wireTransport();
  renderStage();
  // Open on the most popular title so the first screen is not arbitrary.
  const seed = [...items].sort((a, b) => (meta(b).seedPopularity ?? 0) - (meta(a).seedPopularity ?? 0))[0]!;
  play(seed, false);
  render();
}

boot();
