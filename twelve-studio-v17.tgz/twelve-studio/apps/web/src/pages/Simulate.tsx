/**
 * Simulate — the recommendation engine put on trial against a broad catalog.
 *
 * The real catalog is a dozen titles, which is too few for the combination rows
 * to mean anything. `data/seed/fake100.json` adds 100 fictional titles modelled on
 * the IMDb top 100 (no media, `metadata.synthetic = true`), deliberately shaped so
 * that tastes overlap: five horror + romance titles against plain horror and plain
 * romance, franchise clusters, a pacing spread and a rating spread.
 *
 * A scenario is a scripted viewer: a few watch/like/skip events, plus the claims
 * the engine is expected to satisfy afterwards. Playing one posts the events to
 * `POST /reco/simulate` (nothing is stored), draws the rows a player would render,
 * and marks each claim pass or fail with the numbers that decided it.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CatalogItem, Recommendation, RecoRail } from '@twelve-studio/core';
import { canonicalLabel } from '@twelve-studio/core/recommend';
import { Button, Card, EmptyState, ErrorNote, Meter, StatTile, StatusPill } from '../components/ui';
import { Icon } from '../components/Icon';
import { PosterArt } from '../components/Poster';
import { useApi, useQuery } from '../lib/hooks';
import type { ViewerProfile } from '../lib/api';
import { useTopbar } from '../App';

/* ------------------------------------------------------------------ */
/* Scenarios                                                           */
/* ------------------------------------------------------------------ */

type StepAction = 'watch' | 'like' | 'skip';
interface Step {
  itemId: string;
  action: StepAction;
  completion?: number;
  note: string;
}

/** What the engine is expected to do once a scenario has played out. */
interface Claim {
  label: string;
  run: (ctx: Ctx) => { ok: boolean; detail: string };
}

interface Ctx {
  /** Every recommended title, best score first, deduped across rows. */
  ranked: Array<Recommendation & { labels: Set<string> }>;
  rails: RecoRail[];
  profile: ViewerProfile | null;
  titleOf: (id: string) => string;
}

interface Scenario {
  id: string;
  name: string;
  premise: string;
  icon: 'heart' | 'shield' | 'layers' | 'film' | 'star' | 'users';
  steps: Step[];
  claims: Claim[];
  /** Shown when a claim fails: what the failure exposes, so a red mark reads as a result. */
  finding?: string;
}

const has = (r: { labels: Set<string> }, ...labels: string[]) => labels.every((l) => r.labels.has(l));
const best = (ctx: Ctx, pred: (r: Ctx['ranked'][number]) => boolean) => ctx.ranked.find(pred);
const show = (ctx: Ctx, r?: Ctx['ranked'][number]) => (r ? `${ctx.titleOf(r.itemId)} ${r.score.toFixed(2)}` : 'nothing');

/** The headline claim: a title carrying both tastes must beat either taste alone. */
const comboBeatsEitherAlone = (a: string, b: string): Claim => ({
  label: `${a} + ${b} outranks plain ${a} and plain ${b}`,
  run: (ctx) => {
    const both = best(ctx, (r) => has(r, a, b));
    const onlyA = best(ctx, (r) => r.labels.has(a) && !r.labels.has(b));
    const onlyB = best(ctx, (r) => r.labels.has(b) && !r.labels.has(a));
    if (!both) return { ok: false, detail: `no ${a} + ${b} title left in the pool` };
    const ok = (!onlyA || both.score > onlyA.score) && (!onlyB || both.score > onlyB.score);
    return { ok, detail: `${show(ctx, both)} vs ${show(ctx, onlyA)} and ${show(ctx, onlyB)}` };
  },
});

const topCarries = (...labels: string[]): Claim => ({
  label: `top pick is ${labels.join(' + ')}`,
  run: (ctx) => {
    const top = ctx.ranked[0];
    if (!top) return { ok: false, detail: 'nothing was recommended' };
    return { ok: has(top, ...labels), detail: `${show(ctx, top)} — ${[...top.labels].slice(0, 4).join(', ')}` };
  },
});

const comboLearned = (label: string): Claim => ({
  label: `learns the combination "${label}"`,
  run: (ctx) => {
    const c = ctx.profile?.topCombos?.find((x) => x.label === label);
    return { ok: !!c && c.weight > 0.5, detail: c ? `${c.label} at ${c.weight.toFixed(2)}` : 'not in the profile' };
  },
});

const rowExists = (title: string): Claim => ({
  label: `a "${title}" row is built`,
  run: (ctx) => {
    const rail = ctx.rails.find((r) => r.title.toLowerCase().includes(title.toLowerCase()));
    return { ok: !!rail && rail.items.length > 0, detail: rail ? `${rail.title} — ${rail.items.length} titles` : 'no such row' };
  },
});

const inTop = (itemId: string, n: number, name: string): Claim => ({
  label: `${name} lands in the top ${n}`,
  run: (ctx) => {
    const i = ctx.ranked.findIndex((r) => r.itemId === itemId);
    const name = ctx.titleOf(itemId);
    return { ok: i >= 0 && i < n, detail: i < 0 ? `${name} is not in the pool` : `${name} at #${i + 1} (${ctx.ranked[i]!.score.toFixed(2)})` };
  },
});

const nothingRewatched: Claim = {
  label: 'nothing already finished comes back',
  run: (ctx) => {
    const watched = Object.entries(ctx.profile?.watched ?? {}).filter(([, c]) => c >= 0.9).map(([id]) => id);
    const repeat = ctx.ranked.find((r) => watched.includes(r.itemId) && !ctx.rails.some((rail) => rail.kind === 'continue' && rail.items.some((i) => i.itemId === r.itemId)));
    return { ok: !repeat, detail: repeat ? `${ctx.titleOf(repeat.itemId)} came back` : `${watched.length} finished title(s) held out` };
  },
};

const SCENARIOS: Scenario[] = [
  {
    id: 'romantic-horror',
    name: 'Romantic horror',
    premise: 'The case the engine was built for: a viewer whose taste is a pair of genres, not either one.',
    icon: 'heart',
    steps: [
      { itemId: 'fake-021', action: 'watch', completion: 0.97, note: 'watches The Hollow Bride almost to the end' },
      { itemId: 'fake-022', action: 'like', note: 'likes Blood Like Honey' },
    ],
    claims: [
      comboLearned('horror + romance'),
      topCarries('horror', 'romance'),
      comboBeatsEitherAlone('horror', 'romance'),
      rowExists('More Horror + Romance'),
      nothingRewatched,
    ],
  },
  {
    id: 'horror',
    name: 'Horror only',
    premise: 'The control for the case above: plain horror must not drag romance up with it.',
    icon: 'shield',
    steps: [
      { itemId: 'fake-024', action: 'watch', completion: 0.95, note: 'watches Room 1408 Is Fine' },
      { itemId: 'fake-025', action: 'watch', completion: 0.9, note: 'watches The Hosts' },
    ],
    claims: [
      topCarries('horror'),
      {
        label: 'no romance-only title reaches the top three',
        run: (ctx) => {
          const intruder = ctx.ranked.slice(0, 3).find((r) => r.labels.has('romance') && !r.labels.has('horror'));
          return { ok: !intruder, detail: intruder ? `${ctx.titleOf(intruder.itemId)} at ${intruder.score.toFixed(2)}` : 'top three are all horror-adjacent' };
        },
      },
      nothingRewatched,
    ],
  },
  {
    id: 'romance',
    name: 'Romance, half-finished',
    premise: 'One title finished, one abandoned a third of the way in: the abandoned one belongs in Continue watching, not in the recommendations.',
    icon: 'star',
    steps: [
      { itemId: 'fake-039', action: 'watch', completion: 0.95, note: 'finishes Champagne and Lifeboats' },
      { itemId: 'fake-040', action: 'watch', completion: 0.35, note: 'gets a third of the way through Letters from Ravenna' },
    ],
    claims: [
      topCarries('romance'),
      rowExists('Continue watching'),
      {
        label: 'the abandoned title is the one offered to continue',
        run: (ctx) => {
          const rail = ctx.rails.find((r) => r.kind === 'continue');
          const first = rail?.items[0];
          return { ok: first?.itemId === 'fake-040', detail: first ? ctx.titleOf(first.itemId) : 'no Continue watching row' };
        },
      },
    ],
  },
  {
    id: 'mob',
    name: 'Mob saga',
    premise: 'Franchise continuity: watching the first Marchetti film should surface its sequel without anyone tagging them as a series.',
    icon: 'layers',
    steps: [
      { itemId: 'fake-002', action: 'watch', completion: 0.99, note: 'finishes The Marchetti Family' },
      { itemId: 'fake-048', action: 'watch', completion: 0.85, note: 'watches Powder and Pearls' },
    ],
    claims: [comboLearned('crime + drama'), inTop('fake-003', 3, 'the Marchetti sequel'), topCarries('crime'), nothingRewatched],
  },
  {
    id: 'family',
    name: 'Family animation',
    premise: 'The far end of the catalog: a household watching animation should not be handed an R-rated crime saga. This case failed on a fifty-title catalog, and what fixed it was depth, not the engine — see the note below.',
    icon: 'film',
    steps: [
      { itemId: 'fake-043', action: 'watch', completion: 0.95, note: 'watches Little Kingdom' },
      { itemId: 'fake-045', action: 'like', note: 'likes Inside Out of Order' },
    ],
    claims: [
      topCarries('animation'),
      {
        label: 'no horror or crime title reaches the top five',
        run: (ctx) => {
          const intruder = ctx.ranked.slice(0, 5).find((r) => r.labels.has('horror') || r.labels.has('crime'));
          return { ok: !intruder, detail: intruder ? `${ctx.titleOf(intruder.itemId)} at ${intruder.score.toFixed(2)}` : 'top five stay family-shaped' };
        },
      },
    ],
    finding:
      'On the fifty-title catalog this scenario failed: two family films left one animation title in the pool and a high-concept grief drama tied with it, because the liked film contributed the theme "grief" and the mood tag "high concept". Combinations are built from genres, mood tags and themes with no facet weighting, so a thematic coincidence pulls as hard as the genre that defines the audience — turning the theme and mood-tag dials to zero still left it near the top, since the facet weights never reach the combination term. Doubling the catalog gave the row enough animation to recommend and the claims now pass, but the weighting gap is still there and will resurface wherever a taste is thin.',
  },
  {
    id: 'cold',
    name: 'Cold start',
    premise: 'A viewer with no history at all: popularity and variety have to carry the page.',
    icon: 'users',
    steps: [],
    claims: [
      rowExists('Picked for you'),
      {
        label: 'every pick is explained by popularity, not by taste',
        run: (ctx) => {
          const wrong = ctx.ranked.find((r) => r.because.some((b) => !/popular|new viewer/i.test(b)));
          return { ok: !wrong && ctx.ranked.length > 0, detail: wrong ? `${ctx.titleOf(wrong.itemId)}: ${wrong.because.join(', ')}` : `${ctx.ranked.length} titles, all cold-start ranked` };
        },
      },
    ],
  },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

/** Every canonical label a title carries, across the facets the rows are built on. */
function labelsOf(item: CatalogItem | undefined): Set<string> {
  const fp = item?.fingerprint;
  const out = new Set<string>();
  if (!fp) return out;
  for (const facet of ['genres', 'moodTags', 'themes', 'moods'] as const) {
    for (const raw of Object.keys(fp[facet] ?? {})) out.add(canonicalLabel(raw));
  }
  return out;
}

export function Simulate() {
  const api = useApi();
  const catalog = useQuery(() => api.catalog(), []);
  const [scenarioId, setScenarioId] = useState(SCENARIOS[0]!.id);
  const [played, setPlayed] = useState(0);
  const [rails, setRails] = useState<RecoRail[]>([]);
  const [profile, setProfile] = useState<ViewerProfile | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<Error | null>(null);
  const autoplay = useRef<ReturnType<typeof setTimeout> | null>(null);

  const scenario = SCENARIOS.find((s) => s.id === scenarioId)!;
  const items = useMemo(() => new Map((catalog.data ?? []).map((i) => [i.id, i])), [catalog.data]);
  const synthetic = useMemo(() => (catalog.data ?? []).filter((i) => (i.metadata as { synthetic?: boolean } | undefined)?.synthetic), [catalog.data]);
  const titleOf = useCallback((id: string) => items.get(id)?.title ?? id, [items]);

  const genreSpread = useMemo(() => {
    const count = new Map<string, number>();
    for (const i of synthetic) for (const g of Object.keys(i.fingerprint?.genres ?? {})) count.set(canonicalLabel(g), (count.get(canonicalLabel(g)) ?? 0) + 1);
    return [...count.entries()].sort((a, b) => b[1] - a[1]);
  }, [synthetic]);

  /** Titles carrying both halves of a pair — the rows that need a broad catalog. */
  const comboDepth = useMemo(() => {
    const pairs: Array<[string, string]> = [
      ['horror', 'romance'],
      ['horror', 'comedy'],
      ['science fiction', 'romance'],
      ['crime', 'comedy'],
      ['war', 'drama'],
    ];
    return pairs.map(([a, b]) => ({ pair: `${a} + ${b}`, n: synthetic.filter((i) => { const l = labelsOf(i); return l.has(a) && l.has(b); }).length }));
  }, [synthetic]);

  const run = useCallback(
    async (upTo: number) => {
      setBusy(true);
      setErr(null);
      try {
        const events = scenario.steps.slice(0, upTo).map((s) => ({ itemId: s.itemId, action: s.action, completion: s.action === 'watch' ? s.completion ?? 1 : undefined }));
        const last = scenario.steps.slice(0, upTo).filter((s) => s.action === 'watch').at(-1);
        const res = await api.simulateReco({ profileId: `sim-${scenario.id}`, events, seedId: last?.itemId, limit: 8, maxRails: 8 });
        setRails(res.rails);
        setProfile(res.profile);
      } catch (e) {
        setErr(e as Error);
      } finally {
        setBusy(false);
      }
    },
    [api, scenario],
  );

  // Scenario change: back to nothing watched, then play it out a step at a time.
  useEffect(() => {
    if (autoplay.current) clearTimeout(autoplay.current);
    setPlayed(0);
    void run(0);
    let i = 0;
    let cancelled = false;
    // Each step waits for the previous scoring to finish rather than firing on a fixed
    // timer: on a hundred-title catalog a ranking pass is real work, and a fixed
    // interval just queues runs up behind it.
    const tick = async () => {
      if (cancelled || i >= scenario.steps.length) return;
      i += 1;
      setPlayed(i);
      await run(i);
      if (cancelled) return;
      autoplay.current = setTimeout(() => void tick(), 450);
    };
    autoplay.current = setTimeout(() => void tick(), 400);
    return () => {
      cancelled = true;
      if (autoplay.current) clearTimeout(autoplay.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scenarioId, catalog.data]);

  useTopbar(
    <div className="row" style={{ gap: 8 }}>
      {busy && <span className="muted small">scoring…</span>}
      <span className="mono muted" style={{ fontSize: 11 }}>
        POST /reco/simulate
      </span>
    </div>,
    [busy],
  );

  /**
   * One ranking across the taste rows: best score per title wins, rows only decide placement.
   * Continue watching is held out (it is a resume list, not a ranking) and so is "Because you
   * watched", whose scores are steered by the title playing — the claims judge taste alone.
   */
  const ranked = useMemo(() => {
    const seen = new Map<string, Recommendation & { labels: Set<string> }>();
    for (const rail of rails) {
      if (rail.kind === 'continue' || rail.kind === 'next') continue;
      for (const rec of rail.items) {
        const prev = seen.get(rec.itemId);
        if (!prev || prev.score < rec.score) seen.set(rec.itemId, { ...rec, labels: labelsOf(items.get(rec.itemId)) });
      }
    }
    return [...seen.values()].sort((a, b) => b.score - a.score);
  }, [rails, items]);

  const ctx: Ctx = { ranked, rails, profile, titleOf };
  const results = scenario.claims.map((c) => ({ label: c.label, ...c.run(ctx) }));
  const passed = results.filter((r) => r.ok).length;
  const settled = played >= scenario.steps.length && !busy;

  if (catalog.loading) return <div className="content"><Card title="Simulate"><EmptyState icon="layers" title="Loading the catalog…" /></Card></div>;

  if (synthetic.length === 0)
    return (
      <div className="content">
        <Card title="Simulate" icon="layers">
          <EmptyState
            icon="layers"
            title="The synthetic catalog is not loaded"
            text="This page runs the engine against the 100 fictional titles in data/seed/fake100.json. Build them with `npx tsx data/seed/build-fake100.ts`, draw the posters with `build-fake100-posters.ts`, merge the bundles into the store, then reload."
          />
        </Card>
      </div>
    );

  return (
    <div className="content">
      <div className="stack stack--lg" style={{ maxWidth: 1600 }}>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
          <StatTile label="Synthetic titles" value={synthetic.length} hint="fictional, no media, metadata.synthetic" accent="var(--violet)" />
          <StatTile label="Genres covered" value={genreSpread.length} hint={genreSpread.slice(0, 4).map(([g, n]) => `${g} ${n}`).join(' · ')} accent="var(--blue)" />
          <StatTile label="Claims passing" value={`${passed}/${results.length}`} hint={settled ? 'scenario has played out' : 'still playing'} accent={passed === results.length ? 'var(--green)' : 'var(--orange)'} />
          <StatTile label="Titles in the pool" value={ranked.length} hint="scored and returned in a row" accent="var(--info)" />
        </div>

        <ErrorNote error={err} />

        <div className="reco">
          {/* ---------------- left: the scenario ---------------- */}
          <div className="stack">
            <Card title="Scenario" icon="users" sub="A scripted viewer, replayed against the engine">
              <div className="stack" style={{ gap: 6 }}>
                {SCENARIOS.map((s) => (
                  <button key={s.id} className={`simscenario${s.id === scenarioId ? ' is-active' : ''}`} onClick={() => setScenarioId(s.id)}>
                    <Icon name={s.icon} size={14} />
                    <span className="simscenario__name">{s.name}</span>
                    <span className="simscenario__n mono">{s.steps.length}</span>
                  </button>
                ))}
              </div>
              <p className="muted small" style={{ marginTop: 12 }}>{scenario.premise}</p>
            </Card>

            <Card title="Why this catalog" icon="grid" sub="Titles carrying both halves of a pair — what the combination rows need">
              <div className="stack" style={{ gap: 4 }}>
                {comboDepth.map((c) => (
                  <div key={c.pair} className="simlabel">
                    <span>{c.pair}</span>
                    <Meter value={Math.min(1, c.n / 4)} color={c.n > 0 ? 'var(--violet)' : 'var(--line-strong)'} thin />
                    <b className="mono">{c.n}</b>
                  </div>
                ))}
              </div>
            </Card>

            <Card
              title="What they did"
              icon="play"
              sub="Posted to /reco/simulate — nothing is stored"
              actions={
                <div className="row" style={{ gap: 6 }}>
                  <Button size="sm" variant="ghost" icon="refresh" onClick={() => { setPlayed(0); void run(0); }}>
                    Reset
                  </Button>
                  <Button size="sm" icon="play" disabled={played >= scenario.steps.length} onClick={() => { const n = played + 1; setPlayed(n); void run(n); }}>
                    Step
                  </Button>
                </div>
              }
            >
              {scenario.steps.length === 0 && <p className="muted small">No history at all. This is what a first-time viewer sees.</p>}
              <div className="stack" style={{ gap: 8 }}>
                {scenario.steps.map((s, i) => (
                  <div key={`${s.itemId}_${i}`} className={`simstep${i < played ? ' is-done' : ''}`}>
                    <span className="simstep__dot">{i < played ? <Icon name="check" size={11} /> : i + 1}</span>
                    <div>
                      <div className="simstep__title">{titleOf(s.itemId)}</div>
                      <div className="muted small">{s.note}</div>
                    </div>
                    <StatusPill status={s.action} tone={s.action === 'like' ? 'green' : s.action === 'skip' ? 'red' : 'blue'} />
                  </div>
                ))}
              </div>
            </Card>

            <Card title="What it learned" icon="sparkle" sub="The taste profile that falls out of those events">
              {!profile || profile.events === 0 ? (
                <p className="muted small">Nothing yet — a cold viewer has no profile to show.</p>
              ) : (
                <div className="stack" style={{ gap: 14 }}>
                  <div>
                    <div className="muted small" style={{ marginBottom: 6 }}>Combinations</div>
                    {(profile.topCombos ?? []).slice(0, 4).map((c) => (
                      <div key={c.label} className="simlabel">
                        <span>{c.label}</span>
                        <Meter value={c.weight} color="var(--violet)" thin />
                        <b className="mono">{c.weight.toFixed(2)}</b>
                      </div>
                    ))}
                    {(profile.topCombos ?? []).length === 0 && <span className="muted small">none yet</span>}
                  </div>
                  <div>
                    <div className="muted small" style={{ marginBottom: 6 }}>Labels</div>
                    {(profile.top ?? []).slice(0, 6).map((t) => (
                      <div key={`${t.facet}_${t.label}`} className="simlabel">
                        <span>{t.label}</span>
                        <Meter value={t.weight} color="var(--blue)" thin />
                        <b className="mono">{t.weight.toFixed(2)}</b>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          </div>

          {/* ---------------- right: the verdict and the rows ---------------- */}
          <div className="stack">
            <Card
              title="Claims"
              icon={passed === results.length ? 'check' : 'alert'}
              sub={settled ? `${passed} of ${results.length} hold on this catalog` : 'playing the scenario out…'}
            >
              <div className="stack" style={{ gap: 8 }}>
                {results.map((r) => (
                  <div key={r.label} className={`simclaim${r.ok ? ' is-ok' : ''}`}>
                    <Icon name={r.ok ? 'check' : settled ? 'x' : 'clock'} size={13} />
                    <div>
                      <div className="simclaim__label">{r.label}</div>
                      <div className="muted small mono">{r.detail}</div>
                    </div>
                  </div>
                ))}
              </div>
              {settled && passed < results.length && scenario.finding && (
                <div className="simfinding">
                  <Icon name="info" size={13} />
                  <p>{scenario.finding}</p>
                </div>
              )}
            </Card>

            {rails.map((rail) => (
              <Card key={rail.id} title={rail.title} sub={rail.reason} flush>
                <div className="recorail" style={{ padding: '0 16px 14px' }}>
                  {rail.items.map((rec) => {
                    const item = items.get(rec.itemId);
                    return (
                      <div key={rec.itemId} className="recocard">
                        <div className="recocard__art">
                          {item ? <PosterArt item={item} /> : <div className="recocard__blank" />}
                          <span className="recocard__score mono">{Math.round(Math.max(0, rec.score) * 100)}</span>
                        </div>
                        <div className="recocard__body">
                          <div className="recocard__title" title={rec.title}>{rec.title}</div>
                          <div className="recocard__because">
                            {rec.because.slice(0, 2).map((b) => (
                              <span key={b} className={`recocard__reason${b.includes('+') ? ' recocard__reason--combo' : ''}`}>{b}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
