import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Card, ErrorNote, Meter, Skeleton, StatusPill } from '../components/ui';
import { Icon } from '../components/Icon';
import { useApi, useHealth, useQuery, useToast } from '../lib/hooks';
import { isStaticMode } from '../lib/api';
import { estimateCost, MODELS, PRICING } from '../lib/pricing';
import { hours, money } from '../lib/format';
import { useTopbar } from '../App';

export function Settings() {
  const api = useApi();
  const nav = useNavigate();
  const health = useHealth();
  const toast = useToast();
  const stats = useQuery(() => api.stats(), []);
  const assets = useQuery(() => api.twelvelabsAssets({ pageLimit: 50 }), []);
  const account = (() => {
    const rows = assets.data?.assets ?? [];
    const sec = rows.reduce((acc, a) => acc + (a.duration ?? 0), 0);
    return {
      count: assets.data?.pageInfo.totalResults ?? rows.length,
      hours: sec / 3600,
      linkedTitles: rows.filter((a) => a.linked?.kind === 'title').length,
      linkedAds: rows.filter((a) => a.linked?.kind === 'ad').length,
      unlinked: rows.filter((a) => !a.linked && a.status === 'ready').length,
      processing: rows.filter((a) => a.status !== 'ready').length,
    };
  })();
  const [h, setH] = useState<number | null>(null);
  const [items, setItems] = useState<number | null>(null);
  const [queries, setQueries] = useState(1000);
  const [resetting, setResetting] = useState(false);
  const catalogHours = hours(stats.data?.totalDurationSec ?? 0);
  const hoursIn = h ?? Math.max(1, Math.round(catalogHours * 10) / 10);
  const itemsIn = items ?? Math.max(1, stats.data?.items ?? 1);
  const cost = estimateCost(hoursIn, itemsIn, queries);
  const mode = health?.mode ?? (isStaticMode() ? 'static' : 'mock');
  const isStatic = isStaticMode();

  useTopbar(null, []);

  const rows: Array<[string, number, string, string]> = [
    ['Index (Marengo 3.0)', cost.index, `$${PRICING.indexPerHour.toFixed(2)} / h × ${hoursIn} h`, '#0068e0'],
    ['Analyze input (Pegasus 1.5)', cost.analyze, `$${PRICING.analyzePerHourIn} / h × ${PRICING.analyzeCallsPerItem} calls × ${hoursIn} h`, '#6d3fd4'],
    ['Analyze output tokens', cost.analyzeTokens, `${PRICING.analyzeCallsPerItem} × ${PRICING.outputTokensPerCall.toLocaleString()} tokens × ${itemsIn} titles × $${PRICING.analyzePerMTokensOut} / M`, '#c8b0ff'],
    ['Embed (Marengo 3.5)', cost.embed, `${(PRICING.embedTokensPerHour / 1000).toFixed(0)}k tokens / h × $${PRICING.embedPerMTokens} / M`, '#2fbfa6'],
    ['Search', cost.search, `${queries.toLocaleString()} queries × $${PRICING.searchPer1kQueries} / 1k`, '#8cbaff'],
  ];

  return (
    <div className="content">
      <div className="stack stack--lg" style={{ maxWidth: 1100 }}>
        <div className="grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Card title="Connection" icon="key" sub="How this workspace talks to TwelveLabs">
            <dl className="kv" style={{ gridTemplateColumns: '140px 1fr' }}>
              <dt>Mode</dt>
              <dd>
                <StatusPill status={mode}>{mode === 'live' ? 'live — real API calls' : mode === 'mock' ? 'mock — seeded data' : 'static demo — in-browser'}</StatusPill>
              </dd>
              <dt>API key</dt>
              <dd className="row" style={{ gap: 8 }}>
                <Icon name={mode === 'live' ? 'check' : 'alert'} size={14} style={{ color: mode === 'live' ? '#5ec16a' : '#ffa361' }} />
                {mode === 'live' ? 'TWELVELABS_API_KEY present on the API server' : 'No TWELVELABS_API_KEY — set it in .env to go live'}
              </dd>
              <dt>Index</dt>
              <dd className="mono">{health?.index ?? (mode === 'live' ? 'creating on first run…' : 'twelve-studio (mock)')}</dd>
              <dt>Base URL</dt>
              <dd className="mono">https://api.twelvelabs.io/v1.3</dd>
              <dt>API server</dt>
              <dd className="mono">{isStatic ? 'none — StaticApi provider' : health?.ok ? 'http://localhost:8787 (proxied at /api)' : 'unreachable'}</dd>
              <dt>Synopsis langs</dt>
              <dd>es, fr, de, ja, pt, ar, hi, ko</dd>
            </dl>
          </Card>
          <Card title="Model versions" icon="layers" sub="Pinned in @twelve-studio/core">
            <div className="stack">
              {[
                ['Index & search', health?.models?.index ?? MODELS.index, 'POST /indexes · POST /search', 'visual + audio options, thumbnail addon'],
                ['Embeddings', health?.models?.embed ?? MODELS.embed, 'POST /embed-v2', 'video scope · text queries share the space'],
                ['Analysis', health?.models?.analyze ?? MODELS.analyze, 'POST /analyze', 'json_schema output · temperature 0.2 · async tasks > 1 h'],
              ].map(([k, v, api, note]) => (
                <div key={k} className="row" style={{ gap: 12, padding: '10px 12px', borderRadius: 12, background: 'var(--surface-2)' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: 'var(--heading)', fontWeight: 600 }}>{k}</div>
                    <div className="small muted">
                      {api} · {note}
                    </div>
                  </div>
                  <code style={{ color: '#8cbaff', fontWeight: 600 }}>{v}</code>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <Card
          title="TwelveLabs account"
          icon="layers"
          sub="Assets already uploaded to the connected account (GET /v1.3/assets) and how many this workspace uses"
          actions={
            <Button variant="primary" size="sm" icon="refresh" onClick={() => nav('/editorial?upload=twelvelabs')} title="Open the asset picker to import titles or ad creatives without re-uploading">
              Sync assets
            </Button>
          }
        >
          <ErrorNote error={assets.error} />
          {assets.loading && !assets.data ? (
            <Skeleton h={64} />
          ) : (
            <div className="grid" style={{ gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 12 }}>
              {[
                ['Assets', String(account.count), account.processing ? `${account.processing} still processing` : 'all ready'],
                ['Hours of video', account.hours.toFixed(1), 'across the account'],
                ['Linked here', String(account.linkedTitles + account.linkedAds), `${account.linkedTitles} title${account.linkedTitles === 1 ? '' : 's'} · ${account.linkedAds} ad creative${account.linkedAds === 1 ? '' : 's'}`],
                ['Not yet imported', String(account.unlinked), 'ready to import without re-uploading'],
              ].map(([k, v, note]) => (
                <div key={k} style={{ padding: '12px 14px', borderRadius: 12, background: 'var(--surface-2)' }}>
                  <div className="small muted">{k}</div>
                  <div className="stat__value" style={{ fontSize: 28 }}>
                    {v}
                  </div>
                  <div className="small muted">{note}</div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card title="Pricing calculator" icon="dollar" sub="List prices, September 2026. Adjust hours to size a catalog.">
          <div className="grid" style={{ gridTemplateColumns: '300px 1fr', gap: 28 }}>
            <div className="stack">
              <div className="field">
                <label>Hours of video</label>
                <input className="input" type="number" min={0} step={1} value={hoursIn} onChange={(e) => setH(Math.max(0, Number(e.target.value) || 0))} />
              </div>
              <div className="field">
                <label>Titles</label>
                <input className="input" type="number" min={1} step={1} value={itemsIn} onChange={(e) => setItems(Math.max(1, Number(e.target.value) || 1))} />
              </div>
              <div className="field">
                <label>Search queries / month</label>
                <input className="input" type="number" min={0} step={100} value={queries} onChange={(e) => setQueries(Math.max(0, Number(e.target.value) || 0))} />
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setH(null);
                  setItems(null);
                }}
              >
                Use my catalog ({catalogHours.toFixed(1)} h · {stats.data?.items ?? 0} titles)
              </Button>
            </div>
            <div className="stack">
              <div className="row" style={{ alignItems: 'baseline', gap: 12 }}>
                <span className="stat__value" style={{ fontSize: 52 }}>
                  {money(cost.total)}
                </span>
                <span className="muted">
                  one-time enrichment · {money(hoursIn ? (cost.total - cost.search) / hoursIn : 0)} per hour of content · {money(cost.search)} / month search
                </span>
              </div>
              <div className="stack" style={{ gap: 10 }}>
                {rows.map(([label, value, note, color]) => (
                  <div key={label} className="stack" style={{ gap: 4 }}>
                    <div className="row row--between small">
                      <span style={{ color: 'var(--heading)' }}>{label}</span>
                      <span className="num" style={{ color: 'var(--heading)' }}>
                        {money(value)}
                      </span>
                    </div>
                    <div className="row" style={{ gap: 10 }}>
                      <Meter value={cost.total ? value / cost.total : 0} color={color} thin />
                      <span className="muted" style={{ fontSize: 11, minWidth: 260, textAlign: 'right' }}>
                        {note}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="small muted" style={{ marginTop: 6 }}>
                Assumes {PRICING.analyzeCallsPerItem} Pegasus calls per title (fingerprint, emotions, markers, safety, ad breaks, thumbnails, clips) each reading the full runtime. Creative recipe runs add one analyze call per title per run.
              </div>
            </div>
          </div>
        </Card>

        {isStatic && (
          <Card title="Demo data" icon="refresh" sub="This build runs entirely in the browser against a seeded bundle">
            <div className="row" style={{ gap: 16 }}>
              <p className="small muted" style={{ flex: 1 }}>
                Reviews, comments, lists, recipes and re-plans are kept in memory. Reset restores the seeded catalog exactly as shipped.
              </p>
              <Button
                variant="danger"
                icon="refresh"
                loading={resetting}
                onClick={async () => {
                  setResetting(true);
                  await api.resetDemo?.();
                  setResetting(false);
                  toast.push('Demo data reset', 'success');
                  void stats.refetch();
                }}
              >
                Reset demo data
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
