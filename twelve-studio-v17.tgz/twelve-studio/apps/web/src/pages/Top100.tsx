/**
 * Top 100 — the whole synthetic catalog as a poster wall.
 *
 * Simulate proves the engine behaves; this is what the engine is looking at. One
 * hundred titles, ranked by whatever the viewer picks, filtered by genre and
 * decade, searchable. Clicking a poster opens what the pipeline knows about that
 * title: the synopsis, the scored labels, pacing and certificate, and the titles
 * the similarity model puts next to it.
 */

import { useMemo, useState } from 'react';
import type { CatalogItem, SimilarTitle } from '@twelve-studio/core';
import { canonicalLabel } from '@twelve-studio/core/recommend';
import { Button, Card, EmptyState, ErrorNote, Meter, Modal, StatTile } from '../components/ui';
import { PosterArt } from '../components/Poster';
import { Icon } from '../components/Icon';
import { useApi, useQuery } from '../lib/hooks';
import { duration } from '../lib/format';
import { useTopbar } from '../App';

type SortKey = 'rating' | 'popularity' | 'newest' | 'oldest' | 'longest' | 'az';

const SORTS: Array<{ id: SortKey; label: string }> = [
  { id: 'rating', label: 'Rating' },
  { id: 'popularity', label: 'Popularity' },
  { id: 'newest', label: 'Newest' },
  { id: 'oldest', label: 'Oldest' },
  { id: 'longest', label: 'Longest' },
  { id: 'az', label: 'A–Z' },
];

const meta = (i: CatalogItem) => (i.metadata ?? {}) as { seedRating?: number; seedPopularity?: number; synthetic?: boolean };
const ratingOf = (i: CatalogItem) => meta(i).seedRating ?? 0;
const popOf = (i: CatalogItem) => meta(i).seedPopularity ?? 0;
const decadeOf = (i: CatalogItem) => (i.year ? `${Math.floor(i.year / 10) * 10}s` : '—');

/** Top labels of one facet, strongest first. */
const top = (scored: Record<string, number> | undefined, k: number) =>
  Object.entries(scored ?? {}).sort((a, b) => b[1] - a[1]).slice(0, k);

export function Top100() {
  const api = useApi();
  const catalog = useQuery(() => api.catalog(), []);
  const [sort, setSort] = useState<SortKey>('rating');
  const [genre, setGenre] = useState<string | null>(null);
  const [decade, setDecade] = useState<string | null>(null);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<CatalogItem | null>(null);

  const titles = useMemo(() => (catalog.data ?? []).filter((i) => meta(i).synthetic), [catalog.data]);

  const genres = useMemo(() => {
    const c = new Map<string, number>();
    for (const i of titles) for (const g of Object.keys(i.fingerprint?.genres ?? {})) {
      const l = canonicalLabel(g);
      c.set(l, (c.get(l) ?? 0) + 1);
    }
    return [...c.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  }, [titles]);

  const decades = useMemo(() => [...new Set(titles.map(decadeOf))].sort(), [titles]);

  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase();
    const out = titles.filter((i) => {
      if (genre && !Object.keys(i.fingerprint?.genres ?? {}).some((g) => canonicalLabel(g) === genre)) return false;
      if (decade && decadeOf(i) !== decade) return false;
      if (needle) {
        const hay = `${i.title} ${i.fingerprint?.synopsis?.short ?? ''} ${Object.keys(i.fingerprint?.keywords ?? {}).join(' ')}`.toLowerCase();
        if (!hay.includes(needle)) return false;
      }
      return true;
    });
    const by: Record<SortKey, (a: CatalogItem, b: CatalogItem) => number> = {
      rating: (a, b) => ratingOf(b) - ratingOf(a),
      popularity: (a, b) => popOf(b) - popOf(a),
      newest: (a, b) => (b.year ?? 0) - (a.year ?? 0),
      oldest: (a, b) => (a.year ?? 0) - (b.year ?? 0),
      longest: (a, b) => (b.durationSec ?? 0) - (a.durationSec ?? 0),
      az: (a, b) => a.title.localeCompare(b.title),
    };
    return [...out].sort(by[sort]);
  }, [titles, genre, decade, q, sort]);

  const stats = useMemo(() => {
    if (titles.length === 0) return undefined;
    const years = titles.map((i) => i.year ?? 0).filter(Boolean);
    const hours = titles.reduce((a, i) => a + (i.durationSec ?? 0), 0) / 3600;
    const mean = titles.reduce((a, i) => a + ratingOf(i), 0) / titles.length;
    return { years: `${Math.min(...years)}–${Math.max(...years)}`, hours, mean };
  }, [titles]);

  useTopbar(
    <span className="mono muted" style={{ fontSize: 11 }}>
      {shown.length} of {titles.length} titles
    </span>,
    [shown.length, titles.length],
  );

  if (catalog.loading) return <div className="content"><Card title="Top 100"><EmptyState icon="grid" title="Loading the catalog…" /></Card></div>;

  if (titles.length === 0)
    return (
      <div className="content">
        <Card title="Top 100" icon="grid">
          <EmptyState
            icon="grid"
            title="The synthetic catalog is not loaded"
            text="This page shows the 100 fictional titles in data/seed/fake100.json. Build them with `npx tsx data/seed/build-fake100.ts`, draw the posters with `build-fake100-posters.ts`, merge the bundles into the store, then reload."
          />
        </Card>
      </div>
    );

  return (
    <div className="content">
      <div className="stack stack--lg" style={{ maxWidth: 1600 }}>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
          <StatTile label="Titles" value={titles.length} hint="fictional, fingerprinted, no media" accent="var(--violet)" />
          <StatTile label="Genres" value={genres.length} hint={genres.slice(0, 4).map(([g, n]) => `${g} ${n}`).join(' · ')} accent="var(--blue)" />
          <StatTile label="Years" value={stats?.years} hint={`${stats ? Math.round(stats.hours) : 0} hours of runtime`} accent="var(--info)" />
          <StatTile label="Mean rating" value={stats?.mean.toFixed(1)} hint="editorial score on the seed row" accent="var(--green)" />
        </div>

        <ErrorNote error={catalog.error} />

        <Card flush>
          <div className="top100bar">
            <div className="top100search">
              <Icon name="search" size={14} />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search titles, synopsis, keywords…" aria-label="Search" />
              {q && <Button size="sm" variant="ghost" icon="x" onClick={() => setQ('')} aria-label="Clear" />}
            </div>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
              {SORTS.map((s) => (
                <button key={s.id} className={`chip${s.id === sort ? ' is-active' : ''}`} onClick={() => setSort(s.id)}>
                  {s.label}
                </button>
              ))}
            </div>
          </div>
          <div className="top100filters">
            <button className={`chip${genre === null ? ' is-active' : ''}`} onClick={() => setGenre(null)}>All genres</button>
            {genres.map(([g, n]) => (
              <button key={g} className={`chip${g === genre ? ' is-active' : ''}`} onClick={() => setGenre(g === genre ? null : g)}>
                {g} <b className="mono">{n}</b>
              </button>
            ))}
          </div>
          <div className="top100filters top100filters--sub">
            <button className={`chip chip--sm${decade === null ? ' is-active' : ''}`} onClick={() => setDecade(null)}>Any decade</button>
            {decades.map((d) => (
              <button key={d} className={`chip chip--sm${d === decade ? ' is-active' : ''}`} onClick={() => setDecade(d === decade ? null : d)}>
                {d}
              </button>
            ))}
          </div>
        </Card>

        {shown.length === 0 ? (
          <EmptyState icon="search" title="Nothing matches" text="Clear the search or widen the filters." action={<Button size="sm" onClick={() => { setQ(''); setGenre(null); setDecade(null); }}>Reset</Button>} />
        ) : (
          <div className="wall">
            {shown.map((item, i) => (
              <button key={item.id} className="walltile" onClick={() => setOpen(item)}>
                <div className="walltile__art">
                  <PosterArt item={item} showFrame={false} />
                </div>
                <div className="walltile__meta">
                  {/* The rank sits under the art, not on it: posters carry their own type and a badge lands on it. */}
                  <div className="walltile__title" title={item.title}>
                    <span className="walltile__rank mono">{i + 1}</span>
                    {item.title}
                  </div>
                  <div className="walltile__sub">
                    <span>{item.year}</span>
                    <span className="walltile__dot">·</span>
                    <span>{duration(item.durationSec)}</span>
                    {ratingOf(item) > 0 && <span className="walltile__rating mono">{ratingOf(item).toFixed(1)}</span>}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <TitleSheet item={open} onClose={() => setOpen(null)} onOpen={(id) => { const next = titles.find((t) => t.id === id); if (next) setOpen(next); }} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Detail sheet                                                        */
/* ------------------------------------------------------------------ */

function TitleSheet({ item, onClose, onOpen }: { item: CatalogItem | null; onClose: () => void; onOpen: (id: string) => void }) {
  const api = useApi();
  const similar = useQuery<SimilarTitle[]>(() => (item ? api.similar(item.id, 6) : Promise.resolve([])), [item?.id]);
  if (!item) return null;
  const fp = item.fingerprint;
  return (
    <Modal open onClose={onClose} title={`${item.title} · ${item.year ?? ''}`} wide>
      <div className="sheet">
        <div className="sheet__art">
          <PosterArt item={item} showFrame={false} />
        </div>
        <div className="stack" style={{ gap: 16 }}>
          <p style={{ margin: 0, fontSize: 14, lineHeight: 1.6 }}>{fp?.synopsis?.short ?? 'No synopsis.'}</p>

          <div className="row" style={{ gap: 18, flexWrap: 'wrap' }}>
            <div>
              <div className="muted small">Certificate</div>
              <div className="mono" style={{ fontSize: 15 }}>{fp?.audienceRating?.suggested ?? '—'}</div>
            </div>
            <div>
              <div className="muted small">Runtime</div>
              <div className="mono" style={{ fontSize: 15 }}>{duration(item.durationSec)}</div>
            </div>
            <div>
              <div className="muted small">Language</div>
              <div className="mono" style={{ fontSize: 15 }}>{fp?.language?.primary ?? '—'}</div>
            </div>
            <div style={{ minWidth: 160 }}>
              <div className="muted small">Pacing</div>
              <Meter value={fp?.pacing?.score ?? 0} color="var(--orange)" />
            </div>
          </div>

          {([['genres', 'Genres'], ['moodTags', 'Mood tags'], ['themes', 'Themes'], ['keywords', 'Keywords']] as const).map(([facet, label]) => {
            const rows = top(fp?.[facet], facet === 'keywords' ? 6 : 4);
            if (rows.length === 0) return null;
            return (
              <div key={facet}>
                <div className="muted small" style={{ marginBottom: 6 }}>{label}</div>
                <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
                  {rows.map(([l, s]) => (
                    <span key={l} className="tagchip" title={`${s.toFixed(2)}`}>
                      {l} <b className="mono">{s.toFixed(2)}</b>
                    </span>
                  ))}
                </div>
              </div>
            );
          })}

          <div>
            <div className="muted small" style={{ marginBottom: 8 }}>Closest in the catalog</div>
            {similar.loading && <span className="muted small">scoring…</span>}
            <div className="stack" style={{ gap: 6 }}>
              {(similar.data ?? []).map((s) => (
                <button key={s.itemId} className="sheet__similar" onClick={() => onOpen(s.itemId)}>
                  <span className="sheet__similar-title">{s.title}</span>
                  <span className="muted small">{s.because.slice(0, 2).join(', ')}</span>
                  <b className="mono">{Math.round(s.score * 100)}</b>
                </button>
              ))}
              {!similar.loading && (similar.data ?? []).length === 0 && <span className="muted small">nothing close enough</span>}
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
}
