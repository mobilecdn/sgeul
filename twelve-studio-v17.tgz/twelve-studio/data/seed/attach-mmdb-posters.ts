/**
 * Attaches Euan's MMDB poster art to the catalog bundles.
 *
 * The originals live outside the repo in ~/Claude/Projects/Twelve/mmdb-assets (1000x1500
 * JPEGs, one per title, filename = title). `mmdb100-posters-web/` holds 260x390 q68 copies
 * built from them, and those are what get embedded as data URIs: a hundred full-size posters
 * would put mmdb.html past 30 MB, the downscaled set keeps it near two.
 *
 *   npx tsx data/seed/attach-mmdb-posters.ts     (after build-mmdb.ts)
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import type { ItemBundle } from '../../packages/core/src/types.js';

const HERE = resolve(import.meta.dirname);
const WEB = resolve(HERE, 'mmdb100-posters-web');

const bundles = JSON.parse(readFileSync(resolve(HERE, 'mmdb100.json'), 'utf8')) as ItemBundle[];
let bytes = 0;
const missing: string[] = [];

for (const b of bundles) {
  const file = resolve(WEB, `${b.item.id}.jpg`);
  if (!existsSync(file)) { missing.push(b.item.id); continue; }
  const uri = `data:image/jpeg;base64,${readFileSync(file).toString('base64')}`;
  bytes += uri.length;
  b.item.posterUrl = uri;
  b.item.metadata = { ...(b.item.metadata ?? {}), posterSource: 'mcleod', synthetic: true };
}

writeFileSync(resolve(HERE, 'mmdb100.json'), `${JSON.stringify(bundles, null, 2)}\n`);
console.log(`${bundles.length - missing.length} posters attached, ${(bytes / 1024 / 1024).toFixed(2)} MB of data URIs`);
if (missing.length) console.log('missing:', missing.join(', '));
