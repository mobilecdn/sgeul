/** Smoke test: drive the recommendation engine with synthetic viewers over the fake-100 catalog. */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { ItemBundle } from '../../packages/core/src/types.js';
import {
  buildTasteProfile, popularityIndex, recommend, recommendRails,
  normaliseWeights, type WatchEvent,
} from '../../packages/core/src/recommend.js';

const bundles = JSON.parse(readFileSync(resolve(import.meta.dirname, 'fake100.json'), 'utf8')) as ItemBundle[];
const pool = bundles.map((b) => b.item);
const byId = new Map(pool.map((i) => [i.id, i]));
const name = (id: string) => byId.get(id)?.title ?? id;
const w = normaliseWeights({});

let n = 0;
const ev = (profileId: string, itemId: string, action: WatchEvent['action'], completion?: number, daysAgo = 1): WatchEvent => ({
  id: `e${++n}`, profileId, itemId, action, completion,
  at: new Date(Date.now() - daysAgo * 864e5).toISOString(),
});

const VIEWERS: Record<string, WatchEvent[]> = {
  // The headline case: a romantic-horror watcher should get romantic horror first.
  'romantic-horror': [
    ev('romantic-horror', 'fake-021', 'watch', 0.97, 2),   // The Hollow Bride (horror+romance)
    ev('romantic-horror', 'fake-022', 'like', undefined, 1), // Blood Like Honey (horror+romance)
  ],
  // Pure horror, for contrast.
  'horror-only': [
    ev('horror-only', 'fake-024', 'watch', 0.95, 2),       // Room 1408 Is Fine
    ev('horror-only', 'fake-025', 'watch', 0.9, 1),        // The Hosts
  ],
  // Pure romance, for contrast.
  'romance-only': [
    ev('romance-only', 'fake-039', 'watch', 0.93, 2),      // Champagne and Lifeboats
    ev('romance-only', 'fake-040', 'watch', 0.88, 1),      // Letters from Ravenna
  ],
  // Crime/mob watcher, tests franchise continuity.
  'mob': [
    ev('mob', 'fake-002', 'watch', 0.99, 3),               // The Marchetti Family
    ev('mob', 'fake-015', 'watch', 0.8, 1),                // The Quiet Ledger
  ],
  // Cold start.
  'new-viewer': [],
};

const allEvents = Object.values(VIEWERS).flat();
const popularity = popularityIndex(allEvents, w);

for (const [id, events] of Object.entries(VIEWERS)) {
  const profile = buildTasteProfile(id, events, pool, w);
  console.log(`\n${'='.repeat(72)}\nVIEWER ${id}  (${events.length} events)`);
  const combos = Object.entries(profile.combos ?? {}).sort((a, b) => b[1] - a[1]).slice(0, 3);
  if (combos.length) console.log('  top combos:', combos.map(([k, v]) => `${k} ${v.toFixed(2)}`).join(' | '));
  const top = recommend({ profile, pool, weights: w, popularity, limit: 5 });
  for (const r of top) console.log(`   ${r.score.toFixed(3)}  ${name(r.itemId).padEnd(34)} ${r.because.slice(0, 3).join(', ')}`);
  const rails = recommendRails({ profile, pool, weights: w, popularity, limit: 4, maxRails: 6 });
  console.log('  rows:');
  for (const rail of rails) console.log(`   - ${rail.title}  [${rail.items.map((r) => name(r.itemId)).join(' | ')}]`);
}

// Up next, seeded by what is playing now.
console.log(`\n${'='.repeat(72)}\nUP NEXT after The Hollow Bride (horror + romance)`);
const p = buildTasteProfile('romantic-horror', VIEWERS['romantic-horror'], pool, w);
for (const r of recommend({ profile: p, pool, weights: w, popularity, seed: byId.get('fake-021'), limit: 5 }))
  console.log(`   ${r.score.toFixed(3)}  ${name(r.itemId).padEnd(34)} ${r.because.slice(0, 3).join(', ')}`);
