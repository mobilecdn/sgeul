/**
 * Synthetic test catalog: 100 fictional titles modelled on the IMDb top 100.
 *
 * Reads `fake100-source.json` (flat editorial rows) and emits `fake100.json`,
 * an `ItemBundle[]` shape-identical to what the live pipeline writes, so the
 * recommendation engine can be exercised on a broad catalog with no model
 * calls and no media. Every item carries `metadata.synthetic = true`.
 *
 *   npx tsx data/seed/build-fake100.ts
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { CatalogItem, Fingerprint, ItemBundle, ScoredLabels } from '../../packages/core/src/types.js';
import { labelVector } from '../../packages/core/src/similarity.js';

interface Row {
  id: string; title: string; year: number; type: string; runtimeMin: number; synopsis: string;
  genres: string[]; moods: string[]; moodTags: string[]; themes: string[]; keywords: string[];
  pacing: number; audienceRating: number; popularity: number;
}

const HERE = resolve(import.meta.dirname);
const rows = JSON.parse(readFileSync(resolve(HERE, 'fake100-source.json'), 'utf8')) as Row[];

/** Ordered list → descending scores, so the first label is the dominant one. */
const scored = (labels: string[], top = 0.95, step = 0.13): ScoredLabels => {
  const out: ScoredLabels = {};
  labels.forEach((l, i) => { out[l] = Number(Math.max(0.28, top - i * step).toFixed(2)); });
  return out;
};

const LANG: Record<string, string> = {
  'Eight Blades at Dawn': 'ja', 'The Bathhouse of a Thousand Names': 'ja',
  'Parasite Season': 'ko', 'The Ash Sonata': 'pl',
};

type Cert = Fingerprint['audienceRating']['suggested'];
const certOf = (r: Row): Cert => {
  const g = new Set(r.genres);
  if (g.has('animation') || g.has('family')) return r.audienceRating >= 8.2 ? 'PG' : 'G';
  if (g.has('horror')) return g.has('comedy') ? 'PG-13' : 'R';
  if (g.has('war') || g.has('crime')) return r.year < 1980 ? 'PG-13' : 'R';
  if (g.has('thriller')) return 'PG-13';
  if (g.has('musical') || g.has('romance') || g.has('comedy')) return 'PG-13';
  return 'PG-13';
};

const pacingWhy = (p: number) =>
  p >= 0.7 ? 'Short scenes and frequent cuts; the plot rarely pauses.'
  : p >= 0.5 ? 'Steady momentum with room for character beats between set pieces.'
  : 'Long takes and quiet stretches; tension accumulates rather than spikes.';

const ISO = '2026-09-15T12:00:00.000Z';

const bundles: ItemBundle[] = rows.map((r) => {
  const fingerprint: Fingerprint = {
    genres: scored(r.genres),
    keywords: scored(r.keywords, 0.9, 0.09),
    moods: scored(r.moods, 0.92, 0.14),
    moodTags: scored(r.moodTags, 0.9, 0.14),
    themes: scored(r.themes, 0.93, 0.12),
    characters: [],
    pacing: { score: r.pacing, rationale: pacingWhy(r.pacing) },
    language: { primary: LANG[r.title] ?? 'en' },
    audienceRating: { suggested: certOf(r), rationale: 'Derived from genre and content profile of the synthetic row.' },
    synopsis: {
      short: r.synopsis,
      long: `${r.synopsis} Themes: ${r.themes.join(', ')}. Mood: ${r.moods.join(', ')}.`,
    },
    model: 'synthetic-seed',
    generatedAt: ISO,
  };
  fingerprint.embedding = labelVector(fingerprint);

  const item: CatalogItem = {
    id: r.id,
    title: r.title,
    type: 'movie',
    year: r.year,
    sourceUrl: `https://synthetic.invalid/${r.id}.mp4`,
    durationSec: r.runtimeMin * 60,
    createdAt: ISO,
    updatedAt: ISO,
    status: 'ready',
    metadata: { synthetic: true, note: 'Recommendation test row — fictional title, no media.', imdbTopInspired: true, seedPopularity: r.popularity, seedRating: r.audienceRating },
    jobs: { ingest: 'ready', fingerprint: 'ready', embedding: 'ready' },
    fingerprint,
  };

  return { item, fingerprint, jobs: [] };
});

writeFileSync(resolve(HERE, 'fake100.json'), `${JSON.stringify(bundles, null, 2)}\n`);
console.log(`wrote fake100.json — ${bundles.length} bundles, embedding dim ${bundles[0].fingerprint!.embedding!.length}`);
