/**
 * Poster art for the synthetic catalog.
 *
 * A hundred posters that all share one layout read as generated data, which is
 * the opposite of what the catalog is for. A real shelf mixes poster languages:
 * flat colour fields with enormous type, classic billing-block one-sheets, a
 * single small object in a lot of white, duotone portrait bands, seventies
 * title-over-scene, art-house frames. So a poster here is a layout drawn from
 * that vocabulary, a light or dark scheme, a genre palette, a genre motif and an
 * invented billing block — all chosen deterministically from the item id, so a
 * re-run is byte-identical.
 *
 * Nothing here reproduces any real poster: the layouts are generic conventions,
 * the art is abstract, and every name in the credits is invented.
 *
 *   npx tsx data/seed/build-fake100-posters.ts     (after build-fake100.ts)
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { ItemBundle } from '../../packages/core/src/types.js';

const HERE = resolve(import.meta.dirname);
const OUT = resolve(HERE, 'fake100-posters');
const W = 600;
const H = 900;

/* ---- deterministic randomness -------------------------------------- */

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function rng(seed: number) {
  let s = seed || 1;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}
const pick = <T,>(r: () => number, xs: readonly T[]): T => xs[Math.floor(r() * xs.length)]!;
const xml = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
const n = (v: number) => Math.round(v * 10) / 10;

/* ---- type ----------------------------------------------------------- */

const SANS = "'Helvetica Neue', Helvetica, Arial, sans-serif";
const SERIF = "Georgia, 'Times New Roman', Times, serif";
const COND = "'Arial Narrow', 'Helvetica Neue', Helvetica, Arial, sans-serif";
const WIDTH_SCALE: Record<string, number> = { [SANS]: 1, [SERIF]: 1.04, [COND]: 0.84 };

/** Helvetica Bold advance widths (AFM / 1000) — close enough to choose a size that fits. */
const ADV: Record<string, number> = {
  A: 722, B: 722, C: 722, D: 722, E: 667, F: 611, G: 778, H: 722, I: 278, J: 556, K: 722, L: 611, M: 833,
  N: 722, O: 778, P: 667, Q: 778, R: 722, S: 667, T: 611, U: 722, V: 667, W: 944, X: 667, Y: 667, Z: 611,
  ' ': 278, "'": 238, ':': 333, '.': 278, ',': 278, '-': 333, '&': 722,
  '0': 556, '1': 556, '2': 556, '3': 556, '4': 556, '5': 556, '6': 556, '7': 556, '8': 556, '9': 556,
};

interface FitOpts { maxW: number; maxLines?: number; tracking?: number; font?: string; sizes?: number[] }
const DEFAULT_SIZES = [96, 88, 80, 74, 68, 62, 56, 50, 45, 40, 36, 32, 28];

const measure = (text: string, size: number, font: string, tracking: number): number =>
  [...text].reduce((w, ch) => w + ((ADV[ch] ?? 700) / 1000) * size * (WIDTH_SCALE[font] ?? 1) + tracking, 0);

/** Largest size at which the title wraps into `maxLines` lines that all fit `maxW`. */
function fit(title: string, o: FitOpts): { lines: string[]; size: number } {
  const font = o.font ?? SANS;
  const tracking = o.tracking ?? -1.5;
  const maxLines = o.maxLines ?? 4;
  const words = title.toUpperCase().split(/\s+/);
  for (const size of o.sizes ?? DEFAULT_SIZES) {
    if (words.some((w) => measure(w, size, font, tracking) > o.maxW)) continue;
    const lines: string[] = [];
    let cur = '';
    for (const word of words) {
      const next = cur ? `${cur} ${word}` : word;
      if (measure(next, size, font, tracking) <= o.maxW) cur = next;
      else { lines.push(cur); cur = word; }
    }
    if (cur) lines.push(cur);
    if (lines.length <= maxLines) return { lines, size };
  }
  return { lines: [title.toUpperCase()], size: 26 };
}

/** A block of centred or left-aligned lines, returned as one <text>. */
function textBlock(lines: string[], o: { x: number; y: number; size: number; fill: string; font?: string; weight?: number; anchor?: 'start' | 'middle'; tracking?: number; lead?: number }): string {
  const lead = o.lead ?? o.size * 1.02;
  const spans = lines.map((l, i) => `<tspan x="${n(o.x)}" y="${n(o.y + i * lead)}">${xml(l)}</tspan>`).join('');
  return `<text font-family="${o.font ?? SANS}" font-weight="${o.weight ?? 700}" font-size="${n(o.size)}" fill="${o.fill}" letter-spacing="${o.tracking ?? -1.5}" text-anchor="${o.anchor ?? 'start'}">${spans}</text>`;
}

/* ---- palettes -------------------------------------------------------- */

interface Palette { top: string; bottom: string; accent: string; ink: string }
/** Paper schemes: a light ground with dark ink, which is what breaks up a wall of dark posters. */
interface Paper { ground: string; ink: string; accent: string }

const DARK: Record<string, Palette[]> = {
  horror: [{ top: '#0d1014', bottom: '#241016', accent: '#c1443a', ink: '#f2e9e4' }, { top: '#0a0f0d', bottom: '#1b2420', accent: '#8fae9b', ink: '#eef3ef' }],
  thriller: [{ top: '#0b1118', bottom: '#16232f', accent: '#4f9dd6', ink: '#eaf2f8' }, { top: '#11100f', bottom: '#2a2420', accent: '#d4a04a', ink: '#f5efe6' }],
  crime: [{ top: '#0c0a08', bottom: '#2b1c0d', accent: '#e0a032', ink: '#f7f0e4' }],
  mystery: [{ top: '#0d0f1a', bottom: '#1f2138', accent: '#8f7fd6', ink: '#efedf8' }],
  romance: [{ top: '#2a1220', bottom: '#5c2436', accent: '#f0a3a3', ink: '#fdeff0' }, { top: '#241426', bottom: '#4a2340', accent: '#e8b4c8', ink: '#fbeef5' }],
  'science fiction': [{ top: '#050b18', bottom: '#0f2b46', accent: '#57d2e0', ink: '#e8f7fa' }, { top: '#0a0718', bottom: '#241a4a', accent: '#9a86f0', ink: '#efebff' }],
  fantasy: [{ top: '#0a1620', bottom: '#1d3b3a', accent: '#e0b457', ink: '#f6f1e3' }],
  adventure: [{ top: '#101a20', bottom: '#2d4436', accent: '#e4a94c', ink: '#f6f2e6' }],
  action: [{ top: '#12090a', bottom: '#331414', accent: '#e2593c', ink: '#faeeea' }],
  war: [{ top: '#14150f', bottom: '#33352a', accent: '#c8b06a', ink: '#f2f0e6' }],
  western: [{ top: '#2a1508', bottom: '#7a3d16', accent: '#f0b25a', ink: '#fdf1e2' }],
  drama: [{ top: '#0f1114', bottom: '#242a30', accent: '#8fa3b8', ink: '#f0f3f6' }, { top: '#17120f', bottom: '#332a22', accent: '#c8a179', ink: '#f7f1ea' }, { top: '#0d1412', bottom: '#233029', accent: '#8fbfa3', ink: '#eef6f1' }],
  comedy: [{ top: '#1a1206', bottom: '#4a3a0c', accent: '#f5d04a', ink: '#fffaea' }],
  musical: [{ top: '#140a22', bottom: '#3d1a52', accent: '#f0c05a', ink: '#fbf2e6' }],
  animation: [{ top: '#0b1a2e', bottom: '#2a5a8c', accent: '#ffd166', ink: '#f2f9ff' }],
  family: [{ top: '#0e1f2e', bottom: '#2f6383', accent: '#ffcf70', ink: '#f3faff' }],
  history: [{ top: '#161208', bottom: '#3a2e18', accent: '#cfa85e', ink: '#f6f1e4' }],
  biography: [{ top: '#12131a', bottom: '#2c2f3d', accent: '#a9a2c8', ink: '#f1f0f7' }],
  music: [{ top: '#150c1c', bottom: '#3a1f46', accent: '#e8a0d0', ink: '#faeff8' }],
  sport: [{ top: '#101418', bottom: '#243040', accent: '#e07a3c', ink: '#f6f0ea' }],
  documentary: [{ top: '#0e1013', bottom: '#20262c', accent: '#d8d2c4', ink: '#f4f6f8' }],
};
const DARK_FALLBACK: Palette = { top: '#101318', bottom: '#262c34', accent: '#9fb0c4', ink: '#f0f3f7' };

const PAPERS: Paper[] = [
  { ground: '#f4f1e8', ink: '#141210', accent: '#c0392b' },
  { ground: '#ffffff', ink: '#111111', accent: '#1a4fd6' },
  { ground: '#f0e6d2', ink: '#1c1a17', accent: '#0f6b4f' },
  { ground: '#e8e4dd', ink: '#16181c', accent: '#d4741a' },
  { ground: '#fbe9cf', ink: '#2a1a0c', accent: '#b0361f' },
];
/** Genres that keep their dark ground: a light horror poster reads as a comedy. */
const ALWAYS_DARK = new Set(['horror', 'thriller', 'science fiction', 'action', 'crime', 'mystery']);

/* ---- invented credits ------------------------------------------------ */

const FIRST = ['MIRA', 'DESMOND', 'JUNE', 'ARTO', 'CLEA', 'HOLLIS', 'NADIA', 'EAMON', 'SIGRID', 'RUFUS', 'TOMASZ', 'ODILE', 'BRAM', 'IRINA', 'CASPAR', 'LENNOX', 'MAUD', 'SANTI', 'VERITY', 'OSKAR', 'ROSALIND', 'HAKIM', 'PERPETUA', 'NIALL'];
const LAST = ['KOVALENKO', 'ABARA', 'PELLETIER', 'STRAND', 'OKONKWO', 'VANTERPOOL', 'MARCHETTI', 'HALLORAN', 'DIAZ-REY', 'BRUNNER', 'ASHWORTH', 'NAKAGAWA', 'FERRIS', 'OYELARAN', 'LINDQVIST', 'CASTELLANE', 'BRIGHT', 'MWANGI', 'DELACROIX', 'SEVERIN', 'RAMSBOTTOM', 'ILIESCU'];
const STUDIO = ['MERIDIAN PICTURES', 'NORTHGATE FILM COMPANY', 'CASTLE & FEN', 'THE LANTERN GROUP', 'ARGUS RELEASING', 'PALE HORSE FILMS', 'BROADWATER', 'SIXTH FLOOR PICTURES'];

const person = (r: () => number) => `${pick(r, FIRST)} ${pick(r, LAST)}`;

/* ---- motifs ---------------------------------------------------------- */

/** Motifs draw in the full 600x900 frame; a layout scales the whole group into its art box. */
type Motif = (p: Palette, r: () => number, ink: string) => string;

const stars = (r: () => number, count = 60): string => {
  let s = '';
  for (let i = 0; i < count; i++) s += `<circle cx="${n(r() * W)}" cy="${n(r() * H * 0.8)}" r="${n(0.8 + r() * 2)}" fill="#fff" opacity="${n(0.2 + r() * 0.5)}"/>`;
  return s;
};
const ridge = (y: number, amp: number, fill: string, r: () => number, steps = 7): string => {
  let d = `M0 ${H} L0 ${n(y)}`;
  for (let i = 1; i <= steps; i++) d += ` L${n((W / steps) * i - W / steps / 2)} ${n(y - amp * r())} L${n((W / steps) * i)} ${n(y - amp * r() * 0.4)}`;
  return `<path d="${d} L${W} ${H} Z" fill="${fill}"/>`;
};

const MOTIFS: Record<string, Motif> = {
  horror: (p, r) => `<circle cx="${n(150 + r() * 300)}" cy="${n(240 + r() * 120)}" r="${n(80 + r() * 50)}" fill="${p.accent}" opacity="0.55"/>${ridge(660, 130, 'rgba(0,0,0,0.78)', r, 9)}`,
  thriller: (p, r) => { const x = n(160 + r() * 280); return `<path d="M${x} 0 L${n(x + 80)} 0 L${n(x + 260)} ${H} L${n(x - 190)} ${H} Z" fill="${p.accent}" opacity="0.2"/><circle cx="${n(x + 40)}" cy="${n(300 + r() * 120)}" r="${n(100 + r() * 40)}" fill="${p.accent}" opacity="0.2"/>`; },
  crime: (p, r) => { let sky = ''; let x = 0; while (x < W) { const w = 26 + r() * 46; const h = 100 + r() * 240; sky += `<rect x="${n(x)}" y="${n(720 - h)}" width="${n(w)}" height="${n(h)}" fill="rgba(0,0,0,0.85)"/>`; x += w + 6; } return `<circle cx="${n(150 + r() * 300)}" cy="${n(300)}" r="${n(160 + r() * 60)}" fill="${p.accent}" opacity="0.28"/>${sky}`; },
  mystery: (p, r) => { let s = ''; for (let i = 0; i < 6; i++) s += `<circle cx="300" cy="${n(380)}" r="${n(50 + i * 58)}" fill="none" stroke="${p.accent}" stroke-width="${n(1.5 + r() * 1.5)}" opacity="${n(0.5 - i * 0.06)}"/>`; return s; },
  romance: (p, r) => `<circle cx="${n(210 + r() * 80)}" cy="${n(360 + r() * 60)}" r="${n(150 + r() * 40)}" fill="${p.accent}" opacity="0.34"/><circle cx="${n(340 + r() * 80)}" cy="${n(400 + r() * 60)}" r="${n(150 + r() * 40)}" fill="${p.accent}" opacity="0.26"/>`,
  'science fiction': (p, r) => `${stars(r, 90)}<ellipse cx="300" cy="440" rx="${n(240 + r() * 50)}" ry="${n(62 + r() * 20)}" fill="none" stroke="${p.accent}" stroke-width="2.5" opacity="0.6"/><circle cx="${n(200 + r() * 200)}" cy="440" r="${n(100 + r() * 50)}" fill="${p.accent}" opacity="0.38"/>`,
  fantasy: (p, r) => `<circle cx="${n(200 + r() * 200)}" cy="${n(280)}" r="${n(80 + r() * 30)}" fill="${p.accent}" opacity="0.45"/>${ridge(580, 190, 'rgba(0,0,0,0.45)', r, 5)}${ridge(670, 140, 'rgba(0,0,0,0.72)', r, 6)}`,
  adventure: (p, r) => `<circle cx="${n(170 + r() * 260)}" cy="${n(270)}" r="${n(70 + r() * 40)}" fill="${p.accent}" opacity="0.42"/>${ridge(620, 170, 'rgba(0,0,0,0.5)', r, 6)}${ridge(700, 110, 'rgba(0,0,0,0.76)', r, 8)}`,
  action: (p, r) => `<path d="M0 ${n(440 + r() * 80)} L${W} ${n(260 + r() * 80)} L${W} ${n(390 + r() * 60)} L0 ${n(570 + r() * 60)} Z" fill="${p.accent}" opacity="0.36"/><path d="M0 600 L${W} 430 L${W} 476 L0 646 Z" fill="${p.accent}" opacity="0.18"/>`,
  war: (p, r) => { let posts = ''; for (let i = 0; i < 9; i++) posts += `<rect x="${n(i * 70 + r() * 20)}" y="${n(540 + r() * 40)}" width="5" height="${n(130 + r() * 90)}" fill="rgba(0,0,0,0.72)"/>`; return `<circle cx="${n(130 + r() * 340)}" cy="${n(480)}" r="${n(120 + r() * 40)}" fill="${p.accent}" opacity="0.35"/><rect x="0" y="620" width="${W}" height="280" fill="rgba(0,0,0,0.5)"/>${posts}`; },
  western: (p, r) => `<circle cx="300" cy="430" r="${n(170 + r() * 40)}" fill="${p.accent}" opacity="0.55"/><rect x="0" y="440" width="${W}" height="10" fill="rgba(0,0,0,0.35)"/><rect x="0" y="482" width="${W}" height="18" fill="rgba(0,0,0,0.3)"/><rect x="0" y="560" width="${W}" height="340" fill="rgba(0,0,0,0.5)"/>`,
  drama: (p, r, ink) => { const k = Math.floor(r() * 3);
    if (k === 0) return `<circle cx="300" cy="380" r="${n(190 + r() * 40)}" fill="${p.accent}" opacity="0.26"/><rect x="${n(100 + r() * 70)}" y="200" width="320" height="380" fill="none" stroke="${ink}" stroke-width="3" opacity="0.5" transform="rotate(${n(-6 + r() * 12)} 300 380)"/>`;
    if (k === 1) return `<circle cx="${n(170 + r() * 260)}" cy="${n(340)}" r="${n(90 + r() * 40)}" fill="${p.accent}" opacity="0.45"/><path d="M0 520 Q300 ${n(360 + r() * 100)} ${W} 520 L${W} ${H} L0 ${H} Z" fill="${p.accent}" opacity="0.34"/>`;
    return `<circle cx="300" cy="390" r="${n(180 + r() * 50)}" fill="none" stroke="${p.accent}" stroke-width="4" opacity="0.6"/><circle cx="300" cy="390" r="100" fill="${p.accent}" opacity="0.32"/>`; },
  comedy: (p, r) => { let s = ''; for (let i = 0; i < 6; i++) s += `<circle cx="${n(70 + r() * 460)}" cy="${n(180 + r() * 400)}" r="${n(45 + r() * 75)}" fill="${p.accent}" opacity="${n(0.2 + r() * 0.24)}"/>`; return s; },
  musical: (p, r) => `<path d="M280 0 L370 0 L${n(540 + r() * 50)} 640 L${n(70 - r() * 50)} 640 Z" fill="${p.accent}" opacity="0.26"/><ellipse cx="300" cy="640" rx="240" ry="44" fill="${p.accent}" opacity="0.32"/>`,
  animation: (p, r) => { let s = `<circle cx="300" cy="380" r="160" fill="${p.accent}" opacity="0.4"/>`; for (let i = 0; i < 5; i++) s += `<circle cx="${n(80 + r() * 440)}" cy="${n(160 + r() * 440)}" r="${n(28 + r() * 50)}" fill="#fff" opacity="${n(0.12 + r() * 0.2)}"/>`; return s; },
  documentary: (p, r, ink) => { let bars = ''; for (let i = 0; i < 14; i++) bars += `<rect x="${n(40 + i * 38)}" y="${n(320 + r() * 200)}" width="18" height="${n(60 + r() * 260)}" fill="${p.accent}" opacity="${n(0.2 + r() * 0.3)}"/>`; return `${bars}<rect x="40" y="300" width="520" height="2" fill="${ink}" opacity="0.35"/>`; },
};
MOTIFS.family = MOTIFS.animation;
MOTIFS.history = MOTIFS.war;
MOTIFS.biography = MOTIFS.drama;
MOTIFS.music = MOTIFS.musical;
MOTIFS.sport = MOTIFS.action;

/* ---- layouts ---------------------------------------------------------- */

interface Ctx {
  title: string; year: number; genres: string[]; runtimeMin: number;
  p: Palette; paper?: Paper; ink: string; accent: string; ground: string;
  art: (box: { x: number; y: number; w: number; h: number; opacity?: number; clip: string }) => string;
  r: () => number;
  billing: string; director: string; studio: string; credit: string;
}

const smallText = (s: string, o: { x: number; y: number; size: number; fill: string; anchor?: 'start' | 'middle'; weight?: number; tracking?: number; font?: string; opacity?: number }) =>
  `<text x="${n(o.x)}" y="${n(o.y)}" font-family="${o.font ?? SANS}" font-size="${n(o.size)}" font-weight="${o.weight ?? 600}" fill="${o.fill}" letter-spacing="${o.tracking ?? 2}" text-anchor="${o.anchor ?? 'start'}"${o.opacity ? ` opacity="${o.opacity}"` : ''}>${xml(s)}</text>`;

type Layout = (c: Ctx) => string;

/** 1. Flat field, enormous type. Almost no art: the title is the poster. */
const flatType: Layout = (c) => {
  const { lines, size } = fit(c.title, { maxW: W - 96, maxLines: 5, sizes: [104, 92, 84, 76, 68, 60, 54, 48, 42, 38] });
  const top = 168 + size * 0.5 + (5 - lines.length) * 16;
  return `${c.art({ x: 0, y: 0, w: W, h: H, opacity: 0.22, clip: 'full' })}
    ${textBlock(lines, { x: 48, y: top, size, fill: c.ink, lead: size * 0.92, tracking: -3 })}
    <rect x="48" y="${n(top + lines.length * size * 0.92 + 4)}" width="${n(W - 96)}" height="3" fill="${c.accent}"/>
    ${smallText(c.credit, { x: 48, y: H - 56, size: 15, fill: c.ink, opacity: 0.75 })}
    ${smallText(c.director, { x: 48, y: H - 84, size: 15, fill: c.accent })}`;
};

/** 2. Classic one-sheet: billing block up top, art in the middle, title low. */
const oneSheet: Layout = (c) => {
  const { lines, size } = fit(c.title, { maxW: W - 110, maxLines: 3, sizes: [78, 70, 62, 56, 50, 44, 40, 35] });
  // Anchored from the bottom: the last line always clears the credit block, whatever the line count.
  const lastY = H - 152;
  const titleY = lastY - (lines.length - 1) * size * 0.98;
  return `${c.art({ x: 0, y: 90, w: W, h: 620, opacity: 1, clip: 'mid' })}
    <rect y="620" width="${W}" height="280" fill="url(#scrim)"/>
    ${smallText(c.billing, { x: W / 2, y: 58, size: 12.5, fill: c.ink, anchor: 'middle', tracking: 1.6, opacity: 0.8 })}
    ${textBlock(lines, { x: W / 2, y: titleY, size, fill: c.ink, anchor: 'middle', lead: size * 0.98 })}
    <rect x="${n(W / 2 - 40)}" y="${n(lastY + 26)}" width="80" height="3" fill="${c.accent}"/>
    ${smallText(c.director, { x: W / 2, y: H - 74, size: 13, fill: c.ink, anchor: 'middle', opacity: 0.85 })}
    ${smallText(c.studio, { x: W / 2, y: H - 46, size: 11.5, fill: c.ink, anchor: 'middle', opacity: 0.55, tracking: 3 })}`;
};

/** 3. One small object floating in a lot of nothing; title beneath it. */
const objectCentre: Layout = (c) => {
  const { lines, size } = fit(c.title, { maxW: W - 104, maxLines: 3, sizes: [74, 66, 59, 52, 46, 41, 36, 32] });
  const firstY = 580 - (lines.length - 1) * size * 0.5;
  return `${c.art({ x: 130, y: 120, w: 340, h: 340, opacity: 1, clip: 'obj' })}
    ${smallText(c.billing, { x: W / 2, y: 74, size: 11.5, fill: c.ink, anchor: 'middle', opacity: 0.6, tracking: 1.4 })}
    ${textBlock(lines, { x: W / 2, y: n(firstY), size, fill: c.ink, anchor: 'middle', lead: size * 1.02, tracking: -1.5 })}
    ${smallText(c.credit, { x: W / 2, y: H - 92, size: 13, fill: c.ink, anchor: 'middle', opacity: 0.6 })}
    ${smallText(c.studio, { x: W / 2, y: H - 62, size: 11, fill: c.accent, anchor: 'middle', tracking: 3.5 })}`;
};

/** 4. Full-bleed art with the title punched across the middle. */
const bandTitle: Layout = (c) => {
  const { lines, size } = fit(c.title, { maxW: W - 72, maxLines: 3, sizes: [88, 80, 72, 64, 58, 52, 46, 41, 36] });
  const mid = 470 - ((lines.length - 1) * size) / 2;
  return `${c.art({ x: 0, y: 0, w: W, h: H, opacity: 1, clip: 'full' })}
    <rect y="${n(mid - size)}" width="${W}" height="${n(lines.length * size * 1.02 + 44)}" fill="#000" opacity="0.42"/>
    ${textBlock(lines, { x: W / 2, y: mid, size, fill: c.ink, anchor: 'middle', lead: size * 1.02, tracking: -2.5 })}
    ${smallText(c.billing, { x: W / 2, y: 96, size: 12, fill: c.ink, anchor: 'middle', opacity: 0.7, tracking: 1.6 })}
    ${smallText(c.credit, { x: W / 2, y: H - 58, size: 14, fill: c.ink, anchor: 'middle', opacity: 0.8 })}`;
};

/** 5. Seventies: heavy title across the top, the scene underneath it. */
const titleTop: Layout = (c) => {
  const { lines, size } = fit(c.title, { maxW: W - 80, maxLines: 3, font: COND, tracking: 0, sizes: [92, 84, 76, 68, 60, 54, 48, 42, 37] });
  const firstY = 52 + size * 0.78;
  const artTop = firstY + (lines.length - 1) * size * 0.96 + 34;
  return `${c.art({ x: 0, y: n(artTop), w: W, h: n(H - artTop), opacity: 1, clip: 'low' })}
    ${textBlock(lines, { x: W / 2, y: n(firstY), size, fill: c.ink, anchor: 'middle', font: COND, tracking: 0, lead: size * 0.96 })}
    <rect y="${n(H - 92)}" width="${W}" height="92" fill="#000" opacity="${c.paper ? 0.08 : 0.5}"/>
    ${smallText(c.billing, { x: W / 2, y: H - 58, size: 12, fill: c.ink, anchor: 'middle', opacity: 0.85, tracking: 1.4 })}
    ${smallText(c.credit, { x: W / 2, y: H - 34, size: 11, fill: c.accent, anchor: 'middle', tracking: 3 })}`;
};

/** 6. Art-house: a wide border, a small image, quiet serif type. */
const framed: Layout = (c) => {
  const { lines, size } = fit(c.title, { maxW: W - 180, maxLines: 3, font: SERIF, tracking: 0.5, sizes: [52, 46, 41, 36, 32, 28, 25] });
  return `${c.art({ x: 90, y: 150, w: 420, h: 380, opacity: 1, clip: 'frame' })}
    <rect x="90" y="150" width="420" height="380" fill="none" stroke="${c.ink}" stroke-width="1" opacity="0.35"/>
    ${textBlock(lines, { x: W / 2, y: 640, size, fill: c.ink, anchor: 'middle', font: SERIF, tracking: 0.5, weight: 400, lead: size * 1.24 })}
    <rect x="${n(W / 2 - 30)}" y="${n(660 + (lines.length - 1) * size * 1.24)}" width="60" height="1.5" fill="${c.accent}"/>
    ${smallText(c.credit, { x: W / 2, y: H - 96, size: 12, fill: c.ink, anchor: 'middle', opacity: 0.6, font: SERIF, tracking: 1.5 })}
    ${smallText(c.studio, { x: W / 2, y: H - 58, size: 10.5, fill: c.ink, anchor: 'middle', opacity: 0.45, tracking: 4 })}`;
};

/** 7. Colour blocks: the frame split into bands, the title sitting in one of them. */
const blocks: Layout = (c) => {
  const cut = 300 + Math.floor(c.r() * 3) * 120;
  const { lines, size } = fit(c.title, { maxW: W - 96, maxLines: 3, sizes: [76, 68, 60, 54, 48, 43, 38, 34] });
  return `${c.art({ x: 0, y: 0, w: W, h: n(cut), opacity: 1, clip: 'top' })}
    <rect y="${n(cut)}" width="${W}" height="${n(H - cut)}" fill="${c.accent}"/>
    <rect y="${n(cut)}" width="${W}" height="${n(H - cut)}" fill="#000" opacity="${c.paper ? 0.04 : 0.55}"/>
    ${textBlock(lines, { x: 48, y: n(cut + 90), size, fill: c.ink, lead: size * 0.98, tracking: -2 })}
    ${smallText(c.billing, { x: 48, y: H - 84, size: 12, fill: c.ink, opacity: 0.7, tracking: 1.4 })}
    ${smallText(c.credit, { x: 48, y: H - 52, size: 13, fill: c.ink, opacity: 0.9 })}`;
};

/** 8. Modernist corner: a big shape bleeding off an edge, type in the corner. */
const corner: Layout = (c) => {
  const { lines, size } = fit(c.title, { maxW: 420, maxLines: 4, sizes: [72, 64, 58, 52, 46, 41, 36, 32] });
  return `${c.art({ x: 120, y: -80, w: 620, h: 620, opacity: 1, clip: 'corner' })}
    ${textBlock(lines, { x: 48, y: 600, size, fill: c.ink, lead: size * 0.98, tracking: -2 })}
    <rect x="48" y="${n(620 + (lines.length - 1) * size * 0.98)}" width="120" height="4" fill="${c.accent}"/>
    ${smallText(c.director, { x: 48, y: H - 90, size: 14, fill: c.ink, opacity: 0.8 })}
    ${smallText(c.credit, { x: 48, y: H - 58, size: 12, fill: c.ink, opacity: 0.55 })}`;
};

const LAYOUTS: Array<{ name: string; fn: Layout; paperOk: boolean }> = [
  { name: 'flatType', fn: flatType, paperOk: true },
  { name: 'oneSheet', fn: oneSheet, paperOk: false },
  { name: 'objectCentre', fn: objectCentre, paperOk: true },
  { name: 'bandTitle', fn: bandTitle, paperOk: false },
  { name: 'titleTop', fn: titleTop, paperOk: true },
  { name: 'framed', fn: framed, paperOk: true },
  { name: 'blocks', fn: blocks, paperOk: true },
  { name: 'corner', fn: corner, paperOk: true },
];

/* ---- assembly --------------------------------------------------------- */

interface Row { id: string; title: string; year: number; genres: string[]; runtimeMin: number }

function poster(row: Row): { svg: string; layout: string; scheme: string } {
  const r = rng(hash(row.id + row.title));
  const primary = row.genres[0] ?? 'drama';
  const p = pick(r, DARK[primary] ?? [DARK_FALLBACK]);

  const layout = pick(r, LAYOUTS);
  const wantsPaper = layout.paperOk && !row.genres.some((g) => ALWAYS_DARK.has(g)) && r() < 0.55;
  const paper = wantsPaper ? pick(r, PAPERS) : undefined;
  const ink = paper ? paper.ink : p.ink;
  const accent = paper ? paper.accent : p.accent;
  const ground = paper ? paper.ground : 'url(#bg)';

  const motifSvg = (MOTIFS[primary] ?? MOTIFS.drama)!(p, r, ink);
  const art: Ctx['art'] = (box) => {
    const sx = box.w / W;
    const sy = box.h / H;
    const op = box.opacity ?? 1;
    // On paper the motif is a tint of the ink, not a dark field, so the ground stays light.
    const bg = paper
      ? `<rect width="${W}" height="${H}" fill="${p.bottom}" opacity="0.14"/>`
      : `<rect width="${W}" height="${H}" fill="url(#bg)"/>`;
    return `<g clip-path="url(#clip-${box.clip})" opacity="${op}"><g transform="translate(${n(box.x)} ${n(box.y)}) scale(${n(sx * 100) / 100} ${n(sy * 100) / 100})">${bg}${motifSvg}</g></g>`;
  };

  const ctx: Ctx = {
    ...row, p, paper, ink, accent, ground, art, r,
    billing: `${person(r)}   ${person(r)}   ${person(r)}`,
    director: `A FILM BY ${person(r)}`,
    studio: pick(r, STUDIO),
    credit: `${row.year} · ${row.genres.slice(0, 2).map((g) => g.toUpperCase()).join(' / ')} · ${row.runtimeMin} MIN`,
  };

  const body = layout.fn(ctx);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="${xml(row.title)}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0.3" y2="1"><stop offset="0" stop-color="${p.top}"/><stop offset="1" stop-color="${p.bottom}"/></linearGradient>
    <linearGradient id="scrim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="0.6" stop-color="#000" stop-opacity="0.55"/><stop offset="1" stop-color="#000" stop-opacity="0.88"/></linearGradient>
    <clipPath id="clip-full"><rect width="${W}" height="${H}"/></clipPath>
    <clipPath id="clip-mid"><rect y="90" width="${W}" height="620"/></clipPath>
    <clipPath id="clip-obj"><circle cx="300" cy="290" r="170"/></clipPath>
    <clipPath id="clip-low"><rect y="0" width="${W}" height="${H}"/></clipPath>
    <clipPath id="clip-frame"><rect x="90" y="150" width="420" height="380"/></clipPath>
    <clipPath id="clip-top"><rect width="${W}" height="${H}"/></clipPath>
    <clipPath id="clip-corner"><rect width="${W}" height="${H}"/></clipPath>
  </defs>
  <rect width="${W}" height="${H}" fill="${ground}"/>
  ${body}
</svg>`;
  return { svg, layout: layout.name, scheme: paper ? 'paper' : 'dark' };
}

/* ---- run --------------------------------------------------------------- */

const rows = JSON.parse(readFileSync(resolve(HERE, 'fake100-source.json'), 'utf8')) as Row[];
const bundles = JSON.parse(readFileSync(resolve(HERE, 'fake100.json'), 'utf8')) as ItemBundle[];
const byId = new Map(bundles.map((b) => [b.item.id, b]));

mkdirSync(OUT, { recursive: true });
const cards: string[] = [];
const counts: Record<string, number> = {};
let bytes = 0;

for (const row of rows) {
  const { svg, layout, scheme } = poster(row);
  counts[`${layout}/${scheme}`] = (counts[`${layout}/${scheme}`] ?? 0) + 1;
  writeFileSync(resolve(OUT, `${row.id}.svg`), svg);
  const uri = `data:image/svg+xml;base64,${Buffer.from(svg, 'utf8').toString('base64')}`;
  bytes += uri.length;
  const bundle = byId.get(row.id);
  if (bundle) bundle.item.posterUrl = uri;
  cards.push(`<figure><img src="${uri}" alt="${xml(row.title)}"/><figcaption>${xml(row.title)}</figcaption></figure>`);
}

writeFileSync(resolve(HERE, 'fake100.json'), `${JSON.stringify(bundles, null, 2)}\n`);
writeFileSync(resolve(OUT, 'contact-sheet.html'), `<!doctype html><meta charset="utf-8"><title>fake-100 posters</title>
<style>body{margin:0;padding:24px;background:#0b0d10;color:#e8ecf1;font:13px/1.4 'Helvetica Neue',Arial,sans-serif}
h1{font-size:18px;margin:0 0 18px}
.sheet{display:grid;grid-template-columns:repeat(10,1fr);gap:10px}
figure{margin:0}img{width:100%;display:block}
figcaption{margin-top:5px;font-size:9px;color:#8a95a3;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}</style>
<h1>SGEUL synthetic catalog — 100 generated posters</h1><div class="sheet">${cards.join('')}</div>`);

console.log(`${rows.length} posters → ${OUT}`);
console.log(`data URIs ${(bytes / 1024).toFixed(0)} KB total, ${(bytes / rows.length / 1024).toFixed(1)} KB mean`);
console.log(Object.entries(counts).sort().map(([k, v]) => `${k}:${v}`).join('  '));
