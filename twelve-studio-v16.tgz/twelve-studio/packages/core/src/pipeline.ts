/**
 * Enrichment pipeline — nine jobs per catalog item, each one TwelveLabs call
 * (plus deterministic post-processing), orchestrated by `enrichItem`.
 *
 *   ingest       POST /assets (url, or multipart direct upload for local files) → GET /assets/:id
 *                → POST/GET /indexes/:id/indexed-assets   (Marengo)
 *   fingerprint  POST /analyze  (pegasus1.5, json_schema)
 *   embedding    POST /embed-v2 (marengo3.5, video scope) — or /embed-v2/tasks for long assets
 *   emotions     POST /analyze  — or /analyze/tasks (time_based_metadata) when > 1h
 *   markers      POST /analyze
 *   safety       POST /analyze
 *   adbreaks     POST /analyze → planAdBreaks() (pure)
 *   thumbnails   POST /analyze
 *   clips        POST /analyze
 *
 * The pipeline never talks to disk itself: it reads/writes through the small
 * `PipelineStore` interface so the API's JSON store (or any other) can back it.
 */

import type {
  AdBreakPlan,
  AdCreative,
  AdFingerprint,
  CatalogItem,
  EmotionArc,
  Fingerprint,
  ItemBundle,
  Job,
  JobKind,
  JobStatus,
  Marker,
  MarkerSet,
  PreviewClip,
  SafetyCategory,
  SafetyReport,
  ThumbnailCandidate,
} from './types.js';
import {
  MODELS,
  pollUntil,
  TwelveLabsError,
  isFailed,
  isReady,
  type AnalyzeResult,
  type TwelveLabsClientLike,
  type VideoRef,
} from './twelvelabs.js';
import {
  adBreakCandidatesPrompt,
  adFingerprintPrompt,
  clipsPrompt,
  emotionsPrompt,
  fingerprintPrompt,
  markersPrompt,
  safetyPrompt,
  thumbnailsPrompt,
  type AdBreakCandidatesPayload,
  type AdFingerprintPayload,
  type ClipBrief,
  type ClipsPayload,
  type EmotionArcPayload,
  type FingerprintPayload,
  type MarkersPayload,
  type PromptContext,
  type SafetyPayload,
  type ThumbnailBrief,
  type ThumbnailsPayload,
} from './prompts.js';
import { planAdBreaks } from './adbreaks.js';
import { clamp, isHttpUrl, makeId, nowIso, parseJsonRobust, round } from './util.js';

/* ------------------------------------------------------------------ */
/* Dependencies                                                        */
/* ------------------------------------------------------------------ */

export interface PipelineConfig {
  /** Index to create/reuse when `indexId` is not given. */
  indexName: string;
  /** From TWELVELABS_INDEX_ID; otherwise resolved lazily and cached via store meta. */
  indexId?: string;
  /** ISO-639-1 codes for synopsis translations. */
  synopsisLanguages: string[];
  pollIntervalMs?: number;
  pollTimeoutMs?: number;
  /** Assets longer than this use the async task endpoints (default 3600s, the sync /analyze limit). */
  asyncThresholdSec?: number;
  /** Longest range one async analyze task accepts (default 7200s); longer assets are split into windows. */
  analyzeWindowSec?: number;
}

export type SectionKey = 'fingerprint' | 'emotions' | 'markers' | 'adBreaks' | 'safety' | 'thumbnails' | 'clips';

export interface PipelineStore {
  getBundle(itemId: string): ItemBundle | undefined;
  /** Upsert the catalog item (only `item`, never the sections). */
  saveItem(item: CatalogItem): CatalogItem;
  saveSection<K extends SectionKey>(itemId: string, key: K, value: NonNullable<ItemBundle[K]>): void;
  /** Small key/value area for things like the resolved index id. */
  getMeta(key: string): string | undefined;
  setMeta(key: string, value: string): void;
}

export interface PipelineDeps {
  client: TwelveLabsClientLike;
  store: PipelineStore;
  config: PipelineConfig;
}

export interface JobProgress {
  itemId: string;
  kind: JobKind;
  status: JobStatus;
  error?: string;
  upstream?: Job['upstream'];
  startedAt?: string;
  finishedAt?: string;
  /** Short human note for the activity ledger ("→ POST /analyze pegasus1.5"). */
  note?: string;
}

export type ProgressFn = (progress: JobProgress) => void;

/** Options for creative jobs when re-run under a recipe. */
export interface CreativeOptions {
  thumbnails?: ThumbnailBrief;
  clips?: ClipBrief;
}

export interface JobResult {
  kind: JobKind;
  item: CatalogItem;
  upstream?: Job['upstream'];
  /** The section produced (for creative runs the caller may want it without touching the bundle). */
  output?: unknown;
}

export const JOB_ORDER: readonly JobKind[] = [
  'ingest',
  'fingerprint',
  'embedding',
  'emotions',
  'markers',
  'safety',
  'adbreaks',
  'thumbnails',
  'clips',
];

/** Which bundle section a job fills (ingest fills the item itself). */
export const JOB_SECTION: Partial<Record<JobKind, SectionKey>> = {
  fingerprint: 'fingerprint',
  emotions: 'emotions',
  markers: 'markers',
  safety: 'safety',
  adbreaks: 'adBreaks',
  thumbnails: 'thumbnails',
  clips: 'clips',
};

export const INDEX_META_KEY = 'twelvelabs.indexId';

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function pollOpts(config: PipelineConfig) {
  return { intervalMs: config.pollIntervalMs ?? 5000, timeoutMs: config.pollTimeoutMs ?? 45 * 60 * 1000 };
}

export function needsIngest(item: CatalogItem, client: TwelveLabsClientLike): boolean {
  const assetId = item.upstream?.assetId;
  if (!assetId) return true;
  // Seed items carry mock ids; the live client must (re)ingest them.
  if (client.mode === 'live' && assetId.startsWith('mock-')) return true;
  // An asset that exists upstream but was never indexed (e.g. uploaded through Jockey) still needs a Marengo index.
  if (client.mode === 'live' && !item.upstream?.indexedAssetId) return true;
  return !item.durationSec;
}

/** True when the item's bytes live on this host and there is no public URL to hand TwelveLabs. */
export function isLocalItem(item: Pick<CatalogItem, 'localPath' | 'sourceUrl'>): boolean {
  return !!item.localPath && !isHttpUrl(item.sourceUrl);
}

/**
 * Prefer the indexed asset for analyze (already uploaded); fall back to the
 * public URL. Local items have no public URL, so they always analyze by asset id.
 */
export function videoRef(item: CatalogItem, client: TwelveLabsClientLike): VideoRef {
  const assetId = item.upstream?.assetId;
  if (assetId && !(client.mode === 'live' && assetId.startsWith('mock-'))) return { type: 'asset_id', asset_id: assetId };
  if (isLocalItem(item)) throw new TwelveLabsError(`${item.id} is a local file with no uploaded asset yet; run the ingest job first`, 'needs_ingest', 409);
  return { type: 'url', url: item.sourceUrl };
}

function promptContext(item: CatalogItem): PromptContext {
  return {
    title: item.title,
    durationSec: item.durationSec ?? 0,
    fps: item.fps ?? 24,
    year: item.year,
    type: item.type,
    series: item.series,
    metadata: item.metadata,
  };
}

function hint(item: CatalogItem, job: string, extra?: Record<string, unknown>) {
  return { job, title: item.title, sourceUrl: item.sourceUrl, itemId: item.id, extra };
}

/** Resolve (create or find) the Marengo index; cached in store meta. → GET/POST /v1.3/indexes */
export async function ensureIndex(deps: PipelineDeps): Promise<string> {
  const { client, store, config } = deps;
  if (config.indexId) return config.indexId;
  const cached = store.getMeta(INDEX_META_KEY);
  if (cached) return cached;
  const existing = await client.listIndexes({ name: config.indexName });
  const found = existing.find((i) => i.index_name === config.indexName) ?? existing[0];
  const id = found?._id ?? (await client.createIndex({ name: config.indexName }))._id;
  store.setMeta(INDEX_META_KEY, id);
  return id;
}

function cleanLabels(labels: Record<string, number> | undefined, max = 12): Record<string, number> {
  if (!labels || typeof labels !== 'object') return {};
  return Object.fromEntries(
    Object.entries(labels)
      .filter(([k, v]) => typeof k === 'string' && k.trim() && typeof v === 'number' && Number.isFinite(v))
      .map(([k, v]) => [k.trim().toLowerCase(), round(clamp(v, 0, 1), 3)] as const)
      .sort((a, b) => b[1] - a[1])
      .slice(0, max),
  );
}

function stamp<T extends object>(value: T, model: string): T & { model: string; generatedAt: string } {
  return { ...value, model, generatedAt: nowIso() };
}

/* ------------------------------------------------------------------ */
/* Jobs                                                                */
/* ------------------------------------------------------------------ */

async function jobIngest(item: CatalogItem, deps: PipelineDeps, onProgress?: ProgressFn): Promise<JobResult> {
  const { client, store, config } = deps;
  const upstream: NonNullable<CatalogItem['upstream']> = { ...(item.upstream ?? {}) };
  if (client.mode === 'live' && upstream.assetId?.startsWith('mock-')) {
    delete upstream.assetId;
    delete upstream.indexedAssetId;
  }

  // → POST /v1.3/assets {method:'url', url}  — or multipart {method:'direct', file} for a local file
  if (!upstream.assetId) {
    const local = isLocalItem(item);
    const asset = local
      ? await client.createAssetFromFile({ path: item.localPath!, filename: item.title })
      : await client.createAsset({ url: item.sourceUrl, filename: item.title });
    upstream.assetId = asset._id;
    item = store.saveItem({ ...item, status: 'ingesting', upstream, updatedAt: nowIso() });
    onProgress?.({ itemId: item.id, kind: 'ingest', status: 'running', note: `→ POST /assets (${local ? 'direct upload' : 'url'}: ${asset._id})`, upstream });
  }
  // → GET /v1.3/assets/:id until ready
  await pollUntil(async () => {
    const a = await client.getAsset(upstream.assetId!);
    if (isReady(a.status)) return a;
    if (isFailed(a.status)) throw new TwelveLabsError(`Asset ${a._id} failed to process`, 'asset_failed', 502, a);
    return undefined;
  }, pollOpts(config));

  // → POST /v1.3/indexes/:id/indexed-assets {asset_id, enable_video_stream:true}
  const indexId = await ensureIndex(deps);
  upstream.indexId = indexId;
  if (!upstream.indexedAssetId) {
    const ia = await client.createIndexedAsset(indexId, { assetId: upstream.assetId });
    upstream.indexedAssetId = ia._id;
    item = store.saveItem({ ...item, status: 'indexing', upstream, updatedAt: nowIso() });
    onProgress?.({ itemId: item.id, kind: 'ingest', status: 'running', note: `→ POST /indexes/${indexId}/indexed-assets`, upstream });
  }
  // → GET /v1.3/indexes/:id/indexed-assets/:iid until ready (duration/fps/hls)
  const indexed = await pollUntil(async () => {
    const ia = await client.getIndexedAsset(indexId, upstream.indexedAssetId!);
    if (isReady(ia.status)) return ia;
    if (isFailed(ia.status)) {
      const msg = typeof ia.error === 'string' ? ia.error : ia.error?.message;
      throw new TwelveLabsError(`Indexing failed: ${msg ?? 'unknown error'}`, 'indexing_failed', 502, ia);
    }
    return undefined;
  }, pollOpts(config));

  const meta = indexed.system_metadata ?? {};
  const updated = store.saveItem({
    ...item,
    durationSec: meta.duration ?? item.durationSec,
    fps: meta.fps ?? item.fps,
    width: meta.width ?? item.width,
    height: meta.height ?? item.height,
    playback: {
      hlsUrl: indexed.hls?.video_url ?? item.playback?.hlsUrl,
      fileUrl: item.playback?.fileUrl,
      thumbnailUrls: indexed.hls?.thumbnail_urls ?? item.playback?.thumbnailUrls,
    },
    upstream,
    status: 'enriching',
    updatedAt: nowIso(),
  });
  return { kind: 'ingest', item: updated, upstream: { assetId: upstream.assetId, indexedAssetId: upstream.indexedAssetId, model: MODELS.index } };
}

/** Time fields the prompt schemas use; these are shifted when a window reports relative times. */
const TIME_KEYS = new Set(['start', 'end', 'at']);

/**
 * Split an asset into equal analysis windows no longer than `maxSec`.
 * 94 min at 120 → one window; 178 min → two windows of 89 min.
 */
export function analysisWindows(durationSec: number, maxSec = 7200): Array<{ start: number; end: number }> {
  const d = Math.max(0, durationSec);
  const n = Math.max(1, Math.ceil(d / maxSec));
  const size = d / n;
  return Array.from({ length: n }, (_, i) => ({ start: round(i * size, 3), end: round(i === n - 1 ? d : (i + 1) * size, 3) }));
}

function collectTimes(node: unknown, out: number[]): number[] {
  if (Array.isArray(node)) node.forEach((v) => collectTimes(v, out));
  else if (node && typeof node === 'object') {
    for (const [k, v] of Object.entries(node)) {
      if (TIME_KEYS.has(k) && typeof v === 'number' && Number.isFinite(v)) out.push(v);
      else collectTimes(v, out);
    }
  }
  return out;
}

function shiftTimes(node: unknown, offset: number): unknown {
  if (Array.isArray(node)) return node.map((v) => shiftTimes(v, offset));
  if (node && typeof node === 'object') {
    return Object.fromEntries(
      Object.entries(node).map(([k, v]) => [k, TIME_KEYS.has(k) && typeof v === 'number' && Number.isFinite(v) ? round(v + offset, 3) : shiftTimes(v, offset)]),
    );
  }
  return node;
}

/**
 * Put a window's times on the asset timeline. Pegasus may answer with times
 * relative to the window or absolute; if every time fits inside the window's
 * length and at least one falls before the window starts, treat them as relative.
 */
export function toAssetTimeline<T>(data: T, win: { start: number; end: number }): T {
  if (win.start <= 0) return data;
  const times = collectTimes(data, []);
  if (!times.length) return data;
  const len = win.end - win.start;
  const relative = Math.max(...times) <= len + 5 && Math.min(...times) < win.start - 5;
  return relative ? (shiftTimes(data, win.start) as T) : data;
}

/**
 * Merge per-window JSON results: arrays concatenate, label maps (all-numeric
 * objects) keep the highest score per label, other objects merge key by key,
 * and scalars keep the first non-empty value.
 */
export function mergeWindowResults<T>(parts: T[]): T {
  const merge = (a: unknown, b: unknown): unknown => {
    if (a === undefined || a === null || a === '') return b;
    if (b === undefined || b === null || b === '') return a;
    if (Array.isArray(a) && Array.isArray(b)) return [...a, ...b];
    if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) {
      const ao = a as Record<string, unknown>;
      const bo = b as Record<string, unknown>;
      const numeric = (o: Record<string, unknown>) => Object.values(o).every((v) => typeof v === 'number');
      if (numeric(ao) && numeric(bo) && Object.keys(ao).length && Object.keys(bo).length) {
        const out: Record<string, number> = { ...(ao as Record<string, number>) };
        for (const [k, v] of Object.entries(bo as Record<string, number>)) out[k] = Math.max(out[k] ?? -Infinity, v);
        return out;
      }
      const out: Record<string, unknown> = { ...ao };
      for (const [k, v] of Object.entries(bo)) out[k] = merge(out[k], v);
      return out;
    }
    return a;
  };
  return parts.reduce<unknown>((acc, p) => merge(acc, p), undefined) as T;
}

/**
 * Pegasus with a JSON schema; shared by all Pegasus jobs.
 *   ≤ 60 min  → POST /v1.3/analyze (sync)
 *   > 60 min  → POST /v1.3/analyze/tasks per window of ≤ 120 min (start_time/end_time), then
 *               GET /analyze/tasks/:id, times moved onto the asset timeline, windows merged.
 */
async function analyzeJson<T>(
  item: CatalogItem,
  deps: PipelineDeps,
  job: string,
  bundle: { prompt: string; schema: Record<string, unknown>; maxTokens: number },
  extra?: Record<string, unknown>,
  onProgress?: ProgressFn,
): Promise<AnalyzeResult<T>> {
  const { client, config } = deps;
  const duration = item.durationSec ?? 0;
  if (duration <= (config.asyncThresholdSec ?? 3600)) {
    return client.analyze<T>({
      video: videoRef(item, client),
      prompt: bundle.prompt,
      schema: bundle.schema,
      maxTokens: bundle.maxTokens,
      temperature: 0.2,
      hint: hint(item, job, extra),
    });
  }

  const windows = analysisWindows(duration, config.analyzeWindowSec ?? 7200);
  const parts: T[] = [];
  const raws: string[] = [];
  const taskIds: string[] = [];
  let outputTokens = 0;
  for (const [i, win] of windows.entries()) {
    const multi = windows.length > 1;
    const prompt = multi
      ? `${bundle.prompt}\n\nThis request covers only the part of the video from ${Math.round(win.start)}s to ${Math.round(win.end)}s of ${Math.round(duration)}s. Report every time in seconds from the start of the full video.`
      : bundle.prompt;
    const task = await client.createAnalyzeTask({
      video: videoRef(item, client),
      prompt,
      schema: bundle.schema,
      maxTokens: bundle.maxTokens,
      temperature: 0.2,
      startTime: win.start,
      endTime: win.end,
      hint: hint(item, job, { ...(extra ?? {}), window: i }),
    });
    taskIds.push(task._id);
    onProgress?.({ itemId: item.id, kind: job as JobKind, status: 'running', note: `→ POST /analyze/tasks window ${i + 1}/${windows.length} ${Math.round(win.start)}–${Math.round(win.end)}s (${task._id})` });
    const done = await pollUntil(async () => {
      const t = await client.getAnalyzeTask(task._id);
      if (isReady(t.status) && typeof t.data === 'string') return t;
      if (isFailed(t.status)) {
        const msg = typeof t.error === 'string' ? t.error : t.error?.message;
        throw new TwelveLabsError(`Analyze task failed${msg ? `: ${msg}` : ''}`, 'analyze_failed', 502, t);
      }
      return undefined;
    }, pollOpts(config));
    raws.push(done.data!);
    outputTokens += done.usage?.output_tokens ?? 0;
    parts.push(toAssetTimeline(parseJsonRobust<T>(done.data!), win));
  }
  return {
    data: parts.length === 1 ? parts[0]! : mergeWindowResults(parts),
    raw: raws.join('\n'),
    model: MODELS.analyze,
    outputTokens: outputTokens || undefined,
    taskId: taskIds.join(','),
  };
}

async function jobFingerprint(item: CatalogItem, deps: PipelineDeps): Promise<JobResult> {
  const { store, config } = deps;
  const prev = store.getBundle(item.id)?.fingerprint;
  const bundle = fingerprintPrompt(promptContext(item), { languages: config.synopsisLanguages });
  // → POST /v1.3/analyze (pegasus1.5, json_schema: fingerprint)
  const res = await analyzeJson<FingerprintPayload>(item, deps, 'fingerprint', bundle, { languages: config.synopsisLanguages });
  const p = res.data;
  const fingerprint: Fingerprint = stamp(
    {
      genres: cleanLabels(p.genres),
      keywords: cleanLabels(p.keywords),
      moods: cleanLabels(p.moods),
      moodTags: cleanLabels(p.moodTags),
      themes: cleanLabels(p.themes),
      characters: (p.characters ?? []).slice(0, 8).map((c) => ({
        name: String(c.name),
        prominence: round(clamp(Number(c.prominence) || 0, 0, 1), 3),
        description: String(c.description ?? ''),
      })),
      pacing: { score: round(clamp(Number(p.pacing?.score) || 0, 0, 1), 3), rationale: String(p.pacing?.rationale ?? '') },
      language: { primary: p.language?.primary ?? 'none', others: p.language?.others ?? [] },
      audienceRating: p.audienceRating,
      synopsis: { short: p.synopsis.short, long: p.synopsis.long, translations: p.synopsis.translations ?? {} },
      // Keep an existing embedding: the embedding job owns it.
      ...(prev?.embedding ? { embedding: prev.embedding } : {}),
    },
    res.model,
  );
  store.saveSection(item.id, 'fingerprint', fingerprint);
  const updated = store.saveItem({ ...item, fingerprint, updatedAt: nowIso() });
  return { kind: 'fingerprint', item: updated, output: fingerprint, upstream: { assetId: item.upstream?.assetId, model: res.model, taskId: res.taskId } };
}

async function jobEmbedding(item: CatalogItem, deps: PipelineDeps, onProgress?: ProgressFn): Promise<JobResult> {
  const { client, store, config } = deps;
  const assetId = item.upstream?.assetId;
  if (!assetId) throw new TwelveLabsError('Embedding requires an ingested asset', 'not_ingested', 409);
  const fingerprint = store.getBundle(item.id)?.fingerprint;
  if (!fingerprint) throw new TwelveLabsError('Embedding requires a fingerprint to attach to', 'missing_fingerprint', 409);

  let embedding: number[];
  let taskId: string | undefined;
  if ((item.durationSec ?? 0) > (config.asyncThresholdSec ?? 3600)) {
    // → POST /v1.3/embed-v2/tasks (marengo3.5, long asset) then GET /embed-v2/tasks/:id
    const task = await client.createEmbedTask({ assetId, title: item.title });
    taskId = task._id;
    onProgress?.({ itemId: item.id, kind: 'embedding', status: 'running', note: `→ POST /embed-v2/tasks (${taskId})` });
    const done = await pollUntil(async () => {
      const t = await client.getEmbedTask(task._id);
      if (isReady(t.status) && t.data) return t;
      if (isFailed(t.status)) throw new TwelveLabsError('Embedding task failed', 'embed_failed', 502, t);
      return undefined;
    }, pollOpts(config));
    embedding = (done.data ?? []).find((r) => r.embedding_scope === 'video')?.embedding ?? done.data![0]!.embedding;
  } else {
    // → POST /v1.3/embed-v2 (marengo3.5, input_type video, embedding_scope ['video'])
    embedding = await client.embedVideo({ assetId, title: item.title });
  }
  const updatedFp: Fingerprint = { ...fingerprint, embedding };
  store.saveSection(item.id, 'fingerprint', updatedFp);
  const updated = store.saveItem({ ...item, fingerprint: updatedFp, updatedAt: nowIso() });
  return { kind: 'embedding', item: updated, output: { dimensions: embedding.length }, upstream: { assetId, taskId, model: MODELS.embed } };
}

async function jobEmotions(item: CatalogItem, deps: PipelineDeps, onProgress?: ProgressFn): Promise<JobResult> {
  const { client, store, config } = deps;
  const ctx = promptContext(item);
  const bundle = emotionsPrompt(ctx);
  // → POST /v1.3/analyze, or windowed /analyze/tasks when > 1h (see analyzeJson)
  const res = await analyzeJson<EmotionArcPayload>(item, deps, 'emotions', bundle, undefined, onProgress);
  const d = ctx.durationSec || Infinity;
  const samples = (res.data.samples ?? [])
    .filter((s) => Number.isFinite(s.start) && Number.isFinite(s.end))
    .map((s) => ({
      start: round(clamp(s.start, 0, d), 2),
      end: round(clamp(s.end, 0, d), 2),
      valence: round(clamp(Number(s.valence) || 0, -1, 1), 3),
      arousal: round(clamp(Number(s.arousal) || 0, 0, 1), 3),
      dominance: round(clamp(Number(s.dominance) || 0, 0, 1), 3),
      emotions: cleanLabels(s.emotions, 6),
      beat: String(s.beat ?? ''),
      confidence: round(clamp(Number(s.confidence) || 0.5, 0, 1), 3),
    }))
    .sort((a, b) => a.start - b.start)
    .slice(0, 60);
  const emotions: EmotionArc = stamp(
    {
      itemId: item.id,
      samples,
      acts: (res.data.acts ?? []).map((a) => ({ ...a, start: round(clamp(a.start, 0, d), 2), end: round(clamp(a.end, 0, d), 2) })),
      climax: res.data.climax ? { at: round(clamp(res.data.climax.at, 0, d), 2), description: res.data.climax.description } : undefined,
    },
    res.model,
  );
  store.saveSection(item.id, 'emotions', emotions);
  return { kind: 'emotions', item, output: emotions, upstream: { assetId: item.upstream?.assetId, model: res.model, taskId: res.taskId } };
}

async function jobMarkers(item: CatalogItem, deps: PipelineDeps): Promise<JobResult> {
  const { store } = deps;
  const prev = store.getBundle(item.id)?.markers;
  const ctx = promptContext(item);
  // → POST /v1.3/analyze (pegasus1.5, json_schema: markers)
  const res = await analyzeJson<MarkersPayload>(item, deps, 'markers', markersPrompt(ctx));
  const fps = item.fps;
  const d = ctx.durationSec || Infinity;
  const markers: Marker[] = (res.data.markers ?? [])
    .filter((m) => Number.isFinite(m.start) && Number.isFinite(m.end))
    .map((m) => {
      const start = round(clamp(m.start, 0, d), 2);
      const end = round(clamp(Math.max(m.end, m.start), 0, d), 2);
      const previous = prev?.markers.find((p) => p.kind === m.kind && Math.abs(p.start - start) <= 2);
      const marker: Marker = {
        id: previous?.id ?? makeId('mrk', `${item.id}:${m.kind}:${start}`),
        kind: m.kind,
        start,
        end,
        label: m.label,
        confidence: round(clamp(Number(m.confidence) || 0.5, 0, 1), 3),
      };
      if (fps) {
        marker.startFrame = Math.round(start * fps);
        marker.endFrame = Math.round(end * fps);
      }
      if (previous?.review) marker.review = previous.review;
      return marker;
    })
    .sort((a, b) => a.start - b.start);
  const set: MarkerSet = stamp({ itemId: item.id, fps, markers }, res.model);
  store.saveSection(item.id, 'markers', set);
  return { kind: 'markers', item, output: set, upstream: { assetId: item.upstream?.assetId, model: res.model } };
}

/* ------------------------------------------------------------------ */
/* Ad creatives                                                        */
/* ------------------------------------------------------------------ */

/**
 * Creative intelligence for one ad spot: upload it as an asset if it only
 * exists on disk / at a URL, then one Pegasus call with the ad schema.
 * Returns the updated creative (caller persists it). No index is needed:
 * `/analyze` accepts a bare asset id.
 */
export async function fingerprintCreative(
  ad: AdCreative,
  client: TwelveLabsClientLike,
  onProgress?: (note: string) => void,
): Promise<{ creative: AdCreative; upstream: { assetId?: string; model: string } }> {
  let assetId = ad.upstream?.assetId;
  if (assetId && client.mode === 'live' && assetId.startsWith('mock-')) assetId = undefined;
  if (!assetId) {
    // → POST /v1.3/assets (direct upload for a local file, url otherwise)
    const asset = ad.localPath ? await client.createAssetFromFile({ path: ad.localPath, filename: ad.name }) : await client.createAsset({ url: ad.sourceUrl ?? ad.mediaUrl, filename: ad.name });
    assetId = asset._id;
    onProgress?.(`→ POST /assets (${ad.localPath ? 'direct upload' : 'url'}: ${assetId})`);
    await pollUntil(async () => {
      const a = await client.getAsset(assetId!);
      if (isReady(a.status)) return a;
      if (isFailed(a.status)) throw new TwelveLabsError(`Asset ${a._id} failed to process`, 'asset_failed', 502, a);
      return undefined;
    });
  }
  const ctx: PromptContext = { title: ad.name, durationSec: ad.durationSec, fps: 25, type: 'promo', metadata: ad.advertiser ? { advertiser: ad.advertiser } : undefined };
  const bundle = adFingerprintPrompt(ctx);
  onProgress?.('→ POST /analyze (pegasus1.5, json_schema: adFingerprint)');
  const res = await client.analyze<AdFingerprintPayload>({
    video: { type: 'asset_id', asset_id: assetId },
    prompt: bundle.prompt,
    schema: bundle.schema,
    maxTokens: bundle.maxTokens,
    temperature: 0.2,
    hint: { job: 'adFingerprint', title: ad.name, sourceUrl: ad.sourceUrl, itemId: ad.id },
  });
  const p = res.data;
  const fingerprint: AdFingerprint = stamp(
    {
      brand: String(p.brand ?? '').trim(),
      product: String(p.product ?? '').trim(),
      tagline: p.tagline?.trim() || undefined,
      callToAction: p.callToAction?.trim() || undefined,
      synopsis: String(p.synopsis ?? ''),
      mood: cleanLabels(p.mood, 6),
      keywords: cleanLabels(p.keywords, 10),
      tone: cleanLabels(p.tone, 5),
      iab: (p.iab ?? []).map((c) => ({ ...c, tier: clamp(Math.round(Number(c.tier) || 1), 1, 3) as 1 | 2 | 3, confidence: clamp(Number(c.confidence) || 0, 0, 1) })),
      sensitivities: (p.sensitivities ?? []).map((x) => ({ ...x, confidence: clamp(Number(x.confidence) || 0, 0, 1) })),
      familySafe: clamp(Number(p.familySafe) || 0, 0, 1),
      pacing: { score: clamp(Number(p.pacing?.score) || 0, 0, 1), rationale: String(p.pacing?.rationale ?? '') },
      moments: (p.moments ?? []).map((m) => ({ at: round(clamp(Number(m.at) || 0, 0, ad.durationSec), 2), label: String(m.label ?? '') })).sort((a, b) => a.at - b.at),
      language: { primary: p.language?.primary ?? 'en', others: p.language?.others ?? [] },
    },
    res.model,
  );
  return { creative: { ...ad, upstream: { ...(ad.upstream ?? {}), assetId }, fingerprint }, upstream: { assetId, model: res.model } };
}

export function summariseSafety(segments: SafetyReport['segments']): SafetyReport['summary'] {
  const order = { low: 0, medium: 1, high: 2 } as const;
  const summary: SafetyReport['summary'] = {};
  for (const seg of segments) {
    const cur = summary[seg.category] ?? { maxSeverity: 'low' as const, totalSec: 0 };
    summary[seg.category] = {
      maxSeverity: order[seg.severity] > order[cur.maxSeverity] ? seg.severity : cur.maxSeverity,
      totalSec: round(cur.totalSec + Math.max(0, seg.end - seg.start), 1),
    };
  }
  return summary;
}

async function jobSafety(item: CatalogItem, deps: PipelineDeps): Promise<JobResult> {
  const { store } = deps;
  const ctx = promptContext(item);
  // → POST /v1.3/analyze (pegasus1.5, json_schema: safety)
  const res = await analyzeJson<SafetyPayload>(item, deps, 'safety', safetyPrompt(ctx));
  const d = ctx.durationSec || Infinity;
  const segments = (res.data.segments ?? [])
    .filter((s) => Number.isFinite(s.start) && Number.isFinite(s.end))
    .map((s) => ({
      id: makeId('saf', `${item.id}:${s.category}:${s.start}`),
      category: s.category as SafetyCategory,
      severity: s.severity,
      start: round(clamp(s.start, 0, d), 2),
      end: round(clamp(Math.max(s.end, s.start), 0, d), 2),
      description: String(s.description ?? ''),
      confidence: round(clamp(Number(s.confidence) || 0.5, 0, 1), 3),
    }))
    .sort((a, b) => a.start - b.start);
  const report: SafetyReport = stamp({ itemId: item.id, segments, summary: summariseSafety(segments) }, res.model);
  store.saveSection(item.id, 'safety', report);
  return { kind: 'safety', item, output: report, upstream: { assetId: item.upstream?.assetId, model: res.model } };
}

/** Re-plan from existing candidates/emotions/safety without a model call. */
export function replanAdBreaks(
  bundle: ItemBundle,
  candidates: AdBreakCandidatesPayload['candidates'],
  policy: Partial<AdBreakPlan['policy']> | undefined,
  model: string,
): AdBreakPlan {
  const item = bundle.item;
  const sceneChanges = [
    ...(bundle.markers?.markers.filter((m) => m.kind === 'chapter').flatMap((m) => [m.start, m.end]) ?? []),
    ...(bundle.emotions?.samples.map((s) => s.start) ?? []),
  ];
  return planAdBreaks(candidates, {
    durationSec: item.durationSec ?? 0,
    policy: { ...(bundle.adBreaks?.policy ?? {}), ...(policy ?? {}) },
    emotions: bundle.emotions,
    safety: bundle.safety,
    sceneChanges,
    fps: item.fps,
    itemId: item.id,
    model,
    previous: bundle.adBreaks?.breaks,
  });
}

async function jobAdBreaks(item: CatalogItem, deps: PipelineDeps): Promise<JobResult> {
  const { store } = deps;
  const ctx = promptContext(item);
  // → POST /v1.3/analyze (pegasus1.5, json_schema: ad-break candidates)
  const res = await analyzeJson<AdBreakCandidatesPayload>(item, deps, 'adbreaks', adBreakCandidatesPrompt(ctx));
  const candidates = (res.data.candidates ?? []).map((c) => ({
    ...c,
    at: round(clamp(Number(c.at) || 0, 0, ctx.durationSec || Infinity), 2),
    confidence: round(clamp(Number(c.confidence) || 0.5, 0, 1), 3),
    mood: cleanLabels(c.mood, 6),
    keywords: cleanLabels(c.keywords, 8),
    iab: (c.iab ?? []).map((x) => ({ ...x, tier: clamp(Math.round(Number(x.tier) || 1), 1, 3) as 1 | 2 | 3, confidence: round(clamp(Number(x.confidence) || 0.5, 0, 1), 3) })),
  }));
  const bundle = store.getBundle(item.id) ?? { item, jobs: [] };
  // Deterministic pod planner — no model call.
  const plan = replanAdBreaks({ ...bundle, item }, candidates, undefined, `${res.model}+planner`);
  // Keep the raw candidates alongside so the API can re-plan under a new policy later.
  const withCandidates = { ...plan, candidates } as AdBreakPlan & { candidates: typeof candidates };
  store.saveSection(item.id, 'adBreaks', withCandidates);
  return { kind: 'adbreaks', item, output: withCandidates, upstream: { assetId: item.upstream?.assetId, model: res.model } };
}

/** Composite thumbnail score from factor scores (weights documented for the UI). */
export const THUMBNAIL_WEIGHTS = { relevance: 0.3, aesthetics: 0.25, faceProminence: 0.15, stillness: 0.1, brightness: 0.1, safeArea: 0.1 } as const;

export function thumbnailScore(f: ThumbnailCandidate['factors']): number {
  const brightnessFit = 1 - clamp(Math.abs(f.brightness - 0.55) * 2, 0, 1);
  const s =
    f.relevance * THUMBNAIL_WEIGHTS.relevance +
    f.aesthetics * THUMBNAIL_WEIGHTS.aesthetics +
    f.faceProminence * THUMBNAIL_WEIGHTS.faceProminence +
    f.stillness * THUMBNAIL_WEIGHTS.stillness +
    brightnessFit * THUMBNAIL_WEIGHTS.brightness +
    f.safeArea * THUMBNAIL_WEIGHTS.safeArea;
  return round(clamp(s, 0, 1), 3);
}

const DEFAULT_CROPS: ThumbnailCandidate['crops'] = {
  '16:9': { x: 0, y: 0, w: 1, h: 1 },
  '2:3': { x: 0.3125, y: 0, w: 0.375, h: 1 },
  '1:1': { x: 0.21875, y: 0, w: 0.5625, h: 1 },
  '9:16': { x: 0.3418, y: 0, w: 0.3164, h: 1 },
};

export function normaliseThumbnails(
  raw: ThumbnailsPayload['thumbnails'],
  item: CatalogItem,
  salt = '',
): ThumbnailCandidate[] {
  const d = item.durationSec || Infinity;
  const f01 = (v: unknown) => round(clamp(Number(v) || 0, 0, 1), 3);
  return (raw ?? [])
    .filter((t) => Number.isFinite(t.at))
    .map((t) => {
      const factors = {
        relevance: f01(t.factors?.relevance),
        aesthetics: f01(t.factors?.aesthetics),
        faceProminence: f01(t.factors?.faceProminence),
        stillness: f01(t.factors?.stillness),
        brightness: f01(t.factors?.brightness),
        safeArea: f01(t.factors?.safeArea),
      };
      const at = round(clamp(t.at, 0, d), 2);
      const cand: ThumbnailCandidate = {
        id: makeId('thm', `${item.id}:${salt}:${at}`),
        at,
        score: thumbnailScore(factors),
        factors,
        characters: (t.characters ?? []).map(String),
        mood: cleanLabels(t.mood, 5),
        crops: { ...DEFAULT_CROPS, ...(t.crops ?? {}) },
        logoSafeZone: t.logoSafeZone ?? 'top-left',
        safe: Boolean(t.safe),
        caption: String(t.caption ?? ''),
      };
      if (item.fps) cand.frame = Math.round(at * item.fps);
      return cand;
    })
    .sort((a, b) => b.score - a.score);
}

export function normaliseClips(raw: ClipsPayload['clips'], item: CatalogItem, salt = ''): PreviewClip[] {
  const d = item.durationSec || Infinity;
  return (raw ?? [])
    .filter((c) => Number.isFinite(c.start) && Number.isFinite(c.end))
    .map((c) => {
      const start = round(clamp(c.start, 0, d), 2);
      const end = round(clamp(Math.max(c.end, c.start + 1), 0, d), 2);
      const clip: PreviewClip = {
        id: makeId('clp', `${item.id}:${salt}:${start}`),
        start,
        end,
        clipType: String(c.clipType ?? 'moment'),
        relevance: round(clamp(Number(c.relevance) || 0, 0, 1), 3),
        characters: (c.characters ?? []).map(String),
        mood: cleanLabels(c.mood, 5),
        keywords: cleanLabels(c.keywords, 8),
        safe: Boolean(c.safe),
        reframe916: (c.reframe916 ?? []).map((k) => ({ at: round(clamp(k.at, start, end), 2), cx: round(clamp(k.cx, 0, 1), 3) })),
        caption: String(c.caption ?? ''),
        posterAt: round(clamp(Number(c.posterAt) || start, start, end), 2),
      };
      if (typeof c.queryRelevance === 'number') clip.queryRelevance = round(clamp(c.queryRelevance, 0, 1), 3);
      if (c.query) clip.query = c.query;
      return clip;
    })
    .sort((a, b) => b.relevance - a.relevance);
}

async function jobThumbnails(item: CatalogItem, deps: PipelineDeps, brief?: ThumbnailBrief): Promise<JobResult> {
  const { store } = deps;
  const ctx = promptContext(item);
  const bundle = thumbnailsPrompt(ctx, brief ?? { count: 12 });
  // → POST /v1.3/analyze (pegasus1.5, json_schema: thumbnails; brief injected)
  const res = await analyzeJson<ThumbnailsPayload>(item, deps, 'thumbnails', bundle, brief as Record<string, unknown> | undefined);
  const thumbnails = normaliseThumbnails(res.data.thumbnails, item, brief?.brief ?? '');
  if (!brief) store.saveSection(item.id, 'thumbnails', thumbnails);
  return { kind: 'thumbnails', item, output: thumbnails, upstream: { assetId: item.upstream?.assetId, model: res.model } };
}

async function jobClips(item: CatalogItem, deps: PipelineDeps, brief?: ClipBrief): Promise<JobResult> {
  const { store } = deps;
  const ctx = promptContext(item);
  const bundle = clipsPrompt(ctx, brief ?? { count: 6 });
  // → POST /v1.3/analyze (pegasus1.5, json_schema: preview clips; brief injected)
  const res = await analyzeJson<ClipsPayload>(item, deps, 'clips', bundle, brief as Record<string, unknown> | undefined);
  const clips = normaliseClips(res.data.clips, item, brief?.brief ?? '');
  if (!brief) store.saveSection(item.id, 'clips', clips);
  return { kind: 'clips', item, output: clips, upstream: { assetId: item.upstream?.assetId, model: res.model } };
}

/* ------------------------------------------------------------------ */
/* Public entry points                                                 */
/* ------------------------------------------------------------------ */

/** Ingest first if the item has no usable asset. Returns the (possibly updated) item. */
async function ensureIngested(item: CatalogItem, deps: PipelineDeps, onProgress?: ProgressFn): Promise<CatalogItem> {
  if (!needsIngest(item, deps.client)) return item;
  const startedAt = nowIso();
  onProgress?.({ itemId: item.id, kind: 'ingest', status: 'running', startedAt });
  const r = await jobIngest(item, deps, onProgress);
  onProgress?.({ itemId: item.id, kind: 'ingest', status: 'ready', startedAt, finishedAt: nowIso(), upstream: r.upstream });
  return r.item;
}

/**
 * Run one job for one item. Ingest is performed first when the item has no
 * asset; `embedding` runs `fingerprint` first when none exists. Creative jobs
 * accept a brief (recipe run) — in that case the result is returned but NOT
 * written to the item's default thumbnails/clips.
 */
export async function runJob(
  kind: JobKind,
  item: CatalogItem,
  deps: PipelineDeps,
  options: { creative?: CreativeOptions; onProgress?: ProgressFn } = {},
): Promise<JobResult> {
  const { onProgress } = options;
  if (kind === 'ingest') return jobIngest(item, deps, onProgress);
  const current = await ensureIngested(item, deps, onProgress);
  switch (kind) {
    case 'fingerprint':
      return jobFingerprint(current, deps);
    case 'embedding': {
      const fp = deps.store.getBundle(current.id)?.fingerprint;
      const withFp = fp ? current : (await jobFingerprint(current, deps)).item;
      return jobEmbedding(withFp, deps, onProgress);
    }
    case 'emotions':
      return jobEmotions(current, deps, onProgress);
    case 'markers':
      return jobMarkers(current, deps);
    case 'safety':
      return jobSafety(current, deps);
    case 'adbreaks':
      return jobAdBreaks(current, deps);
    case 'thumbnails':
      return jobThumbnails(current, deps, options.creative?.thumbnails);
    case 'clips':
      return jobClips(current, deps, options.creative?.clips);
    default: {
      const never: never = kind;
      throw new Error(`Unknown job kind ${String(never)}`);
    }
  }
}

export interface EnrichOptions {
  /** Force re-run even when the job is already `ready`. */
  force?: boolean;
  /** Restrict to a subset of jobs (still in canonical order). */
  only?: JobKind[];
}

/**
 * Run every job in order for an item. Jobs already `ready` are skipped
 * (unless `force`), a failing job is recorded and the rest continue, and the
 * item's status is kept in sync in the store.
 */
export async function enrichItem(
  item: CatalogItem,
  deps: PipelineDeps,
  onProgress?: ProgressFn,
  options: EnrichOptions = {},
): Promise<CatalogItem> {
  const { store } = deps;
  const kinds = JOB_ORDER.filter((k) => !options.only || options.only.includes(k));
  let current = store.getBundle(item.id)?.item ?? item;
  const jobs: CatalogItem['jobs'] = { ...current.jobs };

  const sectionReady = (kind: JobKind): boolean => {
    const bundle = store.getBundle(current.id);
    if (kind === 'ingest') return !needsIngest(current, deps.client);
    if (kind === 'embedding') return !!bundle?.fingerprint?.embedding?.length;
    const key = JOB_SECTION[kind];
    return key ? !!bundle?.[key] : false;
  };

  for (const kind of kinds) {
    if (!options.force && jobs[kind] === 'ready' && sectionReady(kind)) {
      onProgress?.({ itemId: current.id, kind, status: 'skipped', note: 'already ready' });
      continue;
    }
    const startedAt = nowIso();
    jobs[kind] = 'running';
    current = store.saveItem({ ...current, jobs: { ...jobs }, updatedAt: nowIso() });
    onProgress?.({ itemId: current.id, kind, status: 'running', startedAt });
    try {
      const result = await runJob(kind, current, deps, { onProgress });
      // Refresh from the store: jobs may have updated the item (ingest, fingerprint).
      current = store.getBundle(current.id)?.item ?? result.item;
      jobs[kind] = 'ready';
      if (kind === 'ingest') jobs.ingest = 'ready';
      current = store.saveItem({ ...current, jobs: { ...jobs }, status: 'enriching', updatedAt: nowIso() });
      onProgress?.({ itemId: current.id, kind, status: 'ready', startedAt, finishedAt: nowIso(), upstream: result.upstream });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      jobs[kind] = 'failed';
      current = store.getBundle(current.id)?.item ?? current;
      current = store.saveItem({ ...current, jobs: { ...jobs }, updatedAt: nowIso() });
      onProgress?.({ itemId: current.id, kind, status: 'failed', error: message, startedAt, finishedAt: nowIso() });
      if (kind === 'ingest') {
        // Nothing downstream can run without an asset.
        current = store.saveItem({ ...current, status: 'failed', updatedAt: nowIso() });
        for (const rest of kinds.filter((k) => k !== 'ingest' && jobs[k] !== 'ready')) {
          jobs[rest] = 'skipped';
          onProgress?.({ itemId: current.id, kind: rest, status: 'skipped', note: 'ingest failed' });
        }
        return store.saveItem({ ...current, jobs: { ...jobs }, updatedAt: nowIso() });
      }
    }
  }

  const status: CatalogItem['status'] =
    jobs.ingest === 'ready' && jobs.fingerprint === 'ready' ? 'ready' : jobs.ingest === 'failed' ? 'failed' : 'enriching';
  return store.saveItem({ ...current, jobs: { ...jobs }, status, updatedAt: nowIso() });
}
