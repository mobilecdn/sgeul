# Twelve Studio — build contract

Product concept: what TwelveLabs should sell to media companies and publishers.
A Vionlabs-class application suite (Editorial Lab, Creative Lab, Operations Lab,
Discovery) plus an API and an MCP server, where every intelligence primitive is
Marengo (search/embed) or Pegasus (analyze with `response_format: json_schema`).

Shared types live in `packages/core/src/types.ts` and are the source of truth.

## Repo layout (npm workspaces, Node 22, TypeScript, ESM)

```
twelve-studio/
  package.json              workspaces: packages/*, apps/*   scripts: dev, build, seed, mcp
  packages/core/            @twelve-studio/core  — TwelveLabs client, prompts, pipeline, types
  apps/api/                 @twelve-studio/api   — Express 5 REST API + job runner + JSON store
  apps/web/                 @twelve-studio/web   — Vite + React 18 + TS SPA (dark, Inter)
  apps/mcp/                 @twelve-studio/mcp   — MCP stdio server exposing the same primitives
  data/seed/                demo catalog + enrichment JSON (real TwelveLabs output)
  data/store.json           runtime store (gitignored)
```

## TwelveLabs facts to code against (verified Sept 2026)

- Base `https://api.twelvelabs.io/v1.3`, header `x-api-key`.
- Upload: `POST /assets` multipart `{method:'url', url}` → `{_id,status}`; poll `GET /assets/:id` until `ready`.
- Index: `POST /indexes` `{index_name, models:[{model_name:'marengo3.0', model_options:['visual','audio']}], addons:['thumbnail']}`.
- Index content: `POST /indexes/:id/indexed-assets` `{asset_id, enable_video_stream:true}` → poll `GET /indexes/:id/indexed-assets/:iid` until `status==='ready'`; response has `system_metadata{duration,fps,width,height}`, `hls{video_url,thumbnail_urls}`.
- Search: `POST /search` multipart: `index_id, query_text, search_options[]=visual|audio|transcription, group_by=clip, page_limit`; hits `{video_id, start, end, rank, thumbnail_url?, transcription?}`; `GET /search/:page_token`.
- Assets listing: `GET /assets?page=&page_limit=` → `{data:[{_id, method, status:'ready'|'processing'|'failed', filename, file_type, size, duration, width, height, fps, hls:{manifest_url,status}|null, thumbnail:{representative_url,status}|null, created_at}], page_info:{page,limit_per_page,total_page,total_results}}` (verified 12 Sep 2026; `data/seed/twelvelabs-assets.json` is a real capture).
- Analyze: `POST /analyze` JSON `{model_name:'pegasus1.5', video:{type:'url',url} | {type:'asset_id',asset_id}, prompt, temperature:0.2, stream:false, response_format:{type:'json_schema', json_schema:{...}}, max_tokens, start_time?, end_time?}` → `{data}` (string; parse JSON). Async `POST /analyze/tasks` for >1h with `analysis_mode:'time_based_metadata'`.
- Embed: `POST /embed-v2` JSON `{input_type:'video'|'text', model_name:'marengo3.5', video:{media_source:{asset_id}, embedding_scope:['video']} | text:{input_text}}` → `{data:[{embedding:number[]}]}`; long video → `POST /embed-v2/tasks` and poll `GET /embed-v2/tasks/:id`.
- Analyze rejects numeric/string constraint keywords inside `response_format.json_schema` (`response_format_invalid — numeric constraints ('minimum') are not supported`): the client strips `minimum/maximum/exclusive*/min|maxProperties/min|maxItems/min|maxLength/pattern/format` with `sanitizeJsonSchema` before sending; ranges live in `description`.
- Pricing to surface in UI: index $2.50/h, analyze $1.75/h in + $7.50/M tokens out, search $4/1000 queries, embed video $0.26/M tokens.

`packages/core/src/twelvelabs.ts` wraps exactly these with a tiny fetch client (no SDK dependency, so it is obvious to the reader what is called). `MOCK` mode (no `TWELVELABS_API_KEY`) returns seeded data from `data/seed` so the whole product runs with zero setup.

## Enrichment pipeline (packages/core/src/pipeline.ts)

For each catalog item, jobs run in this order; each is one Pegasus call with a strict JSON schema
(see `prompts.ts`) unless noted:

1. `ingest` — asset → indexed asset (Marengo index). Captures duration/fps/hls.
2. `fingerprint` — Pegasus → `Fingerprint` (genres/keywords/moods/moodTags/themes/characters/pacing/language/rating/synopsis short+long + translations for `SYNOPSIS_LANGS` env, default `es,fr,de,ja,pt,ar,hi,ko`).
3. `embedding` — Marengo 3.5 video-scope embedding stored on the fingerprint.
4. `emotions` — Pegasus (`analysis_mode: time_based_metadata` style prompt) → `EmotionArc` with samples every ~20–30s, acts, climax.
5. `markers` — Pegasus → `MarkerSet` (cold_open/recap/intro/title_card/chapter/credits/post_credits/next_episode_hook/preview) with confidence; frames = round(sec*fps).
6. `safety` — Pegasus → `SafetyReport`.
7. `adbreaks` — Pegasus → candidate pauses, then **deterministic pod planner** (`adbreaks.ts`) applies policy (target count, min spacing, avoid first/last N sec, brand-safety from `safety`, emotion-aware: never cut inside a rising-arousal run) and ranks. Output `AdBreakPlan`.
8. `thumbnails` — Pegasus → `ThumbnailCandidate[]` (12) with factor scores and crops.
9. `clips` — Pegasus → `PreviewClip[]` (6) with reframe keyframes.

Creative "recipes" re-run 8/9 with the brief injected into the prompt (open vocabulary).
Smart lists: rules filter over fingerprints; NL query → Marengo text embedding cosine vs item embeddings (fallback: keyword match); AI curation → k-means over embeddings (k = clamp(items/6, 3, 12)) labelled by top shared moods/keywords.

## REST API (apps/api, port 8787, all JSON)

```
GET    /api/health                       → {ok, mode:'live'|'mock', index?, model versions}
GET    /api/stats                        → CatalogStats
GET    /api/catalog                      → CatalogItem[] (no embeddings)
POST   /api/catalog                      body CatalogItemInput | CatalogItemInput[] → CatalogItem[] (starts pipeline)
GET    /api/twelvelabs/assets?page=&pageLimit= → {assets: Array<TwelveLabsAsset & {linked?:{kind:'title'|'ad',id,title}}>, pageInfo}
POST   /api/catalog/import               body {items:[{assetId, as:'title'|'ad', title?, type?, advertiser?}]} → {items, ads, skipped, errors} (201; links existing account assets, no re-upload)
GET    /api/catalog/:id                  → ItemBundle
DELETE /api/catalog/:id
POST   /api/catalog/:id/jobs/:kind       re-run one job → Job
GET    /api/catalog/:id/emotions | markers | adbreaks | safety | thumbnails | clips | fingerprint
PATCH  /api/catalog/:id/markers/:mid     body Partial<ReviewState> → Marker
PATCH  /api/catalog/:id/adbreaks/:bid    body Partial<ReviewState> → AdBreak
POST   /api/catalog/:id/adbreaks/plan    body Partial<policy> → AdBreakPlan (re-plan deterministically, no model call)
GET    /api/catalog/:id/export/vmap      → VMAP XML of approved breaks
GET    /api/catalog/:id/export/scte35    → JSON list of splice points (pts, duration, id)
GET    /api/catalog/:id/export/markers   → JSON (player-ready: skipIntro, skipRecap, creditsStart, nextEpisodeAt)
GET    /api/catalog/:id/similar?limit=8  → SimilarTitle[]
POST   /api/search                       body {query, modalities?, limit?, pageToken?} → SearchResponse
GET    /api/lists                        → SmartList[]
POST   /api/lists                        body {name, source, rules?, query?} → SmartList (materialised)
POST   /api/lists/curate                 → SmartList[] (AI curation over whole catalog)
DELETE /api/lists/:id
GET    /api/recipes  POST /api/recipes   DELETE /api/recipes/:id
POST   /api/recipes/:id/run              body {itemIds:string[]} → CreativeRun[]
GET    /api/runs/:id                     → CreativeRun
GET    /api/jobs?status=                 → Job[]
GET    /api/events                       Server-Sent Events: {type:'job', job} | {type:'item', item}
```

Errors: `{error:{code,message}}`. All list responses omit `embedding`.
Store: `data/store.json` written atomically; in-memory Map with debounced flush.

## Web app (apps/web)

Design register (from Vionlabs, executed better): near-black `#0a0a0c` page, cards `#161616` /
`rgba(255,255,255,.05)`, text `#fff` headings and `rgba(255,255,255,.7)` body, Inter, radii 12/20px,
action blue `#0068e0`, AI/generative violet `#6d3fd4`, success `#5ec16a`, danger `#ea384c`,
warn `#f56300`. Signature component: **tag chip** `label 0.93` with dim score, `×`, `+N` overflow.
Probability everywhere. Broadcast timecode `HH:MM:SS:FF`.

Routes:
- `/` Overview — stats tiles, pipeline activity (SSE), cost-to-date estimate, "what TwelveLabs did" ledger.
- `/editorial` Editorial Lab — asset library poster grid + right inspector (synopsis short/long + language switch, genres/keywords/moods/moodTags/themes chips, characters, pacing, rating); tabs Asset library | Smart lists | AI curation. Smart list builder with confidence-range dual sliders and NL query box (violet). "Add assets" modal: From URLs (URL list) | From TwelveLabs (account asset table → import as titles / ad creatives).
- `/creative` Creative Lab — recipes list + builder (brief textarea, count, lengths, formats, character requirement, safety exclusions), run against selected items, results: thumbnail grid (frame rendered by seeking a `<video>` to `at`, overlaid crop guides + logo-safe zone, factor bars) and 9:16 clip strip with mood label + play.
- `/operations` Operations Lab — review workspace: left asset queue with status pills, centre player with frame-step transport `-10 -5 -1 ▶ +1 +5 +10`, ruler, tracks: Markers, Ad breaks Rank 1/2/3, Safety, Emotion arc (valence/arousal area chart), right inspector tabs Marker | Metadata | Safety | Comments with approve/decline, 0–5 rating, contextual chips, comments thread. Export menu (VMAP, SCTE-35, markers JSON). Batch approve.
- `/discovery` Discovery — any-to-video search (text) with clip results + thumbnails, similar titles graph for a selected item, emotion arc compare.
- `/api-docs` — the REST + MCP surface rendered from a static spec object with curl samples, and the "TwelveLabs calls behind each endpoint" table.
- `/settings` — key status, index, model versions, "TwelveLabs account" card (asset count, hours, linked, Sync assets), pricing calculator (hours × rates).

Data layer: `src/lib/api.ts` with two providers: `http` (fetch `/api/*`, SSE) and `static` (reads
`window.__TWELVE_DEMO__` seeded bundle, simulates latency; used for the published demo build via
`VITE_STATIC_DEMO=1`). Everything else is provider-agnostic.

## MCP server (apps/mcp)

stdio server, `@modelcontextprotocol/sdk`. Tools (Zod schemas):
`catalog_list`, `catalog_ingest`, `catalog_import`, `twelvelabs_assets_list`, `catalog_get`, `search_moments`, `similar_titles`,
`fingerprint_get`, `emotion_arc_get`, `markers_get`, `adbreaks_plan`, `safety_report`,
`thumbnails_generate`, `clips_generate`, `smartlist_create`, `curate_catalog`,
`export_vmap`, `export_markers`, plus the ad tools in CONTRACT-ads.md (`ads_list`, `ads_add`, `ads_fingerprint`, `adbreaks_fit`,
`adbreaks_autoassign`, `adbreaks_assign_creative`, `stitch_preview`). Resources: `twelve://catalog`, `twelve://item/{id}`.
Prompts: `editorial_brief`, `ad_ops_review`. Talks to the REST API (`TWELVE_API_URL`, default
http://localhost:8787) so one store serves UI, API and agents.
