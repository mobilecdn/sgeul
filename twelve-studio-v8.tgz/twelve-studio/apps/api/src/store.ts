/**
 * JSON store: in-memory Maps, debounced atomic flush to `data/store.json`.
 *
 * One store serves the REST API, the job runner and (through the API) the web
 * app and the MCP server. It implements the core `PipelineStore` interface so
 * the enrichment pipeline writes straight into it.
 */

import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import type {
  AdCreative,
  CatalogItem,
  CreativeRun,
  ItemBundle,
  Job,
  PipelineStore,
  Recipe,
  SectionKey,
  SmartList,
  Seed,
  StitchJob,
} from '@twelve-studio/core';
import { nowIso } from '@twelve-studio/core';

interface StoreFile {
  version: 1;
  bundles: Record<string, ItemBundle>;
  lists: SmartList[];
  recipes: Recipe[];
  runs: CreativeRun[];
  jobs: Job[];
  meta: Record<string, string>;
  ads?: AdCreative[];
  stitches?: StitchJob[];
}

const MAX_JOBS = 1000;
const MAX_RUNS = 500;
const MAX_STITCHES = 200;

export class Store implements PipelineStore {
  private readonly bundles = new Map<string, ItemBundle>();
  private lists: SmartList[] = [];
  private recipes: Recipe[] = [];
  private runs: CreativeRun[] = [];
  private jobs: Job[] = [];
  private meta: Record<string, string> = {};
  private ads: AdCreative[] = [];
  private stitches: StitchJob[] = [];

  private flushTimer: NodeJS.Timeout | undefined;
  private flushing: Promise<void> = Promise.resolve();
  private dirty = false;

  constructor(
    private readonly path: string,
    private readonly debounceMs = 400,
  ) {}

  /* ---- lifecycle -------------------------------------------------- */

  async load(): Promise<boolean> {
    try {
      const text = await readFile(this.path, 'utf8');
      const data = JSON.parse(text) as Partial<StoreFile>;
      for (const b of Object.values(data.bundles ?? {})) this.bundles.set(b.item.id, b);
      this.lists = data.lists ?? [];
      this.recipes = data.recipes ?? [];
      this.runs = data.runs ?? [];
      this.jobs = data.jobs ?? [];
      this.meta = data.meta ?? {};
      this.ads = data.ads ?? [];
      // A render that was mid-flight when the process died can never finish.
      this.stitches = (data.stitches ?? []).map((s) => (s.status === 'queued' || s.status === 'running' ? { ...s, status: 'failed' as const, error: 'interrupted: API restarted during the render', finishedAt: s.finishedAt ?? nowIso() } : s));
      return true;
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return false;
      throw new Error(`Store at ${this.path} is unreadable: ${(err as Error).message}`);
    }
  }

  /** Import a seed (no-op for ids that already exist). Returns the number of items added. */
  importSeed(seed: Seed): number {
    let added = 0;
    for (const bundle of seed.catalog) {
      if (this.bundles.has(bundle.item.id)) continue;
      // Deep-clone so later mutations never touch the seed object graph.
      this.bundles.set(bundle.item.id, structuredClone(bundle));
      added += 1;
    }
    const known = new Set(this.lists.map((l) => l.id));
    for (const list of seed.lists) {
      if (known.has(list.id)) continue;
      this.lists.push(structuredClone(list));
    }
    const knownAds = new Set(this.ads.map((a) => a.id));
    for (const ad of seed.ads ?? []) {
      if (knownAds.has(ad.id)) continue;
      this.ads.push(structuredClone(ad));
    }
    if (added > 0 || seed.lists.length > 0 || (seed.ads ?? []).length > 0) this.touch();
    return added;
  }

  get size(): number {
    return this.bundles.size;
  }

  /** Mark dirty and schedule a debounced flush. */
  private touch(): void {
    this.dirty = true;
    if (this.flushTimer) return;
    this.flushTimer = setTimeout(() => {
      this.flushTimer = undefined;
      void this.flush();
    }, this.debounceMs);
  }

  /** Atomic write: serialise → tmp file → rename. Serialises concurrent flushes. */
  flush(): Promise<void> {
    if (!this.dirty) return this.flushing;
    this.dirty = false;
    const snapshot: StoreFile = {
      version: 1,
      bundles: Object.fromEntries(this.bundles),
      lists: this.lists,
      recipes: this.recipes,
      runs: this.runs,
      jobs: this.jobs,
      meta: this.meta,
      ads: this.ads,
      stitches: this.stitches,
    };
    const text = JSON.stringify(snapshot);
    this.flushing = this.flushing.then(async () => {
      await mkdir(dirname(this.path), { recursive: true });
      const tmp = `${this.path}.${process.pid}.tmp`;
      await writeFile(tmp, text, 'utf8');
      await rename(tmp, this.path);
    });
    return this.flushing;
  }

  /** Flush now (used on shutdown). */
  async close(): Promise<void> {
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
      this.flushTimer = undefined;
    }
    await this.flush();
  }

  /* ---- PipelineStore ---------------------------------------------- */

  getBundle(itemId: string): ItemBundle | undefined {
    return this.bundles.get(itemId);
  }

  saveItem(item: CatalogItem): CatalogItem {
    const existing = this.bundles.get(item.id);
    // The item carries a copy of the fingerprint for list views; the bundle's copy is canonical.
    // Never let a stale item copy drop an embedding the embedding job already stored.
    let fingerprint = item.fingerprint ?? existing?.fingerprint;
    const stored = existing?.fingerprint;
    if (fingerprint && stored?.embedding && !fingerprint.embedding && stored.generatedAt === fingerprint.generatedAt) {
      fingerprint = { ...fingerprint, embedding: stored.embedding };
    }
    const next: CatalogItem = fingerprint ? { ...item, fingerprint } : item;
    const bundle: ItemBundle = existing ? { ...existing, item: next, fingerprint } : { item: next, fingerprint, jobs: [] };
    this.bundles.set(item.id, bundle);
    this.touch();
    return next;
  }

  saveSection<K extends SectionKey>(itemId: string, key: K, value: NonNullable<ItemBundle[K]>): void {
    const bundle = this.bundles.get(itemId);
    if (!bundle) throw new Error(`Cannot save ${key}: item ${itemId} does not exist`);
    (bundle as unknown as Record<string, unknown>)[key] = value;
    if (key === 'fingerprint') bundle.item = { ...bundle.item, fingerprint: value as ItemBundle['fingerprint'] };
    this.touch();
  }

  getMeta(key: string): string | undefined {
    return this.meta[key];
  }

  setMeta(key: string, value: string): void {
    this.meta[key] = value;
    this.touch();
  }

  /* ---- catalog ---------------------------------------------------- */

  allBundles(): ItemBundle[] {
    return [...this.bundles.values()];
  }

  allItems(): CatalogItem[] {
    return this.allBundles().map((b) => b.item);
  }

  findBySourceUrl(url: string): CatalogItem | undefined {
    const norm = url.trim().toLowerCase();
    return this.allItems().find((i) => i.sourceUrl.trim().toLowerCase() === norm);
  }

  deleteItem(itemId: string): boolean {
    const existed = this.bundles.delete(itemId);
    if (!existed) return false;
    for (const list of this.lists) {
      if (list.itemIds.includes(itemId)) {
        list.itemIds = list.itemIds.filter((id) => id !== itemId);
        list.updatedAt = nowIso();
      }
    }
    this.jobs = this.jobs.filter((j) => j.itemId !== itemId);
    this.runs = this.runs.filter((r) => r.itemId !== itemId);
    this.stitches = this.stitches.filter((s) => s.itemId !== itemId);
    this.touch();
    return true;
  }

  /** Mutate a bundle in place through a callback; flushes afterwards. */
  updateBundle(itemId: string, fn: (bundle: ItemBundle) => void): ItemBundle | undefined {
    const bundle = this.bundles.get(itemId);
    if (!bundle) return undefined;
    fn(bundle);
    bundle.item.updatedAt = nowIso();
    this.touch();
    return bundle;
  }

  /* ---- jobs ------------------------------------------------------- */

  allJobs(): Job[] {
    return this.jobs;
  }

  getJob(id: string): Job | undefined {
    return this.jobs.find((j) => j.id === id);
  }

  upsertJob(job: Job): Job {
    const idx = this.jobs.findIndex((j) => j.id === job.id);
    if (idx >= 0) this.jobs[idx] = job;
    else {
      this.jobs.push(job);
      if (this.jobs.length > MAX_JOBS) this.jobs = this.jobs.slice(-MAX_JOBS);
    }
    this.touch();
    return job;
  }

  /** Latest unfinished job for an item/kind pair, if any. */
  openJob(itemId: string, kind: Job['kind']): Job | undefined {
    for (let i = this.jobs.length - 1; i >= 0; i--) {
      const j = this.jobs[i]!;
      if (j.itemId === itemId && j.kind === kind && (j.status === 'queued' || j.status === 'running')) return j;
    }
    return undefined;
  }

  /* ---- lists ------------------------------------------------------ */

  allLists(): SmartList[] {
    return this.lists;
  }

  saveList(list: SmartList): SmartList {
    const idx = this.lists.findIndex((l) => l.id === list.id);
    if (idx >= 0) this.lists[idx] = list;
    else this.lists.push(list);
    this.touch();
    return list;
  }

  deleteList(id: string): boolean {
    const before = this.lists.length;
    this.lists = this.lists.filter((l) => l.id !== id);
    if (this.lists.length !== before) this.touch();
    return this.lists.length !== before;
  }

  replaceAiLists(lists: SmartList[]): void {
    this.lists = [...this.lists.filter((l) => l.source !== 'ai'), ...lists];
    this.touch();
  }

  /* ---- recipes + runs --------------------------------------------- */

  allRecipes(): Recipe[] {
    return this.recipes;
  }

  getRecipe(id: string): Recipe | undefined {
    return this.recipes.find((r) => r.id === id);
  }

  saveRecipe(recipe: Recipe): Recipe {
    const idx = this.recipes.findIndex((r) => r.id === recipe.id);
    if (idx >= 0) this.recipes[idx] = recipe;
    else this.recipes.push(recipe);
    this.touch();
    return recipe;
  }

  deleteRecipe(id: string): boolean {
    const before = this.recipes.length;
    this.recipes = this.recipes.filter((r) => r.id !== id);
    if (this.recipes.length !== before) this.touch();
    return this.recipes.length !== before;
  }

  getRun(id: string): CreativeRun | undefined {
    return this.runs.find((r) => r.id === id);
  }

  allRuns(): CreativeRun[] {
    return this.runs;
  }

  saveRun(run: CreativeRun): CreativeRun {
    const idx = this.runs.findIndex((r) => r.id === run.id);
    if (idx >= 0) this.runs[idx] = run;
    else {
      this.runs.push(run);
      if (this.runs.length > MAX_RUNS) this.runs = this.runs.slice(-MAX_RUNS);
    }
    this.touch();
    return run;
  }

  /* ---- ad creatives ------------------------------------------------ */

  allAds(): AdCreative[] {
    return this.ads;
  }

  getAd(id: string): AdCreative | undefined {
    return this.ads.find((a) => a.id === id);
  }

  saveAd(ad: AdCreative): AdCreative {
    const idx = this.ads.findIndex((a) => a.id === ad.id);
    if (idx >= 0) this.ads[idx] = ad;
    else this.ads.push(ad);
    this.touch();
    return ad;
  }

  /** Delete a creative and unassign it from every break that referenced it. */
  deleteAd(id: string): boolean {
    const before = this.ads.length;
    this.ads = this.ads.filter((a) => a.id !== id);
    if (this.ads.length === before) return false;
    for (const bundle of this.bundles.values()) {
      for (const brk of bundle.adBreaks?.breaks ?? []) {
        if (brk.creativeId === id) delete brk.creativeId;
      }
    }
    this.touch();
    return true;
  }

  /* ---- stitch jobs ------------------------------------------------- */

  allStitches(): StitchJob[] {
    return this.stitches;
  }

  getStitch(id: string): StitchJob | undefined {
    return this.stitches.find((s) => s.id === id);
  }

  saveStitch(job: StitchJob): StitchJob {
    const idx = this.stitches.findIndex((s) => s.id === job.id);
    if (idx >= 0) this.stitches[idx] = job;
    else {
      this.stitches.push(job);
      if (this.stitches.length > MAX_STITCHES) this.stitches = this.stitches.slice(-MAX_STITCHES);
    }
    this.touch();
    return job;
  }
}
