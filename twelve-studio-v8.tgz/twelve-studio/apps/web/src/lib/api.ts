import type {
  AdBreak,
  AdBreakPlan,
  AdCreative,
  AdFingerprint,
  CatalogItem,
  CatalogItemInput,
  CatalogStats,
  CreativeFit,
  CreativeRun,
  EmotionArc,
  Fingerprint,
  ItemBundle,
  ItemType,
  Job,
  JobKind,
  JobStatus,
  Marker,
  MarkerSet,
  PreviewClip,
  Recipe,
  ReviewState,
  SafetyReport,
  SearchHit,
  SearchResponse,
  SimilarTitle,
  SmartList,
  SmartListRule,
  StitchJob,
  ThumbnailCandidate,
  TwelveLabsAsset,
} from '@twelve-studio/core';

import { autoAssign as pickByFit, rankCreatives } from '@twelve-studio/core/creativefit';

export type { TwelveLabsAsset } from '@twelve-studio/core';

/** GET /catalog/:id/adbreaks/fit */
export interface FitReport {
  itemId: string;
  creatives: Array<{ id: string; name: string; fingerprinted: boolean }>;
  breaks: Array<{ breakId: string; at: number; rank: number; assigned?: string; fits: CreativeFit[] }>;
}
export interface AutoAssignResult {
  plan: AdBreakPlan;
  assignments: Array<{ breakId: string; creativeId?: string; fit?: CreativeFit }>;
}

/* ------------------------------------------------------------------ */
/* Contract                                                            */
/* ------------------------------------------------------------------ */

export type Mode = 'live' | 'mock' | 'static';

export interface Health {
  ok: boolean;
  mode: Mode;
  index?: string;
  models?: { index?: string; embed?: string; analyze?: string };
  [k: string]: unknown;
}

export type Modality = 'visual' | 'audio' | 'transcription';

export interface SearchParams {
  query: string;
  modalities?: Modality[];
  limit?: number;
  pageToken?: string;
}

export interface ListInput {
  name: string;
  source: SmartList['source'];
  rules?: SmartListRule[];
  query?: string;
}

export type RecipeInput = Omit<Recipe, 'id' | 'createdAt'>;

export type StudioEvent = { type: 'job'; job: Job } | { type: 'item'; item: CatalogItem } | { type: 'stitch'; job: StitchJob };

export interface AdInput {
  name: string;
  advertiser?: string;
  /** Public URL of the creative (mp4). */
  sourceUrl?: string;
  /** Absolute path on the API host. */
  localPath?: string;
}

export interface AssignInput {
  /** `null` clears the assignment. */
  creativeId: string | null;
  /** Defaults to every planned break. */
  breakIds?: string[];
}

export interface StitchInput {
  /** Defaults to the creative assigned on the selected breaks. */
  creativeId?: string;
  breakIds?: string[];
  /** When no break is approved, render every planned break instead. */
  includeUnapproved?: boolean;
}

/** What a TwelveLabs asset is attached to in this workspace. */
export interface AssetLink {
  kind: 'title' | 'ad';
  id: string;
  title: string;
}
export type LinkedAsset = TwelveLabsAsset & { linked?: AssetLink };

export interface AssetListing {
  assets: LinkedAsset[];
  pageInfo: { page: number; limitPerPage: number; totalPage: number; totalResults: number };
}

export interface ImportInput {
  assetId: string;
  as: 'title' | 'ad';
  title?: string;
  type?: ItemType;
  advertiser?: string;
}

export interface ImportResult {
  items: CatalogItem[];
  ads: AdCreative[];
  skipped: Array<{ assetId: string; linked: AssetLink }>;
  errors: Array<{ assetId: string; error: { code: string; message: string } }>;
}

export interface DemoBundle {
  catalog: ItemBundle[];
  lists: SmartList[];
  recipes?: Recipe[];
  /** Seeded ad creatives (optional — older bundles have none). */
  ads?: AdCreative[];
  /** A captured `GET /v1.3/assets` listing of the demo account (optional). */
  twelvelabsAssets?: TwelveLabsAsset[];
}

declare global {
  interface Window {
    /**
     * Full demo bundle, or a partial overlay (e.g. `{ ads: [...] }`) merged over the
     * fetched `/demo-bundle.json` — handy for screenshots and embeds.
     */
    __TWELVE_DEMO__?: DemoBundle | Partial<DemoBundle>;
  }
}

export interface Api {
  readonly kind: 'http' | 'static';
  health(): Promise<Health>;
  stats(): Promise<CatalogStats>;
  catalog(): Promise<CatalogItem[]>;
  addItems(input: CatalogItemInput | CatalogItemInput[]): Promise<CatalogItem[]>;
  item(id: string): Promise<ItemBundle>;
  deleteItem(id: string): Promise<void>;
  rerunJob(id: string, kind: JobKind): Promise<Job>;
  fingerprint(id: string): Promise<Fingerprint>;
  emotions(id: string): Promise<EmotionArc>;
  markers(id: string): Promise<MarkerSet>;
  adbreaks(id: string): Promise<AdBreakPlan>;
  safety(id: string): Promise<SafetyReport>;
  thumbnails(id: string): Promise<ThumbnailCandidate[]>;
  clips(id: string): Promise<PreviewClip[]>;
  patchMarker(id: string, mid: string, patch: Partial<ReviewState>): Promise<Marker>;
  patchAdBreak(id: string, bid: string, patch: Partial<ReviewState>): Promise<AdBreak>;
  planAdBreaks(id: string, policy: Partial<AdBreakPlan['policy']>): Promise<AdBreakPlan>;
  exportVmap(id: string): Promise<string>;
  exportScte35(id: string): Promise<unknown>;
  exportMarkers(id: string): Promise<unknown>;
  similar(id: string, limit?: number): Promise<SimilarTitle[]>;
  search(params: SearchParams): Promise<SearchResponse>;
  lists(): Promise<SmartList[]>;
  createList(input: ListInput): Promise<SmartList>;
  curate(): Promise<SmartList[]>;
  deleteList(id: string): Promise<void>;
  recipes(): Promise<Recipe[]>;
  createRecipe(input: RecipeInput): Promise<Recipe>;
  deleteRecipe(id: string): Promise<void>;
  runRecipe(id: string, itemIds: string[]): Promise<CreativeRun[]>;
  run(id: string): Promise<CreativeRun>;
  jobs(status?: JobStatus): Promise<Job[]>;
  /* Ad creatives + stitched previews (CONTRACT-ads.md) */
  listAds(): Promise<AdCreative[]>;
  addAd(input: AdInput): Promise<AdCreative>;
  deleteAd(id: string): Promise<void>;
  assignCreative(itemId: string, input: AssignInput): Promise<AdBreakPlan>;
  /** One Pegasus call: brand, mood, keywords, IAB, sensitivities for a creative. */
  fingerprintAd(id: string): Promise<AdCreative>;
  /** Creative-to-break fit for every planned break (deterministic). */
  creativeFit(itemId: string): Promise<FitReport>;
  /** Assign the best-fitting creative per break. */
  autoAssign(itemId: string, input?: { minScore?: number; breakIds?: string[] }): Promise<AutoAssignResult>;
  stitch(itemId: string, input?: StitchInput): Promise<StitchJob>;
  getStitch(id: string): Promise<StitchJob>;
  /** All stitch jobs, or those of one item. */
  listStitches(itemId?: string): Promise<StitchJob[]>;
  /* TwelveLabs account sync */
  /** Assets in the connected TwelveLabs account, annotated with the title / creative they are linked to. */
  twelvelabsAssets(params?: { page?: number; pageLimit?: number }): Promise<AssetListing>;
  /** Import account assets as titles (enrichment starts) or ad creatives. */
  importAssets(items: ImportInput[]): Promise<ImportResult>;
  subscribeEvents(cb: (e: StudioEvent) => void): () => void;
  /** Static provider only: restore the seeded bundle. */
  resetDemo?(): Promise<void>;
}

export class ApiError extends Error {
  constructor(
    public code: string,
    message: string,
    public status?: number,
  ) {
    super(message);
  }
}

/* ------------------------------------------------------------------ */
/* HTTP provider                                                       */
/* ------------------------------------------------------------------ */

async function http<T>(path: string, init?: RequestInit & { text?: boolean }): Promise<T> {
  const res = await fetch(`/api${path}`, {
    ...init,
    headers: { 'content-type': 'application/json', ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    let code = 'http_error';
    let message = `${res.status} ${res.statusText}`;
    try {
      const body = (await res.json()) as { error?: { code?: string; message?: string } };
      code = body.error?.code ?? code;
      message = body.error?.message ?? message;
    } catch {
      /* not JSON */
    }
    throw new ApiError(code, message, res.status);
  }
  if (res.status === 204) return undefined as T;
  if (init?.text) return (await res.text()) as T;
  return (await res.json()) as T;
}

const json = (body: unknown) => JSON.stringify(body);

export class HttpApi implements Api {
  readonly kind = 'http' as const;
  health() {
    return http<Health>('/health');
  }
  stats() {
    return http<CatalogStats>('/stats');
  }
  catalog() {
    return http<CatalogItem[]>('/catalog');
  }
  addItems(input: CatalogItemInput | CatalogItemInput[]) {
    return http<CatalogItem[]>('/catalog', { method: 'POST', body: json(input) });
  }
  item(id: string) {
    return http<ItemBundle>(`/catalog/${id}`);
  }
  deleteItem(id: string) {
    return http<void>(`/catalog/${id}`, { method: 'DELETE' });
  }
  rerunJob(id: string, kind: JobKind) {
    return http<Job>(`/catalog/${id}/jobs/${kind}`, { method: 'POST' });
  }
  fingerprint(id: string) {
    return http<Fingerprint>(`/catalog/${id}/fingerprint`);
  }
  emotions(id: string) {
    return http<EmotionArc>(`/catalog/${id}/emotions`);
  }
  markers(id: string) {
    return http<MarkerSet>(`/catalog/${id}/markers`);
  }
  adbreaks(id: string) {
    return http<AdBreakPlan>(`/catalog/${id}/adbreaks`);
  }
  safety(id: string) {
    return http<SafetyReport>(`/catalog/${id}/safety`);
  }
  thumbnails(id: string) {
    return http<ThumbnailCandidate[]>(`/catalog/${id}/thumbnails`);
  }
  clips(id: string) {
    return http<PreviewClip[]>(`/catalog/${id}/clips`);
  }
  patchMarker(id: string, mid: string, patch: Partial<ReviewState>) {
    return http<Marker>(`/catalog/${id}/markers/${mid}`, { method: 'PATCH', body: json(patch) });
  }
  patchAdBreak(id: string, bid: string, patch: Partial<ReviewState>) {
    return http<AdBreak>(`/catalog/${id}/adbreaks/${bid}`, { method: 'PATCH', body: json(patch) });
  }
  planAdBreaks(id: string, policy: Partial<AdBreakPlan['policy']>) {
    return http<AdBreakPlan>(`/catalog/${id}/adbreaks/plan`, { method: 'POST', body: json(policy) });
  }
  exportVmap(id: string) {
    return http<string>(`/catalog/${id}/export/vmap`, { text: true });
  }
  exportScte35(id: string) {
    return http<unknown>(`/catalog/${id}/export/scte35`);
  }
  exportMarkers(id: string) {
    return http<unknown>(`/catalog/${id}/export/markers`);
  }
  similar(id: string, limit = 8) {
    return http<SimilarTitle[]>(`/catalog/${id}/similar?limit=${limit}`);
  }
  search(params: SearchParams) {
    return http<SearchResponse>('/search', { method: 'POST', body: json(params) });
  }
  lists() {
    return http<SmartList[]>('/lists');
  }
  createList(input: ListInput) {
    return http<SmartList>('/lists', { method: 'POST', body: json(input) });
  }
  curate() {
    return http<SmartList[]>('/lists/curate', { method: 'POST' });
  }
  deleteList(id: string) {
    return http<void>(`/lists/${id}`, { method: 'DELETE' });
  }
  recipes() {
    return http<Recipe[]>('/recipes');
  }
  createRecipe(input: RecipeInput) {
    return http<Recipe>('/recipes', { method: 'POST', body: json(input) });
  }
  deleteRecipe(id: string) {
    return http<void>(`/recipes/${id}`, { method: 'DELETE' });
  }
  runRecipe(id: string, itemIds: string[]) {
    return http<CreativeRun[]>(`/recipes/${id}/run`, { method: 'POST', body: json({ itemIds }) });
  }
  run(id: string) {
    return http<CreativeRun>(`/runs/${id}`);
  }
  jobs(status?: JobStatus) {
    return http<Job[]>(`/jobs${status ? `?status=${status}` : ''}`);
  }
  listAds() {
    return http<AdCreative[]>('/ads');
  }
  addAd(input: AdInput) {
    return http<AdCreative>('/ads', { method: 'POST', body: json(input) });
  }
  deleteAd(id: string) {
    return http<void>(`/ads/${id}`, { method: 'DELETE' });
  }
  assignCreative(itemId: string, input: AssignInput) {
    return http<AdBreakPlan>(`/catalog/${itemId}/adbreaks/assign`, { method: 'POST', body: json(input) });
  }
  fingerprintAd(id: string) {
    return http<AdCreative>(`/ads/${id}/fingerprint`, { method: 'POST', body: json({}) });
  }
  creativeFit(itemId: string) {
    return http<FitReport>(`/catalog/${itemId}/adbreaks/fit`);
  }
  autoAssign(itemId: string, input: { minScore?: number; breakIds?: string[] } = {}) {
    return http<AutoAssignResult>(`/catalog/${itemId}/adbreaks/autoassign`, { method: 'POST', body: json(input) });
  }
  stitch(itemId: string, input: StitchInput = {}) {
    return http<StitchJob>(`/catalog/${itemId}/stitch`, { method: 'POST', body: json(input) });
  }
  getStitch(id: string) {
    return http<StitchJob>(`/stitch/${id}`);
  }
  listStitches(itemId?: string) {
    return http<StitchJob[]>(`/stitch${itemId ? `?itemId=${encodeURIComponent(itemId)}` : ''}`);
  }
  twelvelabsAssets(params: { page?: number; pageLimit?: number } = {}) {
    const qs = new URLSearchParams();
    if (params.page) qs.set('page', String(params.page));
    if (params.pageLimit) qs.set('pageLimit', String(params.pageLimit));
    const q = qs.toString();
    return http<AssetListing>(`/twelvelabs/assets${q ? `?${q}` : ''}`);
  }
  importAssets(items: ImportInput[]) {
    return http<ImportResult>('/catalog/import', { method: 'POST', body: json({ items }) });
  }
  subscribeEvents(cb: (e: StudioEvent) => void) {
    const es = new EventSource('/api/events');
    const handler = (ev: MessageEvent) => {
      try {
        cb(JSON.parse(ev.data) as StudioEvent);
      } catch {
        /* ignore malformed */
      }
    };
    es.onmessage = handler;
    es.addEventListener('job', handler as EventListener);
    es.addEventListener('item', handler as EventListener);
    es.addEventListener('stitch', handler as EventListener);
    return () => es.close();
  }
}

/* ------------------------------------------------------------------ */
/* Static provider (published demo)                                    */
/* ------------------------------------------------------------------ */

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const hash = (str: string) => {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619);
  return h >>> 0;
};
const latency = () => sleep(120 + Math.random() * 220);
const uid = (p: string) => `${p}_${Math.random().toString(36).slice(2, 9)}`;
const now = () => new Date().toISOString();
const clone = <T>(v: T): T => (typeof structuredClone === 'function' ? structuredClone(v) : JSON.parse(JSON.stringify(v)));

const STOP = new Set(
  'the a an and or of to in on at with for from by is are was were be as it its this that these those into over under about after before between during without within he she they them his her their him we you your our i me my'.split(
    ' ',
  ),
);
const tokens = (s: string) =>
  s
    .toLowerCase()
    .split(/[^a-z0-9']+/)
    .filter((t) => t.length > 2 && !STOP.has(t));

function cosine(a: number[], b: number[]): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    dot += a[i]! * b[i]!;
    na += a[i]! * a[i]!;
    nb += b[i]! * b[i]!;
  }
  return na && nb ? dot / Math.sqrt(na * nb) : 0;
}

function stripEmbedding(item: CatalogItem): CatalogItem {
  if (!item.fingerprint?.embedding) return item;
  const { embedding: _e, ...fp } = item.fingerprint;
  return { ...item, fingerprint: fp };
}

export class StaticApi implements Api {
  readonly kind = 'static' as const;
  private seed: DemoBundle | null = null;
  private data: DemoBundle | null = null;
  private runs = new Map<string, CreativeRun>();
  private listeners = new Set<(e: StudioEvent) => void>();
  private loading: Promise<DemoBundle> | null = null;

  private async load(): Promise<DemoBundle> {
    if (this.data) return this.data;
    if (!this.loading) {
      this.loading = (async () => {
        const injected = window.__TWELVE_DEMO__;
        // A full bundle on window wins; a partial object (no catalog) is an overlay on the fetched one.
        let bundle: DemoBundle | undefined = injected && Array.isArray(injected.catalog) ? (injected as DemoBundle) : undefined;
        if (!bundle) {
          // Public demo bundle: next to the page first (single-file builds), then site root.
          const candidates = [new URL('demo-bundle.json', document.baseURI).toString(), '/demo-bundle.json'];
          for (const url of candidates) {
            try {
              const res = await fetch(url);
              if (res.ok) {
                bundle = (await res.json()) as DemoBundle;
                break;
              }
            } catch {
              /* try next */
            }
          }
          if (!bundle) throw new ApiError('no_demo', 'Demo bundle not found (window.__TWELVE_DEMO__ or /demo-bundle.json)');
          if (injected) bundle = { ...bundle, ...(injected as Partial<DemoBundle>), catalog: bundle.catalog };
        }
        this.seed = clone(bundle);
        this.data = clone(bundle);
        this.normalise(this.data);
        return this.data;
      })();
    }
    return this.loading;
  }

  /** Older bundles predate ads/lists/recipes — make every optional collection safe to touch. */
  private normalise(d: DemoBundle) {
    if (!Array.isArray(d.catalog)) d.catalog = [];
    if (!Array.isArray(d.lists)) d.lists = [];
    if (!Array.isArray(d.recipes)) d.recipes = [];
    if (!Array.isArray(d.ads)) d.ads = [];
    if (!Array.isArray(d.twelvelabsAssets)) d.twelvelabsAssets = [];
    for (const b of d.catalog) {
      if (b.item.fingerprint && b.fingerprint) b.item.fingerprint = b.fingerprint;
      if (!b.item.jobs) b.item.jobs = {};
      if (!Array.isArray(b.jobs)) b.jobs = [];
    }
  }

  async resetDemo() {
    await this.load();
    this.data = clone(this.seed!);
    this.normalise(this.data);
    this.runs.clear();
    await latency();
  }

  private emit(e: StudioEvent) {
    for (const l of this.listeners) l(e);
  }

  private async bundle(id: string): Promise<ItemBundle> {
    const d = await this.load();
    const b = d.catalog.find((x) => x.item.id === id);
    if (!b) throw new ApiError('not_found', `No catalog item ${id}`, 404);
    return b;
  }

  async health(): Promise<Health> {
    await sleep(60);
    return {
      ok: true,
      mode: 'static',
      index: 'idx_demo_twelve_studio',
      models: { index: 'marengo3.0', embed: 'marengo3.5', analyze: 'pegasus1.5' },
    };
  }

  async stats(): Promise<CatalogStats> {
    const d = await this.load();
    await latency();
    const items = d.catalog.map((b) => b.item);
    const ready = items.filter((i) => i.status === 'ready').length;
    const totalDurationSec = items.reduce((s, i) => s + (i.durationSec ?? 0), 0);
    const jobKinds: JobKind[] = ['fingerprint', 'emotions', 'markers', 'adbreaks', 'safety', 'thumbnails', 'clips'];
    const covered = items.reduce((s, i) => s + jobKinds.filter((k) => i.jobs[k] === 'ready').length, 0);
    const coverage = items.length ? covered / (items.length * jobKinds.length) : 0;
    const pendingReviews = d.catalog.reduce(
      (s, b) =>
        s +
        (b.markers?.markers.filter((m) => !m.review || m.review.status === 'open').length ?? 0) +
        (b.adBreaks?.breaks.filter((m) => !m.review || m.review.status === 'open').length ?? 0),
      0,
    );
    return { items: items.length, ready, totalDurationSec, lists: d.lists.length, coverage, pendingReviews };
  }

  async catalog() {
    const d = await this.load();
    await latency();
    return d.catalog.map((b) => stripEmbedding(b.item));
  }

  async addItems(input: CatalogItemInput | CatalogItemInput[]) {
    const d = await this.load();
    await latency();
    const inputs = Array.isArray(input) ? input : [input];
    const created: CatalogItem[] = [];
    for (const inp of inputs) {
      const item: CatalogItem = {
        ...inp,
        id: uid('item'),
        type: inp.type ?? 'other',
        createdAt: now(),
        updatedAt: now(),
        status: 'ingesting',
        jobs: { ingest: 'running' },
      };
      d.catalog.push({ item, jobs: [] });
      created.push(item);
      this.simulatePipeline(item.id);
    }
    return created;
  }

  private async simulatePipeline(itemId: string, opts: { skip?: JobKind[] } = {}) {
    const d = await this.load();
    const b = d.catalog.find((x) => x.item.id === itemId);
    if (!b) return;
    const order: JobKind[] = ['ingest', 'fingerprint', 'embedding', 'emotions', 'markers', 'safety', 'adbreaks', 'thumbnails', 'clips'];
    for (const kind of order) {
      if (opts.skip?.includes(kind)) continue;
      const job: Job = { id: uid('job'), itemId, kind, status: 'running', startedAt: now(), upstream: { model: kind === 'ingest' ? 'marengo3.0' : kind === 'embedding' ? 'marengo3.5' : 'pegasus1.5' } };
      b.jobs.push(job);
      b.item.jobs[kind] = 'running';
      b.item.status = kind === 'ingest' ? 'indexing' : 'enriching';
      this.emit({ type: 'job', job: { ...job } });
      this.emit({ type: 'item', item: { ...b.item } });
      await sleep(900 + Math.random() * 900);
      job.status = 'ready';
      job.finishedAt = now();
      b.item.jobs[kind] = 'ready';
      if (kind === 'ingest') {
        b.item.durationSec = b.item.durationSec ?? 1320;
        b.item.fps = b.item.fps ?? 25;
      }
      this.emit({ type: 'job', job: { ...job } });
    }
    b.item.status = 'ready';
    b.item.updatedAt = now();
    this.emit({ type: 'item', item: { ...b.item } });
  }

  async item(id: string) {
    const b = await this.bundle(id);
    await latency();
    const out = clone(b);
    out.item = stripEmbedding(out.item);
    if (out.fingerprint?.embedding) delete out.fingerprint.embedding;
    return out;
  }

  async deleteItem(id: string) {
    const d = await this.load();
    await latency();
    d.catalog = d.catalog.filter((b) => b.item.id !== id);
  }

  async rerunJob(id: string, kind: JobKind) {
    const b = await this.bundle(id);
    await latency();
    const job: Job = {
      id: uid('job'),
      itemId: id,
      kind,
      status: 'running',
      startedAt: now(),
      upstream: { model: kind === 'ingest' ? 'marengo3.0' : kind === 'embedding' ? 'marengo3.5' : 'pegasus1.5' },
    };
    b.jobs.push(job);
    b.item.jobs[kind] = 'running';
    this.emit({ type: 'job', job: { ...job } });
    setTimeout(() => {
      job.status = 'ready';
      job.finishedAt = now();
      b.item.jobs[kind] = 'ready';
      this.emit({ type: 'job', job: { ...job } });
      this.emit({ type: 'item', item: { ...b.item } });
    }, 1600 + Math.random() * 1400);
    return { ...job };
  }

  private async part<K extends keyof ItemBundle>(id: string, key: K): Promise<NonNullable<ItemBundle[K]>> {
    const b = await this.bundle(id);
    await latency();
    const v = b[key];
    if (v == null) throw new ApiError('not_ready', `${String(key)} not generated yet for ${id}`, 404);
    return clone(v) as NonNullable<ItemBundle[K]>;
  }
  fingerprint(id: string) {
    return this.part(id, 'fingerprint');
  }
  emotions(id: string) {
    return this.part(id, 'emotions');
  }
  markers(id: string) {
    return this.part(id, 'markers');
  }
  adbreaks(id: string) {
    return this.part(id, 'adBreaks');
  }
  safety(id: string) {
    return this.part(id, 'safety');
  }
  thumbnails(id: string) {
    return this.part(id, 'thumbnails');
  }
  clips(id: string) {
    return this.part(id, 'clips');
  }

  private applyReview(target: { review?: ReviewState }, patch: Partial<ReviewState>) {
    const prev: ReviewState = target.review ?? { status: 'open', comments: [] };
    const next: ReviewState = { ...prev, ...patch, comments: patch.comments ?? prev.comments };
    if (patch.status && patch.status !== 'open') {
      next.reviewedBy = 'you';
      next.reviewedAt = now();
    }
    target.review = next;
    return next;
  }

  async patchMarker(id: string, mid: string, patch: Partial<ReviewState>) {
    const b = await this.bundle(id);
    await latency();
    const m = b.markers?.markers.find((x) => x.id === mid);
    if (!m) throw new ApiError('not_found', `No marker ${mid}`, 404);
    this.applyReview(m, patch);
    return clone(m);
  }

  async patchAdBreak(id: string, bid: string, patch: Partial<ReviewState>) {
    const b = await this.bundle(id);
    await latency();
    const br = b.adBreaks?.breaks.find((x) => x.id === bid);
    if (!br) throw new ApiError('not_found', `No break ${bid}`, 404);
    this.applyReview(br, patch);
    return clone(br);
  }

  async planAdBreaks(id: string, policy: Partial<AdBreakPlan['policy']>) {
    const b = await this.bundle(id);
    await sleep(400);
    if (!b.adBreaks) throw new ApiError('not_ready', 'No ad-break candidates yet', 404);
    const seedPlan = this.seed?.catalog.find((x) => x.item.id === id)?.adBreaks ?? b.adBreaks;
    const p = { ...b.adBreaks.policy, ...policy };
    const dur = b.item.durationSec ?? Math.max(...seedPlan.breaks.map((x) => x.at)) + 60;
    // Deterministic pod planner: candidates sorted by confidence, greedy with min spacing + edge avoidance.
    const candidates = [...seedPlan.breaks]
      .filter((x) => x.at >= p.avoidFirstSec && x.at <= dur - p.avoidLastSec)
      .sort((a, c) => c.confidence - a.confidence);
    const chosen: AdBreak[] = [];
    for (const c of candidates) {
      if (chosen.length >= p.targetBreaks) break;
      if (chosen.every((x) => Math.abs(x.at - c.at) >= p.minSpacingSec)) chosen.push(clone(c));
    }
    chosen.sort((a, c) => a.at - c.at);
    const ranked = [...chosen].sort((a, c) => c.confidence - a.confidence);
    for (const br of chosen) {
      br.rank = ranked.indexOf(br) + 1;
      const existing = b.adBreaks.breaks.find((x) => x.id === br.id);
      br.review = existing?.review ?? { status: 'open', comments: [] };
    }
    b.adBreaks = { ...b.adBreaks, breaks: chosen, policy: p, generatedAt: now() };
    return clone(b.adBreaks);
  }

  async exportVmap(id: string) {
    const b = await this.bundle(id);
    await latency();
    const approved = (b.adBreaks?.breaks ?? []).filter((x) => x.review?.status === 'approved');
    const tc = (s: number) => {
      const h = Math.floor(s / 3600);
      const m = Math.floor((s % 3600) / 60);
      const sec = (s % 60).toFixed(3);
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${sec.padStart(6, '0')}`;
    };
    const breaks = approved
      .map(
        (x, i) => `  <vmap:AdBreak timeOffset="${tc(x.at)}" breakType="linear" breakId="${x.id}">
    <vmap:AdSource id="pod-${i + 1}" allowMultipleAds="true" followRedirects="true">
      <vmap:AdTagURI templateType="vast3"><![CDATA[https://ads.example.com/vast?item=${id}&break=${x.id}&mood=${encodeURIComponent(
        Object.keys(x.mood)[0] ?? '',
      )}]]></vmap:AdTagURI>
    </vmap:AdSource>
    <vmap:Extensions><vmap:Extension type="twelve-studio"><confidence>${x.confidence.toFixed(2)}</confidence><reason>${x.reason}</reason></vmap:Extension></vmap:Extensions>
  </vmap:AdBreak>`,
      )
      .join('\n');
    return `<?xml version="1.0" encoding="UTF-8"?>\n<vmap:VMAP xmlns:vmap="http://www.iab.net/videosuite/vmap" version="1.0">\n${breaks}\n</vmap:VMAP>\n`;
  }

  async exportScte35(id: string) {
    const b = await this.bundle(id);
    await latency();
    const approved = (b.adBreaks?.breaks ?? []).filter((x) => x.review?.status === 'approved');
    return {
      itemId: id,
      splicePoints: approved.map((x, i) => ({
        id: i + 1,
        breakId: x.id,
        pts: Math.round(x.at * 90000),
        ptsTimeSec: x.at,
        duration: 90000 * 30,
        durationSec: 30,
        spliceEventId: 1000 + i,
        outOfNetwork: true,
      })),
    };
  }

  async exportMarkers(id: string) {
    const b = await this.bundle(id);
    await latency();
    const ms = b.markers?.markers ?? [];
    const find = (k: Marker['kind']) => ms.find((m) => m.kind === k && m.review?.status !== 'declined');
    const intro = find('intro');
    const recap = find('recap');
    const credits = find('credits');
    const hook = find('next_episode_hook');
    return {
      itemId: id,
      fps: b.markers?.fps ?? b.item.fps ?? 25,
      skipIntro: intro ? { start: intro.start, end: intro.end } : null,
      skipRecap: recap ? { start: recap.start, end: recap.end } : null,
      creditsStart: credits?.start ?? null,
      nextEpisodeAt: hook?.start ?? credits?.start ?? null,
      chapters: ms.filter((m) => m.kind === 'chapter').map((m) => ({ title: m.label ?? 'Chapter', start: m.start, end: m.end })),
    };
  }

  async similar(id: string, limit = 8) {
    const d = await this.load();
    const b = await this.bundle(id);
    await latency();
    const out: SimilarTitle[] = [];
    for (const other of d.catalog) {
      if (other.item.id === id || !other.fingerprint || !b.fingerprint) continue;
      const a = b.fingerprint;
      const c = other.fingerprint;
      let score = 0;
      const because: string[] = [];
      if (a.embedding && c.embedding) score = (cosine(a.embedding, c.embedding) + 1) / 2;
      const facets: Array<keyof Pick<Fingerprint, 'genres' | 'moods' | 'themes' | 'keywords' | 'moodTags'>> = [
        'genres',
        'moods',
        'themes',
        'keywords',
        'moodTags',
      ];
      let facetScore = 0;
      for (const f of facets) {
        const shared = Object.keys(a[f]).filter((k) => k in c[f]);
        for (const k of shared) {
          facetScore += Math.min(a[f][k]!, c[f][k]!) / facets.length;
          if (because.length < 6 && !because.includes(k)) because.push(k);
        }
      }
      score = score ? 0.6 * score + 0.4 * Math.min(1, facetScore) : Math.min(1, facetScore);
      out.push({ itemId: other.item.id, title: other.item.title, score: Math.round(score * 100) / 100, because });
    }
    return out.sort((x, y) => y.score - x.score).slice(0, limit);
  }

  async search({ query, limit = 12, modalities }: SearchParams): Promise<SearchResponse> {
    const d = await this.load();
    await sleep(350 + Math.random() * 300);
    const q = tokens(query);
    const hits: SearchHit[] = [];
    const wantsTranscript = !modalities || modalities.includes('transcription') || modalities.includes('audio');
    for (const b of d.catalog) {
      const title = b.item.title;
      const fpText = b.fingerprint
        ? [
            b.fingerprint.synopsis.short,
            b.fingerprint.synopsis.long,
            ...Object.keys(b.fingerprint.keywords),
            ...Object.keys(b.fingerprint.moods),
            ...Object.keys(b.fingerprint.themes),
          ].join(' ')
        : '';
      const fpTokens = new Set(tokens(fpText));
      const titleBoost = q.filter((t) => fpTokens.has(t)).length / Math.max(1, q.length);
      // Emotion beats give us time-localised hits; consecutive samples that share a beat are one moment.
      const samples = b.emotions?.samples ?? [];
      for (let i = 0; i < samples.length; i++) {
        const s = samples[i]!;
        let end = s.end;
        let peak = s.arousal;
        while (i + 1 < samples.length && samples[i + 1]!.beat === s.beat) {
          i++;
          end = samples[i]!.end;
          peak = Math.max(peak, samples[i]!.arousal);
        }
        const beatTokens = new Set([...tokens(s.beat), ...Object.keys(s.emotions)]);
        const m = q.filter((t) => beatTokens.has(t) || [...beatTokens].some((bt) => bt.startsWith(t) || t.startsWith(bt))).length;
        if (m === 0) continue;
        const jitter = ((hash(`${b.item.id}:${s.start}`) % 100) / 100 - 0.5) * 0.06;
        const score = Math.max(0.2, Math.min(0.98, 0.45 + 0.3 * (m / q.length) + 0.1 * titleBoost + 0.12 * peak + jitter));
        hits.push({
          itemId: b.item.id,
          title,
          start: s.start,
          end: Math.min(end, s.start + 30),
          rank: 0,
          score: Math.round(score * 100) / 100,
          transcript: wantsTranscript ? s.beat : undefined,
          modality: 'visual',
        });
      }
      // Clips carry captions + keywords.
      for (const c of b.clips ?? []) {
        const ct = new Set([...tokens(c.caption), ...Object.keys(c.keywords), ...Object.keys(c.mood), ...c.characters.map((x) => x.toLowerCase())]);
        const m = q.filter((t) => ct.has(t)).length;
        if (m === 0) continue;
        hits.push({
          itemId: b.item.id,
          title,
          start: c.start,
          end: c.end,
          rank: 0,
          score: Math.round(Math.min(0.98, 0.4 + 0.35 * (m / q.length) + 0.1 * titleBoost + 0.15 * c.relevance) * 100) / 100,
          transcript: c.caption,
          modality: 'visual',
        });
      }
      if (hits.every((h) => h.itemId !== b.item.id) && titleBoost > 0.3) {
        const dur = b.item.durationSec ?? 600;
        hits.push({ itemId: b.item.id, title, start: dur * 0.3, end: dur * 0.3 + 12, rank: 0, score: 0.4 + 0.3 * titleBoost, transcript: b.fingerprint?.synopsis.short, modality: 'visual' });
      }
    }
    hits.sort((a, c) => (c.score ?? 0) - (a.score ?? 0));
    const page = hits.slice(0, limit).map((h, i) => ({ ...h, rank: i + 1 }));
    return {
      query,
      hits: page,
      nextPageToken: hits.length > limit ? 'static:next' : undefined,
      pool: { items: d.catalog.length, totalDurationSec: d.catalog.reduce((s, b) => s + (b.item.durationSec ?? 0), 0) },
    };
  }

  async lists() {
    const d = await this.load();
    await latency();
    return clone(d.lists);
  }

  private matchRules(fp: Fingerprint | undefined, rules: SmartListRule[]) {
    if (!fp) return false;
    return rules.every((r) => {
      const v = fp[r.facet]?.[r.label];
      return v != null && v >= r.min && v <= r.max;
    });
  }

  private matchQuery(b: ItemBundle, query: string) {
    if (!b.fingerprint) return 0;
    const q = tokens(query);
    const text = new Set(
      tokens(
        [
          b.fingerprint.synopsis.short,
          b.fingerprint.synopsis.long,
          ...Object.keys(b.fingerprint.keywords),
          ...Object.keys(b.fingerprint.moods),
          ...Object.keys(b.fingerprint.moodTags),
          ...Object.keys(b.fingerprint.themes),
          ...Object.keys(b.fingerprint.genres),
        ].join(' '),
      ),
    );
    const m = q.filter((t) => text.has(t) || [...text].some((x) => x.startsWith(t))).length;
    return q.length ? m / q.length : 0;
  }

  async createList(input: ListInput) {
    const d = await this.load();
    await sleep(input.source === 'query' ? 700 : 250);
    let itemIds: string[] = [];
    if (input.source === 'rules' && input.rules) {
      itemIds = d.catalog.filter((b) => this.matchRules(b.fingerprint, input.rules!)).map((b) => b.item.id);
    } else if (input.query) {
      itemIds = d.catalog
        .map((b) => ({ id: b.item.id, s: this.matchQuery(b, input.query!) }))
        .filter((x) => x.s > 0)
        .sort((a, c) => c.s - a.s)
        .map((x) => x.id);
    }
    const list: SmartList = {
      id: uid('list'),
      name: input.name,
      source: input.source,
      rules: input.rules,
      query: input.query,
      itemIds,
      coverage: d.catalog.length ? itemIds.length / d.catalog.length : 0,
      createdAt: now(),
      updatedAt: now(),
    };
    d.lists.push(list);
    return clone(list);
  }

  async curate() {
    const d = await this.load();
    await sleep(1400);
    // Cluster by dominant mood + genre (stand-in for k-means over Marengo embeddings).
    const groups = new Map<string, { ids: string[]; labels: Record<string, number> }>();
    for (const b of d.catalog) {
      const fp = b.fingerprint;
      if (!fp) continue;
      const mood = Object.entries(fp.moods).sort((a, c) => c[1] - a[1])[0]?.[0] ?? 'general';
      const g = groups.get(mood) ?? { ids: [], labels: {} };
      g.ids.push(b.item.id);
      for (const [k, v] of [...Object.entries(fp.keywords), ...Object.entries(fp.genres)]) g.labels[k] = (g.labels[k] ?? 0) + v;
      groups.set(mood, g);
    }
    const created: SmartList[] = [];
    for (const [mood, g] of groups) {
      const top = Object.entries(g.labels)
        .sort((a, c) => c[1] - a[1])
        .slice(0, 3)
        .map(([k]) => k);
      const name = `${mood.charAt(0).toUpperCase() + mood.slice(1)} · ${top.slice(0, 2).join(' & ')}`;
      const list: SmartList = {
        id: uid('list'),
        name,
        description: `Cluster of ${g.ids.length} title${g.ids.length === 1 ? '' : 's'} sharing a ${mood} mood and ${top.join(', ')}.`,
        source: 'ai',
        itemIds: g.ids,
        coverage: d.catalog.length ? g.ids.length / d.catalog.length : 0,
        createdAt: now(),
        updatedAt: now(),
      };
      d.lists = d.lists.filter((l) => !(l.source === 'ai' && l.name === name));
      d.lists.push(list);
      created.push(list);
    }
    return clone(created);
  }

  async deleteList(id: string) {
    const d = await this.load();
    await latency();
    d.lists = d.lists.filter((l) => l.id !== id);
  }

  async recipes() {
    const d = await this.load();
    await latency();
    return clone(d.recipes ?? []);
  }

  async createRecipe(input: RecipeInput) {
    const d = await this.load();
    await latency();
    const r: Recipe = { ...input, id: uid('recipe'), createdAt: now() };
    d.recipes = [...(d.recipes ?? []), r];
    return clone(r);
  }

  async deleteRecipe(id: string) {
    const d = await this.load();
    await latency();
    d.recipes = (d.recipes ?? []).filter((r) => r.id !== id);
  }

  async runRecipe(id: string, itemIds: string[]) {
    const d = await this.load();
    const recipe = (d.recipes ?? []).find((r) => r.id === id);
    if (!recipe) throw new ApiError('not_found', `No recipe ${id}`, 404);
    await latency();
    const out: CreativeRun[] = [];
    const q = tokens(recipe.brief);
    for (const itemId of itemIds) {
      const b = d.catalog.find((x) => x.item.id === itemId);
      if (!b) continue;
      const run: CreativeRun = { id: uid('run'), recipeId: id, itemId, status: 'running', createdAt: now() };
      this.runs.set(run.id, run);
      out.push(run);
      const job: Job = { id: uid('job'), itemId, kind: recipe.target, status: 'running', startedAt: now(), upstream: { model: 'pegasus1.5' } };
      this.emit({ type: 'job', job });
      setTimeout(() => {
        const rel = (text: string[], moods: Record<string, number>) => {
          const t = new Set([...tokens(text.join(' ')), ...Object.keys(moods)]);
          const m = q.filter((x) => t.has(x) || [...t].some((y) => y.startsWith(x))).length;
          return q.length ? m / q.length : 0.5;
        };
        const excluded = new Set(recipe.excludeSafetyCategories ?? []);
        const unsafeSpans = (b.safety?.segments ?? []).filter((s) => excluded.has(s.category));
        const isSafe = (start: number, end: number) => !unsafeSpans.some((s) => s.start < end && s.end > start);
        const needChars = recipe.requireCharacters ?? [];
        if (recipe.target === 'thumbnails') {
          const src = b.thumbnails ?? [];
          run.thumbnails = src
            .filter((t) => needChars.every((c) => t.characters.some((x) => x.toLowerCase().includes(c.toLowerCase()))))
            .map((t) => {
              const r = rel([t.caption, ...t.characters], t.mood);
              const score = Math.min(0.99, 0.55 * t.score + 0.45 * (0.4 + 0.6 * r));
              return { ...clone(t), id: uid('thumb'), score, factors: { ...t.factors, relevance: Math.min(0.99, 0.3 + 0.7 * r) }, safe: t.safe && isSafe(t.at - 2, t.at + 2) };
            })
            .sort((a, c) => c.score - a.score)
            .slice(0, recipe.count);
        } else {
          const src = b.clips ?? [];
          const [minL, maxL] = recipe.clipLengthSec ?? [4, 60];
          run.clips = src
            .filter((c) => needChars.every((n) => c.characters.some((x) => x.toLowerCase().includes(n.toLowerCase()))))
            .map((c) => {
              const r = rel([c.caption, c.clipType, ...c.characters, ...Object.keys(c.keywords)], c.mood);
              let { start, end } = c;
              if (end - start > maxL) end = start + maxL;
              if (end - start < minL) end = Math.min(start + minL, (b.item.durationSec ?? end) - 0.1);
              return { ...clone(c), id: uid('clip'), start, end, query: recipe.brief, queryRelevance: Math.min(0.99, 0.2 + 0.5 * r + 0.3 * c.relevance), safe: c.safe && isSafe(start, end) };
            })
            .sort((a, c) => (c.queryRelevance ?? 0) * c.relevance - (a.queryRelevance ?? 0) * a.relevance)
            .slice(0, recipe.count);
        }
        run.status = 'ready';
        this.emit({ type: 'job', job: { ...job, status: 'ready', finishedAt: now() } });
      }, 1200 + Math.random() * 900);
    }
    return clone(out);
  }

  async run(id: string) {
    await sleep(120);
    const r = this.runs.get(id);
    if (!r) throw new ApiError('not_found', `No run ${id}`, 404);
    return clone(r);
  }

  async jobs(status?: JobStatus) {
    const d = await this.load();
    await latency();
    const all = d.catalog.flatMap((b) => b.jobs);
    return clone(status ? all.filter((j) => j.status === status) : all);
  }

  /* --- ad creatives (in memory) ----------------------------------- */

  async listAds() {
    const d = await this.load();
    await latency();
    return clone(d.ads ?? []);
  }

  /** Read duration/dimensions from the browser's own decoder when the URL is reachable; else assume a 30s spot. */
  private probe(url: string): Promise<{ durationSec: number; width?: number; height?: number }> {
    return new Promise((resolve) => {
      const fallback = { durationSec: 30 };
      if (typeof document === 'undefined') return resolve(fallback);
      const v = document.createElement('video');
      v.muted = true;
      v.preload = 'metadata';
      let done = false;
      const finish = (r: { durationSec: number; width?: number; height?: number }) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        v.removeAttribute('src');
        v.load();
        resolve(r);
      };
      const timer = setTimeout(() => finish(fallback), 4000);
      v.onloadedmetadata = () => finish({ durationSec: isFinite(v.duration) && v.duration > 0 ? Math.round(v.duration * 100) / 100 : 30, width: v.videoWidth || undefined, height: v.videoHeight || undefined });
      v.onerror = () => finish(fallback);
      v.src = url;
    });
  }

  async addAd(input: AdInput) {
    const d = await this.load();
    await latency();
    const name = input.name?.trim();
    if (!name) throw new ApiError('bad_request', 'A creative needs a name', 400);
    if (input.localPath && !input.sourceUrl) throw new ApiError('needs_api', 'Local files need the local API — the static demo can only reference creatives by URL', 400);
    if (!input.sourceUrl) throw new ApiError('bad_request', 'Provide a public URL for the creative', 400);
    const probed = await this.probe(input.sourceUrl);
    const ad: AdCreative = {
      id: uid('ad'),
      name,
      advertiser: input.advertiser?.trim() || undefined,
      sourceUrl: input.sourceUrl,
      mediaUrl: input.sourceUrl,
      ...probed,
      createdAt: now(),
    };
    d.ads = [...(d.ads ?? []), ad];
    return clone(ad);
  }

  async deleteAd(id: string) {
    const d = await this.load();
    await latency();
    if (!(d.ads ?? []).some((a) => a.id === id)) throw new ApiError('not_found', `No creative ${id}`, 404);
    d.ads = (d.ads ?? []).filter((a) => a.id !== id);
    // Assignments pointing at a deleted creative are cleared, like the API does.
    for (const b of d.catalog) for (const br of b.adBreaks?.breaks ?? []) if (br.creativeId === id) delete br.creativeId;
  }

  async assignCreative(itemId: string, input: AssignInput) {
    const d = await this.load();
    const b = await this.bundle(itemId);
    await latency();
    if (!b.adBreaks) throw new ApiError('not_ready', 'No ad-break plan yet', 404);
    if (input.creativeId && !(d.ads ?? []).some((a) => a.id === input.creativeId)) throw new ApiError('not_found', `No creative ${input.creativeId}`, 404);
    const ids = input.breakIds ? new Set(input.breakIds) : null;
    for (const br of b.adBreaks.breaks) {
      if (ids && !ids.has(br.id)) continue;
      if (input.creativeId) br.creativeId = input.creativeId;
      else delete br.creativeId;
    }
    return clone(b.adBreaks);
  }

  async fingerprintAd(id: string) {
    const d = await this.load();
    const ad = (d.ads ?? []).find((a) => a.id === id);
    if (!ad) throw new ApiError('not_found', `No creative ${id}`, 404);
    await sleep(900);
    if (ad.fingerprint) return clone(ad);
    // The static demo cannot call Pegasus: synthesise a labelled placeholder from the name so the fit flow can be tried.
    const words = ad.name.toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 2);
    const fingerprint: AdFingerprint = {
      brand: ad.advertiser ?? (words[0] ? words[0][0]!.toUpperCase() + words[0].slice(1) : ad.name),
      product: ad.name,
      synopsis: `(demo) ${ad.name} — run the local API for a real Pegasus fingerprint.`,
      mood: { upbeat: 0.7, warm: 0.6, playful: 0.5 },
      keywords: Object.fromEntries(words.slice(0, 6).map((w) => [w, 0.8])),
      tone: { humorous: 0.4, emotional: 0.4, energetic: 0.6, premium: 0.4, family: 0.6 },
      iab: [{ id: 'IAB22', name: 'Shopping', tier: 1, confidence: 0.5 }],
      sensitivities: [],
      familySafe: 0.85,
      pacing: { score: 0.6, rationale: '(demo) typical 30s cut rate' },
      moments: [{ at: 1, label: 'open' }, { at: Math.min(12, ad.durationSec / 2), label: 'product' }, { at: Math.max(0, ad.durationSec - 3), label: 'end card' }],
      language: { primary: 'en', others: [] },
      model: 'pegasus1.5 (demo)',
      generatedAt: now(),
    };
    ad.fingerprint = fingerprint;
    return clone(ad);
  }

  async creativeFit(itemId: string): Promise<FitReport> {
    const d = await this.load();
    const b = await this.bundle(itemId);
    await latency();
    if (!b.adBreaks) throw new ApiError('not_ready', 'No ad-break plan yet', 404);
    const creatives = d.ads ?? [];
    return clone({
      itemId,
      creatives: creatives.map((c) => ({ id: c.id, name: c.name, fingerprinted: !!c.fingerprint })),
      breaks: b.adBreaks.breaks.map((brk) => ({ breakId: brk.id, at: brk.at, rank: brk.rank, assigned: brk.creativeId, fits: rankCreatives(brk, creatives) })),
    });
  }

  async autoAssign(itemId: string, input: { minScore?: number; breakIds?: string[] } = {}): Promise<AutoAssignResult> {
    const d = await this.load();
    const b = await this.bundle(itemId);
    await sleep(300);
    if (!b.adBreaks) throw new ApiError('not_ready', 'No ad-break plan yet', 404);
    const creatives = d.ads ?? [];
    if (!creatives.some((c) => c.fingerprint)) throw new ApiError('no_fingerprints', 'No creative has a fingerprint yet', 409);
    const ids = input.breakIds ? new Set(input.breakIds) : null;
    const picks = pickByFit(b.adBreaks.breaks.filter((x) => !ids || ids.has(x.id)), creatives, input.minScore ?? 0);
    for (const pick of picks) {
      const brk = b.adBreaks.breaks.find((x) => x.id === pick.breakId);
      if (brk && pick.creativeId) brk.creativeId = pick.creativeId;
    }
    return clone({ plan: b.adBreaks, assignments: picks });
  }

  async stitch(itemId: string, _input: StitchInput = {}): Promise<StitchJob> {
    await this.bundle(itemId);
    await latency();
    throw new ApiError('stitch_unavailable', 'Rendering needs the local API (ffmpeg)', 501);
  }

  async getStitch(id: string): Promise<StitchJob> {
    await sleep(60);
    throw new ApiError('not_found', `No stitch job ${id}`, 404);
  }

  async listStitches(_itemId?: string): Promise<StitchJob[]> {
    await sleep(60);
    return [];
  }

  /* --- TwelveLabs account (from the captured listing in the bundle) --- */

  private linkFor(d: DemoBundle, assetId: string): AssetLink | undefined {
    const b = d.catalog.find((x) => x.item.upstream?.assetId === assetId);
    if (b) return { kind: 'title', id: b.item.id, title: b.item.title };
    const ad = (d.ads ?? []).find((a) => a.upstream?.assetId === assetId);
    if (ad) return { kind: 'ad', id: ad.id, title: ad.name };
    return undefined;
  }

  async twelvelabsAssets(params: { page?: number; pageLimit?: number } = {}): Promise<AssetListing> {
    const d = await this.load();
    await latency();
    const all = [...(d.twelvelabsAssets ?? [])].sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at));
    const page = Math.max(1, params.page ?? 1);
    const limit = Math.max(1, params.pageLimit ?? 50);
    const assets: LinkedAsset[] = all.slice((page - 1) * limit, page * limit).map((a) => {
      const linked = this.linkFor(d, a._id);
      return linked ? { ...clone(a), linked } : clone(a);
    });
    return { assets, pageInfo: { page, limitPerPage: limit, totalPage: Math.max(1, Math.ceil(all.length / limit)), totalResults: all.length } };
  }

  async importAssets(inputs: ImportInput[]): Promise<ImportResult> {
    const d = await this.load();
    await sleep(500 + Math.random() * 300);
    const byId = new Map((d.twelvelabsAssets ?? []).map((a) => [a._id, a]));
    const out: ImportResult = { items: [], ads: [], skipped: [], errors: [] };
    const seen = new Set<string>();
    for (const input of inputs) {
      if (seen.has(input.assetId)) continue;
      seen.add(input.assetId);
      const asset = byId.get(input.assetId);
      if (!asset) {
        out.errors.push({ assetId: input.assetId, error: { code: 'asset_not_found', message: `Asset ${input.assetId} is not in this TwelveLabs account` } });
        continue;
      }
      const linked = this.linkFor(d, asset._id);
      if (linked) {
        out.skipped.push({ assetId: asset._id, linked });
        continue;
      }
      if (asset.status !== 'ready') {
        out.errors.push({ assetId: asset._id, error: { code: 'asset_not_ready', message: `${asset.filename} is still ${asset.status} on TwelveLabs — import it once it is ready` } });
        continue;
      }
      const manifest = asset.hls?.manifest_url;
      const name = input.title?.trim() || asset.filename.replace(/\.[a-z0-9]{2,4}$/i, '').replace(/[-_]+/g, ' ').trim() || asset._id;
      if (input.as === 'ad') {
        const ad: AdCreative = {
          id: uid('ad'),
          name,
          advertiser: input.advertiser?.trim() || undefined,
          durationSec: asset.duration ?? 30,
          sourceUrl: manifest ?? `twelvelabs://asset/${asset._id}`,
          mediaUrl: manifest ?? `twelvelabs://asset/${asset._id}`,
          width: asset.width ?? undefined,
          height: asset.height ?? undefined,
          upstream: { assetId: asset._id },
          createdAt: now(),
        };
        d.ads = [...(d.ads ?? []), ad];
        out.ads.push(clone(ad));
        continue;
      }
      const item: CatalogItem = {
        id: uid('item'),
        title: name,
        type: input.type ?? 'other',
        sourceUrl: manifest ?? `twelvelabs://asset/${asset._id}`,
        posterUrl: asset.thumbnail?.representative_url,
        durationSec: asset.duration ?? undefined,
        fps: asset.fps ?? undefined,
        width: asset.width ?? undefined,
        height: asset.height ?? undefined,
        playback: manifest ? { hlsUrl: manifest, thumbnailUrls: asset.thumbnail ? [asset.thumbnail.representative_url] : undefined } : undefined,
        upstream: { assetId: asset._id },
        externalIds: { twelvelabsAsset: asset._id },
        metadata: { filename: asset.filename, uploadedAt: asset.created_at, uploadMethod: asset.method, sizeBytes: asset.size },
        createdAt: now(),
        updatedAt: now(),
        // The asset is already uploaded and streamable: the demo shows it enriching, never re-ingesting.
        status: 'enriching',
        jobs: { ingest: 'ready' },
      };
      d.catalog.push({ item, jobs: [] });
      out.items.push(clone(item));
      this.simulatePipeline(item.id, { skip: ['ingest'] });
    }
    return out;
  }

  subscribeEvents(cb: (e: StudioEvent) => void) {
    this.listeners.add(cb);
    return () => {
      this.listeners.delete(cb);
    };
  }
}

/* ------------------------------------------------------------------ */
/* Provider selection                                                  */
/* ------------------------------------------------------------------ */

export function isStaticMode(): boolean {
  return import.meta.env.VITE_STATIC_DEMO === '1' || typeof window !== 'undefined' && !!window.__TWELVE_DEMO__;
}

let instance: Api | null = null;
export function getApi(): Api {
  if (!instance) instance = isStaticMode() ? new StaticApi() : new HttpApi();
  return instance;
}
