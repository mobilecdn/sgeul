#!/usr/bin/env node
/**
 * Twelve Studio MCP server (stdio).
 *
 * Exposes the media-intelligence primitives of Twelve Studio — a catalog
 * enriched by TwelveLabs Marengo (search / embeddings) and Pegasus (structured
 * video analysis) — to any MCP client: Claude Desktop, Claude Code, Cursor,
 * custom agents. Every tool talks to the REST API (apps/api) so the web app,
 * the API and agents share one store and one review state.
 *
 *   TWELVE_API_URL=http://localhost:8787 node dist/server.js
 */

import { McpServer, ResourceTemplate } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { createRequire } from 'node:module';
import { z } from 'zod';
import type {
  AdBreak,
  AdBreakPlan,
  AdCreative,
  CreativeFit,
  CatalogItem,
  CreativeRun,
  EmotionArc,
  Fingerprint,
  ItemBundle,
  Job,
  MarkerSet,
  Recipe,
  ReviewState,
  SafetyReport,
  SearchResponse,
  SimilarTitle,
  SmartList,
  SmartListRule,
  StitchJob,
  TwelveLabsAsset,
} from '@twelve-studio/core';
import { ApiClient } from './api.js';
import { guard, hms, labelNames, ok, sleep, tidy, topLabels } from './format.js';

const require = createRequire(import.meta.url);
const pkg = require('../package.json') as { version: string };

const api = new ApiClient({ baseUrl: process.env.TWELVE_API_URL ?? 'http://localhost:8787', auth: process.env.TWELVE_API_AUTH });

const server = new McpServer(
  { name: 'twelve-studio', version: pkg.version },
  {
    instructions: [
      'Twelve Studio turns a video catalog into media-operations data using TwelveLabs models.',
      'All times are seconds from the start of the asset unless a field is named *Frame. Confidences are probabilities 0..1.',
      'Typical flows: catalog_list → catalog_get(id) for a summary; search_moments(query) to find clips across the catalog;',
      'adbreaks_plan(itemId, policy) then adbreaks_review(...) then export_vmap(itemId) for ad ops;',
      'twelvelabs_assets_list shows what is already uploaded to the TwelveLabs account and catalog_import(assetIds, as) links those assets as titles (indexed in place, no re-upload) or ad creatives;',
      'ads_add / ads_list for ad creatives, ads_fingerprint(creativeId) for creative intelligence, adbreaks_fit(itemId) to see which spot suits each break and adbreaks_autoassign(itemId) or adbreaks_assign_creative(itemId, creativeId) to fill breaks, then stitch_preview(itemId) to render an MP4 with the ads burned in at keyframe-snapped break points (needs the title ingested from a local file and ffmpeg on the API host);',
      'thumbnails_generate / clips_generate with a free-text creative brief for marketing;',
      'smartlist_create or curate_catalog for editorial rails. Use jobs_status to wait for enrichment after catalog_ingest.',
    ].join(' '),
  },
);

/* ------------------------------------------------------------------ */
/* Summaries                                                           */
/* ------------------------------------------------------------------ */

function itemSummary(item: CatalogItem) {
  const fp = item.fingerprint;
  return {
    id: item.id,
    title: item.title,
    type: item.type,
    year: item.year,
    duration: hms(item.durationSec),
    durationSec: item.durationSec,
    fps: item.fps,
    status: item.status,
    jobs: item.jobs,
    genres: labelNames(fp?.genres, 4),
    moods: labelNames(fp?.moods, 4),
    synopsis: fp?.synopsis.short,
    rating: fp?.audienceRating.suggested,
  };
}

function fingerprintSummary(fp: Fingerprint) {
  const { embedding: _e, ...rest } = fp;
  return rest;
}

function breakSummary(b: AdBreak) {
  return {
    id: b.id,
    rank: b.rank,
    at: b.at,
    timecode: hms(b.at),
    window: b.window,
    confidence: b.confidence,
    reason: b.reason,
    sceneBefore: b.sceneBefore,
    sceneAfter: b.sceneAfter,
    mood: topLabels(b.mood, 4),
    keywords: topLabels(b.keywords, 4),
    iab: b.iab.slice(0, 3),
    brandSafety: b.brandSafety,
    creativeId: b.creativeId,
    snappedAt: b.snappedAt,
    review: b.review ? { status: b.review.status, rating: b.review.rating, comments: b.review.comments.length } : undefined,
  };
}

function creativeSummary(c: AdCreative) {
  return {
    id: c.id,
    name: c.name,
    advertiser: c.advertiser,
    durationSec: c.durationSec,
    duration: hms(c.durationSec),
    dimensions: c.width && c.height ? `${c.width}x${c.height}` : undefined,
    source: c.localPath ? `local: ${c.localPath}` : c.sourceUrl,
    mediaUrl: c.mediaUrl,
    fingerprint: c.fingerprint
      ? {
          brand: c.fingerprint.brand,
          product: c.fingerprint.product,
          tagline: c.fingerprint.tagline,
          mood: topLabels(c.fingerprint.mood, 4),
          keywords: topLabels(c.fingerprint.keywords, 6),
          tone: c.fingerprint.tone,
          iab: c.fingerprint.iab.map((i) => `${i.name} (${i.id}, ${i.confidence})`),
          familySafe: c.fingerprint.familySafe,
          sensitivities: c.fingerprint.sensitivities.map((x) => `${x.category} ${x.severity} (${x.confidence})`),
          moments: c.fingerprint.moments,
        }
      : undefined,
  };
}

function fitSummary(f: CreativeFit) {
  return { creativeId: f.creativeId, score: f.score, mood: f.mood, keywords: f.keywords, iab: f.iab, safety: f.safety, because: f.because };
}

function stitchSummary(j: StitchJob) {
  return {
    id: j.id,
    itemId: j.itemId,
    creativeId: j.creativeId,
    status: j.status,
    insertions: j.insertions.map((i) => ({ ...i, requested: hms(i.requestedAt), snapped: hms(i.snappedAt) })),
    outputUrl: j.outputUrl ? `${api.baseUrl}${j.outputUrl}` : undefined,
    durationSec: j.durationSec,
    error: j.error,
    log: j.status === 'failed' ? j.log : undefined,
    createdAt: j.createdAt,
    finishedAt: j.finishedAt,
  };
}

function downsample<T>(arr: T[], max: number): T[] {
  if (arr.length <= max) return arr;
  const step = arr.length / max;
  return Array.from({ length: max }, (_, i) => arr[Math.floor(i * step)]!);
}

const sectionEnum = z.enum(['fingerprint', 'emotions', 'markers', 'adBreaks', 'safety', 'thumbnails', 'clips']);

/* ------------------------------------------------------------------ */
/* Tools: catalog                                                      */
/* ------------------------------------------------------------------ */

server.registerTool(
  'catalog_list',
  {
    title: 'List catalog',
    description:
      'List every title in the catalog with enrichment status and a one-line fingerprint (top genres, moods, short synopsis, suggested rating). Use it first to discover item ids. Returns no embeddings or timelines; call catalog_get for detail.',
    inputSchema: {
      status: z.enum(['ingesting', 'indexing', 'enriching', 'ready', 'failed']).optional().describe('Only items in this status'),
      query: z.string().optional().describe('Case-insensitive filter on title'),
    },
  },
  async ({ status, query }) =>
    guard(async () => {
      let items = await api.get<CatalogItem[]>('/catalog');
      if (status) items = items.filter((i) => i.status === status);
      if (query) items = items.filter((i) => i.title.toLowerCase().includes(query.toLowerCase()));
      const rows = items.map(itemSummary);
      return ok(`${rows.length} title(s): ${rows.map((r) => `${r.title} [${r.id}, ${r.status}]`).join('; ')}`, rows);
    }),
);

server.registerTool(
  'catalog_ingest',
  {
    title: 'Ingest videos',
    description:
      'Add one or more videos to the catalog by URL (mp4/mov/HLS or YouTube) or by absolute local path on the API host (needed for stitch_preview) and start the TwelveLabs enrichment pipeline (index → fingerprint → embedding → emotions → markers → safety → ad breaks → thumbnails → clips). Returns immediately with the new item ids; poll jobs_status until status is ready (mock mode: ~10s, live: minutes).',
    inputSchema: {
      urls: z.array(z.string().min(1)).min(1).max(20).describe('Publicly reachable video URLs, or absolute local paths / file:// URLs of files on the API host'),
      titles: z.array(z.string()).optional().describe('Optional titles, same order as urls'),
      type: z.enum(['movie', 'episode', 'short', 'clip', 'promo', 'other']).optional(),
    },
  },
  async ({ urls, titles, type }) =>
    guard(async () => {
      const body = urls.map((sourceUrl, i) => ({ sourceUrl, title: titles?.[i] ?? sourceUrl.split('/').pop() ?? 'Untitled', type }));
      const items = await api.post<CatalogItem[]>('/catalog', body);
      return ok(`Queued ${items.length} item(s): ${items.map((i) => `${i.title} → ${i.id}`).join(', ')}. Poll jobs_status.`, items.map(itemSummary));
    }),
);

type LinkedAsset = TwelveLabsAsset & { linked?: { kind: 'title' | 'ad'; id: string; title: string } };

function assetSummary(a: LinkedAsset) {
  return {
    assetId: a._id,
    filename: a.filename,
    status: a.status,
    method: a.method,
    duration: a.duration != null ? hms(a.duration) : undefined,
    durationSec: a.duration ?? undefined,
    dimensions: a.width && a.height ? `${a.width}x${a.height}` : undefined,
    fps: a.fps ?? undefined,
    sizeMB: a.size ? Math.round((a.size / 1024 / 1024) * 10) / 10 : undefined,
    uploadedAt: a.created_at,
    hlsUrl: a.hls?.manifest_url,
    thumbnailUrl: a.thumbnail?.representative_url,
    linked: a.linked,
  };
}

server.registerTool(
  'twelvelabs_assets_list',
  {
    title: 'List TwelveLabs account assets',
    description:
      'Everything already uploaded to the connected TwelveLabs account (GET /v1.3/assets): asset id, filename, status (ready/processing/failed), duration, dimensions, size, HLS manifest, thumbnail, and whether it is linked to a catalog title or an ad creative in this workspace. Use it before catalog_import to avoid re-uploading media that is already there.',
    inputSchema: {
      page: z.number().int().min(1).optional(),
      pageLimit: z.number().int().min(1).max(100).optional(),
      onlyUnlinked: z.boolean().optional().describe('Only assets not yet linked to a title or creative'),
    },
  },
  async ({ page, pageLimit, onlyUnlinked }) =>
    guard(async () => {
      const r = await api.get<{ assets: LinkedAsset[]; pageInfo: { page: number; totalPage: number; totalResults: number } }>('/twelvelabs/assets', { page, pageLimit: pageLimit ?? 50 });
      const rows = onlyUnlinked ? r.assets.filter((a) => !a.linked) : r.assets;
      const linked = r.assets.filter((a) => a.linked).length;
      return ok(
        `${r.pageInfo.totalResults} asset(s) in the account (page ${r.pageInfo.page}/${r.pageInfo.totalPage}); ${linked} linked here. ${rows.map((a) => `${a.filename} [${a._id}, ${a.status}${a.linked ? `, → ${a.linked.kind} ${a.linked.title}` : ''}]`).join('; ')}`,
        { assets: rows.map(assetSummary), pageInfo: r.pageInfo },
      );
    }),
);

server.registerTool(
  'catalog_import',
  {
    title: 'Import TwelveLabs assets',
    description:
      'Link assets that already exist in the TwelveLabs account (ids from twelvelabs_assets_list) into the workspace. as="title" creates catalog titles with HLS playback and starts enrichment — the ingest job indexes the existing asset without re-uploading; as="ad" creates ad creatives streaming from the asset. Assets already linked are skipped and assets still processing are reported per item (never a batch failure). Poll jobs_status for imported titles.',
    inputSchema: {
      assetIds: z.array(z.string().min(1)).min(1).max(50).describe('TwelveLabs asset ids'),
      as: z.enum(['title', 'ad']).describe('Import as catalog titles or as ad creatives'),
      titles: z.array(z.string()).optional().describe('Optional names, same order as assetIds (default: filename without extension)'),
      type: z.enum(['movie', 'episode', 'short', 'clip', 'promo', 'other']).optional().describe('Item type for titles'),
      advertiser: z.string().optional().describe('Advertiser for ad creatives'),
    },
  },
  async ({ assetIds, as, titles, type, advertiser }) =>
    guard(async () => {
      const items = assetIds.map((assetId, i) => ({ assetId, as, title: titles?.[i], type: as === 'title' ? type : undefined, advertiser: as === 'ad' ? advertiser : undefined }));
      const r = await api.post<{ items: CatalogItem[]; ads: AdCreative[]; skipped: Array<{ assetId: string; linked: { kind: string; id: string; title: string } }>; errors: Array<{ assetId: string; error: { code: string; message: string } }> }>('/catalog/import', { items });
      const parts = [
        r.items.length ? `${r.items.length} title(s): ${r.items.map((i) => `${i.title} → ${i.id}`).join(', ')} (enriching; poll jobs_status)` : '',
        r.ads.length ? `${r.ads.length} creative(s): ${r.ads.map((a) => `${a.name} → ${a.id}`).join(', ')}` : '',
        r.skipped.length ? `${r.skipped.length} skipped (already linked: ${r.skipped.map((s) => `${s.assetId} → ${s.linked.kind} ${s.linked.title}`).join(', ')})` : '',
        r.errors.length ? `${r.errors.length} error(s): ${r.errors.map((e) => `${e.assetId}: ${e.error.message}`).join('; ')}` : '',
      ].filter(Boolean);
      return ok(parts.join('. ') || 'Nothing imported', { items: r.items.map(itemSummary), ads: r.ads.map(creativeSummary), skipped: r.skipped, errors: r.errors });
    }),
);

server.registerTool(
  'catalog_get',
  {
    title: 'Get title',
    description:
      'Get one title. By default returns a compact summary (item, fingerprint without embedding, marker list, planned ad breaks, safety rollup, counts). Pass `sections` to include full sections: fingerprint, emotions (full arc), markers, adBreaks, safety, thumbnails, clips.',
    inputSchema: {
      itemId: z.string().describe('Catalog item id (from catalog_list)'),
      sections: z.array(sectionEnum).optional().describe('Full sections to include verbatim'),
    },
  },
  async ({ itemId, sections }) =>
    guard(async () => {
      const b = await api.get<ItemBundle>(`/catalog/${encodeURIComponent(itemId)}`);
      const summary: Record<string, unknown> = {
        item: itemSummary(b.item),
        fingerprint: b.fingerprint ? fingerprintSummary(b.fingerprint) : undefined,
        acts: b.emotions?.acts,
        climax: b.emotions?.climax,
        markers: b.markers?.markers.map((m) => ({ kind: m.kind, start: m.start, end: m.end, label: m.label, confidence: m.confidence, review: m.review?.status })),
        adBreaks: b.adBreaks?.breaks.map(breakSummary),
        adBreakPolicy: b.adBreaks?.policy,
        safetySummary: b.safety?.summary,
        counts: { emotionSamples: b.emotions?.samples.length ?? 0, safetySegments: b.safety?.segments.length ?? 0, thumbnails: b.thumbnails?.length ?? 0, clips: b.clips?.length ?? 0 },
        playback: b.item.playback,
      };
      for (const s of sections ?? []) summary[s] = s === 'fingerprint' && b.fingerprint ? fingerprintSummary(b.fingerprint) : b[s];
      return ok(`${b.item.title} (${hms(b.item.durationSec)}, ${b.item.status}); ${b.markers?.markers.length ?? 0} markers, ${b.adBreaks?.breaks.length ?? 0} breaks, ${b.safety?.segments.length ?? 0} safety segments`, summary);
    }),
);

server.registerTool(
  'jobs_status',
  {
    title: 'Job status',
    description: 'Enrichment job status for the whole catalog or one item. Optionally wait (poll) until the item is ready or failed, up to `waitSec`.',
    inputSchema: {
      itemId: z.string().optional(),
      waitSec: z.number().int().min(0).max(600).optional().describe('Poll until ready/failed, at most this many seconds'),
    },
  },
  async ({ itemId, waitSec }) =>
    guard(async () => {
      const deadline = Date.now() + (waitSec ?? 0) * 1000;
      for (;;) {
        const jobs = await api.get<Job[]>('/jobs', itemId ? { itemId } : undefined);
        const pending = jobs.filter((j) => j.status === 'queued' || j.status === 'running');
        if (!itemId || pending.length === 0 || Date.now() > deadline) {
          const item = itemId ? await api.get<ItemBundle>(`/catalog/${encodeURIComponent(itemId)}`).then((b) => b.item) : undefined;
          return ok(
            itemId ? `${item?.title}: ${item?.status}; ${pending.length} job(s) still running` : `${jobs.length} job(s), ${pending.length} running`,
            { item: item ? itemSummary(item) : undefined, jobs: jobs.map((j) => ({ id: j.id, itemId: j.itemId, kind: j.kind, status: j.status, error: j.error, model: j.upstream?.model })) },
          );
        }
        await sleep(2000);
      }
    }),
);

/* ------------------------------------------------------------------ */
/* Tools: discovery                                                    */
/* ------------------------------------------------------------------ */

server.registerTool(
  'search_moments',
  {
    title: 'Search moments',
    description:
      'Natural-language any-to-video search across the whole catalog (TwelveLabs Marengo). Returns ranked clips with itemId, title, start/end seconds and a thumbnail when available. Use for "find every moment with X", then pass start/end to clips_generate or a player.',
    inputSchema: {
      query: z.string().min(1).describe('What to look for, in plain language (visual and audio)'),
      modalities: z.array(z.enum(['visual', 'audio', 'transcription'])).optional(),
      limit: z.number().int().min(1).max(50).optional(),
      pageToken: z.string().optional().describe('From a previous result to fetch the next page'),
    },
  },
  async ({ query, modalities, limit, pageToken }) =>
    guard(async () => {
      const r = await api.post<SearchResponse>('/search', { query, modalities, limit: limit ?? 12, pageToken });
      return ok(
        `${r.hits.length} moment(s) for "${query}" across ${r.pool.items} title(s)` + (r.hits[0] ? `; top: ${r.hits[0].title} ${hms(r.hits[0].start)}–${hms(r.hits[0].end)}` : ''),
        { hits: r.hits.map((h) => ({ ...h, timecode: `${hms(h.start)}–${hms(h.end)}` })), nextPageToken: r.nextPageToken, pool: r.pool },
      );
    }),
);

server.registerTool(
  'similar_titles',
  {
    title: 'Similar titles',
    description: 'Titles most similar to a given item by fingerprint embedding (Marengo) blended with shared genres/moods/themes. Each result says why it matched.',
    inputSchema: { itemId: z.string(), limit: z.number().int().min(1).max(20).optional() },
  },
  async ({ itemId, limit }) =>
    guard(async () => {
      const r = await api.get<SimilarTitle[]>(`/catalog/${encodeURIComponent(itemId)}/similar`, { limit: limit ?? 8 });
      return ok(`${r.length} similar title(s): ${r.map((s) => `${s.title} (${s.score.toFixed(2)})`).join(', ')}`, r);
    }),
);

/* ------------------------------------------------------------------ */
/* Tools: intelligence sections                                        */
/* ------------------------------------------------------------------ */

server.registerTool(
  'fingerprint_get',
  {
    title: 'Fingerprint',
    description: 'Title-level fingerprint from Pegasus: genres, keywords, moods, mood tags, themes (each label → probability), characters with prominence, pacing, language, suggested rating, synopsis short/long with translations.',
    inputSchema: { itemId: z.string(), languages: z.array(z.string()).optional().describe('Only these ISO-639-1 translations (default: all)') },
  },
  async ({ itemId, languages }) =>
    guard(async () => {
      const fp = await api.get<Fingerprint>(`/catalog/${encodeURIComponent(itemId)}/fingerprint`);
      const out = fingerprintSummary(fp);
      if (languages && out.synopsis.translations) {
        out.synopsis = { ...out.synopsis, translations: Object.fromEntries(Object.entries(out.synopsis.translations).filter(([k]) => languages.includes(k))) };
      }
      return ok(`Genres ${labelNames(fp.genres, 3).join('/')}; moods ${labelNames(fp.moods, 3).join('/')}; rating ${fp.audienceRating.suggested}; ${Object.keys(fp.synopsis.translations ?? {}).length} translations`, out);
    }),
);

server.registerTool(
  'emotion_arc_get',
  {
    title: 'Emotion arc',
    description: 'Continuous emotional arc: samples over time with valence (-1..1), arousal (0..1), dominance (0..1), discrete emotions and a beat description; plus narrative acts and the climax. `resolution` downsamples to at most N samples.',
    inputSchema: { itemId: z.string(), resolution: z.number().int().min(4).max(120).optional() },
  },
  async ({ itemId, resolution }) =>
    guard(async () => {
      const arc = await api.get<EmotionArc>(`/catalog/${encodeURIComponent(itemId)}/emotions`);
      const samples = downsample(arc.samples, resolution ?? 40);
      const peak = arc.samples.reduce((m, s) => (s.arousal > m.arousal ? s : m), arc.samples[0]!);
      return ok(`${arc.samples.length} samples, ${arc.acts.length} acts; climax at ${hms(arc.climax?.at)}; peak arousal ${peak.arousal.toFixed(2)} at ${hms(peak.start)} ("${peak.beat}")`, { ...arc, samples });
    }),
);

server.registerTool(
  'markers_get',
  {
    title: 'Markers',
    description: 'Structural markers with frame accuracy and confidence: cold_open, recap, intro, title_card, chapter, credits, post_credits, next_episode_hook, preview. Use for skip-intro, skip-recap, chapters and next-episode prompts.',
    inputSchema: { itemId: z.string(), kinds: z.array(z.string()).optional().describe('Filter to these marker kinds') },
  },
  async ({ itemId, kinds }) =>
    guard(async () => {
      const ms = await api.get<MarkerSet>(`/catalog/${encodeURIComponent(itemId)}/markers`);
      const markers = kinds ? ms.markers.filter((m) => kinds.includes(m.kind)) : ms.markers;
      const credits = ms.markers.find((m) => m.kind === 'credits');
      return ok(`${markers.length} marker(s)` + (credits ? `; credits start ${hms(credits.start)}` : ''), { ...ms, markers });
    }),
);

server.registerTool(
  'safety_report',
  {
    title: 'Safety report',
    description: 'Timestamped content-safety segments (nudity, sexual_content, violence, gore, profanity, drugs, alcohol, tobacco, weapons, hate, self_harm, flashing_lights) with severity and confidence, plus a per-category rollup for ratings and brand safety.',
    inputSchema: { itemId: z.string(), minSeverity: z.enum(['low', 'medium', 'high']).optional() },
  },
  async ({ itemId, minSeverity }) =>
    guard(async () => {
      const r = await api.get<SafetyReport>(`/catalog/${encodeURIComponent(itemId)}/safety`);
      const order = { low: 0, medium: 1, high: 2 } as const;
      const segments = minSeverity ? r.segments.filter((s) => order[s.severity] >= order[minSeverity]) : r.segments;
      return ok(`${segments.length} segment(s); categories: ${Object.keys(r.summary).join(', ') || 'none'}`, { ...r, segments });
    }),
);

/* ------------------------------------------------------------------ */
/* Tools: ad operations                                                */
/* ------------------------------------------------------------------ */

server.registerTool(
  'adbreaks_plan',
  {
    title: 'Plan ad breaks',
    description:
      'Return the ad-break plan for a title, optionally re-planning deterministically with a new policy (no model call): target number of breaks, minimum spacing, fences at start/end. Breaks are windows (not points), ranked, with confidence, the emotional state entering the break, keywords, IAB categories and brand-safety flags. Approved breaks keep their review state across re-plans.',
    inputSchema: {
      itemId: z.string(),
      targetBreaks: z.number().int().min(1).max(12).optional(),
      minSpacingSec: z.number().min(30).optional(),
      avoidFirstSec: z.number().min(0).optional(),
      avoidLastSec: z.number().min(0).optional(),
    },
  },
  async ({ itemId, ...policy }) =>
    guard(async () => {
      const replan = Object.values(policy).some((v) => v !== undefined);
      const plan = replan
        ? await api.post<AdBreakPlan>(`/catalog/${encodeURIComponent(itemId)}/adbreaks/plan`, policy)
        : await api.get<AdBreakPlan>(`/catalog/${encodeURIComponent(itemId)}/adbreaks`);
      return ok(
        `${plan.breaks.length} break(s) ${replan ? 're-planned' : 'planned'}: ${plan.breaks.map((b) => `#${b.rank} ${hms(b.at)} (${b.confidence.toFixed(2)}${b.brandSafety.suitable ? '' : ', unsuitable'})`).join(', ')}`,
        { policy: plan.policy, breaks: plan.breaks.map(breakSummary) },
      );
    }),
);

server.registerTool(
  'adbreaks_review',
  {
    title: 'Review ad break',
    description: 'Approve, decline or rate one ad break and optionally add a comment. Only approved breaks are exported to VMAP/SCTE-35.',
    inputSchema: {
      itemId: z.string(),
      breakId: z.string(),
      status: z.enum(['open', 'approved', 'declined']).optional(),
      rating: z.number().int().min(0).max(5).optional(),
      comment: z.string().optional(),
      reviewedBy: z.string().optional().describe('Reviewer name (default: agent)'),
    },
  },
  async ({ itemId, breakId, status, rating, comment, reviewedBy }) =>
    guard(async () => {
      const patch: Partial<ReviewState> = { status, rating: rating as ReviewState['rating'], reviewedBy: reviewedBy ?? 'agent' };
      if (comment) patch.comments = [{ id: '', author: reviewedBy ?? 'agent', text: comment, at: '' }];
      const b = await api.patch<AdBreak>(`/catalog/${encodeURIComponent(itemId)}/adbreaks/${encodeURIComponent(breakId)}`, patch);
      return ok(`Break #${b.rank} at ${hms(b.at)} is now ${b.review?.status}${b.review?.rating !== undefined ? `, rated ${b.review.rating}/5` : ''}`, breakSummary(b));
    }),
);

server.registerTool(
  'markers_review',
  {
    title: 'Review marker',
    description: 'Approve or decline a structural marker (intro, credits, chapter…), with optional rating and comment.',
    inputSchema: {
      itemId: z.string(),
      markerId: z.string(),
      status: z.enum(['open', 'approved', 'declined']).optional(),
      rating: z.number().int().min(0).max(5).optional(),
      comment: z.string().optional(),
    },
  },
  async ({ itemId, markerId, status, rating, comment }) =>
    guard(async () => {
      const patch: Partial<ReviewState> = { status, rating: rating as ReviewState['rating'], reviewedBy: 'agent' };
      if (comment) patch.comments = [{ id: '', author: 'agent', text: comment, at: '' }];
      const m = await api.patch<MarkerSet['markers'][number]>(`/catalog/${encodeURIComponent(itemId)}/markers/${encodeURIComponent(markerId)}`, patch);
      return ok(`${m.kind} "${m.label ?? ''}" ${hms(m.start)}–${hms(m.end)} is now ${m.review?.status}`, m);
    }),
);

server.registerTool(
  'export_vmap',
  {
    title: 'Export VMAP',
    description: 'VMAP 1.0 XML of the approved ad breaks (pass all=true to include every planned break). Optional pre-roll / post-roll. Feed this to an SSAI or player ad scheduler.',
    inputSchema: { itemId: z.string(), all: z.boolean().optional(), preroll: z.boolean().optional(), postroll: z.boolean().optional(), durationSec: z.number().optional().describe('Break duration in seconds (default 30)') },
  },
  async ({ itemId, all, preroll, postroll, durationSec }) =>
    guard(async () => {
      const xml = await api.getText(`/catalog/${encodeURIComponent(itemId)}/export/vmap`, { all: all ? 1 : undefined, preroll: preroll ? 1 : undefined, postroll: postroll ? 1 : undefined, duration: durationSec });
      const n = (xml.match(/<vmap:AdBreak\b/g) ?? []).length;
      return ok(`VMAP with ${n} ad break(s)`, xml);
    }),
);

server.registerTool(
  'export_scte35',
  {
    title: 'Export SCTE-35 splice list',
    description: 'JSON list of splice points (pts_time at 90kHz, splice_time_sec, duration) for the approved breaks, ready for an SCTE-35 injector.',
    inputSchema: { itemId: z.string(), all: z.boolean().optional() },
  },
  async ({ itemId, all }) =>
    guard(async () => {
      const r = await api.get<{ splices: unknown[] }>(`/catalog/${encodeURIComponent(itemId)}/export/scte35`, { all: all ? 1 : undefined });
      return ok(`${r.splices.length} splice point(s)`, r);
    }),
);

server.registerTool(
  'export_markers',
  {
    title: 'Export player markers',
    description: 'Player-ready markers JSON: skipIntro, skipRecap, creditsStart, nextEpisodeAt, chapters. Drop into a player config or a CMS.',
    inputSchema: { itemId: z.string() },
  },
  async ({ itemId }) =>
    guard(async () => {
      const r = await api.get<Record<string, unknown>>(`/catalog/${encodeURIComponent(itemId)}/export/markers`);
      return ok('Player markers', r);
    }),
);

/* ------------------------------------------------------------------ */
/* Tools: ad creatives + stitched previews                             */
/* ------------------------------------------------------------------ */

server.registerTool(
  'ads_list',
  {
    title: 'List ad creatives',
    description: 'All ad creatives in the library (name, advertiser, duration, dimensions, where the media comes from). Creatives are assigned to ad breaks with adbreaks_assign_creative and burned into previews with stitch_preview.',
    inputSchema: {},
  },
  async () =>
    guard(async () => {
      const ads = await api.get<AdCreative[]>('/ads');
      return ok(`${ads.length} creative(s): ${ads.map((a) => `${a.name} (${hms(a.durationSec)}) [${a.id}]`).join('; ') || 'none'}`, ads.map(creativeSummary));
    }),
);

server.registerTool(
  'ads_add',
  {
    title: 'Add ad creative',
    description:
      'Add an ad creative from a public URL (sourceUrl) or a file on the API host (localPath, absolute path or file:// URL). Local files are ffprobed for duration and dimensions; for URLs pass durationSec if known. Returns the creative id to use with adbreaks_assign_creative.',
    inputSchema: {
      name: z.string().min(1).describe('Creative name, e.g. "Kinder Bueno 30s"'),
      sourceUrl: z.string().optional().describe('Public http(s) URL of the MP4'),
      localPath: z.string().optional().describe('Absolute path of the MP4 on the API host'),
      advertiser: z.string().optional(),
      durationSec: z.number().positive().optional().describe('Known duration (used for URL creatives that cannot be probed)'),
    },
  },
  async ({ name, sourceUrl, localPath, advertiser, durationSec }) =>
    guard(async () => {
      if (!sourceUrl && !localPath) throw new Error('Provide sourceUrl or localPath');
      const ad = await api.post<AdCreative>('/ads', { name, sourceUrl, localPath, advertiser, durationSec });
      return ok(`Added "${ad.name}" (${hms(ad.durationSec)}${ad.width ? `, ${ad.width}x${ad.height}` : ''}) → ${ad.id}`, creativeSummary(ad));
    }),
);

server.registerTool(
  'ads_fingerprint',
  {
    title: 'Fingerprint an ad creative',
    description:
      'Creative intelligence for one ad spot with a single Pegasus call: brand, product, tagline, mood, keywords, tone, IAB categories, sensitivities (alcohol, weapons…), family-safety and key moments. Uploads the creative to TwelveLabs first when it only exists locally. Needed before adbreaks_fit / adbreaks_autoassign can score it.',
    inputSchema: { creativeId: z.string().describe('Creative id from ads_list / ads_add') },
  },
  async ({ creativeId }) =>
    guard(async () => {
      const ad = await api.post<AdCreative & { _meta?: { model: string; ms: number } }>(`/ads/${encodeURIComponent(creativeId)}/fingerprint`, {});
      const fp = ad.fingerprint!;
      return ok(`${ad.name}: ${fp.brand} · ${fp.product} · mood ${labelNames(fp.mood, 3).join(', ')} · familySafe ${fp.familySafe} (${ad._meta?.model ?? fp.model}, ${ad._meta?.ms ?? '?'} ms)`, creativeSummary(ad));
    }),
);

server.registerTool(
  'adbreaks_fit',
  {
    title: 'Creative fit per ad break',
    description:
      'Rank every ad creative against each planned break of a title. Fit (0..1) blends mood, keyword and IAB agreement between the creative and the scenes around the cut, plus brand-safety agreement; each score comes with the overlaps that produced it. Deterministic, no model call. Creatives without a fingerprint score 0.',
    inputSchema: { itemId: z.string() },
  },
  async ({ itemId }) =>
    guard(async () => {
      const r = await api.get<{ itemId: string; creatives: Array<{ id: string; name: string; fingerprinted: boolean }>; breaks: Array<{ breakId: string; at: number; rank: number; assigned?: string; fits: CreativeFit[] }> }>(
        `/catalog/${encodeURIComponent(itemId)}/adbreaks/fit`,
      );
      const lines = r.breaks.map((b) => `#${b.rank} ${hms(b.at)} → ${b.fits[0] ? `${b.fits[0].creativeId} ${b.fits[0].score}` : 'no creatives'}${b.assigned ? ` (assigned: ${b.assigned})` : ''}`);
      return ok(lines.join('\n'), { creatives: r.creatives, breaks: r.breaks.map((b) => ({ breakId: b.breakId, at: b.at, rank: b.rank, assigned: b.assigned, fits: b.fits.map(fitSummary) })) });
    }),
);

server.registerTool(
  'adbreaks_autoassign',
  {
    title: 'Auto-assign best-fit creatives',
    description: 'Assign the best-fitting fingerprinted creative to each planned break of a title (only breaks whose best fit reaches minScore). Returns the plan and the per-break pick with its explanation.',
    inputSchema: {
      itemId: z.string(),
      minScore: z.number().min(0).max(1).optional().describe('Leave a break unassigned when its best fit is below this (default 0)'),
      breakIds: z.array(z.string()).optional().describe('Only these breaks (default: every planned break)'),
    },
  },
  async ({ itemId, minScore, breakIds }) =>
    guard(async () => {
      const r = await api.post<{ plan: AdBreakPlan; assignments: Array<{ breakId: string; creativeId?: string; fit?: CreativeFit }> }>(`/catalog/${encodeURIComponent(itemId)}/adbreaks/autoassign`, { minScore, breakIds });
      const done = r.assignments.filter((a) => a.creativeId);
      return ok(`${done.length}/${r.assignments.length} break(s) assigned by fit`, { assignments: r.assignments.map((a) => ({ breakId: a.breakId, creativeId: a.creativeId, fit: a.fit ? fitSummary(a.fit) : undefined })), breaks: r.plan.breaks.map(breakSummary) });
    }),
);

server.registerTool(
  'adbreaks_assign_creative',
  {
    title: 'Assign creative to ad breaks',
    description: 'Assign an ad creative to the planned breaks of a title (all breaks by default, or only breakIds). Pass creativeId null to clear. Assigned creatives appear as inline VAST in export_vmap and are used by stitch_preview.',
    inputSchema: {
      itemId: z.string(),
      creativeId: z.string().nullable().describe('Creative id from ads_list / ads_add; null clears the assignment'),
      breakIds: z.array(z.string()).optional().describe('Only these breaks (default: every planned break)'),
    },
  },
  async ({ itemId, creativeId, breakIds }) =>
    guard(async () => {
      const plan = await api.post<AdBreakPlan>(`/catalog/${encodeURIComponent(itemId)}/adbreaks/assign`, { creativeId, breakIds });
      const assigned = plan.breaks.filter((b) => b.creativeId);
      return ok(
        creativeId ? `${assigned.length}/${plan.breaks.length} break(s) now carry ${creativeId}` : `Cleared creatives on ${breakIds ? breakIds.length : plan.breaks.length} break(s)`,
        { breaks: plan.breaks.map(breakSummary) },
      );
    }),
);

server.registerTool(
  'stitch_preview',
  {
    title: 'Render stitched preview',
    description:
      'Render an MP4 of a title with the ad creative burned in at its ad breaks (approved breaks by default; includeUnapproved uses every planned break when none is approved). Each break is snapped to the nearest keyframe inside its window so the movie is stream-copied, not re-encoded. Requires the title to have been ingested from a local file and ffmpeg on the API host. Polls up to waitSec and returns the job with insertions (requestedAt/snappedAt) and the outputUrl of the render.',
    inputSchema: {
      itemId: z.string(),
      creativeId: z.string().optional().describe('Defaults to the creative assigned to the breaks'),
      breakIds: z.array(z.string()).optional().describe('Only these breaks'),
      includeUnapproved: z.boolean().optional(),
      waitSec: z.number().int().min(0).max(900).optional().describe('Poll until ready/failed, at most this many seconds (default 300)'),
    },
  },
  async ({ itemId, creativeId, breakIds, includeUnapproved, waitSec }) =>
    guard(async () => {
      let job = await api.post<StitchJob>(`/catalog/${encodeURIComponent(itemId)}/stitch`, { creativeId, breakIds, includeUnapproved });
      const deadline = Date.now() + (waitSec ?? 300) * 1000;
      while ((job.status === 'queued' || job.status === 'running') && Date.now() < deadline) {
        await sleep(1500);
        job = await api.get<StitchJob>(`/stitch/${encodeURIComponent(job.id)}`);
      }
      const summary =
        job.status === 'ready'
          ? `Stitched preview ready: ${job.insertions.length} ad break(s) at ${job.insertions.map((i) => hms(i.snappedAt)).join(', ')} (${hms(job.durationSec)} total) → ${api.baseUrl}${job.outputUrl}`
          : job.status === 'failed'
            ? `Stitch failed: ${job.error}`
            : `Stitch still ${job.status} after ${waitSec ?? 300}s; poll GET /api/stitch/${job.id}`;
      return ok(summary, stitchSummary(job));
    }),
);

/* ------------------------------------------------------------------ */
/* Tools: creative                                                     */
/* ------------------------------------------------------------------ */

async function runRecipe(recipe: Omit<Recipe, 'id' | 'createdAt'>, itemId: string, waitSec: number): Promise<CreativeRun> {
  const created = await api.post<Recipe>('/recipes', recipe);
  const [run] = await api.post<CreativeRun[]>(`/recipes/${created.id}/run`, { itemIds: [itemId] });
  const deadline = Date.now() + waitSec * 1000;
  let current = run!;
  while ((current.status === 'queued' || current.status === 'running') && Date.now() < deadline) {
    await sleep(1500);
    current = await api.get<CreativeRun>(`/runs/${current.id}`);
  }
  return current;
}

server.registerTool(
  'thumbnails_generate',
  {
    title: 'Generate thumbnails',
    description:
      'Pick thumbnail frames for a title from a free-text creative brief (e.g. "hero shot of the dragon, dramatic lighting"). Each candidate has a timestamp, composite score with factor breakdown (relevance, aesthetics, face prominence, stillness, brightness, safe area), crops for 16:9 / 2:3 / 1:1 / 9:16, a logo-safe zone and a caption. Waits up to waitSec for the run.',
    inputSchema: {
      itemId: z.string(),
      brief: z.string().describe('Creative brief, free text'),
      count: z.number().int().min(1).max(24).optional(),
      formats: z.array(z.enum(['16:9', '2:3', '1:1', '9:16'])).optional(),
      requireCharacters: z.array(z.string()).optional(),
      waitSec: z.number().int().min(0).max(600).optional(),
    },
  },
  async ({ itemId, brief, count, formats, requireCharacters, waitSec }) =>
    guard(async () => {
      const run = await runRecipe({ name: `agent: ${brief.slice(0, 40)}`, target: 'thumbnails', brief, count: count ?? 8, formats: formats ?? ['16:9', '2:3', '9:16'], requireCharacters }, itemId, waitSec ?? 120);
      const thumbs = run.thumbnails ?? [];
      return ok(`Run ${run.status}: ${thumbs.length} thumbnail(s)` + (thumbs[0] ? `; best at ${hms(thumbs[0].at)} (score ${thumbs[0].score.toFixed(2)}) "${thumbs[0].caption}"` : ''), { runId: run.id, status: run.status, thumbnails: thumbs });
    }),
);

server.registerTool(
  'clips_generate',
  {
    title: 'Generate preview clips',
    description:
      'Cut preview clips for a title from a free-text brief (e.g. "three 15-second vertical cuts of the chase"). Each clip has start/end, type, relevance, mood, keywords, a safety flag, a 9:16 reframe path (subject x-centre keyframes) and a poster frame. Waits up to waitSec for the run.',
    inputSchema: {
      itemId: z.string(),
      brief: z.string(),
      count: z.number().int().min(1).max(12).optional(),
      minLengthSec: z.number().min(3).optional(),
      maxLengthSec: z.number().min(5).optional(),
      formats: z.array(z.enum(['16:9', '2:3', '1:1', '9:16'])).optional(),
      waitSec: z.number().int().min(0).max(600).optional(),
    },
  },
  async ({ itemId, brief, count, minLengthSec, maxLengthSec, formats, waitSec }) =>
    guard(async () => {
      const run = await runRecipe(
        { name: `agent: ${brief.slice(0, 40)}`, target: 'clips', brief, count: count ?? 4, clipLengthSec: [minLengthSec ?? 10, maxLengthSec ?? 30], formats: formats ?? ['16:9', '9:16'] },
        itemId,
        waitSec ?? 120,
      );
      const clips = run.clips ?? [];
      return ok(`Run ${run.status}: ${clips.length} clip(s)` + (clips[0] ? `; first ${hms(clips[0].start)}–${hms(clips[0].end)} "${clips[0].caption}"` : ''), { runId: run.id, status: run.status, clips });
    }),
);

/* ------------------------------------------------------------------ */
/* Tools: editorial                                                    */
/* ------------------------------------------------------------------ */

const ruleSchema = z.object({
  facet: z.enum(['genres', 'keywords', 'moods', 'moodTags', 'themes']),
  label: z.string(),
  min: z.number().min(0).max(1).default(0.5),
  max: z.number().min(0).max(1).default(1),
});

server.registerTool(
  'smartlist_create',
  {
    title: 'Create smart list',
    description:
      'Create an editorial list: either rule-based (facet + label + confidence range, all rules must match) or from a natural-language query (embedding similarity across the catalog). Returns the materialised item ids and coverage.',
    inputSchema: {
      name: z.string(),
      description: z.string().optional(),
      rules: z.array(ruleSchema).optional().describe('Rule-based list'),
      query: z.string().optional().describe('Natural-language list, e.g. "quiet melancholic stories about loss"'),
    },
  },
  async ({ name, description, rules, query }) =>
    guard(async () => {
      if (!rules?.length && !query) throw new Error('Provide rules or a query');
      const body = { name, description, source: query ? 'query' : 'rules', rules: rules as SmartListRule[] | undefined, query };
      const list = await api.post<SmartList>('/lists', body);
      return ok(`List "${list.name}" → ${list.itemIds.length} title(s) (${Math.round((list.coverage ?? 0) * 100)}% of catalog)`, list);
    }),
);

server.registerTool(
  'smartlists_list',
  { title: 'List smart lists', description: 'All saved editorial lists with their item ids and coverage.', inputSchema: {} },
  async () =>
    guard(async () => {
      const lists = await api.get<SmartList[]>('/lists');
      return ok(`${lists.length} list(s): ${lists.map((l) => `${l.name} (${l.itemIds.length})`).join(', ')}`, lists);
    }),
);

server.registerTool(
  'curate_catalog',
  {
    title: 'AI curation',
    description: 'Cluster the whole catalog by fingerprint embedding and label each cluster from its shared moods/keywords, producing ready-made editorial rails. Returns the generated lists.',
    inputSchema: {},
  },
  async () =>
    guard(async () => {
      const lists = await api.post<SmartList[]>('/lists/curate', {});
      return ok(`${lists.length} curated list(s): ${lists.map((l) => `${l.name} (${l.itemIds.length})`).join(', ')}`, lists);
    }),
);

/* ------------------------------------------------------------------ */
/* Resources                                                           */
/* ------------------------------------------------------------------ */

server.registerResource(
  'catalog',
  'twelve://catalog',
  { title: 'Catalog', description: 'All titles with enrichment status and fingerprint summary', mimeType: 'application/json' },
  async (uri) => {
    const items = await api.get<CatalogItem[]>('/catalog');
    return { contents: [{ uri: uri.href, mimeType: 'application/json', text: JSON.stringify(tidy(items.map(itemSummary)), null, 2) }] };
  },
);

server.registerResource(
  'item',
  new ResourceTemplate('twelve://item/{id}', {
    list: async () => {
      const items = await api.get<CatalogItem[]>('/catalog');
      return { resources: items.map((i) => ({ uri: `twelve://item/${i.id}`, name: i.title, description: i.fingerprint?.synopsis.short, mimeType: 'application/json' })) };
    },
  }),
  { title: 'Title bundle', description: 'Summary bundle for one title (fingerprint, acts, markers, breaks, safety rollup)', mimeType: 'application/json' },
  async (uri, { id }) => {
    const b = await api.get<ItemBundle>(`/catalog/${encodeURIComponent(String(id))}`);
    const body = {
      item: itemSummary(b.item),
      fingerprint: b.fingerprint ? fingerprintSummary(b.fingerprint) : undefined,
      acts: b.emotions?.acts,
      markers: b.markers?.markers,
      adBreaks: b.adBreaks?.breaks.map(breakSummary),
      safetySummary: b.safety?.summary,
    };
    return { contents: [{ uri: uri.href, mimeType: 'application/json', text: JSON.stringify(tidy(body), null, 2) }] };
  },
);

/* ------------------------------------------------------------------ */
/* Prompts                                                             */
/* ------------------------------------------------------------------ */

server.registerPrompt(
  'editorial_brief',
  {
    title: 'Editorial programming brief',
    description: 'Write a programming brief for a title from its fingerprint and emotional arc.',
    argsSchema: { itemId: z.string().describe('Catalog item id') },
  },
  ({ itemId }) => ({
    messages: [
      {
        role: 'user',
        content: {
          type: 'text',
          text: [
            `You are a senior content programmer at a streaming service. Using the Twelve Studio tools, call fingerprint_get and emotion_arc_get for item "${itemId}" (and similar_titles for context).`,
            'Then write a one-page programming brief: (1) a 2-line positioning statement; (2) three audience segments it will resonate with, each tied to specific mood tags and themes with their confidences; (3) which rails/collections it belongs in and why; (4) the emotional shape of the title in three sentences, citing the acts and the climax timestamp; (5) tone-matched thumbnail and preview-clip guidance (which beats to show, which to avoid); (6) suggested rating and any compliance notes from the safety report.',
            'Quote probabilities as written (e.g. "melancholic 0.84"). Do not invent facts that the tools did not return.',
          ].join('\n'),
        },
      },
    ],
  }),
);

server.registerPrompt(
  'ad_ops_review',
  {
    title: 'Ad-ops break review',
    description: 'Review the ad-break plan of a title against brand safety and the emotional arc, then recommend approvals.',
    argsSchema: { itemId: z.string().describe('Catalog item id'), targetBreaks: z.string().optional().describe('Desired number of breaks (integer as text)') },
  },
  ({ itemId, targetBreaks }) => ({
    messages: [
      {
        role: 'user',
        content: {
          type: 'text',
          text: [
            `You are an ad-operations lead. For item "${itemId}", call adbreaks_plan${targetBreaks ? ` with targetBreaks=${targetBreaks}` : ''}, safety_report (minSeverity medium) and emotion_arc_get.`,
            'For each planned break: state the timecode and window, whether it sits on a falling or flat arousal slope, whether any medium/high safety segment lies within 60 seconds, the contextual IAB categories advertisers could buy against, and the mood entering the break (so creative can be tone-matched).',
            'Recommend approve / decline / move for each break with a one-line reason. Apply your recommendations with adbreaks_review, then call export_vmap and show the VMAP.',
            'Never approve a break inside a rising action beat or within 45 seconds of a high-severity safety segment.',
          ].join('\n'),
        },
      },
    ],
  }),
);

/* ------------------------------------------------------------------ */

const transport = new StdioServerTransport();
await server.connect(transport);
process.stderr.write(`twelve-studio-mcp ${pkg.version} ready (API ${api.baseUrl})\n`);
