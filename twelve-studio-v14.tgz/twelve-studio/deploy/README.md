# Putting SGEUL on sgeul.com

There are two ways to host it. Pick one.

## Option A: full app (recommended for the CEO demo)

What you get: the web app, the REST API, TwelveLabs live enrichment, asset sync, stitched previews, and the MCP
server all from one Node process behind nginx. Needs a Linux VM (1 vCPU / 2 GB is fine; more for renders).

1. Copy `twelve-studio-v14.tgz` and this `deploy/` folder to the server.
2. `sudo bash deploy/install.sh twelve-studio-v14.tgz` (installs Node 22, nginx, ffmpeg; unpacks to /opt/sgeul; runs it as a service).
3. Edit `/opt/sgeul/twelve-studio/.env`: put your TwelveLabs key in `TWELVELABS_API_KEY` and set `BASIC_AUTH=user:password`.
   With a key set and no BASIC_AUTH, anyone who finds the site can spend your TwelveLabs credit. Health stays open at /api/health.
4. `sudo systemctl restart sgeul`, then `sudo certbot --nginx -d sgeul.com -d www.sgeul.com` for TLS.
5. Copy the demo media into `/var/lib/sgeul/media` if you want "Render preview" to work on the server:
   `DavidandGoliath1960.mp4`, `Kinder Bueno - 30 second - ad.mp4`, `Kinder Bueno - 10second - ad.mp4`, `grok4.mp4`.
6. Open https://sgeul.com. Settings shows mode: live and the account asset count.

Logs: `journalctl -u sgeul -f`. Data lives in `/var/lib/sgeul` (store.json, renders). Upgrade: unpack a newer tgz over
/opt/sgeul, `npm ci --omit=dev --ignore-scripts`, `systemctl restart sgeul`; the store is kept and new seed titles import on boot.

MCP for agents on the same host: `TWELVE_API_URL=http://127.0.0.1:8787 node apps/mcp/dist/server.js`
(add `Authorization: Basic ...` via `TWELVE_API_AUTH=user:password` if BASIC_AUTH is on).

### File uploads (v14)

Editorial → Add assets → **From file** uploads straight from the browser to a bucket in resumable 64 MB parts, then
TwelveLabs pulls the file by a signed URL. Nothing passes through Node or nginx (no 2 GB body limit), a dropped
connection only retries the part in flight, and closing the tab and re-adding the same file resumes. If a TwelveLabs
asset fails or stalls past the 45 minute poll, ingest resubmits it once from the bucket.

1. In the DigitalOcean control panel: **Spaces Object Storage → Access Keys → Create Access Key**. Give it read/write/delete
   on all buckets (so setup can create the bucket), or create the bucket yourself first (`sgeul-media`, region `nyc3`,
   File Listing: Restricted) and limit the key to it.
2. Put the values in `/opt/sgeul/twelve-studio/.env`: `S3_ENDPOINT=https://nyc3.digitaloceanspaces.com`, `S3_REGION=nyc3`,
   `S3_BUCKET=sgeul-media`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`.
3. Run the setup once. It creates the bucket if missing (private), sets CORS (PUT/GET/HEAD from sgeul.com, exposes ETag),
   adds a lifecycle rule that aborts unfinished uploads after 7 days, then verifies everything with a real test upload:

   ```bash
   cd /opt/sgeul/twelve-studio && sudo -u sgeul node deploy/spaces-setup.mjs --origin https://sgeul.com --origin https://www.sgeul.com
   sudo systemctl restart sgeul
   ```

   `--dry-run` prints what it would apply. The key is read from `.env` and never printed. The boot log then shows
   `uploads=sgeul-media via https://nyc3.digitaloceanspaces.com`; without the S3_* values the tab stays hidden.

Limit is 4 GB per file (TwelveLabs URL ingest cap). Transcode larger masters to a mezzanine first.

## Option B: static demo only (any web host, no Node)

Upload `static/index.html` to the web root (cPanel, S3 + CloudFront, Netlify, GitHub Pages, all fine). It is the whole
demo in one 1.6 MB file: every screen, all five titles, both creatives, creative fit, exports. It runs on captured
TwelveLabs output, so nothing costs money and nothing can be modified by visitors. Video playback uses the TwelveLabs
CDN HLS streams; "Render preview" and "Fingerprint" show a message that they need the local API.

You can also run both: Option A at https://sgeul.com and the static file at https://sgeul.com/demo/ by adding
`location /demo/ { alias /var/www/sgeul/; try_files $uri /demo/index.html; }` to the nginx config.

## Ports and firewall

Only 80 and 443 need to be open. Node listens on 127.0.0.1:8787 (HOST in .env); nginx proxies to it with buffering
off so the live job feed (Server-Sent Events) streams.
